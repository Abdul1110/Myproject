export const environment = {
  production: true,
  appSettings: {
    region: 'us',
    locale: 'en-US',
    environment: 'us-test',
    apiBaseUrl: 'https://api-refresh-test.lawconnect.com/api/',

    legacyEndpoint: 'https://app-legacy.test.lawconnect.com',
    orionEndpoint: 'https://app.refresh.test.lawconnect.com',
    authClientId: 'kRlkbMSAxAoSVmIFP5ObeGjBqqjcpH7k',
    authDomain: 'authtest.lawconnect.com.au',
    authAudience: 'https://api-test.lawconnect.com.au/',
    authCallback: 'https://app.refresh.test.lawconnect.com/account/callback',
    sessionTTL: 480, //in minutes
    rememberMeSessionTTL: 10080, //in minutes -  timeout if user chooses remember me, session timeout to be 7 days

    pubnubSubscriberKey: 'sub-c-fcde0c20-7e23-11e6-ab81-02ee2ddab7fe',
    pubnubPublisherKey: 'pub-c-591bc1c2-ab3e-4cbe-9aed-e3c514c5d57a',

    leapDomainUrl: 'https://matter.test.lawconnect.com',
    lcIntegratorApiUrl: 'https://lcintegrator-refresh-test.leapaws.com',
    description: 'us-test',
    uploadFileSizeLimit: 120,
    aboutUrl: 'https://lawconnect.com/',

    privacyUrl: 'https://lawconnect.com/terms-and-conditions.html',
    previewFileSizeLimit: 51200 //value in KB = 50MB
  },
  config: {
    logs: {
      // required config
      collector:
        'ZaVnC4dhaV0RrbnjUJbRUJM5qlKPBW33YPpcTn0SPNMmrX1G_1xat9kJFCqGdwKtuNmMKPtB0EAF0iRGuvw24vZ2JAjVteMlAagaP6dHzhO1uCOs0nG7Mw==',
      // optional config
      endpoint: 'https://collectors.au.sumologic.com/receiver/v1/http/',
      level: 'error'
    },
    support: {
      feedbackUrl: 'https://uxform.typeform.com/to',
      feedbackCode: 'yOYOgc',
      communityUrl: 'https://community.lawconnect.com/s/'
    }
  },
  locale: {
    global: {
      menu: {
        matters: {
          title: 'Select Cases',
          icon: 'cases'
        },
        recents: {
          title: 'Recent',
          icon: 'recent'
        },
        firms: {
          title: 'Firms'
        },
        documents: {
          title: 'Documents',
          icon: 'files'
        },
        signatures: {
          title: 'Signature Requests',
          icon: 'signature'
        },
        collaborations: {
          title: 'Collaboration',
          icon: 'users-outline'
        },
        correspondence: {
          title: 'Correspondence',
          icon: 'correspondence'
        },
        billing: {
          title: 'Billing & Statements',
          icon: 'creditcard'
        },
        trust: {
          title: 'Trust',
          icon: 'creditcard'
        },
        apps: {
          title: 'App Store',
          icon: 'apps'
        },
        support: {
          title: 'Help',
          icon: 'support'
        },
        feedback: {
          title: 'Feedback',
          icon: 'feedback'
        },
        resources: {
          title: 'Resources',
          icon: 'resources'
        }
      },
      currency: {
        code: 'USD',
        symbol: '$'
      },
      side_menu: {
        details: 'Details',
        attachments: 'Attachments',
        comments: 'Comments'
      }
    },
    matters: {
      select: {
        title: 'Select Case',
        document: 'document',
        documents: 'documents'
      },
      title: 'All Cases',
      upload: {
        navigation_away_warning: 'There are still items to be uploaded. Are you sure you want to leave this page?',
        cancel_warning: 'There are still items to be uploaded. Are you sure you want to cancel?'
      }
    },
    recents: {
      title: 'Recent',
      document_header: 'Documents',
      notification_header: 'Unread Notifications'
    },
    firms: {
      title: 'Firms'
    },
    document_actions: {
      delete: {
        title: 'Delete Document',
        message: 'Are you sure you want to delete the document'
      }
    },
    no_results: {
      comments: {
        file_to_large: {
          title: 'Comment and Reply',
          message: 'This file is too large to add comments'
        },
        empty: {
          title: 'Comment and Reply',
          message: 'Select some text and click on the speech bubble to comment',
          icon: 'no-result-no-comments'
        },
        error: {
          title: 'Something Went Wrong'
        }
      },
      details: {
        file_to_large: {
          title: 'Document Details',
          message: 'This file is too large to view details'
        },
        empty: {
          title: 'Document Details',
          message: 'Select a document to view its details and activity',
          icon: 'no-result-no-comments'
        },
        error: {
          title: 'Something Went Wrong'
        }
      },
      documents: {
        empty: {
          title: 'No Documents Available',
          message: 'Drag and drop documents into this window to upload',
          icon: 'no-result-file-too-large'
        },
        document: {
          file_to_large: {
            title: 'This document is too large to preview',
            message: 'Please download the file to view the full document',
            icon: 'no-result-file-too-large'
          },
          server_error: {
            title: 'The server appears to have an issue getting the document!',
            message: '',
            icon: 'no-result-server-error'
          },
          file_unsupported: {
            title: 'files are unable to be previewed',
            message: 'Please download the file to view the full document',
            icon: ''
          },
          document_comments: {
            title: 'Document comments have arrived!',
            message: 'Select the text you would like to comment on and click the speech bubble icon. Enjoy!',
            icon: 'no-result-document-comments'
          },
          please_download: {
            title: 'files are unable to be previewed',
            message: 'Please download to view'
          },
          recent_document: {
            title: 'No documents have been shared or updated recently.'
          }
        },
        server_error: {
          title: 'The server appears to have an issue getting documents!',
          message: '',
          icon: 'no-result-server-error'
        }
      },
      billing: {
        account: {
          title: 'Account Statements Unavailable',
          message: 'No statements available, check back soon'
        },
        error: {
          title: 'Something Went Wrong',
          message: 'The server appears to have an issue getting documents!'
        },
        trust: {
          title: 'Trust Statements Unavailable',
          message: 'No statements available, check back soon'
        },
        details: {
          title: 'Details Unavailable',
          message: 'There are currently no details for this account',
          iconAccount: 'no-result-details-data',
          iconTrust: 'no-result-details-data'
        }
      },
      firms: {
        title: 'No firms available'
      }
    },
    billing: {
      statement_of_account: {
        title: 'Statement of Account',
        filter: {
          summary: 'Summary',
          debtorLedger: 'Details'
        },
        side_info: {
          invoices: 'Invoices',
          ageing: 'Aging'
        }
      },
      trust_account: {
        title: 'Trust Account Statement',
        filter: {
          all: 'All Accounts'
        },
        side_info: {
          trust_account: 'Trust Account',
          trust_accounts: 'Trust Accounts',
          trust_transaction: 'Trust Totals'
        }
      }
    }
  }
};
