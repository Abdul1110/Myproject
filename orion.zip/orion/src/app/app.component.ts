import { Component, ViewEncapsulation, Inject, OnDestroy, OnInit, ChangeDetectorRef } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Select } from '@ngxs/store';
import { BrowserService, LyraAnimation } from '@leap/lyra-design';
import { Subject, fromEvent, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { environment } from '@env/environment';
import { ToastService, AnalyticService, CustomEventService, LAYOUT_HOME_INIT_COMPLETED } from './core/services';
import { AppState } from './core/store/states';

const { locale } = environment;

@Component({
  selector: 'sc-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [LyraAnimation.xAnimationMenuCollapse],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnDestroy, OnInit {
  private destroy$ = new Subject<boolean>();

  title = 'orion';
  firmName = '';
  isAuthenticated = false;
  isLayoutHomeInitCompleted = false;
  isThemeLoading = false;
  isThemeError = false;
  themeErrorMessage = '';

  @Select(AppState.getAppAuthentication) userAuthenticationStatus$: Observable<boolean>;

  get isInitializating(): boolean {
    return (!this.isLayoutHomeInitCompleted && this.isAuthenticated) || this.isThemeLoading;
  }

  ngOnInit(): void {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.initalise();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.dispose();
    }
  }

  onThemeLoading = (loading: boolean): void => {
    this.isThemeLoading = loading;
  };

  onThemeError = (message: string): void => {
    this.themeErrorMessage = message;
    this.isThemeError = true;
  };

  constructor(
    @Inject(DOCUMENT) private document: any,
    private browserSvc: BrowserService,
    private toastService: ToastService,
    private analyticsSvc: AnalyticService,
    private customEventSvc: CustomEventService,
    private cdr: ChangeDetectorRef
  ) {
    const hostName = this.document.location.hostname;
    const firm = hostName.split('.');

    this.firmName = firm[0] || '';

    if (!this.browserSvc.isServer) {
      this.analyticsSvc.startTracking();
    }

    if (this.browserSvc.isBrowser) {
      merge(this.getUserAuthenticationStatus$(), this.toasterHandler$(), this.getLayoutHomeInitCompleted$())
        .pipe(takeUntil(this.destroy$))
        .subscribe();

      // use by walkmein only.
      if (!this.browserSvc.window['walkme_get_language']) {
        this.browserSvc.window['walkme_get_language'] = (): string => {
          return environment.appSettings.locale;
        };
      }
    }
  }

  private getUserAuthenticationStatus$ = (): Observable<boolean> => {
    return this.userAuthenticationStatus$.pipe(
      tap(status => {
        this.isAuthenticated = !!status;
      })
    );
  };

  private getLayoutHomeInitCompleted$ = (): Observable<any> => {
    return this.customEventSvc.registerEvent(LAYOUT_HOME_INIT_COMPLETED, () => {
      this.isLayoutHomeInitCompleted = true;
      this.cdr && this.cdr.markForCheck();
    });
  };

  private toasterHandler$ = (): Observable<any> => {
    return fromEvent(this.browserSvc.window, 'message').pipe(
      tap(event => {
        if (event && event['data'] && event['data']['type'] === 'error') {
          this.toastService.showError(event['data']['message']);
          return;
        }
        if (event && event['data'] && event['data']['type'] === 'success') {
          this.toastService.showSuccess(event['data']['message']);
          return;
        }
      })
    );
  };
}
