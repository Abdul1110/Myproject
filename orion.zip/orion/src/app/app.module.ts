import { BrowserModule, makeStateKey } from '@angular/platform-browser';
import { BrowserTransferStateModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID, APP_INITIALIZER, ErrorHandler } from '@angular/core';
import { PLATFORM_ID, APP_ID, Inject } from '@angular/core';
import { isPlatformBrowser, registerLocaleData } from '@angular/common';
import { TransferHttpCacheModule } from '@nguniversal/common';
import localeAU from '@angular/common/locales/en-AU';
import localeAUExtra from '@angular/common/locales/extra/en-AU';
import localeGB from '@angular/common/locales/en-GB';
import localeGBExtra from '@angular/common/locales/extra/en-GB';
import localeCA from '@angular/common/locales/en-CA';
import localeCAExtra from '@angular/common/locales/extra/en-CA';
import { HttpClientModule } from '@angular/common/http';
import { InlineSVGModule } from 'ng-inline-svg';
import * as SentryBrowser from '@sentry/browser';

import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared';

import { AppRoutingModule } from './app-routing.module';
import { environment } from '@env/environment';
import { appRouteHandlerComponents } from './components';
import {
  LyraDesignMenuModule,
  LyraDesignIconModule,
  LyraDesignCommonModule,
  LyraDesignAsideModule,
  LyraDesignAnimationModule,
  LyraDesignTypeModule,
  LyraDesignEmptyStateModule
} from '@leap/lyra-design';
import { SentryLogger } from './shared/services/logger/sentry-logger';

export const REQ_KEY = makeStateKey<string>('req');

if (environment && environment.appSettings && environment.appSettings.locale) {
  switch (environment.appSettings.locale) {
    case 'en-AU':
      registerLocaleData(localeAU, 'en-AU', localeAUExtra);
      break;
    case 'en-GB':
      registerLocaleData(localeGB, 'en-GB', localeGBExtra);
      break;
    case 'en-CA':
      registerLocaleData(localeCA, 'en-CA', localeCAExtra);
      break;
    default:
      break;
  }
}

@NgModule({
  declarations: [AppComponent, ...appRouteHandlerComponents],
  imports: [
    BrowserModule.withServerTransition({ appId: 'orion' }),
    BrowserTransferStateModule,
    HttpClientModule,
    TransferHttpCacheModule,
    CoreModule.forRoot([]),
    AppRoutingModule,
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    SharedModule,
    LyraDesignMenuModule,
    LyraDesignIconModule,
    LyraDesignCommonModule,
    LyraDesignAsideModule,
    LyraDesignAnimationModule,
    LyraDesignTypeModule,
    LyraDesignEmptyStateModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: environment.appSettings.locale },
    { provide: ErrorHandler, useFactory: SentryLogger.initWith(SentryBrowser, 'browser') }
    // {
    //   // Provider for APP_INITIALIZER
    //   provide: APP_INITIALIZER,
    //   useFactory: startupServiceFactory,
    //   deps: [StartupService],
    //   multi: true
    // }
  ],
  bootstrap: [AppComponent, ...appRouteHandlerComponents]
})
export class AppModule {
  constructor(@Inject(PLATFORM_ID) private platformId: Object, @Inject(APP_ID) private appId: string) {
    const platform = isPlatformBrowser(platformId) ? 'in the browser' : 'on the server';
    console.log(`Running ${platform} with appId=${appId}`);
  }
}
