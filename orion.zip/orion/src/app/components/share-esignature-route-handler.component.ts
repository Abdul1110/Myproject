import { Component, ViewEncapsulation, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { Observable, Subject } from 'rxjs';
import { takeUntil, tap, take, skip, delay } from 'rxjs/operators';

import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models';
import { NavigationService } from '@app/core/services';

@Component({
  selector: 'sc-share-esignature-route-handler',
  template: `
    <router-outlet></router-outlet>
  `,
  encapsulation: ViewEncapsulation.None
})
export class ShareESignatureRouteHandlerComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  @Select(AppState.getSharePreviewInfo) sharePreview$: Observable<CoreModel.SharePreviewInfo>;

  constructor(
    private router: Router,
    private snap: ActivatedRoute,
    private store: Store,
    private brwSvc: BrowserService,
    private navigationSvc: NavigationService
  ) {
    const shareLoginQueryParams = this.snap ? this.snap.queryParams['value'] : undefined;
    const isShareLogin = !!(shareLoginQueryParams['requestId'] && shareLoginQueryParams['userId']);

    if (this.brwSvc.isServer) {
      return;
    }

    if (isShareLogin) {
      this.sharePreview$
        .pipe(
          takeUntil(this.destroy$),
          skip(1),
          delay(1),
          take(2),
          tap(v => {
            let path = '/account/signup';

            if (v && !v.isExistingUser) {
              this.navigationSvc.goto(<CoreModel.NavigationData>{
                path,
                queryParams: <Params>{
                  returnTo: `${(this.brwSvc && this.brwSvc.isBrowser && this.brwSvc.window.location.pathname) || '/'}`
                }
              });
              return;
            }

            if (v && v.isExistingUser) {
              path = `/matters/${v.matterId}/signatures/${(v.eSignature &&
                v.eSignature.orderId &&
                `${v.eSignature.orderId}`) ||
                'none'}/sign`;
            } else if (!v) {
              path = this.router.url;
            }

            this.navigationSvc.goto(
              <CoreModel.NavigationData>{
                path
              },
              1000
            );
          })
        )
        .subscribe();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }
}
