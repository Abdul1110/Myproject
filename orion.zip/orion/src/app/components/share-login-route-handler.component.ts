import { Component, ViewEncapsulation, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'sc-share-login-route-handler',
  template: `
    <router-outlet></router-outlet>
  `,
  encapsulation: ViewEncapsulation.None
})
export class ShareLoginRouteHandlerComponent {
  constructor(@Inject(DOCUMENT) private document: any, private router: Router) {
    // matter share or document share handler!!
    // e.g. doc share url: ?redirectUrl=%2Fnodes%2Ffce5d8e9-1637-4134-b0e6-bcbc21ff3238%2Fevent%2F81856b81-c8b4-42d2-823f-2c03485d8cdd%3Fviewer%3Dpdf%26sharedTo%3Dgk.leapdev%2540gmail.com&sharedTo=gk.leapdev%40gmail.com&nodeId=fce5d8e9-1637-4134-b0e6-bcbc21ff3238&eventId=81856b81-c8b4-42d2-823f-2c03485d8cdd
    //         convert to: ?isMatterShared=false&nodeId=fce5d8e9-1637-4134-b0e6-bcbc21ff3238&eventId=81856b81-c8b4-42d2-823f-2c03485d8cdd&viewer=pdf
    if (this.document.URL && this.document.URL.indexOf('share-login') >= 0) {
      const redirectUrl = this.document.location.search;
      if (redirectUrl) {
        const paramsX = new Set<string>(redirectUrl.split('&'));
        const params = Array.of(...paramsX);
        const shareKeys = ['sharedTo=', 'nodeId=', 'eventId='];
        const shareParams = params
          .filter(x => shareKeys.findIndex(y => x.indexOf(y) >= 0) >= 0)
          .map<{ [key: string]: string }>(x => {
            const value = x.split('=') as string[];
            return { [`${value[0]}`]: decodeURIComponent(value[1]) };
          });

        let viewerValue = [];
        if (params) {
          const redirectUrlIndex = params.findIndex(d => d.indexOf('?redirectUrl=') >= 0);
          if (redirectUrlIndex >= 0) {
            const value = decodeURIComponent(params[redirectUrlIndex]);
            const valueX = new Set<string>(value.split('?'));
            const valueY = Array.of(...valueX);
            const extraKeys = ['viewer='];
            extraKeys.forEach(viewerKey => {
              const viewerIndex = valueY.findIndex(z => z.indexOf(viewerKey) >= 0);
              if (viewerIndex >= 0) {
                const viewerInfo = Array.of(...valueY[viewerIndex].split('&'));
                const actualViewerIndex = viewerInfo.findIndex(x => x.indexOf(viewerKey) >= 0);
                if (actualViewerIndex >= 0) {
                  const final = viewerInfo[actualViewerIndex].split(viewerKey)[1];
                  viewerValue = [{ [viewerKey.replace('=', '')]: final }];
                }
              }
            });
          }
        }

        this.router.navigate(['account/signin'], {
          queryParams: Object.assign(
            {},
            { isMatterShared: !(shareParams.findIndex(r => Object.keys(r).indexOf('eventId') >= 0) >= 0) },
            ...shareParams,
            ...viewerValue
          )
        });
      }
    }
  }
}
