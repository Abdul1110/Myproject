import { PreviewRouteHandlerComponent } from './preview-route-handler.component';
import { NoRouteHandlerComponent } from './no-route-handler.component';
import { ShareLoginRouteHandlerComponent } from './share-login-route-handler.component';
import { ShareNodeRouteHandlerComponent } from './share-node-route-handler.component';
import { ShareESignatureRouteHandlerComponent } from './share-esignature-route-handler.component';
import { ESignatureRequestRouteHandlerComponent } from './esignature-request-route-handler.component';
import { ShareFolderRouteHandlerComponent } from './share-folder-route-handler.component';
import { ShareAppRouteHandlerComponent } from './share-app-route-handler.component';

export * from './preview-route-handler.component';
export * from './no-route-handler.component';
export * from './share-login-route-handler.component';
export * from './share-node-route-handler.component';
export * from './share-esignature-route-handler.component';
export * from './esignature-request-route-handler.component';
export * from './share-app-route-handler.component';

export const appRouteHandlerComponents = [
  PreviewRouteHandlerComponent,
  NoRouteHandlerComponent,
  ShareLoginRouteHandlerComponent,
  ShareNodeRouteHandlerComponent,
  ShareESignatureRouteHandlerComponent,
  ESignatureRequestRouteHandlerComponent,
  ShareFolderRouteHandlerComponent,
  ShareAppRouteHandlerComponent
];
