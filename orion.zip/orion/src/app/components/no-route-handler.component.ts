import { Component, ViewEncapsulation, Optional } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Store } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';

import * as actions from '../core/store/actions';
import { CoreModel } from '@app/core/models';
import { NavigationService } from '@app/core/services';

@Component({
  template: `
    <router-outlet></router-outlet>
  `,
  encapsulation: ViewEncapsulation.None
})
export class NoRouteHandlerComponent {
  constructor(
    @Optional() private router: Router,
    private browserSvc: BrowserService,
    private route: ActivatedRoute,
    private store: Store,
    private navigationSvc: NavigationService
  ) {
    if (this.browserSvc.isServer) {
      return;
    }

    const email = this.route.snapshot.queryParams['email'];

    if (!!email) {
      this.store.dispatch(new actions.SetSignUpEmail(email));
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `account/signin`
      });
      return;
    }

    this.router.navigate(['recents']);
  }
}
