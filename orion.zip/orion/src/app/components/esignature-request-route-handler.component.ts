import { Component, ViewEncapsulation } from '@angular/core';
import { BrowserService } from '@leap/lyra-design';
import { ActivatedRoute } from '@angular/router';
import { environment } from '@env/environment';

@Component({
  template: `
    <router-outlet></router-outlet>
  `,
  encapsulation: ViewEncapsulation.None
})
export class ESignatureRequestRouteHandlerComponent {
  constructor(private browserSvc: BrowserService, private snap: ActivatedRoute) {
    if (this.browserSvc.isBrowser) {
      const ticketId = this.snap.queryParams['value']['ticketId'] || '';
      const leapToken = this.snap.queryParams['value']['leapToken'] || '';
      const version = this.snap.queryParams['value']['version'] || 'xx';
      this.browserSvc.window.location = `${environment.appSettings.legacyEndpoint}/esignatures?ticketId=${ticketId}&version=${version}&leapToken=${leapToken}`;
    }
  }
}
