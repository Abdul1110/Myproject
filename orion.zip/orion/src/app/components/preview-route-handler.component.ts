import { Component, ViewEncapsulation, HostBinding } from '@angular/core';
import { BrowserService } from '@leap/lyra-design';

@Component({
  selector: 'sc-preview-handler',
  template: `
    <router-outlet></router-outlet>
  `,
  encapsulation: ViewEncapsulation.None
})
export class PreviewRouteHandlerComponent {
  constructor(private browserSvc: BrowserService) {
    if (this.browserSvc.isServer) {
      return;
    }
  }

  @HostBinding('class') class = 'w-100';
}
