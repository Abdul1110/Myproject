import { Component, ViewEncapsulation, Inject, OnDestroy } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Store } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { Subject, throwError } from 'rxjs';
import { tap, take, delay, map, catchError } from 'rxjs/operators';

import { CoreModel } from '@app/core/models';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { ThemeService, NavigationService } from '@app/core/services';

@Component({
  selector: 'sc-share-folder-route-handler',
  template: `
    <router-outlet></router-outlet>
  `,
  encapsulation: ViewEncapsulation.None
})
export class ShareFolderRouteHandlerComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  sharePreview$ = this.appActionSvc.sharePreview$;

  constructor(
    @Inject(DOCUMENT) private document: any,
    private router: Router,
    private snap: ActivatedRoute,
    private store: Store,
    private appActionSvc: AppActionService,
    private brwSvc: BrowserService,
    private themeSvc: ThemeService,
    private navigationSvc: NavigationService
  ) {
    const shareLoginParams = this.snap ? this.snap.params['value'] : undefined;
    const shareLoginQueryParams = this.snap ? this.snap.queryParams['value'] : undefined;
    const isNodesPath = this.router.url.indexOf('/nodes/') === 0;
    const isShareLogin = !!(
      shareLoginParams &&
      shareLoginParams['nodeId'] &&
      (shareLoginQueryParams['sharedTo'] || shareLoginQueryParams['sharedto'] || isNodesPath)
    );
    const isCollaborationPath = this.router.url.includes('/folders/');

    if (this.brwSvc.isServer) {
      return;
    }

    if (isShareLogin && isCollaborationPath) {
      const { sharedTo, sharedto, email, documentId } = shareLoginQueryParams;
      const { nodeId, folderId } = shareLoginParams;

      this.sharePreview$
        .pipe(
          delay(1),
          take(2),
          tap(v => {
            let path = '/account/signup';

            if (v && !v.isExistingUser) {
              this.navigationSvc.goto(<CoreModel.NavigationData>{
                path,
                queryParams: <Params>{
                  isMatterShared: false,
                  sharedTo: sharedTo || sharedto || 'none',
                  nodeId: nodeId,
                  eventId: undefined,
                  folderId,
                  returnTo: `${(this.brwSvc && this.brwSvc.isBrowser && this.brwSvc.window.location.pathname) || '/'}`
                }
              });
              return;
            }

            if (v && v.isExistingUser) {
              path = `/matters/${v.matterId || nodeId}/collaborations/${documentId || ''}`;
            } else if (!v) {
              if (nodeId && folderId) {
                const email = sharedTo || sharedto || 'none';
                this.themeSvc
                  .getShareInfo(email, nodeId, '', '', '', true, folderId, documentId, '', '')
                  .pipe(
                    take(1),
                    map(v => {
                      path = 'recents';
                      if (v && v.share && v.share.matterId) {
                        const { matterId } = v.share;
                        path = `matters/${matterId}/collaborations/${documentId || ''}`;
                      }
                      this.navigationSvc.goto(
                        <CoreModel.NavigationData>{
                          path
                        },
                        0
                      );
                    }),
                    catchError(err => {
                      this.navigationSvc.goto(
                        <CoreModel.NavigationData>{
                          path: 'recents'
                        },
                        0
                      );
                      return throwError(err);
                    })
                  )
                  .subscribe();
                return;
              }
            }

            this.navigationSvc.goto(
              <CoreModel.NavigationData>{
                path
              },
              1000
            );
          })
        )
        .subscribe();
      return;
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }
}
