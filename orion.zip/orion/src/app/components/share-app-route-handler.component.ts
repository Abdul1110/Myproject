import { Component, ViewEncapsulation, OnDestroy } from '@angular/core';
import { Subject, throwError } from 'rxjs';
import { ActivatedRoute, Params } from '@angular/router';
import { BrowserService } from '@leap/lyra-design';
import { takeUntil, map, catchError } from 'rxjs/operators';
import { Store } from '@ngxs/store';

import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models';
import { ThemeService, NavigationService } from '@app/core/services';

@Component({
  selector: 'sc-share-app-route-handler',
  template: `
    <router-outlet></router-outlet>
  `,
  encapsulation: ViewEncapsulation.None
})
export class ShareAppRouteHandlerComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }

  constructor(
    private activedRoute: ActivatedRoute,
    private brwSvc: BrowserService,
    private themeSvc: ThemeService,
    private store: Store,
    private navigationSvc: NavigationService
  ) {
    if (brwSvc.isBrowser) {
      if (this.activedRoute) {
        const { appId, shareId } = this.activedRoute.snapshot.params;
        if (appId && shareId) {
          const previewInfo = this.store.selectSnapshot(AppState.getSharePreviewInfo);

          if (!previewInfo) {
            // none = read email from cache.
            this.themeSvc
              .getShareInfo('none', '', '', '', '', false, undefined, undefined, appId, shareId)
              .pipe(
                takeUntil(this.destroy$),
                map(v => {
                  if (!v) {
                    this.navigateTo('recents', true);
                    return;
                  }

                  const { matterId } = v.share;
                  if (matterId) {
                    this.navigateTo(`/matters/${matterId}/apps/${appId}/shares/${shareId}`, true);
                    return;
                  }
                }),
                catchError(err => {
                  this.navigateTo('recents', true);
                  return throwError(err);
                })
              )
              .subscribe();
            return;
          }

          const { isExistingUser, userEmail } = previewInfo;

          if (!isExistingUser) {
            this.navigationSvc.goto(<CoreModel.NavigationData>{
              path: '/account/signup',
              queryParams: <Params>{
                isMatterShared: false,
                sharedTo: userEmail || 'none',
                nodeId: undefined,
                eventId: undefined,
                returnTo: `${(this.brwSvc && this.brwSvc.isBrowser && this.brwSvc.window.location.pathname) || '/'}`
              }
            });
            return;
          }

          const { matterId } = previewInfo;
          if (isExistingUser) {
            this.navigateTo(`/matters/${matterId}/apps/${appId}/shares/${shareId}`);
            return;
          }
        }
      }
    }
  }

  private navigateTo(path: string, useTimeout: boolean = false) {
    this.navigationSvc.goto(
      <CoreModel.NavigationData>{
        path
      },
      useTimeout ? 0 : -1
    );
  }
}
