import { NgModule } from '@angular/core';
import { NgxsModule } from '@ngxs/store';
import { CollaborationsStates } from './store';

@NgModule({
  imports: [NgxsModule.forFeature([...CollaborationsStates])]
})
export class CollaborationsStateModule {}
