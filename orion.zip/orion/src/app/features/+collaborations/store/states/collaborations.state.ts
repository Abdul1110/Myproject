import { State, Action, StateContext, Selector } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { switchMap, catchError, map } from 'rxjs/operators';
import { saveAs as FileSaver } from 'file-saver';

import { CollaborationsAction } from '../actions';
import { CollaborationsModel } from '../../models/collaborations.model';
import { LawConnectApiService } from '../../services';
import {
  AddCollaborationBin,
  DeleteFromCollaborationBin,
  AddPendingCollaboration,
  AddUploadDraftToStore
} from '@app/core/store/actions';
import { CoreModel } from '@app/core/models';

export interface CollaborationsStateModel {
  error: string;
  loading: boolean;
  onlyMyUploads: boolean;
}

@State<CollaborationsStateModel>({
  name: 'collaborations',
  defaults: {
    error: undefined,
    loading: false,
    onlyMyUploads: false
  }
})
export class CollaborationsState {
  constructor(private browserSvc: BrowserService, private lcApiSvc: LawConnectApiService) {}

  @Action(CollaborationsAction.SetOnlyMyUploads)
  SetOnlyMyUploads({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    const state = getState();
    const showOnly = !!payload.payload;
    setState({
      ...state,
      onlyMyUploads: showOnly
    });
  }

  @Selector()
  static getOnlyMyUploadsFlag(state: CollaborationsStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.onlyMyUploads;
  }

  @Action(CollaborationsAction.PreviewDocument, { cancelUncompleted: true })
  PreviewDocument({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { matterId, documentId, isImage } = payload.payload as CollaborationsModel.PreviewDocumentRequest;

    const downloadSvc = this.lcApiSvc.getCollaborationDocumentDownloadUrl(matterId, documentId, isImage ? false : true);

    return downloadSvc.pipe(
      switchMap(response => dispatch(new CollaborationsAction.PreviewDocumentSuccess(response.downloadUrl))),
      catchError(error => dispatch(new CollaborationsAction.PreviewDocumentFailure(error)))
    );
  }

  @Action(CollaborationsAction.DownloadDocument, { cancelUncompleted: true })
  DownloadDocument({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { matterId, documentId, documentName } = payload.payload as CollaborationsModel.DownloadDocumentRequest;

    const downloadSvc = this.lcApiSvc.getCollaborationDocumentDownloadUrl(matterId, documentId, false);

    return downloadSvc.pipe(
      switchMap(res => this.lcApiSvc.download(res.downloadUrl)),
      map(bl => FileSaver.saveAs(bl, documentName)),
      map(() => dispatch(new CollaborationsAction.DownloadDocumentSuccess())),
      catchError(error => dispatch(new CollaborationsAction.DownloadDocumentFailure(error)))
    );
  }

  @Action(CollaborationsAction.DownloadAttachment, { cancelUncompleted: true })
  DownloadAttachment({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { documentName, attachmentUrl } = payload.payload as CollaborationsModel.DownloadAttachmentRequest;

    return this.lcApiSvc.download(attachmentUrl).pipe(
      map(bl => FileSaver.saveAs(bl, documentName)),
      map(() => dispatch(new CollaborationsAction.DownloadDocumentSuccess())),
      catchError(error => dispatch(new CollaborationsAction.DownloadDocumentFailure(error)))
    );
  }

  @Action(CollaborationsAction.PreviewAttachment, { cancelUncompleted: true })
  PreviewAttachment({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { matterId, documentId, previewUrl } = payload.payload as CollaborationsModel.PreviewAttachmentRequest;

    const downloadSvc = this.lcApiSvc.getCollaborationAttachmentDownloadUrl(matterId, documentId, previewUrl);

    return downloadSvc.pipe(
      switchMap(response => dispatch(new CollaborationsAction.PreviewAttachmentSuccess(response.downloadUrl))),
      catchError(error => dispatch(new CollaborationsAction.PreviewAttachmentFailure(error)))
    );
  }

  @Action(CollaborationsAction.DeleteDocument)
  DeleteDocument({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    const deleteRequest = payload.payload as CollaborationsModel.DeleteDocumentRequest;

    if (!deleteRequest || !deleteRequest.documentId) {
      return;
    }

    // update to the bin list to exclude from displaying.
    dispatch(new AddCollaborationBin(deleteRequest.documentId));

    return this.lcApiSvc.deleteDocument([deleteRequest.documentId]).pipe(
      map(deleted => dispatch(new CollaborationsAction.DeleteDocumentSuccess(deleteRequest))),
      catchError(error => dispatch(new CollaborationsAction.DeleteDocumentFailure({ data: deleteRequest, err: error })))
    );
  }

  @Action(CollaborationsAction.DeleteDocumentFailure)
  DeleteDocumentFailure({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    const state = getState();
    const { data, err: error } = payload.payload as { data; err };
    const err = this.browserSvc.getStandardError(error);

    const resetStatus = ['403', '404', '400', '500'];
    if (err && resetStatus.includes(err.status)) {
      return dispatch(new DeleteFromCollaborationBin(data.documentId));
    }
  }

  @Action(CollaborationsAction.CreateUploadDraft)
  CreateUploadDraft({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    const draftsRequest = payload.payload as CollaborationsModel.DraftUploadRequest;

    if (!draftsRequest || !draftsRequest.matterId || !draftsRequest.firmId) {
      return;
    }

    const { firmId, matterId, files, folderId, matterName, collaborationRootId } = draftsRequest;

    return this.lcApiSvc
      .createDocumentDraft(
        firmId,
        matterId,
        files.map(
          d =>
            <CollaborationsModel.DraftInfo>{
              id: d.alias,
              name: d.file.name,
              folderId: folderId,
              extension: d.file.type
            }
        )
      )
      .pipe(
        map(created =>
          dispatch([
            new CollaborationsAction.CreateUploadDraftSuccess({
              created: created,
              matterName: matterName,
              collaborationRootId: collaborationRootId,
              folderId: folderId
            })
          ])
        ),
        catchError(error => dispatch(new CollaborationsAction.CreateUploadDraftFailure(error)))
      );
  }

  @Action(CollaborationsAction.CreateUploadDraftSuccess)
  CreateUploadDraftSuccess({ getState, setState, dispatch }: StateContext<CollaborationsStateModel>, payload) {
    const response = payload.payload as {
      created: CollaborationsModel.DraftCreated;
      matterName: string;
      collaborationRootId: string;
      folderId: string;
    };

    const draftsWithMatterName = response.created.draft.map(x => {
      return { ...x, matterName: response.matterName };
    });

    dispatch(new AddUploadDraftToStore(draftsWithMatterName));

    const drafts = response.created.draft;
    const hasRootId = !!response.collaborationRootId;
    const collaborationRootId = response.collaborationRootId || 'empty-1';
    const folderId = hasRootId ? response.folderId : response.folderId || 'empty-1';
    const pendingCollaborations = drafts.map(x => {
      const splitName = (x.name && x.name.split('.')) || [x.fileContentType];
      const fileExtension = splitName[splitName.length - 1];

      return <CoreModel.PendingCollaration>{
        collaborationRootId,
        folderId: folderId || collaborationRootId,
        createDate: new Date(),
        fileExtension,
        fileId: x.id,
        fileName: x.name,
        folderName: '',
        uploading: true
      };
    });

    return dispatch(new AddPendingCollaboration(pendingCollaborations));
  }
}
