import { CollaborationsModel } from '../../models/collaborations.model';
import { FileItem } from 'ng2-file-upload';

export namespace CollaborationsAction {
  const prefix = '[Collaborations]';

  export const ActionTypes = {
    PREVIEW_DOCUMENT: `${prefix} preview document`,
    PREVIEW_DOCUMENT_SUCCESS: `${prefix} preview document succcess`,
    PREVIEW_DOCUMENT_FAILURE: `${prefix} Failed to preview document`,
    DOWNLOAD_DOCUMENT: `${prefix} download document`,
    DOWNLOAD_ATTACHMENT: `${prefix} download attachment`,
    DOWNLOAD_DOCUMENT_SUCCESS: `${prefix} download document succcess`,
    DOWNLOAD_DOCUMENT_FAILURE: `${prefix} Failed to download document`,

    PREVIEW_ATTACHMENT: `${prefix} preview attachment`,
    PREVIEW_ATTACHMENT_SUCCESS: `${prefix} preview attachment succcess`,
    PREVIEW_ATTACHMENT_FAILURE: `${prefix} Failed to preview attachment`,

    DELETE_DOCUMENT: `${prefix} delete document`,
    DELETE_DOCUMENT_SUCCESS: `${prefix} delete document succcess`,
    DELETE_DOCUMENT_FAILURE: `${prefix} Failed to delete document`,

    CREATE_UPLOAD_DRAFT: `${prefix} create upload draft`,
    CREATE_UPLOAD_DRAFT_SUCCESS: `${prefix} create upload draft success`,
    CREATE_UPLOAD_DRAFT_FAILURE: `${prefix} Failed to create upload draft`,
    DOCUMENT_UPLOAD_FAILURE: `${prefix} Failed to upload document`,

    SET_ONLY_MY_UPLOADS: `${prefix} set only my uploads filter`
  };

  export class PreviewDocument {
    static readonly type = ActionTypes.PREVIEW_DOCUMENT;
    constructor(public payload: CollaborationsModel.PreviewDocumentRequest) {}
  }

  export class PreviewDocumentSuccess {
    static readonly type = ActionTypes.PREVIEW_DOCUMENT_SUCCESS;
    constructor(public payload: string) {}
  }

  export class PreviewDocumentFailure {
    static readonly type = ActionTypes.PREVIEW_DOCUMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class DownloadDocument {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT;
    constructor(public payload: CollaborationsModel.DownloadDocumentRequest) {}
  }

  export class DownloadAttachment {
    static readonly type = ActionTypes.DOWNLOAD_ATTACHMENT;
    constructor(public payload: CollaborationsModel.DownloadAttachmentRequest) {}
  }

  export class DownloadDocumentSuccess {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT_SUCCESS;
    constructor() {}
  }

  export class DownloadDocumentFailure {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class PreviewAttachment {
    static readonly type = ActionTypes.PREVIEW_ATTACHMENT;
    constructor(public payload: CollaborationsModel.PreviewAttachmentRequest) {}
  }

  export class PreviewAttachmentSuccess {
    static readonly type = ActionTypes.PREVIEW_ATTACHMENT_SUCCESS;
    constructor(public payload: string) {}
  }

  export class PreviewAttachmentFailure {
    static readonly type = ActionTypes.PREVIEW_ATTACHMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class DeleteDocument {
    static readonly type = ActionTypes.DELETE_DOCUMENT;
    constructor(public payload: CollaborationsModel.DeleteDocumentRequest) {}
  }

  export class DeleteDocumentSuccess {
    static readonly type = ActionTypes.DELETE_DOCUMENT_SUCCESS;
    constructor(public payload: CollaborationsModel.DeleteDocumentRequest) {}
  }

  export class DeleteDocumentFailure {
    static readonly type = ActionTypes.DELETE_DOCUMENT_FAILURE;
    constructor(public payload: { data: CollaborationsModel.DeleteDocumentRequest; err: any }) {}
  }

  export class CreateUploadDraft {
    static readonly type = ActionTypes.CREATE_UPLOAD_DRAFT;
    constructor(public payload: CollaborationsModel.DraftUploadRequest) {}
  }

  export class CreateUploadDraftSuccess {
    static readonly type = ActionTypes.CREATE_UPLOAD_DRAFT_SUCCESS;
    constructor(public payload: CollaborationsModel.DraftUploadRequestSuccess) {}
  }

  export class CreateUploadDraftFailure {
    static readonly type = ActionTypes.CREATE_UPLOAD_DRAFT_FAILURE;
    constructor(public payload: any) {}
  }

  export class DocumentUploadFailure {
    static readonly type = ActionTypes.DOCUMENT_UPLOAD_FAILURE;
    constructor(public payload: string) {}
  }

  export class SetOnlyMyUploads {
    static readonly type = ActionTypes.SET_ONLY_MY_UPLOADS;
    constructor(public payload: boolean) {}
  }
}
