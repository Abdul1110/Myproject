import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UUID } from 'angular2-uuid';
import { CollaborationsModel } from '../models/collaborations.model';

@Injectable({
  providedIn: 'root'
})
export class LawConnectApiService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  getCollaborationDocumentDownloadUrl(
    matterId: string,
    documentId: string,
    isPreview: boolean = true
  ): Observable<any> {
    const url = `${this.endpoint}/api/document/${documentId}/collaboration/download?preview=${isPreview}&matterId=${matterId}`;
    return this.http.get(url);
  }

  getCollaborationAttachmentDownloadUrl(matterId: string, documentId: string, previewUrl: string): Observable<any> {
    const url = `${this.endpoint}/api/document/${documentId}/collaboration/download/attachment`;

    return this.http.post(url, { matterId, previewUrl });
  }

  createDocumentDraft(
    firmId: string,
    matterId: string,
    files: CollaborationsModel.DraftInfo[]
  ): Observable<CollaborationsModel.DraftCreated> {
    const url = `${this.endpoint}/api/document/upload/${firmId}/matter/${matterId}`; //?rdid=${randomId}
    return this.http.post<CollaborationsModel.DraftCreated>(url, { files: files });
  }

  deleteDocumentDraft(documentIds: string[]): Observable<any> {
    const url = `${this.endpoint}/api/document/upload/draft/delete`; //?rdid=${randomId}
    return this.http.post<any>(url, { documentIds });
  }

  uploadToS3(url: string, documentId: string, fileContentType: string, file: File): Observable<any> {
    const req = new HttpRequest('PUT', url, file, {
      reportProgress: true,
      headers: new HttpHeaders({
        'Content-Type': fileContentType,
        'x-amz-meta-lcweb-action': 'file-upload',
        'x-amz-meta-lcweb-docid': documentId
      })
    });

    return this.http.request(req);
  }

  download(url: string): Observable<any> {
    return this.http.get(url, { responseType: 'blob' });
  }

  downloadDocument(docId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/${docId}/download?preview=false`;
    return this.http.get(url);
  }

  deleteDocument(documentIds: string[]): Observable<any> {
    const url = `${this.endpoint}/api/document/delete`;

    return this.http.put<any>(url, { documentIds });
  }
}
