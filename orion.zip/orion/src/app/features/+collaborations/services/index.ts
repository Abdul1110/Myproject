import { LawConnectApiService } from './lawconnect-api.service';
import { UploadGuard } from '../guards/upload.guard';

export * from './lawconnect-api.service';

export const collaborationsServices = [LawConnectApiService, UploadGuard];
