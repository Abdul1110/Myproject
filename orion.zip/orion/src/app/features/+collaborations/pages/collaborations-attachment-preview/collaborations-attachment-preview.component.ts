import { Component, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { Params, ActivatedRoute, Router } from '@angular/router';
import { UUID } from 'angular2-uuid';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { CoreModel } from '@app/core/models';
import { GetCollaborationSuccess } from '@app/core/store/actions';
import { AnalyticService, NavigationService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { AppState } from '@app/core/store/states';
import { environment } from '@env/environment';
import { CollaborationsAction } from '../../store';

const { file_unsupported, file_to_large } = environment.locale.no_results.documents.document;

@Component({
  selector: 'sc-collaborations-attachment-preview',
  templateUrl: './collaborations-attachment-preview.component.html'
})
export class CollaborationsAttachmentPreviewComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  previewDocName = '';
  documentId = '';
  attachmentId = '';
  matterId = '';
  previewUrl = ''; // use this to exchange correct attachmentPreviewUrl
  isLoading = true;
  isError = false;
  attachmentPreviewUrl = '';
  fileExtension = '';
  isDocumentDownloading = false;
  bigFileWarning = file_to_large;

  close(): void {
    const attachmentViewFromPreview = '(preview//preview:attachment)';
    const attachmentViewFromList = '(preview:attachment)';
    const currentPath = this.browserSvc.window.location.pathname;
    const path = currentPath.includes(attachmentViewFromPreview)
      ? `${(currentPath as string).split(attachmentViewFromPreview)[0]}`
      : `${(currentPath as string).split(attachmentViewFromList)[0]}`;

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path,
      queryParams: <Params>{
        t: UUID.UUID()
      },
      outlet: 'preview',
      outletPath: ''
    });
  }

  isImageFile(extension: string): boolean {
    return CoreModel.Helper.isImageFile(extension);
  }

  isPreviewNotSupported(fileExtension: string): boolean {
    const viewType = CoreModel.Helper.getFileViewer(fileExtension);

    return [CoreModel.ViewType.notSupported, CoreModel.ViewType.none].includes(viewType);
  }

  getUnsupportedTitle(fileExtension: string): string {
    return `<b>.${fileExtension}</b> ${file_unsupported.title}`;
  }

  getUnsupportedMessage(): string {
    return file_unsupported.message;
  }

  download(documentName: string, attachmentUrl: string): void {
    this.isDocumentDownloading = true;
    this.store.dispatch(new CollaborationsAction.DownloadAttachment({ documentName, attachmentUrl }));
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private navigationSvc: NavigationService,
    private activedRoute: ActivatedRoute,
    private actions$: Actions,
    private router: Router
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersPreviewAttachmentPage,
        action: "View selected collaboration's attachment"
      });

      merge(
        this.getPreviewAttachmentUrlSuccessSideEffect$(),
        this.getPreviewAttachmentUrlFailureSideEffect$(),
        this.getDownloadDocumentSuccessSideEffect$(),
        this.getDownloadDocumentFailureSideEffect$()
      )
        .pipe(takeUntil(this.destroy$))
        .subscribe();

      const { queryParams, state } = router.getCurrentNavigation().extras;
      const name = queryParams['name'];
      const id = queryParams['id'];
      const ext = queryParams['ext'];
      const names = `${name}.${ext}`;
      const docName = (names && names.length > 1 && names) || '';
      const { matterId, documentId } = this.activedRoute.parent.snapshot.params;

      this.previewDocName = decodeURIComponent(docName);
      this.matterId = matterId;
      this.documentId = documentId;
      this.attachmentId = id;
      this.fileExtension = ext;

      if (state && state.previewUrl) {
        state.previewUrl &&
          this.dispatchPreviewAttachmentUrlRequest(this.matterId, this.attachmentId, state.previewUrl);
        return;
      }

      this.getCollaborationsSuccessSideEffect$()
        .pipe(takeUntil(this.destroy$))
        .subscribe();
    }
  }

  private getCollaborationsSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetCollaborationSuccess),
      tap(success => this.getAttachmentPreviewUrl(this.matterId, this.documentId, this.attachmentId))
    );
  }

  private getAttachmentPreviewUrl(matterId: string, documentId: string, attachmentId: string): void {
    const result = CoreModel.Helper.getCollaborationFileByDocumentId(
      matterId,
      documentId,
      this.store.selectSnapshot(AppState.getCollaboration),
      this.store.selectSnapshot(AppState.getAllCollaborations)
    );

    if (!!(result && result.doc)) {
      const attachment = result.doc.attachments && result.doc.attachments.find(a => a.id == attachmentId);
      const previewUrl = (attachment && attachment.previewUrl) || '';
      previewUrl && this.dispatchPreviewAttachmentUrlRequest(this.matterId, this.attachmentId, previewUrl);
    }
  }

  private dispatchPreviewAttachmentUrlRequest(matterId: string, attachmentId: string, previewUrl: string): void {
    this.isLoading = false;
    this.previewUrl = previewUrl;

    this.store.dispatch(new CollaborationsAction.PreviewAttachment({ matterId, documentId: attachmentId, previewUrl }));
  }

  private getPreviewAttachmentUrlSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.PreviewAttachmentSuccess),
      tap(({ payload: url }) => {
        this.isLoading = false;
        this.attachmentPreviewUrl = url;
      })
    );
  }

  private getPreviewAttachmentUrlFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.PreviewAttachmentFailure),
      tap(err => {
        this.isLoading = false;
        this.isError = true;
      })
    );
  }

  private getDownloadDocumentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.DownloadDocumentSuccess),
      tap(() => {
        this.isDocumentDownloading = false;
      })
    );
  }

  private getDownloadDocumentFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.DownloadDocumentFailure),
      tap(() => {
        this.isDocumentDownloading = false;
        this.isError = true;
      })
    );
  }
}
