import { CollaborationsViewDetailsMobileComponent } from './collaborations-view-details-mobile/collaborations-view-details-mobile.component';
import { CollaborationsSideComponent } from './collaborations-side/collaborations-side.component';
import { CollaborationsAttachmentPreviewComponent } from './collaborations-attachment-preview/collaborations-attachment-preview.component';
import { CollaborationsListHeaderComponent } from './collaborations-list-header/collaborations-list-header.component';
import { CollaborationsListComponent } from './collaborations-list/collaborations-list.component';
import { CollaborationsDocumentPreviewComponent } from './collaborations-document-preview/collaborations-document-preview.component';
import { CollaborationsUploadComponent } from './collaborations-upload/collaborations-upload.component';
import { CollaborationsSideMobileComponent } from './collaborations-side-mobile/collaborations-side-mobile.component';

export * from './collaborations-view-details-mobile/collaborations-view-details-mobile.component';
export * from './collaborations-side/collaborations-side.component';
export * from './collaborations-attachment-preview/collaborations-attachment-preview.component';
export * from './collaborations-list-header/collaborations-list-header.component';
export * from './collaborations-list/collaborations-list.component';
export * from './collaborations-document-preview/collaborations-document-preview.component';
export * from './collaborations-upload/collaborations-upload.component';
export * from './collaborations-side-mobile/collaborations-side-mobile.component';

export const collaborationsPages = [
  CollaborationsViewDetailsMobileComponent,
  CollaborationsSideComponent,
  CollaborationsAttachmentPreviewComponent,
  CollaborationsListHeaderComponent,
  CollaborationsListComponent,
  CollaborationsDocumentPreviewComponent,
  CollaborationsUploadComponent,
  CollaborationsSideMobileComponent
];
