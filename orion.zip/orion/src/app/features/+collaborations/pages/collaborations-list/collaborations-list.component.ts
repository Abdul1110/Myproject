import { Component, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { CoreModel } from '@app/core/models';
import { CollaborationsModel } from '../../models/collaborations.model';
import { environment } from '@env/environment';
import {
  CustomEventService,
  COLLABORATIONS_LIST_SORTING,
  COLLABORATIONS_SIDE_TAB_SWITCH,
  COLLABORATIONS_LIST_HOME_VIEW,
  COLLABORATIONS_LIST_FILE_DELETE,
  MATTERS_SELECT_CLOSED,
  DOCUMENTS_SIDE_TAB_SWITCH,
  NAVIGATION_SIDE_BAR_TOGGLE,
  COLLABORATIONS_LIST_MY_UPLOADS_ONLY,
  NavigationService
} from '@app/core/services';
import { AppState } from '@app/core/store/states';
import {
  GetCollaborationSuccess,
  GetCollaborationFailure,
  GetCollaborationStart,
  PopulateCurrentCollaboration,
  DeleteUploadDraftSuccess,
  AddCollaborationBin
} from '@app/core/store/actions';
import { DialogService } from '@app/shared/services';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { CollaborationsAction, CollaborationsState } from '../../store';
import { BrowserService } from '@leap/lyra-design';

const { delete: document_delete } = environment.locale.document_actions;

@Component({
  selector: 'sc-collaborations-list',
  templateUrl: './collaborations-list.component.html'
})
export class CollaborationsListComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private matterId = '';
  private documentId = '';
  private activeSorting: CoreModel.ColumnSorting = CollaborationsModel.Helper.getDocDefaultSortingOption();
  private showOnlyMyUploads = false;
  emptyDocument = environment.locale.no_results.documents.empty;
  serverError = environment.locale.no_results.documents.server_error;
  hasNoDocument = false;
  hasError = false;
  isLoading = true;
  collaborations: CollaborationsModel.CollaborationItem[] = [];
  currentUser = undefined;
  isSmallScreen = false;
  pendingUploads: CoreModel.PendingCollaration[] = [];
  screenInnerHeight: 0;

  scrollObserver(scrollIndex: number): void {}

  isActiveItem(collaborationId: string): boolean {
    return this.documentId === collaborationId;
  }

  isUploadingItem(collaborationId: string): boolean {
    if (this.pendingUploads && this.pendingUploads.length > 0) {
      const found = this.pendingUploads.find(x => x.fileId == collaborationId);
      return found ? found.uploading : false;
    }
    return false;
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private customEventSvc: CustomEventService,
    private store: Store,
    private route: ActivatedRoute,
    private appActionSvc: AppActionService,
    private actions$: Actions,
    private dialogSvc: DialogService,
    private navigationSvc: NavigationService,
    private browserSvc: BrowserService
  ) {
    this.matterId = this.route.snapshot.params['matterId'];
    this.documentId = this.route.snapshot.params['documentId'];
    this.showOnlyMyUploads = this.store.selectSnapshot(CollaborationsState.getOnlyMyUploadsFlag);
    this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads);
    this.screenInnerHeight =
      this.browserSvc && this.browserSvc.isBrowser && this.browserSvc.window && this.browserSvc.window.innerHeight;

    merge(
      this.changeListOrderSideEffect$(),
      this.changeShowMyUploadsOnlySideEffect$(),
      this.logonUserSideEffect$(),
      this.getCollaborationsSuccessSideEffect$(),
      this.getCollaborationsFailureSideEffect$(),
      this.getFolderNavigationChangeSideEffect$(),
      this.detectSmallScreen$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.listenToDeleteDocumentRequestSideEffect$(),
      this.changeToHomeViewSideEffect$(),
      this.listenToUploadingDocumentSideEffect$(),
      this.listenToUploadingDocumentDeleteSuccessSideEffect$(),
      this.listenToMoveDocumentToDeleteSideEffect$(),
      this.listenToMatterSelectedFromOptions$(),
      this.pendingUploadStatus$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
  }

  private pendingUploadStatus$(): Observable<any> {
    return this.appActionSvc.uploadPendingCollaboration$.pipe(
      tap(p => {
        this.pendingUploads = p;
      })
    );
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      if (matterId && this.matterId !== matterId) {
        this.isLoading = true;
        this.store.dispatch(new GetCollaborationStart({ matterId, skipPathUpdate: false }));
      }

      this.matterId = matterId;
      this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads);
      this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, {
        tabId: 'details',
        id: '',
        skipListRender: true
      });
    });
  }

  private deleteDocument(document: CollaborationsModel.DeleteDocumentRequest): void {
    this.dialogSvc.confirm({
      title: document_delete.title,
      message: `${document_delete.message} <strong>${document.documentName}.${document.fileExtension}</strong>?`,
      actionText: 'Delete',
      closeText: 'Cancel',
      showCancel: true,
      onClose: (confirmed: boolean) => {
        if (confirmed) {
          this.documentId = '';
          this.store.dispatch(new CollaborationsAction.DeleteDocument(document));
          this.navigationSvc.goto(<CoreModel.NavigationData>{
            path: `matters/${this.matterId}/collaborations`
          });
        }
      }
    });
  }

  private listenToDeleteDocumentRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      COLLABORATIONS_LIST_FILE_DELETE,
      (document: CollaborationsModel.DeleteDocumentRequest) => {
        this.deleteDocument(document);
      }
    );
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_SIDE_TAB_SWITCH, ({ id, ...others }) => {
      if (this.documentId !== id) {
        this.documentId = id;
      }
    });
  }

  private detectSmallScreen$(): Observable<any> {
    return this.appActionSvc.isSmallScreen$.pipe(tap(isSmall => (this.isSmallScreen = isSmall)));
  }

  private changeListOrderSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_LIST_SORTING, (sorting: CoreModel.ColumnSorting) => {
      this.renderCollaborationList(sorting, this.showOnlyMyUploads);
    });
  }

  private changeShowMyUploadsOnlySideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_LIST_MY_UPLOADS_ONLY, ({ onlyMyUploads }) => {
      this.showOnlyMyUploads = onlyMyUploads;
      this.store.dispatch(new CollaborationsAction.SetOnlyMyUploads(onlyMyUploads));
      this.renderCollaborationList(this.activeSorting, onlyMyUploads);
    });
  }

  private changeToHomeViewSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_LIST_HOME_VIEW, () => {
      this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads);
    });
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private getFolderNavigationChangeSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateCurrentCollaboration),
      tap(change => {
        this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads);
      })
    );
  }

  private getCollaborationsSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetCollaborationSuccess),
      tap(success => this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads))
    );
  }

  private listenToUploadingDocumentSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.CreateUploadDraftSuccess),
      tap(success => this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads))
    );
  }

  private listenToUploadingDocumentDeleteSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DeleteUploadDraftSuccess),
      tap(success => this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads))
    );
  }

  private listenToMoveDocumentToDeleteSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(AddCollaborationBin),
      tap(success => this.renderCollaborationList(this.activeSorting, this.showOnlyMyUploads))
    );
  }

  private getCollaborationsFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetCollaborationFailure),
      tap(error => {
        this.isLoading = false;
        this.hasError = true;
      })
    );
  }

  private sortBy(d: any, sortBy: CoreModel.ColumnSorting): [] {
    return d.sort((a, b) => {
      const bName = b ? (b[sortBy.column] || '').toString().toLowerCase() : '';
      const aName = a ? (a[sortBy.column] || '').toString().toLowerCase() : '';

      if (sortBy.sort === CoreModel.SortBy.asc) {
        if (bName > aName) {
          return -1;
        }

        if (bName < aName) {
          return 1;
        }

        return 0;
      }

      if (sortBy.sort === CoreModel.SortBy.desc) {
        if (aName < bName) {
          return 1;
        }

        if (aName > bName) {
          return -1;
        }

        return 0;
      }

      return 0;
    });
  }

  private getFirmName(selectedFirm: CoreModel.FirmDetail): string {
    return selectedFirm && selectedFirm.name;
  }

  private getLatestCollaborationList(
    sortBy: CoreModel.ColumnSorting,
    onlyMyUploads: boolean
  ): CollaborationsModel.CollaborationItem[] {
    const allCollaborations = this.store.selectSnapshot(AppState.getAllCollaborations);
    const currentCollaborations = this.store.selectSnapshot(AppState.getCollaboration);
    const pendingCollaborations = this.store.selectSnapshot(AppState.getPendingCollaboration);
    const collaborationBinIds = this.store.selectSnapshot(AppState.geCollaborationBinIds);
    const collaborationNavigations = this.store.selectSnapshot(AppState.getNavigation);
    const collaborationListByMatter = CollaborationsModel.Helper.getCollaborations(
      this.matterId,
      allCollaborations,
      currentCollaborations,
      pendingCollaborations,
      collaborationBinIds,
      collaborationNavigations
    );

    const docs = collaborationListByMatter[this.matterId];

    if (!docs || (docs.length === 0 && collaborationNavigations.length < 2)) {
      const defaultFolder = <CollaborationsModel.CollaborationItem>{
        isFolder: false,
        isFolderHeader: true,
        collaborationRootId: 'empty',
        fileExtension: 'doctype-folder-collaboration',
        id: 'empty',
        name: `Collaboration with ${this.getFirmName(this.store.selectSnapshot(AppState.getSelectedFirm))}`,
        otherUsers: []
      };
      return [defaultFolder];
    }

    const f: CollaborationsModel.CollaborationItem[] = [].concat(docs.filter(x => x.isFolder));
    const d: CollaborationsModel.CollaborationItem[] = [].concat(docs.filter(x => !x.isFolder));

    if (!sortBy) {
      return onlyMyUploads ? docs.filter(d => d.isFolder || d.isFolderHeader || d.isDeletable) : docs;
    }

    const documents: CollaborationsModel.CollaborationItem[] = [].concat(this.sortBy(d, sortBy));

    const folders: CollaborationsModel.CollaborationItem[] = [].concat(this.sortBy(f, sortBy));

    const allFoldersAndDocuments = folders.concat(...documents);

    if (!currentCollaborations) {
      return [];
    }

    let newFoldersAndDocuments: CollaborationsModel.CollaborationItem[] = [];

    const hasMoreThanOneGroup = Object.keys(currentCollaborations).length > 1;

    Object.keys(currentCollaborations).forEach(rootId => {
      const activeCollborations = allFoldersAndDocuments.filter(x => x.collaborationRootId == rootId) || [];
      if (!hasMoreThanOneGroup || rootId !== 'empty') {
        newFoldersAndDocuments = newFoldersAndDocuments.concat(
          <CollaborationsModel.CollaborationItem>{
            isFolder: false,
            isFolderHeader: true,
            collaborationRootId: rootId,
            fileExtension: 'doctype-folder-collaboration',
            id: rootId,
            name: `${currentCollaborations[rootId][0].name}`,
            otherUsers: currentCollaborations[rootId][0].otherUsers || []
          },
          activeCollborations.filter(y => y.id !== rootId)
        );
      }
    });

    if (collaborationNavigations && collaborationNavigations.length > 1) {
      return onlyMyUploads
        ? newFoldersAndDocuments.filter(d => !d.isFolderHeader && (d.isFolder || d.isDeletable))
        : newFoldersAndDocuments.filter(x => !x.isFolderHeader);
    }

    return onlyMyUploads
      ? newFoldersAndDocuments.filter(d => d.isFolder || d.isFolderHeader || d.isDeletable)
      : newFoldersAndDocuments;
  }

  private renderCollaborationList(sorting: CoreModel.ColumnSorting, onlyMyUploads: boolean): void {
    this.collaborations = this.getLatestCollaborationList(sorting, onlyMyUploads);
    this.hasNoDocument = this.collaborations.length == 0;
    this.activeSorting = { ...sorting };
    this.isLoading = this.store.selectSnapshot(AppState.getCollaborationLoading);
  }
}
