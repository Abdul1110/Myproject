import { Component, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { ActivatedRoute } from '@angular/router';
import { tap, takeUntil } from 'rxjs/operators';
import { Observable, Subject, merge } from 'rxjs';

import { CoreModel } from '@app/core/models';
import { GetCollaborationSuccess } from '@app/core/store/actions';
import { AnalyticService, CustomEventService, NAVIGATION_SIDE_BAR_TOGGLE } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { AppState } from '@app/core/store/states';
import { CollaborationsAction } from '../../store';
import { environment } from '@env/environment';

const { file_unsupported, server_error, file_to_large } = environment.locale.no_results.documents.document;
const { previewFileSizeLimit } = environment.appSettings;

@Component({
  selector: 'sc-collaborations-document-preview',
  templateUrl: './collaborations-document-preview.component.html'
})
export class CollaborationsDocumentPreviewComponent implements OnDestroy {
  private getDataSuccess = false;
  private destroy$ = new Subject<boolean>();
  isLoading = true;
  isError = false;
  isDocumentDownloading = false;
  documentName = '';
  documentNameWithExtension = '';
  documentId = '';
  matterId = '';
  previewUrl = '';
  fileExtension = '';
  isBigFile = false;
  bigFileWarning = file_to_large;
  maxPreviewFileSizeInBytes = previewFileSizeLimit * 1024;
  isPendingApiToBeUpdated = false;
  knownErrorMessage = '';

  isImageFile(extension: string): boolean {
    return CoreModel.Helper.isImageFile(extension);
  }

  getFileViewType(fileExtension: string): CoreModel.ViewType {
    const viewType = CoreModel.Helper.getFileViewer(fileExtension);
    return viewType;
  }

  download(matterId: string, documentId: string, documentName: string): void {
    this.isDocumentDownloading = true;
    this.store.dispatch(new CollaborationsAction.DownloadDocument({ matterId, documentId, documentName }));
  }

  getUnsupportedTitle(fileExtension: string): string {
    return `<b>.${fileExtension}</b> ${file_unsupported.title}`;
  }

  getUnsupportedMessage(): string {
    return file_unsupported.message;
  }

  getServerErrorIcon(): string {
    return server_error.icon;
  }

  getServerErrorTitle(): string {
    return this.knownErrorMessage || server_error.title;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private router: ActivatedRoute,
    private actions$: Actions,
    private customEventSvc: CustomEventService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersPreviewDocument,
        action: "View selected collaboration's document"
      });

      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: false });

      merge(
        this.getPreviewDocumentUrlSuccessSideEffect$(),
        this.getPreviewDocumentUrlFailureSideEffect$(),
        this.getDownloadDocumentSuccessSideEffect$(),
        this.getDownloadDocumentFailureSideEffect$()
      )
        .pipe(takeUntil(this.destroy$))
        .subscribe();

      const { matterId, documentId } = this.router.parent.snapshot.params;
      const result = CoreModel.Helper.getCollaborationFileByDocumentId(
        matterId,
        documentId,
        this.store.selectSnapshot(AppState.getCollaboration),
        this.store.selectSnapshot(AppState.getAllCollaborations)
      );

      this.documentId = documentId;
      this.matterId = matterId;
      this.getDataSuccess = !!(result && result.doc);

      if (!this.getDataSuccess) {
        this.getCollaborationsSuccessSideEffect$()
          .pipe(takeUntil(this.destroy$))
          .subscribe();

        //check is it pending uploads.
        const pendingCollaborations = this.store.selectSnapshot(AppState.getPendingCollaboration);
        if (pendingCollaborations && pendingCollaborations.find(f => f.fileId == this.documentId)) {
          this.isLoading = false;
          this.isPendingApiToBeUpdated = true;
        }
        return;
      }

      if (result.doc) {
        this.isBigFile = result.doc.fileSizeInBytes >= this.maxPreviewFileSizeInBytes;
      }

      if (!this.isBigFile) {
        this.dispatchPreviewUrlRequest(matterId, documentId, result.doc);
        return;
      }

      this.documentNameWithExtension = CoreModel.Helper.getValidDocumentNameWithExtension(
        result.doc.name,
        result.doc.fileExtension
      );
      this.isLoading = false;
    }
  }

  private dispatchPreviewUrlRequest(matterId: string, documentId: string, doc: CoreModel.Doc): void {
    const isImage = this.isImageFile(doc.fileExtension);
    this.fileExtension = doc.fileExtension;
    this.documentName = doc.name;
    this.documentNameWithExtension = CoreModel.Helper.getValidDocumentNameWithExtension(doc.name, doc.fileExtension);

    this.store.dispatch(new CollaborationsAction.PreviewDocument({ matterId, documentId, isImage }));
  }

  private getCollaborationsSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetCollaborationSuccess),
      tap(success => {
        const result = CoreModel.Helper.getCollaborationFileByDocumentId(
          this.matterId,
          this.documentId,
          this.store.selectSnapshot(AppState.getCollaboration),
          this.store.selectSnapshot(AppState.getAllCollaborations)
        );

        // document has been deleted;
        this.knownErrorMessage = '';
        if (result && !result.doc) {
          this.isLoading = false;
          if (!this.isError && !this.isPendingApiToBeUpdated) {
            this.knownErrorMessage = 'The document no longer available';
            this.isError = true;
          }
          return;
        }

        if (result && result.doc && result.doc.fileSizeInBytes) {
          this.isBigFile = result.doc.fileSizeInBytes >= this.maxPreviewFileSizeInBytes;
        }

        if (!this.isBigFile) {
          this.getPreviewDocumentUrl(this.matterId, this.documentId);
          return;
        }

        this.documentNameWithExtension = CoreModel.Helper.getValidDocumentNameWithExtension(
          result.doc.name,
          result.doc.fileExtension
        );
        this.isLoading = false;
      })
    );
  }

  private getPreviewDocumentUrlSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.PreviewDocumentSuccess),
      tap(({ payload: url }) => {
        this.isLoading = false;
        this.previewUrl = url;
      })
    );
  }

  private getPreviewDocumentUrlFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.PreviewDocumentFailure),
      tap(err => {
        this.isLoading = false;
        this.isError = true;
      })
    );
  }

  private getPreviewDocumentUrl(matterId: string, documentId: string): void {
    const result = CoreModel.Helper.getCollaborationFileByDocumentId(
      matterId,
      documentId,
      this.store.selectSnapshot(AppState.getCollaboration),
      this.store.selectSnapshot(AppState.getAllCollaborations)
    );
    this.getDataSuccess = !!(result && result.doc);

    if (this.getDataSuccess) {
      this.dispatchPreviewUrlRequest(matterId, documentId, result.doc);
      return;
    }

    this.isLoading = false;
    this.isError = true;
  }

  private getDownloadDocumentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.DownloadDocumentSuccess),
      tap(() => {
        this.isDocumentDownloading = false;
      })
    );
  }

  private getDownloadDocumentFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.DownloadDocumentFailure),
      tap(() => {
        this.isDocumentDownloading = false;
        this.isError = true;
      })
    );
  }
}
