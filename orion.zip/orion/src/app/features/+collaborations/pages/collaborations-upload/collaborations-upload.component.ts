import {
  Component,
  OnInit,
  OnDestroy,
  HostBinding,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  ElementRef
} from '@angular/core';
import { FileUploader, FileItem, FileLikeObject } from 'ng2-file-upload';
import { Store } from '@ngxs/store';
import { UUID } from 'angular2-uuid';
import { collapseOnLeaveAnimation, expandOnEnterAnimation } from 'angular-animations';
import { LyraDesignFormModel } from '@leap/lyra-design';
import { CollaborationsAction } from '../../store';
import { Observable, Subject, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { environment } from '@env/environment';
import { DialogService } from '@app/shared/services';
import { CoreModel } from '@app/core/models/core.model';
import { AppState } from '@app/core/store/states/app.state';
import {
  UpdateUploadCancelFlag,
  DeleteUploadDraft,
  RemoveUploadDraftFromStore,
  DeleteStaleUploadDrafts,
  UpdateUploadCompleteFlag
} from '@app/core/store/actions';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { UploadService } from '@app/core/services/lawconnect/upload.service';
// import { CollaborationsModel } from '../../models/collaborations.model';

const { locale } = environment;

@Component({
  selector: 'sc-collaborations-upload',
  templateUrl: './collaborations-upload.component.html',
  animations: [collapseOnLeaveAnimation(), expandOnEnterAnimation()]
})
export class CollaborationsUploadComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<boolean>();
  private uploadQueue: FileItem[] = [];

  isCollapsed = false;
  lastUploadCompletedId = '';
  validFileExtensions: string;
  cancelAll: boolean = false;
  startAll: boolean = false;
  removeAll: boolean = false;

  @Input('firm-id') firmId: string;

  @Input('matter-id') matterId: string;

  @Input('matter-name') matterName: string;

  @Input('open')
  set openFileSelect(v: string) {
    if (v) {
      setTimeout(() => {
        this.dragLeave.emit(false);
        this.fileSelect.nativeElement.click();
      }, 0);
    }
  }

  @Input('drag-enter') dragEnter: boolean;

  @Output('drag-leave') dragLeave = new EventEmitter<boolean>();

  @Output('upload-start') uploadStart = new EventEmitter<string>();

  uploader: FileUploader = new FileUploader({
    url: '',
    disableMultipart: true,
    filters: [
      {
        name: 'extension',
        fn: (item: any): boolean => {
          const fileExtension = item.name.substring(item.name.lastIndexOf('.') + 1);
          return CoreModel.Helper.getValidFileTypes().includes(fileExtension);
        }
      }
    ]
  });

  @ViewChild('fileselect', { read: ElementRef, static: true })
  private fileSelect: ElementRef;

  drafts$ = this.appActionSvc.drafts$;
  drafts: CoreModel.DraftDocument[] = [];
  showDropZone = false;
  hasBaseDropZoneOver: boolean = false;

  fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
    this.showDropZone = true;
  }

  onDragLeave(): void {
    this.dragLeave.emit(false);
  }

  removeUpload(data: { f: FileItem; draftCreated: boolean; documentId: string }): void {
    const { f, draftCreated, documentId } = data;

    if (draftCreated) {
      this.store.dispatch(new DeleteUploadDraft([documentId]));
    } else {
      this.store.dispatch(new RemoveUploadDraftFromStore([f.alias]));
    }

    f.remove();
  }

  cancelUpload(data: { f: FileItem; hasCanceled: boolean; localId: string }): void {
    this.store.dispatch(new UpdateUploadCancelFlag([{ localId: data.localId, flag: data.hasCanceled }]));
  }

  resumeUpload(data: { f: FileItem; hasCanceled: boolean; localId: string }): void {
    this.store.dispatch(new UpdateUploadCancelFlag([{ localId: data.localId, flag: data.hasCanceled }]));
  }

  uploadFile(f: FileItem): void {
    const folders: CoreModel.Collaboration[] = this.getAllCollaborationFolders();

    const options: LyraDesignFormModel.SelectOption[] = folders.map(
      f => <LyraDesignFormModel.SelectOption>{ id: f.id, name: `${f.name}`, value: f }
    );

    this.dragEnter = false;
    this.uploadQueue = [].concat(this.uploadQueue).concat(f);

    const uploadIndex = this.uploader.queue.findIndex(x => x.file.name == f.file.name);

    if (uploadIndex == this.uploader.queue.length - 1) {
      const currentCollaboration = this.store.selectSnapshot(AppState.getCollaboration);
      const hasMoreThanOneCollaborationFolders = currentCollaboration && Object.keys(currentCollaboration).length > 1;

      const navigationPaths = this.store.selectSnapshot(AppState.getNavigation);
      const stillOnTopLevelPath = !navigationPaths || navigationPaths.length < 2;

      const defaultFolderId =
        (navigationPaths && navigationPaths.length > 0 && navigationPaths[navigationPaths.length - 1].id) ||
        (folders.length == 1 && folders[0].id);

      if (hasMoreThanOneCollaborationFolders && stillOnTopLevelPath) {
        this.dialogSvc.folderSelections({
          title: 'Select Upload Location',
          folderOptions: options,
          defaultFolderId: defaultFolderId || undefined,
          onClose: (folderId: string) => {
            if (!folderId) {
              this.uploadQueue.forEach(q => q.remove());
              this.uploadQueue = [];
              return;
            }

            const folder = folders.find(x => x.id == folderId);
            let collaborationRootId =
              folder.level <= 0 || folder.level == undefined ? folder.id : this.getParent(folder, 1, folder.level).id;

            this.store.dispatch(
              new CollaborationsAction.CreateUploadDraft({
                files: this.uploadQueue,
                matterName: this.matterName,
                folderId: folderId && folderId.replace('empty-1', ''),
                collaborationRootId: collaborationRootId && `${collaborationRootId}`.replace('empty-1', ''),
                matterId: this.matterId,
                firmId: this.firmId
              })
            );

            this.uploadStart.emit(UUID.UUID());

            this.uploadQueue = [];
          }
        });
        return;
      }

      this.store.dispatch(
        new CollaborationsAction.CreateUploadDraft({
          files: this.uploadQueue,
          matterName: this.matterName,
          folderId: defaultFolderId || '',
          collaborationRootId: folders[0].id,
          matterId: this.matterId,
          firmId: this.firmId
        })
      );

      this.uploadStart.emit(UUID.UUID());

      this.uploadQueue = [];
    }
  }

  getDocumentId(localId: string, draft: CoreModel.DraftDocument[]): string {
    if (draft) {
      const x = draft.find(z => z.id == localId);
      return x ? x.documentId : undefined;
    }

    return undefined;
  }

  getDocumentUploadInfo(localId: string, draft: CoreModel.DraftDocument[]): CoreModel.DraftDocument {
    if (draft) {
      const x = draft.find(z => z.id == localId);
      return x;
    }
    return undefined;
  }

  isCompleted(draft: CoreModel.DraftDocument[]): boolean {
    if (draft) {
      const completedUploads = draft.filter(z => z.done);
      const countUploads = draft;
      return completedUploads.length === countUploads.length;
    }
    return false;
  }

  getUploadCount(draft: CoreModel.DraftDocument[]): number {
    if (draft) {
      const completedUploads = draft;
      return completedUploads.length;
    }
    return 0;
  }

  getUploadCompletedCount(draft: CoreModel.DraftDocument[]): number {
    if (draft) {
      const completedUploads = draft.filter(z => z.done);
      return completedUploads.length;
    }
    return 0;
  }

  getUploadCompletedCountText(draft: CoreModel.DraftDocument[]): string {
    if (draft) {
      const completedUploads = draft.filter(z => z.done);
      return completedUploads && completedUploads.length > 0
        ? completedUploads.length === 1
          ? `Uploaded ${completedUploads.length} ${locale.matters.select.document}`
          : `Uploaded ${completedUploads.length} ${locale.matters.select.documents}`
        : 'Uploading';
    }
    return '';
  }

  doneUpload(data: { documentId: string; f: FileItem }): void {
    this.store.dispatch(new RemoveUploadDraftFromStore([data.f.alias]));
    data.f.remove();
  }

  trackElement(index: number, element: any) {
    return element ? element.alias : index;
  }

  setCollapseUploadContent(): void {
    this.isCollapsed = !this.isCollapsed;
  }

  showContent(): boolean {
    return this.uploader && this.uploader.queue.length > 0;
  }

  uploadCompleted(documentId: string, id: string): void {
    this.lastUploadCompletedId = documentId;
    this.store.dispatch(new UpdateUploadCompleteFlag([{ localId: id, flag: true }]));
  }

  onError(error: string, id: string) {
    if (error) {
      this.store.dispatch(new UpdateUploadCompleteFlag([{ localId: id, flag: true }]));
    }
  }

  closeUploader(): void {
    this.cancelAll = true;
    const hasUploadedAll = this.uploadSvc.canNavigate(this.drafts);

    if (!hasUploadedAll) {
      this.dialogSvc.confirm({
        title: 'Confirmation',
        message: locale.matters.upload.cancel_warning,
        actionText: 'Continue',
        closeText: 'Cancel',
        showCancel: true,
        onClose: (confirmed: boolean) => {
          if (confirmed) {
            const pendingDocumentIds = this.drafts.filter(d => !d.done).map(x => x.documentId);
            this.store.dispatch(new DeleteStaleUploadDrafts(pendingDocumentIds));
            this.removeAll = true;
            setTimeout(() => this.reset(true), 500);
          } else {
            this.startAll = true;
            setTimeout(() => this.reset(false), 500);
          }
        }
      });
    } else {
      setTimeout(() => this.reset(true), 500);
    }
  }

  reset(cleanQueue: boolean): void {
    this.cancelAll = false;
    this.startAll = false;
    this.removeAll = false;
    if (cleanQueue === true) {
      this.uploader.queue = [];
    }
  }

  constructor(
    private store: Store,
    private dialogSvc: DialogService,
    private uploadSvc: UploadService,
    private appActionSvc: AppActionService
  ) {
    this.fileUploaderEvents();

    this.validFileExtensions = CoreModel.Helper.getValidFileTypes()
      .map(x => {
        return '.'.concat(x);
      })
      .join(',');

    merge(this.draftUploadStateSideEffect$())
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  @HostBinding('class') classes = 'x-upload';

  ngOnInit(): void {}

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }

  private fileUploaderEvents(): void {
    this.uploader.onWhenAddingFileFailed = (item: FileLikeObject, filter: any, options: any) => {
      const message = 'This file type is not supported and could not be uploaded.';
      this.store.dispatch(new CollaborationsAction.DocumentUploadFailure(message));
      this.dragLeave.emit(false);
    };

    const self = this;
    this.uploader.onAfterAddingFile = function(item) {
      item.alias = UUID.UUID();
      self.dragLeave.emit(false);
      return item;
    };
  }

  private draftUploadStateSideEffect$(): Observable<CoreModel.DraftDocument[]> {
    return this.appActionSvc.drafts$.pipe(
      tap(d => {
        this.drafts = d;
        if (d && d.length > 0) {
          const uploaderIds = this.uploader.queue.map(x => x.alias);
          const unusedDraftDocumentIds = d
            //upload-draft is not in the uploader queue and it was never completed, then delete it.
            .filter(x => uploaderIds.findIndex(z => z == x.id) < 0 && !x.done)
            .map(c => c.documentId);
          if (unusedDraftDocumentIds && unusedDraftDocumentIds.length > 0) {
            this.store.dispatch(new DeleteStaleUploadDrafts(unusedDraftDocumentIds));
          }

          const completedDraftIds = d
            //upload-draft is not in the uploader queue and it was  completed, then remove it from state.
            .filter(x => uploaderIds.findIndex(z => z == x.id) < 0 && x.done)
            .map(c => c.id);
          if (completedDraftIds && completedDraftIds.length > 0) {
            this.store.dispatch(new RemoveUploadDraftFromStore(completedDraftIds));
          }
        }
      })
    );
  }

  private getParent(p: any, current: number, max: number): any {
    if (current == max) {
      return p.parent;
    }
    return this.getParent(p.parent, current + 1, max);
  }

  private getAllCollaborationFolders(): CoreModel.Collaboration[] {
    const collaborations = this.store.selectSnapshot(AppState.getCollaboration) as {
      [rootId: string]: CoreModel.Collaboration[];
    };

    if (!collaborations) {
      return [];
    }

    let folders: CoreModel.Collaboration[] = [];

    const hasMoreThanOneGroup = Object.keys(collaborations).length > 1;

    Object.keys(collaborations).forEach(rootId => {
      if (hasMoreThanOneGroup && rootId == 'empty') {
        return;
      }

      const rootFolder = collaborations[rootId][0];
      const temp = this.getAllFolders(rootFolder, undefined, 0);

      if (folders && temp) {
        folders = [].concat(folders).concat(temp);
        return;
      }

      if (folders) {
        folders = [].concat(folders);
        return;
      }

      if (temp) {
        folders = [].concat(temp);
        return;
      }
    });

    return folders;
  }

  private getAllFolders(
    folder: CoreModel.Collaboration,
    parentFolder: CoreModel.Collaboration,
    level: number
  ): CoreModel.Collaboration[] {
    if (folder.folders && folder.folders.length > 0) {
      const temp = folder.folders
        .map(x => this.getAllFolders(x, folder, level + 1))
        .reduce((a, b) => {
          return a.concat(b);
        });

      const folderWithLevel = folder && folder.level !== undefined ? folder : Object.assign({}, folder, { level });

      return temp && temp.length > 0
        ? parentFolder
          ? level == 1 && temp.findIndex(x => x.id == parentFolder.id) == -1
            ? [].concat(folderWithLevel).concat(temp)
            : [].concat(folderWithLevel).concat(temp)
          : [].concat(folderWithLevel).concat(temp)
        : [];
    }

    return [Object.assign({}, folder, { level })];
  }
}
