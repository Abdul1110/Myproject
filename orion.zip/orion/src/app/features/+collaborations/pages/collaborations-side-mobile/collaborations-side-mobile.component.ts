import { ChangeDetectionStrategy, Component, Input, HostBinding, Inject } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { CollaborationsEvent } from '../../models/event.model';

@Component({
  selector: 'sc-collaborations-side-mobile',
  templateUrl: './collaborations-side-mobile.component.html'
})
export class CollaborationsSideMobileComponent {
  title = '';
  subtitle = '';

  isViewDetail(): boolean {
    return this.data && this.data.actionType == CollaborationsEvent.MultipleActionDispatchType.viewInfo;
  }

  isViewAttachment(): boolean {
    return this.data && this.data.actionType == CollaborationsEvent.MultipleActionDispatchType.viewAttachmentList;
  }

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  constructor(
    private bottomSheetRef: MatBottomSheetRef<CollaborationsSideMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';
  }
}
