import { Component, OnDestroy } from '@angular/core';
import { Store, ofActionSuccessful, Actions } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subject, merge } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { Location } from '@angular/common';

import { environment } from '@env/environment';
import { CustomEventService, COLLABORATIONS_SIDE_TAB_SWITCH } from '@app/core/services';
import { GetCollaborationFailure } from '@app/core/store/actions';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { CoreModel } from '@app/core/models';
import { AppState } from '@app/core/store/states';
import { CollaborationsModel } from '../../models/collaborations.model';

const { details, attachments } = environment.locale.global.side_menu;

@Component({
  selector: 'sc-collaborations-side',
  templateUrl: './collaborations-side.component.html'
})
export class CollaborationsSideComponent implements OnDestroy {
  isPreview = false;
  documentId = '';
  matterId: '';
  selectedTabId = CollaborationsModel.CollaborationTabId.details;
  collaborationDetail = undefined;
  isLoading = true;

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  changeDisplay(id: CollaborationsModel.CollaborationTabId): void {
    this.selectedTabId = id;
  }

  isSelected(tabId: string, selectedTabId: string): boolean {
    return tabId == selectedTabId;
  }

  tabsFilter(hasAttachment: boolean): { title: string; id: string }[] {
    if (hasAttachment) {
      return this.tabs;
    }
    return this.tabs.filter(t => t.id !== CollaborationsModel.CollaborationTabId.attachments);
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private route: ActivatedRoute,
    private appActionSvc: AppActionService,
    private customEventSvc: CustomEventService,
    private actions$: Actions,
    private location: Location
  ) {
    this.documentId = this.route.snapshot.params['documentId'] || '';
    this.matterId = (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';

    const locationState = this.location.getState();
    if (locationState && !!locationState['isAttachmentTab']) {
      this.selectedTabId = CollaborationsModel.CollaborationTabId.attachments;
    }

    merge(
      this.currentCollaborationSideEffect$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.getCollaborationsFailureSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private destroy$ = new Subject<boolean>();
  private tabs = [
    { title: details, id: CollaborationsModel.CollaborationTabId.details },
    { title: attachments, id: CollaborationsModel.CollaborationTabId.attachments }
  ];

  private getCollaborationsFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetCollaborationFailure),
      tap(error => {
        this.isLoading = false;
      })
    );
  }

  private currentCollaborationSideEffect$(): Observable<{}> {
    return this.appActionSvc.collaborations$.pipe(
      tap(v => {
        this.collaborationDetail = this.getCollaborationDetail(
          v,
          this.store.selectSnapshot(AppState.getAllCollaborations)
        );
        if (v) {
          this.isLoading = false;
        }
      })
    );
  }

  private getCollaborationDetail(currentCollaborations: {}, allCollaborations: {}): CoreModel.Doc {
    if (this.matterId && this.documentId) {
      const result = CoreModel.Helper.getCollaborationFileByDocumentId(
        this.matterId,
        this.documentId,
        currentCollaborations,
        allCollaborations
      );
      return (result && result.doc) || undefined;
    }
    return undefined;
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_SIDE_TAB_SWITCH, ({ tabId, id, ...others }) => {
      this.changeDisplay(tabId);

      if (this.documentId !== id) {
        this.documentId = id;
        this.isLoading = true;
        this.collaborationDetail = this.getCollaborationDetail(
          this.store.selectSnapshot(AppState.getCollaboration),
          this.store.selectSnapshot(AppState.getAllCollaborations)
        );
        this.isLoading = false;
      }
    });
  }
}
