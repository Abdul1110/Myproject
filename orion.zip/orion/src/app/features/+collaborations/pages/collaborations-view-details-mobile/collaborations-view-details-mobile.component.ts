import { Component, ChangeDetectionStrategy, OnDestroy, Inject, HostBinding } from '@angular/core';
import { Subject } from 'rxjs';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { CustomEventService, COLLABORATIONS_MULTIPLE_ACTIONS } from '@app/core/services';
import { CollaborationsEvent } from '../../models/event.model';
// import { CollaborationModel } from '../../models/collaborations.model';

@Component({
  selector: 'sc-collaborations-view-details-mobile',
  templateUrl: './collaborations-view-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CollaborationsViewDetailsMobileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  title = '';
  subtitle = '';

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  isGlobal(data: any): boolean {
    return data && data.isGlobal;
  }

  isFolder(data: any): boolean {
    return data && (data.isFolder || (data.item && data.item.fileExtension == 'folder'));
  }

  hasAttachments(data: any): boolean {
    if (data && data.attachments && data.attachments.length > 0) {
      return true;
    }

    return false;
  }

  isDeletable(data: any): boolean {
    if (data && data.isDeletable && !!!data.hidePreview) {
      return true;
    }

    return false;
  }

  previewDocument(data: any): void {
    this.dispatchEvent(CollaborationsEvent.MultipleActionDispatchType.preview, data);
    this.bottomSheetRef.dismiss();
  }

  upload(data: any): void {
    this.dispatchEvent(CollaborationsEvent.MultipleActionDispatchType.upload, data);
    this.bottomSheetRef.dismiss();
  }

  download(data: any): void {
    this.dispatchEvent(CollaborationsEvent.MultipleActionDispatchType.download, data);
    this.bottomSheetRef.dismiss();
  }

  viewInfo(data: any): void {
    this.dispatchEvent(CollaborationsEvent.MultipleActionDispatchType.viewInfo, data);
    this.bottomSheetRef.dismiss();
  }

  delete(data: any): void {
    this.dispatchEvent(CollaborationsEvent.MultipleActionDispatchType.delete, data);
    this.bottomSheetRef.dismiss();
  }

  viewAttachmentList(data: any): void {
    this.dispatchEvent(CollaborationsEvent.MultipleActionDispatchType.viewAttachmentList, data);
    this.bottomSheetRef.dismiss();
  }

  showPreview(data: any): boolean {
    return data && !this.isFolder(data) && !!!data.hidePreview;
  }

  constructor(
    private customEventSvc: CustomEventService,
    private bottomSheetRef: MatBottomSheetRef<CollaborationsViewDetailsMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';
  }

  @HostBinding('class.x-action-list')
  ngOnDestroy() {
    this.destroy$.next();
  }

  private dispatchEvent(actionType: string, data: any): void {
    this.customEventSvc.dispatchEvent(COLLABORATIONS_MULTIPLE_ACTIONS, {
      actionType,
      value: { ...this.data }
    });
  }
}
