import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';

import { CanComponentDeactivate } from '@app/shared/models';
import { DialogService } from '@app/shared/services';
import { environment } from '@env/environment';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';

const { locale } = environment;
@Injectable()
export class UploadGuard implements CanDeactivate<CanComponentDeactivate> {
  constructor(private dialogSvc: DialogService, private appActionSvc: AppActionService) {}

  canDeactivate(component: CanComponentDeactivate) {
    return Observable.create(obs => {
      if (!component || !component.canDeactivate || component.canDeactivate()) {
        return obs.next(true);
      } else {
        this.dialogSvc.confirm({
          title: 'Navigation Confirmation',
          message: locale.matters.upload.navigation_away_warning,
          actionText: 'Continue',
          closeText: 'Cancel',
          showCancel: true,
          onClose: (confirmed: boolean) => {
            if (confirmed) {
              this.appActionSvc.deletePendingUploads();

              obs.next(true);
            } else {
              obs.next(false);
            }
          }
        });
      }
    });
  }
}
