import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CoreModel } from '@app/core/models';
import { environment } from '@env/environment';
@Component({
  selector: 'sc-collaboration-side-details',
  templateUrl: './collaboration-side-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CollaborationSideDetailsComponent {
  @Input('data') data: CoreModel.Doc;
  documentMessage = environment.locale.no_results.details.empty;

  fileSize(fs: number): string {
    if (!fs || fs === 0) {
      return '0 KB';
    }

    const sizes = [' KB', ' MB', ' GB'];
    const i = Math.floor(Math.log(fs) / Math.log(1024));
    const sizeAbbIndex = i - 1 >= 0 ? i - 1 : 0;
    const fileSize =
      i < 3 ? Math.round(fs / Math.pow(1024, i)) + sizes[sizeAbbIndex] : Math.round(fs / Math.pow(1024, 2)) + sizes[2];
    return fileSize;
  }

  hasValidDetail(data: CoreModel.Doc): boolean {
    if (!data || !(data.id && data.name)) {
      return false;
    }

    return true;
  }

  constructor() {}
}
