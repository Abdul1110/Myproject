import {
  ChangeDetectionStrategy,
  Component,
  Input,
  EventEmitter,
  Output,
  OnInit,
  OnDestroy,
  ChangeDetectorRef,
  NgZone,
  HostBinding
} from '@angular/core';
import { collapseAnimation, collapseOnLeaveAnimation, expandOnEnterAnimation } from 'angular-animations';
import { Subject } from 'rxjs';
import { FileItem, FileUploader, FileUploaderOptions } from 'ng2-file-upload';
import { LyraAnimation } from '@leap/lyra-design';
import { CoreModel } from '@app/core/models';

@Component({
  selector: 'sc-collaboration-upload-item',
  templateUrl: './collaboration-upload-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [collapseOnLeaveAnimation(), expandOnEnterAnimation()]
})
export class CollaborationUploadItemComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<boolean>();
  private uploader: FileUploader;
  private uploadFileItem: FileItem;
  private progress: number = 0;
  public isProgress: boolean;

  error = '';
  private uploadTriggered = false;
  _item: FileItem = undefined;

  @Input('document-id') documentId: string;

  @Input('item')
  get item() {
    return this._item;
  }
  set item(v: any) {
    this._item = v;

    if (v && !this.uploadTriggered) {
      setTimeout(() => this.upload.emit(v), 0);
    }
  }
  @Input('removeAll')
  set removeAll(v: boolean) {
    if (v === true) {
      this.reset();
    }
  }

  @Input('cancelAll')
  set cancelAll(v: boolean) {
    if (v === true) {
      this.cancelItem(this._item);
    }
  }

  @Input('startAll')
  set startAll(v: boolean) {
    if (v === true) {
      this.startItem(this._item);
    }
  }

  @Input('items') items;

  @Input('upload-info') uploadInfo: CoreModel.DraftDocument;

  @Input('refresh-ui') lastCompletedUploadId: string;

  @Output('upload') upload = new EventEmitter<FileItem>();

  @Output('resume') resume = new EventEmitter<{ f: FileItem; hasCanceled: boolean; localId: string }>();

  @Output('cancel') cancel = new EventEmitter<{ f: FileItem; hasCanceled: boolean; localId: string }>();

  @Output('remove') remove = new EventEmitter<{ f: FileItem; draftCreated: boolean; documentId: string }>();

  @Output('done') done = new EventEmitter<{ documentId: string; f: FileItem }>();

  @Output('upload-completed') uploadCompleted = new EventEmitter<string>();

  @Output('upload-error') uploadError = new EventEmitter<string>();

  constructor(private cd: ChangeDetectorRef, private ngZone: NgZone) {}

  @HostBinding('class.x-upload_item')
  ngOnInit() {}

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }

  showProgress(): boolean {
    if (this.lastCompletedUploadId == this.documentId) {
      return false;
    }
    if (this.isDocumentUploaded() && this.isDocumentSuccess()) {
      return false;
    }
    if (this.isDocumentUploading() || this.isDocumentUploaded() || this.isDocumentResume()) {
      return true;
    }
  }

  uploadItem(i: FileItem): void {
    this.upload.emit(i);
  }

  removeItem(i: FileItem): void {
    this.remove.emit({ f: i, draftCreated: this.hasDocumentS3InfoCreated(), documentId: this.documentId });
    this.reset();
  }

  cancelItem(i: FileItem): void {
    if (this.uploadFileItem) {
      this.uploadFileItem.cancel();
    }
  }

  startItem(i: FileItem): void {
    if (this.uploadFileItem) {
      this.uploadFileItem.upload();
    }
  }

  doneItem(i: FileItem): void {
    this.done.emit({ documentId: this.documentId, f: i });
    this.reset();
  }

  getItemSize(i: FileItem): string {
    if (!i || !i.file || !i.file.size) {
      return '0 MB';
    }

    const szInMB = Math.round(i.file.size / 1024 / 1024).toString();
    if (szInMB !== '0') {
      return `${szInMB} MB`;
    }

    const szInKB = Math.round(i.file.size / 1024).toString();
    if (szInKB !== '0') {
      return `${szInKB} KB`;
    }

    return `${Math.round(i.file.size)} bytes`;
  }

  getIcon(item: FileItem): string {
    const fileName = item.file.name;
    const ext = fileName.substring(fileName.lastIndexOf('.') + 1);

    return CoreModel.Helper.getDocTypeIcon(ext);
  }

  hasDocumentS3InfoCreated(): boolean {
    if (!this.uploadInfo) {
      return false;
    }

    const created = this.uploadInfo.documentId === this.documentId;

    if (created && !this.uploader && !this.uploadInfo.done) {
      const { fileContentType, documentId, uploadUrl } = this.uploadInfo;
      const option: FileUploaderOptions = {
        headers: [
          { name: 'Content-Type', value: fileContentType },
          { name: 'x-amz-meta-lcweb-action', value: 'file-upload' },
          { name: 'x-amz-meta-lcweb-docid', value: documentId }
        ],
        url: uploadUrl,
        disableMultipart: true,
        method: 'PUT'
      };

      this.uploader = new FileUploader(option);
      this.uploader.addToQueue([this.item._file]);
      this.uploadFileItem = this.uploader.queue[0];
      this.uploadFileItem.upload();

      this.uploadFileItem.onProgress = (progress: number) => {
        this.progress = progress;
        this.cd.detectChanges();
      };

      const self = this;
      this.uploader.onErrorItem = this.ngZone.run(
        () =>
          function(item: FileItem, response: string, status: number) {
            self.error = response || 'error';
            self.uploadError.emit(self.error);
            self.cd.detectChanges();
          }
      );
    }

    return created;
  }

  isDocumentCancel(): boolean {
    if (!this.uploadInfo) {
      return false;
    }
    return this.isDocumentUploading() && !this.uploadInfo.uploadCancel;
  }

  isDocumentResume(): boolean {
    if (!this.uploadInfo) {
      return false;
    }
    return !this.isDocumentUploading() && this.uploadInfo.uploadCancel;
  }

  isDocumentUploading(): boolean {
    return this.hasDocumentS3InfoCreated() && this.uploadFileItem && this.uploadFileItem.isUploading;
  }

  isDocumentUploaded(): boolean {
    if (this.documentId === this.lastCompletedUploadId) {
      return true;
    }

    return (
      this.hasDocumentS3InfoCreated() &&
      this.uploadFileItem &&
      this.uploadFileItem.isUploaded &&
      !this.uploadFileItem.isError
    );
  }

  getProgressBar(): number {
    if (this.progress >= 100) {
      this.uploadCompleted.emit(this.documentId);
    }

    return this.progress;
  }

  getDoneText(): string {
    return this.progress === 100 ? `uploading` : `${this.progress}% uploading`;
  }

  isDocumentSuccess(): boolean {
    if (this.documentId === this.lastCompletedUploadId) {
      return true;
    }

    if (this.hasDocumentS3InfoCreated() && this.uploadFileItem && this.uploadFileItem.isSuccess) {
      return true;
    }
  }

  isDocumentError(): boolean {
    if (this.hasDocumentS3InfoCreated() && this.uploadFileItem && this.uploadFileItem.isError) {
      return true;
    }
  }

  getDoneType(): string {
    if (this.hasDocumentS3InfoCreated() && this.uploadFileItem && this.uploadFileItem.isError) {
      return 'danger';
    }
    if (
      this.hasDocumentS3InfoCreated() &&
      this.uploadFileItem &&
      (this.uploadFileItem.isSuccess || this.uploadFileItem.progress == 100)
    ) {
      return 'success';
    }
    if (this.hasDocumentS3InfoCreated() && this.uploadFileItem && this.uploadFileItem.isCancel) {
      return 'info';
    }
  }

  private reset(): void {
    this.documentId = undefined;
    if (this.uploader) {
      this.uploader.clearQueue();
      this.uploader.destroy();
      this.uploader = undefined;
    }

    if (this.uploadFileItem) {
      this.uploadFileItem.onProgress = undefined;
      this.uploadFileItem = undefined;
    }
  }
}
