import { CollaborationSideDetailsComponent } from './collaboration-side-details/collaboration-side-details.component';
import { CollaborationSideAttachmentsComponent } from './collaboration-side-attachments/collaboration-side-attachments.component';
import { CollaborationListItemComponent } from './collaboration-list-item/collaboration-list-item.component';
import { CollaborationUploadItemComponent } from './collaboration-upload-item/collaboration-upload-item.component';

export * from './collaboration-side-details/collaboration-side-details.component';
export * from './collaboration-side-attachments/collaboration-side-attachments.component';
export * from './collaboration-list-item/collaboration-list-item.component';
export * from './collaboration-upload-item/collaboration-upload-item.component';

export const collaborationsComponents = [
  CollaborationSideDetailsComponent,
  CollaborationSideAttachmentsComponent,
  CollaborationListItemComponent,
  CollaborationUploadItemComponent
];
