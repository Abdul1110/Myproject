import { ChangeDetectionStrategy, Component, Input, Inject, LOCALE_ID } from '@angular/core';
import { CoreModel } from '@app/core/models';
import {
  CustomEventService,
  COLLABORATIONS_SIDE_TAB_SWITCH,
  COLLABORATIONS_LIST_FOLDER_OPEN,
  COLLABORATIONS_LIST_FILE_PREVIEW,
  COLLABORATIONS_LIST_FILE_DELETE,
  COLLABORATIONS_MULTIPLE_ACTIONS_OPEN,
  COLLABORATIONS_SIDE_TAB_TOGGLE
} from '@app/core/services';
import { CollaborationsModel } from '../../models/collaborations.model';
import { Store } from '@ngxs/store';
import { CollaborationsAction } from '../../store';

@Component({
  selector: 'sc-collaboration-list-item',
  templateUrl: './collaboration-list-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [
    `
      .mb-6 {
        margin-bottom: 60px;
      }

      .mb-8 {
        margin-bottom: 80px;
      }

      .mb-10 {
        margin-bottom: 100px;
      }

      .mb-12 {
        margin-bottom: 120px;
      }
    `
  ]
})
export class CollaborationListItemComponent {
  @Input('data') data: CollaborationsModel.CollaborationItem;
  @Input('matter-id') matterId: string;
  @Input('last-item') isLastItem: boolean;
  @Input('current-user') currentUser: CoreModel.LogonUserInfo;
  @Input('small-screen') isSmallScreen: boolean;
  @Input('is-active') isActive: boolean;
  @Input('is-uploading') isUploading: boolean;
  @Input('screen-height') screenHeight: Number;

  get isFolderHeader(): boolean {
    return !!(this.data && this.data.isFolderHeader);
  }

  get groupTitle(): string {
    return (this.data && this.data.name) || '-';
  }

  get groupOtherUsers(): CoreModel.OtherUser[] {
    return (this.data && this.data.otherUsers) || [];
  }

  getRootCss(isLast: boolean, isSmallScreen: boolean): string {
    if (isLast && this.screenHeight < 1300) {
      if (isSmallScreen) {
        // ipad
        if (this.screenHeight >= 1024) {
          return 'x-file-complex mb-8';
        }
        // iphone x
        if (this.screenHeight >= 812) {
          return 'x-file-complex mb-10';
        }
        // galaxy s5
        return 'x-file-complex mb-12';
      }

      return 'x-file-complex mb-6';
    }

    return 'x-file-complex';
  }

  getIcon(ext: string): string {
    return CoreModel.Helper.getDocTypeIcon(ext);
  }

  getLastModifiedDate(): Date {
    return this.data.lastModified || this.data.createDate;
  }

  getOwnerInitial(): CoreModel.User {
    if (this.data) {
      const displayName = (this.currentUser && this.currentUser.displayName) || '';
      return this.data.isDeletable
        ? { initial: CoreModel.Helper.getUserInitial(displayName), name: displayName }
        : {
            initial: this.data.ownerInitials || CoreModel.Helper.getUserInitial(this.data.ownerName),
            name: this.data.ownerName
          };
    }

    return { initial: '', name: '' };
  }

  openActionSheet(): void {
    this.customEventSvc.dispatchEvent(COLLABORATIONS_MULTIPLE_ACTIONS_OPEN, {
      ...this.data,
      title: this.data.isFolder
        ? this.data.name
        : CoreModel.Helper.getValidDocumentNameWithExtension(this.data.name, this.data.fileExtension),
      subTitle: this.data.createDate
        ? `Created on ${CollaborationsModel.Helper.localeFormat(this.data.createDate, this.locale)}`
        : ''
    });
  }

  isFolder(): boolean {
    return !!(this.data && this.data.isFolder);
  }

  isDeletable(): boolean {
    return !!(this.data && this.data.isDeletable);
  }

  isAttachment(): boolean {
    return !!(this.data && this.data.attachments && this.data.attachments.length > 0);
  }

  preview(item: CollaborationsModel.CollaborationItem): void {
    item.isFolder && this.customEventSvc.dispatchEvent(COLLABORATIONS_LIST_FOLDER_OPEN, { ...item });

    if (!item.isFolder) {
      this.customEventSvc.dispatchEvent(COLLABORATIONS_LIST_FILE_PREVIEW, { ...item });
      this.customEventSvc.dispatchEvent(COLLABORATIONS_SIDE_TAB_TOGGLE, { show: true });
    }
  }

  download(item: CollaborationsModel.CollaborationItem): void {
    this.viewSideDetail(item);
    const documentName = CoreModel.Helper.getValidDocumentNameWithExtension(item.name, item.fileExtension);
    const documentId = item.id;
    if (documentName && this.matterId) {
      this.store.dispatch(
        new CollaborationsAction.DownloadDocument({ matterId: this.matterId, documentId, documentName })
      );
      return;
    }
  }

  viewSideDetail(item: CollaborationsModel.CollaborationItem): void {
    this.customEventSvc.dispatchEvent(COLLABORATIONS_SIDE_TAB_SWITCH, {
      tabId: 'details',
      ...item,
      skipListRender: false
    });
    this.customEventSvc.dispatchEvent(COLLABORATIONS_SIDE_TAB_TOGGLE, { show: true });
  }

  viewAttachment(item: CollaborationsModel.CollaborationItem): void {
    this.customEventSvc.dispatchEvent(COLLABORATIONS_SIDE_TAB_SWITCH, {
      tabId: CollaborationsModel.CollaborationTabId.attachments,
      ...item,
      skipListRender: false
    });
  }

  delete(item: CollaborationsModel.CollaborationItem): void {
    this.customEventSvc.dispatchEvent(COLLABORATIONS_LIST_FILE_DELETE, {
      documentId: item.id,
      fileExtension: item.fileExtension,
      documentName: item.name,
      matterId: this.matterId
    } as CollaborationsModel.DeleteDocumentRequest);
  }

  constructor(
    private customEventSvc: CustomEventService,
    private store: Store,
    @Inject(LOCALE_ID) private locale: string
  ) {}
}
