import { ChangeDetectionStrategy, Component, Input, Output } from '@angular/core';
import { CoreModel } from '@app/core/models';
import { CustomEventService, COLLABORATIONS_PREVIEW_ATTACHMENT } from '@app/core/services';

@Component({
  selector: 'sc-collaboration-side-attachments',
  templateUrl: './collaboration-side-attachments.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CollaborationSideAttachmentsComponent {
  @Input('data') data: CoreModel.DocAttachment[];

  constructor(private customEventSvc: CustomEventService) {}

  onSelect(attachment: CoreModel.DocAttachment): void {
    this.customEventSvc.dispatchEvent(COLLABORATIONS_PREVIEW_ATTACHMENT, { ...attachment });
  }

  getCss(isLast: boolean): string {
    return isLast ? 'mb-1' : 'mb-2';
  }

  getName(att: CoreModel.DocAttachment): string {
    return att ? `${att.name}.${att.ext}` : '??';
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }
}
