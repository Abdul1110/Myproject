import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CollaborationsHomeComponent } from './layout';
import { CollaborationsAttachmentPreviewComponent, CollaborationsDocumentPreviewComponent } from './pages';
import { UploadGuard } from './guards/upload.guard';
import { MatterSelectComponent } from '@app/shared/components/matter-select/matter-select.component';

const routes: Routes = [
  {
    path: '',
    component: CollaborationsHomeComponent,
    canDeactivate: [UploadGuard]
  },
  {
    path: ':documentId',
    component: CollaborationsHomeComponent,
    canDeactivate: [UploadGuard],
    children: [
      {
        path: 'attachment',
        component: CollaborationsAttachmentPreviewComponent,
        outlet: 'preview'
      },
      {
        path: 'preview',
        component: CollaborationsDocumentPreviewComponent
      },
      {
        path: 'select',
        component: MatterSelectComponent,
        outlet: 'aside'
      }
    ]
  },
  {
    path: 'select',
    component: MatterSelectComponent,
    outlet: 'aside'
  },
  {
    path: '**',
    component: CollaborationsHomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CollaborationsRoutingModule {}
