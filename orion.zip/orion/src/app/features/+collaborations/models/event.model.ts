export namespace CollaborationsEvent {
  export interface MultipleActionEventDetail {
    actionType: string;
    value: any;
  }

  export enum MultipleActionDispatchType {
    preview = 'preview',
    download = 'download',
    viewInfo = 'view-info',
    delete = 'delete',
    viewAttachmentList = 'view-attachment-list',
    upload = 'upload'
  }
}
