import { CoreModel } from '@app/core/models';
import { FileItem } from 'ng2-file-upload';
import { formatDate } from '@angular/common';

export namespace CollaborationsModel {
  export interface CollaborationItem {
    isFolderHeader: boolean;
    isFolder: boolean;
    collaborationRootId: string;
    fileExtension: string;
    id: string;
    name: string;
    fileSizeInBytes?: number;
    isDeletable?: boolean;
    currentVersionId?: string;
    ownerName?: string;
    ownerInitials?: string;
    lastModified?: Date;
    createDate?: Date;
    deleted?: boolean;
    attachments?: CoreModel.DocAttachment[];
    otherUsers?: CoreModel.OtherUser[];
  }
  export interface PreviewDocumentRequest {
    matterId: string;
    documentId: string;
    isImage: boolean;
  }

  export interface DownloadDocumentRequest {
    matterId: string;
    documentId: string;
    documentName: string;
  }

  export interface DownloadAttachmentRequest {
    documentName: string;
    attachmentUrl: string;
  }

  export interface PreviewAttachmentRequest {
    matterId: string;
    documentId: string;
    previewUrl: string;
  }

  export interface DeleteDocumentRequest {
    documentId: string;
    documentName: string;
    fileExtension: string;
    matterId: string;
  }

  export interface DraftInfo {
    id: string;
    name: string;
    folderId: string;
    extension: string;
  }

  export interface DraftCreated {
    draft: CoreModel.DraftDocument[];
  }

  export interface DraftUploadRequest {
    firmId: string;
    matterId: string;
    files: FileItem[];
    matterName: string;
    folderId: string;
    collaborationRootId: string;
  }

  export interface DraftUploadRequestSuccess {
    created: CollaborationsModel.DraftCreated;
    matterName: string;
    collaborationRootId: string;
    folderId: string;
  }

  export enum CollaborationTabId {
    details = 'details',
    attachments = 'attachments'
  }

  export class Helper {
    static localeFormat(dt: Date, locale: string, format: string = 'mediumDate'): string {
      return formatDate(dt, format, locale);
    }

    static getDocSortingOptions(): CoreModel.ColumnSorting[] {
      return [].concat([
        <CoreModel.ColumnSorting>{ column: 'createDate', title: 'Created', sort: 0 },
        <CoreModel.ColumnSorting>{ column: 'name', title: 'Document Name', sort: 0 },
        <CoreModel.ColumnSorting>{ column: 'ownerName', title: 'Owner', sort: 0 },
        <CoreModel.ColumnSorting>{ column: 'fileExtension', title: 'File Type', sort: 0 }
      ]);
    }

    static getDocFilterOptions(): CoreModel.ColumnFilter[] {
      return [].concat([<CoreModel.ColumnFilter>{ column: 'isDeletable', title: 'Owned By Me' }]);
    }

    static getDocDefaultSortingOption(): CoreModel.ColumnSorting {
      return <CoreModel.ColumnSorting>{ column: 'createDate', title: 'Created', sort: 1 };
    }

    static getCollaborations(
      matterId: string,
      collaborations: { [matterId: string]: CoreModel.Collaboration[] },
      currentCollaborations: { [rootId: string]: CoreModel.Collaboration[] },
      pendingCollaborations: CoreModel.PendingCollaration[],
      collaborationBinIds: string[],
      navigation: CoreModel.FolderPath[]
    ): { [matterId: string]: CollaborationsModel.CollaborationItem[] } {
      let documents = {};
      if (collaborations && collaborations[matterId] && collaborations[matterId].length > 0 && currentCollaborations) {
        const isInSubFolder = navigation && navigation.length > 1;
        const selectedCollaborations = isInSubFolder
          ? [].concat(collaborations[matterId].find(x => x.id == navigation[0].id) || [])
          : collaborations[matterId];

        try {
          selectedCollaborations.forEach(foldersAndDocs => {
            const rootId = this.getRootId(foldersAndDocs);
            const collaborations = currentCollaborations[rootId];
            const targetCollaboration =
              collaborations && collaborations.length > 0 ? collaborations[collaborations.length - 1] : undefined;

            if (targetCollaboration) {
              // #collaboration uploading: the logic need to further improve; e.g. flag from api to indicate the folder is default instead of by Name
              const isDefaultFolder =
                rootId.includes('empty') || targetCollaboration.name.startsWith('Collaboration with');

              // Adjust the fileId to origin id if upload same doc.
              const pendings =
                (pendingCollaborations &&
                  pendingCollaborations.length > 0 &&
                  pendingCollaborations.map(p => {
                    if (
                      p.collaborationRootId &&
                      currentCollaborations[p.collaborationRootId] &&
                      currentCollaborations[p.collaborationRootId].length > 0
                    ) {
                      const folder = currentCollaborations[p.collaborationRootId].find(x =>
                        x.fullDocuments.find(y => y.isDeletable && `${y.name}.${y.fileExtension}`.includes(p.fileName))
                      );
                      const fileId =
                        (folder &&
                          folder.fullDocuments.find(y => `${y.name}.${y.fileExtension}`.includes(p.fileName)).id) ||
                        p.fileId;
                      return { ...p, fileId };
                    }
                    return { ...p };
                  })) ||
                [];

              // append the list with Pending upload items if available.
              const pendingDocs = pendings.filter(
                x =>
                  (x.collaborationRootId == rootId && x.folderId == targetCollaboration.id) ||
                  (isDefaultFolder && (x.collaborationRootId.includes('empty') || !x.collaborationRootId)) // #collaboration uploading: add pending to the default folder where folder has been generated with valid id but still waiting for completing the upload.
              );

              const targetCollaborationWithPending = this.updateWithPendingUploadCollaborationFileIfAvailable(
                pendingDocs,
                targetCollaboration
              );

              // #collaboration uploading: rootId equals to empty only come from lawyer has create folder before sharing any document via collaboration.
              const latest =
                isDefaultFolder &&
                (!targetCollaborationWithPending || targetCollaborationWithPending.fullDocuments.length == 0)
                  ? [
                      {
                        collaborationRootId: rootId,
                        id: rootId,
                        name: targetCollaborationWithPending.name,
                        fileExtension: 'folder',
                        isFolder: true,
                        isFolderHeader: false
                      }
                    ]
                  : this.getFoldersAndDocuments(targetCollaborationWithPending, rootId);

              if (collaborationBinIds && collaborationBinIds.length > 0) {
                const updatedList = latest.map(x => {
                  if (collaborationBinIds.includes(x.id) && !x.deleted) {
                    return { ...x, deleted: true } as CollaborationsModel.CollaborationItem;
                  }
                  return x as CollaborationsModel.CollaborationItem;
                });

                documents[matterId] = this.mergeTwoArrays(
                  documents[matterId],
                  updatedList.filter(z => !z.deleted)
                );
              } else {
                documents[matterId] = this.mergeTwoArrays(documents[matterId], latest);
              }
            }
          });
        } catch (err) {
          console.error(err);
        }
      }

      return documents;
    }

    private static mergeTwoArrays(a: any, b: any): any {
      return a && a.length > 0 ? a.concat(b) : [].concat(b);
    }

    private static getRootId(item: any): string {
      if (!item || !item.parent) {
        return '';
      }

      if (item.parent.id == null && item.parent.name && item.parent.name == 'Home') {
        return item.id;
      }

      return this.getRootId(item.parent);
    }

    private static updateWithPendingUploadCollaborationFileIfAvailable(
      pendingDocs: CoreModel.PendingCollaration[],
      current: CoreModel.Collaboration
    ): CoreModel.Collaboration {
      const validPendingDocs = pendingDocs
        ? pendingDocs.filter(d => current.fullDocuments.findIndex((x: CoreModel.Doc) => x.id == d.fileId) === -1)
        : undefined;
      const hasNewPending = validPendingDocs && validPendingDocs.length > 0;
      const pendingFullDocuments = hasNewPending
        ? validPendingDocs.map<CoreModel.Doc>(x => {
            const { name: fileName, extension: fileExtension } = CoreModel.Helper.fileNameToNameAndExtension(
              x.fileName
            );
            return CoreModel.Helper.toDoc(
              x.fileId,
              fileExtension,
              fileName,
              x.createDate,
              false,
              true,
              'PendingUpload'
            );
          })
        : undefined;

      let newCurrentFullDocuments = [];
      if (pendingFullDocuments && current.documents && current.documents.length > 0) {
        newCurrentFullDocuments = current.fullDocuments.filter(f => {
          if (!f.isDeletable) {
            return true;
          }
          return pendingFullDocuments.findIndex(x => x.name == f.name) === -1;
        });
      }

      return Object.assign(
        {},
        current,
        {
          documents: hasNewPending
            ? [].concat(pendingFullDocuments.map(x => x.id)).concat(newCurrentFullDocuments.map(x => x.id))
            : current.documents
        },
        {
          fullDocuments: hasNewPending
            ? [].concat(pendingFullDocuments).concat(newCurrentFullDocuments)
            : current.fullDocuments
        }
      );
    }

    private static getFoldersAndDocuments(
      source: CoreModel.Collaboration,
      collaborationRootId: string = ''
    ): CollaborationItem[] {
      const folders = source.folders.map<CollaborationItem>(f => {
        return {
          collaborationRootId,
          id: f.id,
          name: f.name,
          fileExtension: 'folder',
          isFolder: true,
          isFolderHeader: false
        };
      });
      const documents = source.fullDocuments.map<CollaborationItem>((d: CoreModel.Doc) => {
        return {
          isFolderHeader: false,
          isFolder: false,
          collaborationRootId,
          id: d.id,
          name: d.name,
          fileExtension: d.fileExtension,
          fileSizeInBytes: d.fileSizeInBytes,
          lastModified: d.lastModified,
          isDeletable: d.isDeletable,
          currentVersionId: d.currentVersionId,
          ownerName: d.ownerName,
          ownerInitials: d.ownerInitials,
          createDate: d.createDate,
          deleted: d.deleted,
          attachments: d.attachments
        };
      });

      return [].concat(...folders, ...documents);
    }
  }
}
