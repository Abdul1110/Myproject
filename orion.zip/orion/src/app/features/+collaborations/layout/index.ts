import { CollaborationsHomeComponent } from './home/collaborations-home.component';

export * from './home/collaborations-home.component';

export const collaborationsLayouts = [CollaborationsHomeComponent];
