import { Component, HostBinding, HostListener, Inject, LOCALE_ID } from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { MatBottomSheet } from '@angular/material';
import { Store, Select, ofActionSuccessful, Actions } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { Subject, Observable, merge, fromEvent } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { UUID } from 'angular2-uuid';

import { xAnimationAsideCollapse } from '@app/shared/components/animation/animation';
import { AppState } from '@app/core/store/states';
import {
  GetCollaborationStart,
  UpdateUploadCompleteFlag,
  GotoCollaborationFolder,
  GetCollaborationSuccess,
  PopulateMatter,
  SetNavigationActionId,
  SetMatterFirmId,
  GetCollaborationFailure,
  GetNotification
} from '@app/core/store/actions';
import { CoreModel, NodeModel } from '@app/core/models';
import {
  PubNubService,
  CustomEventService,
  COLLABORATIONS_PREVIEW_ATTACHMENT,
  COLLABORATIONS_SIDE_TAB_SWITCH,
  COLLABORATIONS_LIST_FOLDER_OPEN,
  COLLABORATIONS_LIST_FILE_PREVIEW,
  COLLABORATIONS_SIDE_TAB_TOGGLE,
  COLLABORATIONS_MULTIPLE_ACTIONS,
  COLLABORATIONS_MULTIPLE_ACTIONS_OPEN,
  COLLABORATIONS_LIST_FILE_DELETE,
  NAVIGATION_SIDE_BAR_TOGGLE,
  DOCUMENTS_SIDE_TAB_SWITCH,
  MATTERS_SELECT_CLOSED,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED,
  NavigationService
} from '@app/core/services';

import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { environment } from '@env/environment';
import { CanComponentDeactivate, SideNavigationModel } from '@app/shared/models';
import { CollaborationsViewDetailsMobileComponent, CollaborationsSideMobileComponent } from '../../pages';
import { CollaborationsAction } from '../../store';
import { CollaborationsEvent } from '../../models/event.model';
import { CollaborationsModel } from '../../models/collaborations.model';

const { locale } = environment;
const icon = locale.global.menu.collaborations.icon;

@Component({
  selector: 'sc-collaborations-home',
  templateUrl: './collaborations-home.component.html',
  animations: [xAnimationAsideCollapse]
})
export class CollaborationsHomeComponent implements OnDestroy, OnInit, CanComponentDeactivate {
  private pubNubSub: CoreModel.PubNubSubscription;
  private destroy$ = new Subject<boolean>();
  @HostBinding('class') classes;
  isSmallScreen$: Observable<boolean>;
  showHeader = true;
  isPreviewMode = false;
  folderPaths: CoreModel.FolderPath[] = [];
  hasSubPath = false;
  matterId = '';
  documentId = '';
  documentName = '';
  matterName = '';
  firmId = '';
  asideDetails = true;
  isDownloading = false;
  fileSelect = undefined;
  dragEnter = false;
  uploadsIsCreatingDraft = false;
  drafts: any;

  get isCurrentSubLevel(): boolean {
    return this.hasSubPath && this.folderPaths.length > 1;
  }

  getFirmName(firm: CoreModel.FirmDetail): string {
    return (firm && firm.name) || locale.matters.title;
  }

  getNavbarIcon(): string {
    return this.isPreviewMode ? 'Back' : icon;
  }

  @Select(AppState.getLoginUser) logonUser$: Observable<CoreModel.LogonUserInfo>;

  @Select(AppState.getDocumentsByMatter) matterDocs$: Observable<{ [matterId: string]: NodeModel.LawConnectNode[] }>;

  home(): void {
    if (this.hasSubPath) {
      this.sliceFolder(undefined);
    }

    if (this.isPreviewMode || this.route.snapshot.url.toString().indexOf('preview') >= 0) {
      this.renderListView();
      return;
    }
  }

  renderListView(tabId: string = ''): void {
    const isAttachmentTab = tabId && tabId.includes(CollaborationsModel.CollaborationTabId.attachments);
    this.isPreviewMode = false;
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${this.matterId}/collaborations/${this.documentId || ''}`,
      queryParams: <Params>{
        t: UUID.UUID()
      },
      state: {
        isAttachmentTab
      }
    });
  }

  openGlobalActionSheet(): void {
    this.bottomSheet.open(CollaborationsViewDetailsMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { isGlobal: true, title: 'Please select' }
    });
  }

  openActionSheet(): void {
    const { documentId, matterId } = this.route.snapshot.params;
    const data = CoreModel.Helper.getCollaborationFileByDocumentId(
      matterId,
      documentId,
      this.store.selectSnapshot(AppState.getCollaboration),
      this.store.selectSnapshot(AppState.getAllCollaborations)
    );

    if (data && data.doc) {
      const doc = data.doc;
      const title = CoreModel.Helper.getValidDocumentNameWithExtension(doc.name, doc.fileExtension);
      const subTitle = `Created on ${CollaborationsModel.Helper.localeFormat(doc.createDate, this.locale)}`;
      this.bottomSheet.open(CollaborationsViewDetailsMobileComponent, {
        panelClass: 'x-bottom-sheet',
        data: { isGlobal: false, ...doc, title, subTitle, hidePreview: true }
      });
    }
  }

  documentTitle(): string {
    return this.documentName ? this.documentName : 'Collaboration';
  }

  getMatterName(): string {
    return this.matterName;
  }

  showSideDetail(isSmallScreen: boolean): boolean {
    return !isSmallScreen && this.asideDetails;
  }

  openFileSelect(): void {
    this.fileSelect = UUID.UUID();
  }

  toggleAside(): void {
    this.asideDetails = !this.asideDetails;
  }

  downloadDocument(matterId: string, documentId: string, documentName: string): void {
    this.isDownloading = true;
    this.updateFromPathParams(matterId);
    this.updateDocumentName(matterId, documentId);

    if (documentName) {
      this.store.dispatch(
        new CollaborationsAction.DownloadDocument({
          matterId,
          documentId,
          documentName
        })
      );
      return;
    }

    this.isDownloading = false;
  }

  gotoHomeView(): void {
    this.renderListView();
    this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, {
      tabId: 'details',
      id: this.documentId
    });
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
  }

  dragLeave(show: boolean): void {
    this.dragEnter = show;
    this.fileSelect = undefined;
  }

  startUpload(anyId: string): void {
    this.uploadsIsCreatingDraft = true;
  }

  layoutCss(isPreview: boolean): string {
    if (isPreview) {
      return 'position-relative h-100 overflow-auto x-scroll-hidden';
    }
    return 'layout-column position-relative h-100';
  }

  @HostListener('dragend', ['$event'])
  onDragleave($event) {
    if (this.dragEnter === true) {
      this.dragEnter = false;
    }
  }

  @HostListener('window:beforeunload')
  canDeactivate(): Observable<boolean> | boolean {
    const isCreateDraftInProgress = this.uploadsIsCreatingDraft;
    if (isCreateDraftInProgress) {
      return false;
    }

    const canNavigate = this.hasAnyPendingDraft(this.drafts);
    return canNavigate;
  }

  constructor(
    private store: Store,
    private pubNubSvc: PubNubService,
    private actions$: Actions,
    private appActionSvc: AppActionService,
    private route: ActivatedRoute,
    private bottomSheet: MatBottomSheet,
    private customEventSvc: CustomEventService,
    private browserSvc: BrowserService,
    private navigationSvc: NavigationService,
    @Inject(LOCALE_ID) private locale: string
  ) {
    this.classes = 'lt-container bg-light-secondary';
    this.updateFromPathParams();
    this.updateMatterName(this.matterId);
    this.documentId && this.matterId && this.updateDocumentName(this.matterId, this.documentId);

    const nodes = this.store.selectSnapshot(AppState.getNodes);
    const node = nodes.find(x => x.id == this.matterId);

    if (node && node.parentId) {
      this.store.dispatch(new SetMatterFirmId({ matterId: this.matterId, firmId: node.parentId }));
    }

    this.triggerRecentNotificationDataPulledIfCountZero();
    // const collaborations = this.store.selectSnapshot(AppState.getAllCollaborations) || {};

    // skip data reload where user views details because list item have been loaded.
    const collaborationFile = CoreModel.Helper.getCollaborationFileByDocumentId(
      this.matterId,
      this.documentId,
      this.store.selectSnapshot(AppState.getCollaboration),
      this.store.selectSnapshot(AppState.getAllCollaborations)
    );

    const hasDataLoaded = !!(collaborationFile && collaborationFile.doc); //(collaborations[this.matterId] || []).length > 0;

    !hasDataLoaded &&
      this.store.dispatch(new GetCollaborationStart({ matterId: this.matterId, skipPathUpdate: false }));

    this.store.dispatch(new SetNavigationActionId(SideNavigationModel.SideActionId.collaborations));
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, {
      actionId: SideNavigationModel.SideActionId.collaborations
    });

    // handle no matter match from the list.
    if (!node) {
      const isPreview =
        this.route &&
        this.route.firstChild &&
        this.route.firstChild.url['value'] &&
        this.route.firstChild.url['value'][0] &&
        this.route.firstChild.url['value'][0]['path'] &&
        this.route.firstChild.url['value'][0]['path'].includes('preview');

      if (isPreview) {
        this.navigationSvc.goto(<CoreModel.NavigationData>{
          url: `/matters/${this.matterId}/collaborations/${this.documentId || ''}/(aside:select)` // to fix the reroute to preview with aside:selection
        });
      } else {
        this.navigationSvc.goto(<CoreModel.NavigationData>{
          path: `/matters/${this.matterId}/collaborations/${this.documentId || ''}`,
          outlet: 'aside',
          outletPath: 'select'
        });
      }

      this.store.dispatch(new GetCollaborationFailure('No matter detail available'));

      return;
    }
  }

  ngOnInit() {
    this.isSmallScreen$ = this.appActionSvc.isSmallScreen$;

    merge(
      this.logonUserSideEffect$(),
      this.uploadFileCompletedSideEffect$(),
      this.previewAttachmentSideEffect$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.listenToOpenFolderSideEffect$(),
      this.previewDocumentSideEffect$(),
      this.getDownloadDocumentSuccessSideEffect$(),
      this.getDownloadDocumentFailureSideEffect$(),
      this.getCollaborationsSuccessSideEffect$(),
      this.getMattersSuccessSideEffect$(),
      this.windowDragEnterSideEffect$(),
      this.listenToCreateUploadDraftSuccessSideEffect$(),
      this.listenToCreateUploadDraftFailureSideEffect$(),
      this.listenToRemoteSideDetailToggleRequestSideEffect$(),
      this.listenToMobileActionSideEffect$(),
      this.listenToMobileActionOpenRequestSideEffect$(),
      this.listenToDocumentUploadingAfterDraftStateSideEffect$(),
      this.listenToMatterSelectedFromOptions$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);

    if (this.pubNubSub) {
      this.pubNubSub.unsubscribe();
    }
  }

  private triggerRecentNotificationDataPulledIfCountZero(): void {
    const user = this.store.selectSnapshot(AppState.getLoginUser);
    const notificationCount = this.store.selectSnapshot(AppState.getNotificationCount) || 0;
    user && user.userId && notificationCount == 0 && this.store.dispatch(new GetNotification(user.userId));
  }

  private listenToDocumentUploadingAfterDraftStateSideEffect$(): Observable<CoreModel.DraftDocument[]> {
    return this.appActionSvc.drafts$.pipe(
      tap(drafts => {
        this.drafts = drafts;
        // this.uploadValidator$ = this.getUploaderValidator();
      })
    );
  }

  private hasAnyPendingDraft(drafts: CoreModel.DraftDocument[]): boolean {
    if (!drafts) {
      return true;
    }
    const hasUploadedAll = drafts.reduce((result, x) => {
      return x.done && x.done === true && result;
    }, true);

    if (!hasUploadedAll) {
      return false;
    } else {
      return true;
    }
  }

  private openMobileItemActionSheet(data: any): void {
    this.bottomSheet.open(CollaborationsViewDetailsMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { ...data, isGlobal: false }
    });
  }

  private windowDragEnterSideEffect$(): Observable<any> {
    return fromEvent(this.browserSvc.window.document, 'dragenter').pipe(
      tap(event => {
        this.dragEnter = !this.isPreviewMode;
      })
    );
  }

  private getCollaborationsSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetCollaborationSuccess),
      tap(success => this.updateDocumentName(this.matterId, this.documentId))
    );
  }

  private getMattersSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateMatter),
      tap(success => this.updateMatterName(this.matterId))
    );
  }

  private listenToCreateUploadDraftSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.CreateUploadDraftSuccess),
      tap(success => (this.uploadsIsCreatingDraft = false))
    );
  }

  private listenToCreateUploadDraftFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.CreateUploadDraftFailure),
      tap(success => (this.uploadsIsCreatingDraft = false))
    );
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      this.updateFromPathParams(matterId);
      this.updateMatterName(this.matterId);
    });
  }

  private updateFromPathParams(matterId: string = undefined): void {
    this.documentId = (this.route.snapshot.params && this.route.snapshot.params['documentId']) || '';
    this.matterId = matterId || (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';
    this.isPreviewMode =
      this.route.snapshot &&
      this.route.snapshot.firstChild &&
      this.route.snapshot.firstChild.routeConfig.path.toLowerCase() == 'preview';
  }

  private updateMatterName(matterId: string): void {
    const matterDetail = CoreModel.Helper.getMatterDetail(
      matterId,
      this.store.selectSnapshot(AppState.getMattersByFirm)
    );

    this.matterName = (matterDetail && matterDetail.name) || '';
    this.firmId = (matterDetail && matterDetail.parentId) || '';
  }

  private updateDocumentName(matterId: string, documentId: string): void {
    const result = CoreModel.Helper.getCollaborationFileByDocumentId(
      matterId,
      documentId,
      this.store.selectSnapshot(AppState.getCollaboration),
      this.store.selectSnapshot(AppState.getAllCollaborations)
    );

    const newDocName =
      result && result.doc
        ? CoreModel.Helper.getValidDocumentNameWithExtension(result.doc.name, result.doc.fileExtension)
        : '';

    if (newDocName !== this.documentName) {
      this.documentName = newDocName;
    }
  }

  private sliceFolder(folder: CoreModel.FolderPath): void {
    if (!folder) {
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/collaborations/${this.documentId || ''}`,
        outlet: 'aside',
        outletPath: 'select',
        queryParams: <Params>{
          t: UUID.UUID()
        }
      });
      return;
    }

    this.store.dispatch(new GotoCollaborationFolder({ rootId: folder.collaborationId, folderId: folder.id }));
  }

  private previewDocumentSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_LIST_FILE_PREVIEW, ({ id, ...others }) => {
      this.isPreviewMode = true;
      this.documentId = id || this.documentId;
      this.matterId = (this.route.parent && this.route.parent.snapshot.params['matterId']) || this.matterId;

      this.updateDocumentName(this.matterId, this.documentId);

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/collaborations/${this.documentId}/preview`,
        queryParams: <Params>{
          t: UUID.UUID()
        }
      });

      this.customEventSvc.dispatchEvent(COLLABORATIONS_SIDE_TAB_SWITCH, {
        id: this.documentId,
        tabId: 'details',
        skipListRender: true
      });
    });
  }

  private previewAttachmentSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_PREVIEW_ATTACHMENT, ({ id, name, ext, ...others }) => {
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/collaborations/${this.documentId}`,
        outlet: 'preview',
        outletPath: 'attachment',
        queryParams: <Params>{
          t: UUID.UUID(),
          id,
          name,
          ext
        },
        state: others
      });
    });
  }

  private logonUserSideEffect$(): Observable<CoreModel.LogonUserInfo> {
    return this.logonUser$.pipe(
      tap(user => {
        if (this.pubNubSub) {
          this.pubNubSub.unsubscribe();
        }

        if (!user) {
          return;
        }

        if (user.userId) {
          this.pubNubSub = this.pubNubSvc.subscribeToChannels(user.userId, [user.userId], notification => {
            const msg = CoreModel.Helper.convertNotificationMessage(notification);

            if (
              msg.notificationType === CoreModel.PubNubNotificationType.sharing ||
              msg.notificationType === CoreModel.PubNubNotificationType.revoking ||
              msg.notificationType === CoreModel.PubNubNotificationType.delete ||
              msg.notificationType === CoreModel.PubNubNotificationType.uploading
            ) {
              const { matterId } = this.route.snapshot.params;

              this.store.dispatch([new GetCollaborationStart({ matterId, skipPathUpdate: true })]);
            }
          });
        }
      })
    );
  }

  private uploadFileCompletedSideEffect$(): Actions {
    return this.actions$.pipe(
      ofActionSuccessful(UpdateUploadCompleteFlag),
      tap(v => {
        this.store.dispatch([new GetCollaborationStart({ matterId: this.matterId, skipPathUpdate: true })]);
      })
    );
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      COLLABORATIONS_SIDE_TAB_SWITCH,
      ({ id, skipListRender, tabId, ...others }) => {
        if (this.documentId !== id) {
          this.documentId = id;
          skipListRender !== undefined && !skipListRender && this.renderListView(tabId);
          this.updateDocumentName(this.matterId, this.documentId);
        }
      }
    );
  }

  private listenToOpenFolderSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      COLLABORATIONS_LIST_FOLDER_OPEN,
      ({ id, collaborationRootId, collaborationId, ...others }) => {
        const rootId = collaborationRootId || (collaborationId == id ? id : collaborationId);
        id &&
          rootId &&
          this.store.dispatch(
            new GotoCollaborationFolder({
              folderId: id,
              rootId,
              matterId: this.matterId
            })
          );
      }
    );
  }

  private listenToRemoteSideDetailToggleRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_SIDE_TAB_TOGGLE, ({ show }) => {
      if (show !== undefined) {
        this.asideDetails = show;
        return;
      }
    });
  }

  private listenToMobileActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_MULTIPLE_ACTIONS, ({ actionType, value }) => {
      if (actionType == CollaborationsEvent.MultipleActionDispatchType.upload) {
        this.openFileSelect();
        return;
      }

      if (actionType == CollaborationsEvent.MultipleActionDispatchType.download) {
        this.downloadDocument(
          this.matterId,
          value.id,
          CoreModel.Helper.getValidDocumentNameWithExtension(value.name, value.fileExtension)
        );
        return;
      }

      if (actionType == CollaborationsEvent.MultipleActionDispatchType.preview) {
        value.isFolder && this.customEventSvc.dispatchEvent(COLLABORATIONS_LIST_FOLDER_OPEN, { ...value });
        !value.isFolder && this.customEventSvc.dispatchEvent(COLLABORATIONS_LIST_FILE_PREVIEW, { ...value });
        return;
      }

      if (actionType == CollaborationsEvent.MultipleActionDispatchType.viewInfo) {
        this.bottomSheet.open(CollaborationsSideMobileComponent, {
          panelClass: 'x-bottom-sheet',
          data: { isGlobal: false, value, actionType, title: 'Details' }
        });
      }

      if (actionType == CollaborationsEvent.MultipleActionDispatchType.viewAttachmentList) {
        this.bottomSheet.open(CollaborationsSideMobileComponent, {
          panelClass: 'x-bottom-sheet',
          data: { isGlobal: false, value, actionType, title: 'Attachments' }
        });
      }

      if (actionType == CollaborationsEvent.MultipleActionDispatchType.delete) {
        this.customEventSvc.dispatchEvent(COLLABORATIONS_LIST_FILE_DELETE, {
          documentId: value.id,
          fileExtension: value.fileExtension,
          documentName: value.name,
          matterId: this.matterId
        } as CollaborationsModel.DeleteDocumentRequest);
        return;
      }
    });
  }

  private listenToMobileActionOpenRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_MULTIPLE_ACTIONS_OPEN, data => {
      this.openMobileItemActionSheet(data);
    });
  }

  private getDownloadDocumentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.DownloadDocumentSuccess),
      tap(() => {
        this.isDownloading = false;
      })
    );
  }

  private getDownloadDocumentFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(CollaborationsAction.DownloadDocumentFailure),
      tap(() => {
        this.isDownloading = false;
      })
    );
  }
}
