import { NgModule } from '@angular/core';
import { InlineSVGModule } from 'ng-inline-svg';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { AppStateModule } from '@app/core/app-state.module';
import { DocumentsRoutingModule } from './documents-routing.module';
import { documentsPages } from './pages';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { MatBottomSheetModule, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { MAT_BOTTOM_SHEET_DATA } from '@angular/material';

import {
  LyraDesignEmptyStateModule,
  GalaxyPreLoaderComponentModule,
  LyraDesignPanelModule,
  LyraDesignMenuModule,
  LyraDesignAvatarModule,
  LyraDesignCommonModule,
  LyraDesignButtonModule,
  LyraDesignCardModule,
  LyraDesignAsideModule,
  LyraDesignIconModule,
  LyraDesignFormModule,
  LyraDesignTabsModule,
  LyraDesignMainModule,
  LyraDesignNavbarModule,
  LyraDesignTypeModule,
  LyraDesignFilesModule,
  LyraDesignUserModule,
  LyraDesignSectionModule,
  LyraDesignAnimationModule
} from '@leap/lyra-design';

import { documentsLayouts } from './layout';
import { documentsServices } from './services';
import { documentsComponents } from './components';
import { SharedModule } from '@app/shared';
import { DocumentsStateModule } from './documents-state.module';

@NgModule({
  imports: [
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule,
    SharedModule,
    AppStateModule,
    DocumentsStateModule,
    DocumentsRoutingModule,
    LyraDesignEmptyStateModule,
    GalaxyPreLoaderComponentModule,
    LyraDesignIconModule,
    LyraDesignAvatarModule,
    LyraDesignPanelModule,
    LyraDesignMenuModule,
    LyraDesignCommonModule,
    LyraDesignButtonModule,
    LyraDesignCardModule,
    LyraDesignAsideModule,
    LyraDesignFormModule,
    LyraDesignTabsModule,
    LyraDesignMainModule,
    LyraDesignNavbarModule,
    LyraDesignUserModule,
    LyraDesignFilesModule,
    LyraDesignTypeModule,
    LyraDesignSectionModule,
    LyraDesignAnimationModule,
    BsDropdownModule.forRoot(),
    ProgressbarModule.forRoot(),
    MatBottomSheetModule
  ],
  entryComponents: [...documentsLayouts, ...documentsPages, ...documentsComponents],
  declarations: [...documentsLayouts, ...documentsPages, ...documentsComponents],
  providers: [
    ...documentsServices,
    { provide: MatBottomSheetRef, useValue: [] },
    { provide: MAT_BOTTOM_SHEET_DATA, useValue: [] }
  ]
})
export class DocumentsModule {}
