import { NgModule } from '@angular/core';
import { NgxsModule } from '@ngxs/store';
import { DocumentsStates } from './store';

@NgModule({
  imports: [NgxsModule.forFeature([...DocumentsStates])]
})
export class DocumentsStateModule {}
