import { State, Action, StateContext, Selector } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { switchMap, catchError, map } from 'rxjs/operators';
import { saveAs as FileSaver } from 'file-saver';

import { DocumentsAction } from '../actions';
import { LawConnectApiService } from '../../services';
import { AnnotatorModel } from '@app/shared/models';
import { UUID } from 'angular2-uuid';
import { DocumentsModel } from '@app/features/+documents/models/documents.model';
import { of } from 'rxjs';

export interface DocumentsStateModel {
  error: string;
  loading: boolean;
  onlyMyUploads: boolean;
}

@State<DocumentsStateModel>({
  name: 'documents',
  defaults: {
    error: undefined,
    loading: false,
    onlyMyUploads: false
  }
})
export class DocumentsState {
  constructor(private browserSvc: BrowserService, private lcApiSvc: LawConnectApiService) {}

  @Action(DocumentsAction.SetOnlyMyUploads)
  SetOnlyMyUploads({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const state = getState();
    const showOnly = !!payload.payload;
    setState({
      ...state,
      onlyMyUploads: showOnly
    });
  }

  @Selector()
  static getOnlyMyUploadsFlag(state: DocumentsStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.onlyMyUploads;
  }

  @Action(DocumentsAction.GetDocumentActivity, { cancelUncompleted: true })
  GetDocumentActivity({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const documentId = payload.payload as string;

    const activity$ = this.lcApiSvc.getDocumentActivities(documentId);

    return activity$.pipe(
      switchMap(response => dispatch(new DocumentsAction.GetDocumentActivitySuccess(response))),
      catchError(error => dispatch(new DocumentsAction.GetDocumentActivityFailure(error)))
    );
  }

  @Action(DocumentsAction.GetDocumentAnnotation, { cancelUncompleted: true })
  GetDocumentAnnotation({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const documentId = payload.payload as string;

    const annotation$ = this.lcApiSvc.getDocumentAnnotations(documentId);

    return annotation$.pipe(
      switchMap(response => dispatch(new DocumentsAction.GetDocumentAnnotationSuccess(response))),
      catchError(error => dispatch(new DocumentsAction.GetDocumentAnnotationFailure(error)))
    );
  }

  @Action(DocumentsAction.GetDocumentReplied, { cancelUncompleted: true })
  GetDocumentReplied({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const annotationIds = payload.payload as string[];

    const replied$ = this.lcApiSvc.getDocumentAnnotationsReplied(annotationIds);

    return replied$.pipe(
      switchMap(response => dispatch(new DocumentsAction.GetDocumentRepliedSuccess(response))),
      catchError(error => dispatch(new DocumentsAction.GetDocumentRepliedFailure(error)))
    );
  }

  @Action(DocumentsAction.DeleteReplied)
  DeleteReplied({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const state = getState();
    const data = payload.payload as AnnotatorModel.DeleteAnnotationReply;

    if (!data || !data.annotationId || !data.replyId) {
      return;
    }

    return this.lcApiSvc.deleteDocumentReply(data.replyId).pipe(
      map(deleted =>
        dispatch(
          new DocumentsAction.DeleteRepliedSuccess({
            success: deleted,
            annotationId: data.annotationId,
            replyId: data.replyId
          })
        )
      ),
      catchError(error => dispatch(new DocumentsAction.DeleteRepliedFailure({ data, err: error })))
    );
  }

  @Action(DocumentsAction.PreviewDocument, { cancelUncompleted: true })
  PreviewDocument({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { matterId, documentId, isImage } = payload.payload as DocumentsModel.PreviewDocumentRequest;

    const downloadSvc = this.lcApiSvc.getPreviewDocumentDownloadUrl(documentId, !isImage);

    return downloadSvc.pipe(
      switchMap(response => dispatch(new DocumentsAction.PreviewDocumentSuccess(response.downloadUrl))),
      catchError(error => dispatch(new DocumentsAction.PreviewDocumentFailure(error)))
    );
  }

  @Action(DocumentsAction.DownloadDocument, { cancelUncompleted: true })
  DownloadDocument({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { matterId, documentId, documentName } = payload.payload as DocumentsModel.DownloadDocumentRequest;

    const isImage = false;
    const downloadSvc = this.lcApiSvc.getDocumentDownloadUrl(documentId, isImage);

    return downloadSvc.pipe(
      switchMap(res => this.lcApiSvc.download(res.downloadUrl)),
      map(bl => FileSaver.saveAs(bl, documentName)),
      map(() => dispatch(new DocumentsAction.DownloadDocumentSuccess())),
      catchError(error => dispatch(new DocumentsAction.DownloadDocumentFailure(error)))
    );
  }

  @Action(DocumentsAction.ReplyComment)
  ReplyComment({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const reply = payload.payload as DocumentsModel.LawConnectDocumentAnnotationReply;
    const detail = <DocumentsModel.LawConnectDocumentAnnotationReply>{
      ...reply
    };

    return this.lcApiSvc.replyDocumentAnnotation(detail).pipe(
      map(replied => dispatch(new DocumentsAction.ReplyCommentSuccess(replied))),
      catchError(error => dispatch(new DocumentsAction.ReplyCommentFailure(error)))
    );
  }

  @Action(DocumentsAction.DeleteAnnotation)
  DeleteAnnotation({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const state = getState();
    const annotationId = payload.payload as string;

    if (!annotationId) {
      return;
    }

    return this.lcApiSvc.deleteDocumentAnnotation(annotationId).pipe(
      map(deleted => dispatch(new DocumentsAction.DeleteAnnotationSuccess({ success: !!deleted, annotationId }))),
      catchError(error => dispatch(new DocumentsAction.DeleteAnnotationFailure(error)))
    );
  }

  @Action(DocumentsAction.AddAnnotation)
  AddAnnotation({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const data = payload.payload as DocumentsModel.NewAnnotationRequest;

    if (!data) {
      return;
    }

    const { userId, displayName, quote, ranges, comment, aboutPage, allowAnyoneView } = data;
    const user = <AnnotatorModel.AnnotatedUser>{ userId, userName: displayName };
    const { page, fileId } = aboutPage;
    const readPermission = allowAnyoneView ? [] : [userId];
    const permissions = <AnnotatorModel.AnnotatedPermission>{
      admin: [userId],
      delete: [userId],
      read: readPermission,
      update: [userId]
    };

    const newAnnotation = <AnnotatorModel.NewAnnotation>{
      fileId,
      id: UUID.UUID(),
      user,
      pageId: page,
      permissions,
      quote,
      ranges,
      text: comment
    };

    return this.lcApiSvc.addDocumentAnnotation(newAnnotation).pipe(
      map(updated => dispatch(new DocumentsAction.AddAnnotationSuccess(updated && !!updated['id']))),
      catchError(error => dispatch(new DocumentsAction.AddAnnotationFailure(error)))
    );
  }

  @Action(DocumentsAction.UpdateAnnotation)
  UpdateAnnotation({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const state = getState();
    const data = payload.payload as DocumentsModel.NewAnnotationRequest;

    if (!data || !data.annotationId) {
      return;
    }

    const { userId, displayName, quote, ranges, comment, aboutPage, allowAnyoneView, aboutUpdate } = data;
    const { page, fileId } = aboutPage;
    const { creationDate, events, isDuringUpdate, oldText, versionId } = aboutUpdate;

    const user = <AnnotatorModel.AnnotatedUser>{ userId, userName: displayName };
    const updateDate = new Date().toString();
    const readPermission = allowAnyoneView ? [] : [userId];
    const permissions = <AnnotatorModel.AnnotatedPermission>{
      admin: [userId],
      delete: [userId],
      read: readPermission,
      update: [userId]
    };

    const updatedAnnotation = <DocumentsModel.UpdateAnnotationRequest>{
      fileId,
      id: data.annotationId,
      user,
      pageId: page,
      permissions,
      quote,
      ranges,
      text: comment,
      creationDate,
      events,
      isDuringUpdate,
      oldText,
      updateDate,
      versionId
    };

    return this.lcApiSvc.updateDocumentAnnotation(updatedAnnotation).pipe(
      map(updated => dispatch(new DocumentsAction.UpdateAnnotationSuccess(updated.success))),
      catchError(error => dispatch(new DocumentsAction.UpdateAnnotationFailure(error)))
    );
  }

  // Email depends on this to send out list of changes at scheduled time e.g. end of day.
  @Action(DocumentsAction.StartActiveUserInDocument)
  StartActiveUserInDocument({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const { userId, documentId } = payload.payload as DocumentsModel.UserIsPreviewingTheDocument;
    return this.lcApiSvc.activeUserInDocument(documentId, userId).pipe(
      catchError(err => {
        // it is ok to ignore the error; normally, it has been notified before and still active.
        return of();
      })
    );
  }

  // Email depends on this to send out list of changes at scheduled time e.g. end of day.
  @Action(DocumentsAction.UpdateActiveUserHeartBeat)
  UpdateActiveUserHeartBeat({ getState, setState, dispatch }: StateContext<DocumentsStateModel>, payload) {
    const { userId, documentId } = payload.payload as DocumentsModel.UserIsPreviewingTheDocument;

    return this.lcApiSvc.activeUserHeartBeat(documentId, userId).pipe(
      catchError(err => {
        // it is ok to ignore the error; normally, it has expired.
        return of();
      })
    );
  }
}
