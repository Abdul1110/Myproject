import { DocumentsState } from './states';

export * from './states';
export * from './actions';

export const DocumentsStates = [DocumentsState];
