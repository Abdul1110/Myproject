import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DocumentsHomeComponent } from './layout';
import { DocumentsDocumentPreviewComponent } from './pages';
import { MatterSelectComponent } from '@app/shared/components/matter-select/matter-select.component';

const routes: Routes = [
  {
    path: '',
    component: DocumentsHomeComponent
  },
  {
    path: ':documentId',
    component: DocumentsHomeComponent,
    children: [
      {
        path: 'preview',
        component: DocumentsDocumentPreviewComponent
      },
      {
        path: 'select',
        component: MatterSelectComponent,
        outlet: 'aside'
      }
    ]
  },
  {
    path: 'select',
    component: MatterSelectComponent,
    outlet: 'aside'
  },
  {
    path: '**',
    component: DocumentsHomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DocumentsRoutingModule {}
