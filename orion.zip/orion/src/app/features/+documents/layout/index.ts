import { DocumentsHomeComponent } from './home/documents-home.component';

export * from './home/documents-home.component';

export const documentsLayouts = [DocumentsHomeComponent];
