import { Component, HostBinding, Inject, LOCALE_ID, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { MatBottomSheet } from '@angular/material';
import { Store, Select, ofActionSuccessful, Actions } from '@ngxs/store';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { UUID } from 'angular2-uuid';

import { xAnimationAsideCollapse } from '@app/shared/components/animation/animation';
import { AppState } from '@app/core/store/states';
import {
  GetMattersStart,
  PopulateMatter,
  PopulateDocument,
  SetNavigationActionId,
  GetMattersFailure,
  GetNotification
} from '@app/core/store/actions';
import { CoreModel, NodeModel } from '@app/core/models';
import {
  PubNubService,
  CustomEventService,
  DOCUMENTS_SIDE_TAB_SWITCH,
  DOCUMENTS_LIST_FILE_PREVIEW,
  DOCUMENTS_SIDE_TAB_TOGGLE,
  DOCUMENTS_MULTIPLE_ACTIONS,
  DOCUMENTS_MULTIPLE_ACTIONS_OPEN,
  DOCUMENTS_LIST_VIEW,
  DOCUMENTS_PREVIEW_HEADER_DISPLAY,
  NAVIGATION_SIDE_BAR_TOGGLE,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED,
  MATTERS_SELECT_CLOSED,
  NavigationService
} from '@app/core/services';

import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { environment } from '@env/environment';
import { DocumentsViewDetailsMobileComponent, DocumentsSideMobileComponent } from '../../pages';
import { DocumentsAction } from '../../store';
import { DocumentsEvent } from '../../models/event.model';
import { DocumentsModel } from '../../models/documents.model';
import { SideNavigationModel } from '@app/shared/models';

const { locale } = environment;
const icon = locale.global.menu.documents.icon;

@Component({
  selector: 'sc-documents-home',
  templateUrl: './documents-home.component.html',
  animations: [xAnimationAsideCollapse]
})
export class DocumentsHomeComponent implements OnDestroy, OnInit {
  private pubNubSub: CoreModel.PubNubSubscription;
  private destroy$ = new Subject<boolean>();
  @HostBinding('class') classes;
  showHeader = true;
  isPreviewMode = false;
  matterId = '';
  documentId = '';
  documentName = '';
  matterName = '';
  firmId = '';
  asideDetails = true;
  isDownloading = false;
  documentList: DocumentsModel.DocumentItem[] = [];
  isSmall = false;

  getFirmName(firm: CoreModel.FirmDetail): string {
    return (firm && firm.name) || locale.matters.title;
  }

  getNavbarIcon(): string {
    return this.isPreviewMode ? 'Back' : icon;
  }

  @Select(AppState.getLoginUser) logonUser$: Observable<CoreModel.LogonUserInfo>;

  @Select(AppState.getDocumentsByMatter) matterDocs$: Observable<{ [matterId: string]: NodeModel.LawConnectNode[] }>;

  renderListView(): void {
    this.isPreviewMode = false;

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${this.matterId}/sharedocuments/${this.documentId || ''}`,
      queryParams: <Params>{
        t: UUID.UUID()
      }
    });
  }

  openGlobalActionSheet(): void {
    this.bottomSheet.open(DocumentsViewDetailsMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { isGlobal: true, title: 'Please select' }
    });
  }

  openActionSheet(): void {
    const documentDetail = this.getDocumentDetail(this.documentList, this.documentId);

    if (documentDetail) {
      const title = CoreModel.Helper.getValidDocumentNameWithExtension(
        documentDetail.name,
        documentDetail.fileExtension
      );
      const subTitle = `Created on ${DocumentsModel.Helper.localeFormat(documentDetail.createdDate, this.locale)}`;
      this.bottomSheet.open(DocumentsViewDetailsMobileComponent, {
        panelClass: 'x-bottom-sheet',
        data: { isGlobal: false, ...documentDetail, title, subTitle, hidePreview: true }
      });
    }
  }

  documentTitle(): string {
    return this.documentName ? this.documentName : 'Documents';
  }

  getMatterName(): string {
    return this.matterName;
  }

  showSideDetail(isSmallScreen: boolean): boolean {
    return !isSmallScreen && this.asideDetails;
  }

  toggleAside(): void {
    this.asideDetails = !this.asideDetails;
  }

  downloadDocument(matterId: string, documentId: string, documentName: string): void {
    this.isDownloading = true;
    this.updateFromPathParams(matterId);
    this.updateDocumentName(
      documentId,
      DocumentsModel.Helper.getLatestDocumentList(matterId, this.store.selectSnapshot(AppState.getDocumentsByMatter))
    );

    if (documentName) {
      this.store.dispatch(
        new DocumentsAction.DownloadDocument({
          matterId,
          documentId,
          documentName
        })
      );
      return;
    }

    this.isDownloading = false;
  }

  gotoHomeView(): void {
    this.renderListView();
    this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, {
      tabId: 'details',
      id: this.documentId
    });
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
  }

  layoutCss(isPreview: boolean): string {
    if (isPreview) {
      return 'position-relative h-100 overflow-auto x-scroll-hidden';
    }
    return 'layout-column position-relative h-100';
  }

  constructor(
    private store: Store,
    private pubNubSvc: PubNubService,
    private actions$: Actions,
    private appActionSvc: AppActionService,
    private route: ActivatedRoute,
    private bottomSheet: MatBottomSheet,
    private customEventSvc: CustomEventService,
    private navigationSvc: NavigationService,
    @Inject(LOCALE_ID) private locale: string
  ) {
    this.updateFromPathParams();
    this.updateMatterName(this.matterId);
    this.classes = 'lt-container bg-light-secondary';

    this.triggerRecentNotificationDataPulledIfCountZero();
    this.store.dispatch([
      new SetNavigationActionId(SideNavigationModel.SideActionId.documents),
      new GetMattersStart(false)
    ]);

    const isMatterSelection = this.route.snapshot.children[0] && this.route.snapshot.children[0].outlet == 'aside';
    !isMatterSelection &&
      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, {
        actionId: SideNavigationModel.SideActionId.documents
      });

    // handle no matter match from the list.
    if (
      !this.matterName &&
      !CoreModel.Helper.getMatterDetail(this.matterId, this.store.selectSnapshot(AppState.getMattersByFirm))
    ) {
      this.store.dispatch(new GetMattersFailure('No matter detail available'));
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/sharedocuments/${this.documentId || ''}`,
        outlet: 'aside',
        outletPath: 'select',
        queryParams: <Params>{
          t: UUID.UUID()
        }
      });
    }
  }

  ngOnInit() {
    merge(
      this.logonUserSideEffect$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.previewDocumentSideEffect$(),
      this.getDownloadDocumentSuccessSideEffect$(),
      this.getDownloadDocumentFailureSideEffect$(),
      this.getMattersSuccessSideEffect$(),
      this.listenToRemoteSideDetailToggleRequestSideEffect$(),
      this.listenToMobileActionSideEffect$(),
      this.listenToMobileActionOpenRequestSideEffect$(),
      this.getDocumentDetailSuccess$(),
      this.documentListViewSideEffect$(),
      this.showOrHideHeaderSideEffect$(),
      this.listenToIsSmallScreenSideEffect$(),
      this.listenToMatterSelectedFromOptions$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);

    if (this.pubNubSub) {
      this.pubNubSub.unsubscribe();
    }
  }

  private triggerRecentNotificationDataPulledIfCountZero(): void {
    const user = this.store.selectSnapshot(AppState.getLoginUser);
    const notificationCount = this.store.selectSnapshot(AppState.getNotificationCount) || 0;
    user && user.userId && notificationCount == 0 && this.store.dispatch(new GetNotification(user.userId));
  }

  private listenToIsSmallScreenSideEffect$(): Observable<any> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(isSmall => {
        this.isSmall = !!isSmall;
      })
    );
  }

  private openMobileItemActionSheet(data: any): void {
    this.bottomSheet.open(DocumentsViewDetailsMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { ...data, isGlobal: false }
    });
  }

  private getDocumentDetailSuccess$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateDocument),
      tap(e => {
        this.updateDocumentName(
          this.documentId,
          DocumentsModel.Helper.getLatestDocumentList(
            this.matterId,
            this.store.selectSnapshot(AppState.getDocumentsByMatter)
          )
        );
      })
    );
  }

  private getMattersSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateMatter),
      tap(success => {
        this.documentList = DocumentsModel.Helper.getLatestDocumentList(
          this.matterId,
          this.store.selectSnapshot(AppState.getDocumentsByMatter)
        );
        this.updateMatterName(this.matterId);
      })
    );
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      this.updateFromPathParams(matterId);
      this.updateMatterName(this.matterId);
    });
  }

  private updateFromPathParams(matterId: string = undefined): void {
    this.documentId = (this.route.snapshot.params && this.route.snapshot.params['documentId']) || '';
    this.matterId = matterId || (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';

    this.isPreviewMode =
      this.route.snapshot &&
      this.route.snapshot.firstChild &&
      this.route.snapshot.firstChild.routeConfig.path.toLowerCase() == 'preview';
  }

  private updateMatterName(matterId: string): void {
    const matterDetail = CoreModel.Helper.getMatterDetail(
      matterId,
      this.store.selectSnapshot(AppState.getMattersByFirm)
    );

    this.matterName = (matterDetail && matterDetail.name) || '';
    this.firmId = (matterDetail && matterDetail.parentId) || '';
  }

  private updateDocumentName(
    documentId: string,
    documentList: DocumentsModel.DocumentItem[],
    documentName: string = ''
  ): void {
    const documentDetail = this.getDocumentDetail(documentList, documentId);
    const nameWithFileExtension =
      documentDetail &&
      CoreModel.Helper.getValidDocumentNameWithExtension(documentDetail.name, documentDetail.fileExtension);

    this.documentName = nameWithFileExtension || documentName;
  }

  private getDocumentDetail(documents: DocumentsModel.DocumentItem[], documentId: string): DocumentsModel.DocumentItem {
    if (documentId) {
      const result = documents && documents.find(s => s.id == documentId);

      return result ? { ...result } : undefined;
    }
    return undefined;
  }

  private previewDocumentSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_LIST_FILE_PREVIEW, ({ id, ...others }) => {
      this.isPreviewMode = true;

      this.documentId = id;
      this.updateDocumentName(
        this.documentId,
        DocumentsModel.Helper.getLatestDocumentList(
          this.matterId,
          this.store.selectSnapshot(AppState.getDocumentsByMatter)
        )
      );

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/sharedocuments/${this.documentId}/preview`,
        queryParams: <Params>{
          t: UUID.UUID()
        }
      });
    });
  }

  private showOrHideHeaderSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_PREVIEW_HEADER_DISPLAY, ({ showHeader }) => {
      this.showHeader = showHeader;
    });
  }

  private documentListViewSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_LIST_VIEW, () => {
      this.isPreviewMode = false;
    });
  }

  private logonUserSideEffect$(): Observable<CoreModel.LogonUserInfo> {
    return this.logonUser$.pipe(
      tap(user => {
        if (this.pubNubSub) {
          this.pubNubSub.unsubscribe();
        }

        if (!user) {
          return;
        }

        if (user.userId) {
          this.pubNubSub = this.pubNubSvc.subscribeToChannels(user.userId, [user.userId], notification => {
            const msg = CoreModel.Helper.convertNotificationMessage(notification);

            if (
              msg.notificationType === CoreModel.PubNubNotificationType.sharing ||
              msg.notificationType === CoreModel.PubNubNotificationType.revoking
            ) {
              this.store.dispatch([new GetMattersStart(false)]);
            }
          });
        }
      })
    );
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_SIDE_TAB_SWITCH, ({ id, skipListRender, ...others }) => {
      if (this.documentId !== id) {
        this.documentId = id;
        skipListRender !== undefined && !skipListRender && this.renderListView();
        this.updateDocumentName(
          this.documentId,
          DocumentsModel.Helper.getLatestDocumentList(
            this.matterId,
            this.store.selectSnapshot(AppState.getDocumentsByMatter)
          )
        );

        this.navigationSvc.goto(<CoreModel.NavigationData>{
          path: `/matters/${this.matterId}/sharedocuments/${this.documentId}/`,
          queryParams: <Params>{
            t: UUID.UUID()
          }
        });

        return;
      }
    });
  }

  private listenToRemoteSideDetailToggleRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_SIDE_TAB_TOGGLE, ({ show }) => {
      if (show !== undefined) {
        this.asideDetails = show;
        return;
      }
    });
  }

  private listenToMobileActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_MULTIPLE_ACTIONS, ({ actionType, value }) => {
      if (actionType == DocumentsEvent.MultipleActionDispatchType.download) {
        this.isDifferentDocumentId(value.id) && this.mobileNavigateTo(value.id);
        this.downloadDocument(
          this.matterId,
          value.id,
          CoreModel.Helper.getValidDocumentNameWithExtension(value.name, value.fileExtension)
        );
        return;
      }

      if (actionType == DocumentsEvent.MultipleActionDispatchType.preview) {
        value && this.customEventSvc.dispatchEvent(DOCUMENTS_LIST_FILE_PREVIEW, { ...value });
        return;
      }

      if (actionType == DocumentsEvent.MultipleActionDispatchType.viewInfo) {
        this.isDifferentDocumentId(value.id) && this.mobileNavigateTo(value.id);
        this.bottomSheet.open(DocumentsSideMobileComponent, {
          panelClass: 'x-bottom-sheet',
          data: { isGlobal: false, value, actionType, title: 'Details', matterId: this.matterId }
        });
      }

      if (actionType == DocumentsEvent.MultipleActionDispatchType.viewComment) {
        this.isDifferentDocumentId(value.id) && this.mobileNavigateTo(value.id);
        this.bottomSheet.open(DocumentsSideMobileComponent, {
          panelClass: 'x-bottom-sheet',
          data: { isGlobal: false, value, actionType, title: 'Comments', matterId: this.matterId }
        });
      }
    });
  }

  private isDifferentDocumentId(id: string): boolean {
    return this.documentId !== id;
  }

  private mobileNavigateTo(id: string): void {
    this.documentId = id;
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${this.matterId}/sharedocuments/${this.documentId || ''}`,
      queryParams: <Params>{
        t: UUID.UUID()
      }
    });
  }

  private listenToMobileActionOpenRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_MULTIPLE_ACTIONS_OPEN, data => {
      this.updateDocumentName(this.documentId, [], data.name);
      this.mobileNavigateTo(data.id);
      this.openMobileItemActionSheet(data);
    });
  }

  private getDownloadDocumentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DownloadDocumentSuccess),
      tap(() => {
        this.isDownloading = false;
      })
    );
  }

  private getDownloadDocumentFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DownloadDocumentFailure),
      tap(() => {
        this.isDownloading = false;
      })
    );
  }
}
