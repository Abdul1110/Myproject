export namespace DocumentsEvent {
  export interface MultipleActionEventDetail {
    actionType: string;
    value: any;
  }

  export enum MultipleActionDispatchType {
    preview = 'preview',
    download = 'download',
    viewInfo = 'view-info',
    viewComment = 'view-comment'
  }
}
