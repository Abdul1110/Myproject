import { Component, Inject, OnDestroy } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { DocumentsEvent } from '../../models/event.model';
import { Actions, ofActionSuccessful, Store } from '@ngxs/store';
import { Observable, merge, Subject } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { DocumentsAction } from '../../store';
import { DocumentsModel } from '../../models/documents.model';
import { AnnotatorModel } from '@app/shared/models';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { CustomEventService, DOCUMENTS_COMMENT_REPLIED_DELETE, DOCUMENTS_SIDE_REFRESH_ME } from '@app/core/services';
import { AppState } from '@app/core/store/states';

@Component({
  selector: 'sc-documents-side-mobile',
  templateUrl: './documents-side-mobile.component.html'
})
export class DocumentsSideMobileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private repliedDeletedIds: string[] = [];
  title = '';
  subtitle = '';
  documentDetail: DocumentsModel.DocumentItem = undefined;
  comments: DocumentsModel.LawConnectDocumentAnnotation[] = [];
  replied: DocumentsModel.AnnotationRepliedList = undefined;
  commentSeqs: AnnotatorModel.AnnotationSeq[] = [];
  documentActivities: DocumentsModel.LawConnectDocumentHistory[] = [];
  documentId = '';
  matterId = '';
  currentUser = undefined;
  firmName = '';

  isViewDetail(): boolean {
    return this.data && this.data.actionType == DocumentsEvent.MultipleActionDispatchType.viewInfo;
  }

  isViewComment(): boolean {
    return this.data && this.data.actionType == DocumentsEvent.MultipleActionDispatchType.viewComment;
  }

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private bottomSheetRef: MatBottomSheetRef<DocumentsSideMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private actions$: Actions,
    private store: Store,
    private appActionSvc: AppActionService,
    private customEventSvc: CustomEventService
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';

    merge(
      this.firmSideEffect$(),
      this.documentAnnotationSuccessSideEffect$(),
      this.listenToDeleteCommentSuccessSideEffect$(),
      this.documentActivitySuccessSideEffect$(),
      this.documentActivityFailureSideEffect$(),
      this.logonUserSideEffect$(),
      this.listenToCommentsRepliedDeleteRequestSideEffect$(),
      this.listenToNewCommentReplySuccessSideEffect$(),
      this.deleteAnnotationRepliedFailureSideEffect$(),
      this.documentAnnotationRepliedSuccessSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    const { id } = this.data.value;
    const { matterId } = this.data;

    this.documentId = id;
    this.matterId = matterId;
    this.documentDetail = this.getLatestDocumentDetail(this.matterId, this.documentId);

    id && this.store.dispatch(new DocumentsAction.GetDocumentAnnotation(this.documentId));
    id && this.store.dispatch(new DocumentsAction.GetDocumentActivity(this.documentId));
  }

  private getLatestDocumentDetail(matterId: string, documentId: string): DocumentsModel.DocumentItem {
    const documents = DocumentsModel.Helper.getLatestDocumentList(
      matterId,
      this.store.selectSnapshot(AppState.getDocumentsByMatter)
    );

    return documents ? documents.find(d => d.id == documentId) : undefined;
  }

  private documentAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentAnnotationSuccess),
      tap(({ payload }) => {
        if (payload && payload.length > 0) {
          this.comments = DocumentsModel.Helper.getCommentsInAscOrder(payload);
          this.commentSeqs = DocumentsModel.Helper.getCommentSeqs(this.comments);

          const annotationIds = payload.map(a => a.id);
          this.store.dispatch(new DocumentsAction.GetDocumentReplied(annotationIds));
          return;
        }

        this.comments = [];
        this.commentSeqs = [];
      })
    );
  }

  private listenToCommentsRepliedDeleteRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_COMMENT_REPLIED_DELETE, ({ replyId, annotationId }) => {
      this.repliedDeletedIds = [].concat(this.repliedDeletedIds).concat(replyId);
      this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);
      this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_REFRESH_ME, {});

      this.store.dispatch(new DocumentsAction.DeleteReplied({ replyId, annotationId }));
    });
  }

  private getLatestReplied(
    payload: DocumentsModel.AnnotationRepliedList,
    repliedDeletedIds: string[]
  ): DocumentsModel.AnnotationRepliedList {
    const repliedByAnnotation = payload;

    // exclude just deleted reply ids
    if (Object.keys(repliedByAnnotation).length > 0 && repliedDeletedIds.length > 0) {
      let replies = {};
      const old = { ...repliedByAnnotation };
      Object.keys(old).forEach(annotationId => {
        replies[annotationId] = old[annotationId].filter(x => repliedDeletedIds.findIndex(d => d == x.id) == -1) || [];
      });

      return { ...replies };
    }

    return { ...repliedByAnnotation };
  }

  private listenToDeleteCommentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DeleteAnnotationSuccess),
      tap(({ payload: { success, annotationId: deletedAnnotationId } }) => {
        if (!success) {
          return this.store.dispatch(new DocumentsAction.DeleteAnnotationFailure('Delete annotation failed'));
        }

        this.comments = DocumentsModel.Helper.getLatestCommentsAfterDeletingComment(this.comments, deletedAnnotationId);

        this.commentSeqs = DocumentsModel.Helper.getLatestCommentSeqsAfterDeletingComment(
          this.commentSeqs,
          deletedAnnotationId
        );

        this.replied = DocumentsModel.Helper.getLatestRepliedAfterDeletingComment(this.replied, deletedAnnotationId);
        this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_REFRESH_ME, {});
      })
    );
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private documentActivitySuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentActivitySuccess),
      tap(({ payload: { activities, info } }) => {
        this.documentDetail = { ...this.documentDetail, fileSizeKb: info ? info.fileSizeKb : 0 };
        this.documentActivities = activities || [];
      })
    );
  }

  private documentActivityFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentActivityFailure),
      tap((error: any) => {
        this.documentActivities = [];
      })
    );
  }

  private firmSideEffect$(): Observable<any> {
    return this.appActionSvc.selectedFirm$.pipe(
      tap(firm => {
        this.firmName = (firm && firm.name) || '';
      })
    );
  }

  private listenToNewCommentReplySuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.ReplyCommentSuccess),
      tap(({ payload }) => {
        const replied = { ...this.replied };
        let repliedUpdate = {};
        Object.keys(replied).forEach(annotationId => {
          repliedUpdate[annotationId] =
            annotationId === payload.annotationId ? replied[annotationId].concat(payload) : replied[annotationId];
        });

        this.replied = { ...repliedUpdate };
        this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_REFRESH_ME, {});
      })
    );
  }

  private deleteAnnotationRepliedFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DeleteRepliedFailure),
      tap(({ payload: { data: { replyId }, err } }) => {
        this.repliedDeletedIds = this.repliedDeletedIds.filter(d => d !== replyId) || [];
        this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);

        if (err && err.status == '500') {
          return this.store.dispatch(new DocumentsAction.GetDocumentAnnotation(this.documentId));
        }
      })
    );
  }

  private documentAnnotationRepliedSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentRepliedSuccess),
      tap(({ payload }) => {
        this.replied = this.getLatestReplied(payload || {}, this.repliedDeletedIds);
        this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_REFRESH_ME, {});
      })
    );
  }
}
