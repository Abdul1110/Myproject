import { Component, ChangeDetectionStrategy, OnDestroy, Inject, HostBinding } from '@angular/core';
import { Subject } from 'rxjs';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { CustomEventService, DOCUMENTS_MULTIPLE_ACTIONS } from '@app/core/services';
import { DocumentsEvent } from '../../models/event.model';
import { CoreModel } from '@app/core/models';

@Component({
  selector: 'sc-documents-view-details-mobile',
  templateUrl: './documents-view-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DocumentsViewDetailsMobileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  title = '';
  subtitle = '';

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  isGlobal(data: any): boolean {
    return data && data.isGlobal;
  }

  isImage(data: any): boolean {
    return data && CoreModel.Helper.isImageFile(data.fileExtension);
  }

  previewDocument(data: any): void {
    this.dispatchEvent(DocumentsEvent.MultipleActionDispatchType.preview, data);
    this.bottomSheetRef.dismiss();
  }

  download(data: any): void {
    this.dispatchEvent(DocumentsEvent.MultipleActionDispatchType.download, data);
    this.bottomSheetRef.dismiss();
  }

  viewSideDetail(data: any): void {
    this.dispatchEvent(DocumentsEvent.MultipleActionDispatchType.viewInfo, data);
    this.bottomSheetRef.dismiss();
  }

  viewSideComment(data: any): void {
    this.dispatchEvent(DocumentsEvent.MultipleActionDispatchType.viewComment, data);
    this.bottomSheetRef.dismiss();
  }

  hidePreview(data: any): boolean {
    return data && data.hidePreview;
  }

  constructor(
    private customEventSvc: CustomEventService,
    private bottomSheetRef: MatBottomSheetRef<DocumentsViewDetailsMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';
  }

  @HostBinding('class.x-action-list')
  ngOnDestroy() {
    this.destroy$.next();
  }

  private dispatchEvent(actionType: string, data: any): void {
    this.customEventSvc.dispatchEvent(DOCUMENTS_MULTIPLE_ACTIONS, {
      actionType,
      value: { ...this.data }
    });
  }
}
