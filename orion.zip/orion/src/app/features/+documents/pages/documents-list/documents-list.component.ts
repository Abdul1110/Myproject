import { Component, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { CoreModel } from '@app/core/models';
import { DocumentsModel } from '../../models/documents.model';
import { environment } from '@env/environment';
import {
  CustomEventService,
  DOCUMENTS_LIST_SORTING,
  DOCUMENTS_SIDE_TAB_SWITCH,
  DOCUMENTS_MULTIPLE_ACTIONS,
  DOCUMENTS_MULTIPLE_ACTIONS_OPEN,
  NAVIGATION_SIDE_BAR_TOGGLE,
  MATTERS_SELECT_CLOSED,
  DOCUMENTS_LIST_MY_UPLOADS_ONLY
} from '@app/core/services';
import { AppState } from '@app/core/store/states';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { PopulateDocument } from '@app/core/store/actions';
import { DocumentsAction, DocumentsState } from '../../store';
import { BrowserService } from '@leap/lyra-design';

const { delete: document_delete } = environment.locale.document_actions;

@Component({
  selector: 'sc-documents-list',
  templateUrl: './documents-list.component.html'
})
export class DocumentsListComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private matterId = '';
  private documentId = '';
  private activeSorting: CoreModel.ColumnSorting = DocumentsModel.Helper.getDocDefaultSortingOption();
  private onlyMyUploads = false;

  emptyDocument = environment.locale.no_results.documents.empty;
  serverError = environment.locale.no_results.documents.server_error;
  hasNoDocument = false;
  hasError = false;
  isLoading = true;
  documentList: DocumentsModel.DocumentItem[] = [];
  currentUser = undefined;
  isSmallScreen = false;
  screenInnerHeight = 0;

  scrollObserver(scrollIndex: number): void {}

  isActiveItem(document: DocumentsModel.DocumentItem): boolean {
    if (this.documentId == undefined) {
      return false;
    }

    const { id } = document;
    return this.documentId == id;
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private customEventSvc: CustomEventService,
    private store: Store,
    private route: ActivatedRoute,
    private appActionSvc: AppActionService,
    private actions$: Actions,
    private browserSvc: BrowserService
  ) {
    this.matterId = this.route.snapshot.params['matterId'];
    this.documentId = this.route.snapshot.params['documentId'];
    this.onlyMyUploads = this.store.selectSnapshot(DocumentsState.getOnlyMyUploadsFlag);
    this.screenInnerHeight =
      this.browserSvc && this.browserSvc.isBrowser && this.browserSvc.window && this.browserSvc.window.innerHeight;

    merge(
      this.changeListOrderSideEffect$(),
      this.changeShowMyUploadsOnlySideEffect$(),
      this.logonUserSideEffect$(),
      this.detectSmallScreen$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.getDocumentListSuccessSideEffect$(),
      this.loadDocumentPageFailureSideEffet$(),
      this.listenToMobileMultipleActionSideEffect$(),
      this.listenToMobileActionOpenRequestSideEffect$(),
      this.listenToMatterSelectedFromOptions$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.renderSharedWithMeList(this.activeSorting, this.onlyMyUploads);
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      this.matterId = matterId;
      this.renderSharedWithMeList(this.activeSorting, this.onlyMyUploads);
      this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, {
        tabId: 'details',
        id: '',
        skipListRender: true
      });
    });
  }

  private listenToMobileMultipleActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_MULTIPLE_ACTIONS, ({ value: { id, ...others } }) => {
      if (this.documentId !== id) {
        this.documentId = id;
      }
    });
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_SIDE_TAB_SWITCH, ({ id, ...others }) => {
      if (this.documentId !== id) {
        this.documentId = id;
      }
    });
  }

  private listenToMobileActionOpenRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_MULTIPLE_ACTIONS_OPEN, data => {
      if (data && this.documentId !== data.id) {
        this.documentId = data.id;
      }
    });
  }

  private detectSmallScreen$(): Observable<any> {
    return this.appActionSvc.isSmallScreen$.pipe(tap(isSmall => (this.isSmallScreen = isSmall)));
  }

  private changeListOrderSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_LIST_SORTING, (sorting: CoreModel.ColumnSorting) => {
      this.renderSharedWithMeList(sorting, this.onlyMyUploads);
    });
  }

  private changeShowMyUploadsOnlySideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_LIST_MY_UPLOADS_ONLY, ({ onlyMyUploads }) => {
      this.onlyMyUploads = onlyMyUploads;
      this.store.dispatch(new DocumentsAction.SetOnlyMyUploads(onlyMyUploads));
      this.renderSharedWithMeList(this.activeSorting, onlyMyUploads);
    });
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private getDocumentListSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateDocument),
      tap(v => {
        this.renderSharedWithMeList(this.activeSorting, this.onlyMyUploads);
        if (
          this.documentId &&
          !this.hasNoDocument &&
          this.documentList.filter(s => s.id == this.documentId).length > 0
        ) {
          this.store.dispatch([
            new DocumentsAction.GetDocumentActivity(this.documentId),
            new DocumentsAction.GetDocumentAnnotation(this.documentId)
          ]);
        }
      })
    );
  }

  private loadDocumentPageFailureSideEffet$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.LoadDocumentPageFailure),
      tap(v => {
        this.renderSharedWithMeList(this.activeSorting, this.onlyMyUploads);
      })
    );
  }

  private getLatestDocumentList(sortBy: CoreModel.ColumnSorting, onlyMyUploads = false): DocumentsModel.DocumentItem[] {
    const documents = DocumentsModel.Helper.getLatestDocumentList(
      this.matterId,
      this.store.selectSnapshot(AppState.getDocumentsByMatter)
    );

    const filtered = !onlyMyUploads
      ? documents
      : documents.filter(d => this.currentUser && d.ownerUserId == this.currentUser.userId);

    if (filtered && filtered.length == 0) {
      return [];
    }

    if (!sortBy) {
      return [].concat(filtered);
    }

    return [].concat(CoreModel.Helper.sortBy(filtered, sortBy));
  }

  private renderSharedWithMeList(sorting: CoreModel.ColumnSorting, onlyMyUploads = false): void {
    this.documentList = this.getLatestDocumentList(sorting, onlyMyUploads);
    this.hasNoDocument = this.documentList.length == 0;
    this.activeSorting = { ...sorting };
    this.isLoading = false;
  }
}
