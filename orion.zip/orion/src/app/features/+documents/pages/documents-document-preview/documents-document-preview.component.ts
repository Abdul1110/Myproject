import { Component, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { ActivatedRoute } from '@angular/router';
import { tap, takeUntil } from 'rxjs/operators';
import { Observable, Subject, merge, interval } from 'rxjs';

import {
  AnalyticService,
  CustomEventService,
  DOCUMENTS_SIDE_TAB_SWITCH,
  DOCUMENTS_COMMENT_CLICK_TO_VIEW,
  DOCUMENTS_PREVIEW_HEADER_DISPLAY,
  NAVIGATION_SIDE_BAR_TOGGLE
} from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

import { environment } from '@env/environment';
import { DocumentsAction } from '../../store';
import { DocumentsModel } from '../../models/documents.model';
import { AnnotatorModel } from '@app/shared/models';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { CoreModel } from '@app/core/models';
import { AppState } from '@app/core/store/states';

const { server_error, file_unsupported, file_to_large } = environment.locale.no_results.documents.document;
const { previewFileSizeLimit } = environment.appSettings;

@Component({
  selector: 'sc-documents-document-preview',
  templateUrl: './documents-document-preview.component.html'
})
export class DocumentsDocumentPreviewComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private comments: DocumentsModel.LawConnectDocumentAnnotation[] = [];
  private commentSeqs: AnnotatorModel.AnnotationSeq[] = [];
  private isSmallScreen = false;

  enableAnnotator = true;
  isLoading = true;
  isError = false;
  isDocumentDownloading = false;
  isBigFile = false;
  documentName = '';
  documentNameWithExtension = '';
  documentId = '';
  matterId = '';
  previewUrl = '';
  fileExtension = '';
  switchToPage: DocumentsModel.CommentClickToViewRequest = undefined;
  annotatingBy: AnnotatorModel.AnnotatingBy = undefined;
  activeAnnotation: AnnotatorModel.AnnotationBeforeCreated = undefined;
  bigFileWarning = file_to_large;
  apiStillCreatingPdf = false;

  download(matterId: string, documentId: string, documentName: string): void {
    this.isDocumentDownloading = true;
    this.store.dispatch(new DocumentsAction.DownloadDocument({ matterId, documentId, documentName }));
  }

  getServerErrorIcon(): string {
    return server_error.icon;
  }

  getServerErrorTitle(): string {
    return server_error.title;
  }

  setActiveCommentStatus(currentActive: AnnotatorModel.AnnotationBeforeCreated): void {
    this.activeAnnotation = this.enrichActiveAnnotationDetail(currentActive, this.comments);
  }

  addOrUpdateComment(comment: AnnotatorModel.AnnotationData): void {
    const newAnnotation = <AnnotatorModel.AnnotationData>{
      ...comment,
      aboutPage: <AnnotatorModel.AnnotatedPage>{
        ...comment.aboutPage,
        fileId: this.documentId
      }
    };

    const { userId, userName } = this.annotatingBy;
    if (comment.isNew) {
      this.store.dispatch(new DocumentsAction.AddAnnotation({ ...newAnnotation, userId, displayName: userName }));
      return;
    }

    this.store.dispatch(new DocumentsAction.UpdateAnnotation({ ...newAnnotation, userId, displayName: userName }));
  }

  deleteComment(comment: AnnotatorModel.DeleteAnnotation): void {
    this.store.dispatch(new DocumentsAction.DeleteAnnotation(comment.annotationId));
  }

  togglePageHeader(direction: string): void {
    this.isSmallScreen &&
      this.customEventSvc.dispatchEvent(DOCUMENTS_PREVIEW_HEADER_DISPLAY, { showHeader: direction === 'up' });
  }

  getFileViewType(fileExtension: string): CoreModel.ViewType {
    const viewType = CoreModel.Helper.getFileViewer(fileExtension);
    return viewType;
  }

  getUnsupportedTitle(fileExtension: string): string {
    return `<b>.${fileExtension}</b> ${file_unsupported.title}`;
  }

  getUnsupportedMessage(): string {
    return file_unsupported.message;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private router: ActivatedRoute,
    private actions$: Actions,
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersPreviewDocument,
        action: "View selected shared's document"
      });

      const { matterId, documentId } = this.router.parent.snapshot.params;

      this.documentId = documentId;
      this.matterId = matterId;

      merge(
        this.logonUserSideEffect$(),
        this.getPreviewDocumentUrlSuccessSideEffect$(),
        this.getPreviewDocumentUrlFailureSideEffect$(),
        this.getDownloadDocumentSuccessSideEffect$(),
        this.getDownloadDocumentFailureSideEffect$(),
        this.listenToCommentClickToViewRequestSideEffect$(),
        this.documentAnnotationSuccessSideEffect$(),
        this.listenToDeleteCommentSuccessSideEffect$(),
        this.addAnnotationSuccessSideEffect$(),
        this.updateAnnotationSuccessSideEffect$(),
        this.smallScreenDetectionSideEffect$(),
        this.isLargeFileSideEffect$(),
        this.failToReadDocumentActivitySideEffect$(),
        this.updateEvery60SecondsIfUserStillPreviewingDocumentHeartBeat$()
      )
        .pipe(takeUntil(this.destroy$))
        .subscribe();

      const documents = DocumentsModel.Helper.getLatestDocumentList(
        this.matterId,
        this.store.selectSnapshot(AppState.getDocumentsByMatter)
      );

      const document = documents ? documents.find(d => d.id == this.documentId) : undefined;
      this.fileExtension = (document && document.fileExtension) || '';
      this.documentNameWithExtension =
        document && CoreModel.Helper.getValidDocumentNameWithExtension(document.name, document.fileExtension);

      if (document && CoreModel.Helper.isImageFile(this.fileExtension)) {
        this.store.dispatch(new DocumentsAction.GetDocumentActivity(this.documentId));
      } else {
        this.store.dispatch([
          new DocumentsAction.GetDocumentAnnotation(this.documentId),
          new DocumentsAction.GetDocumentActivity(this.documentId)
        ]);
      }

      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: false });
    }
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(
      tap(user => {
        if (user && user.userId && this.documentId && !CoreModel.Helper.isImageFile(this.fileExtension)) {
          this.store.dispatch(
            new DocumentsAction.StartActiveUserInDocument({ documentId: this.documentId, userId: user.userId })
          );
        }

        this.annotatingBy = <AnnotatorModel.AnnotatingBy>{
          documentId: this.documentId,
          userId: user.userId,
          userName: user.displayName
        };
      })
    );
  }

  private updateEvery60SecondsIfUserStillPreviewingDocumentHeartBeat$(): Observable<any> {
    return interval(60000).pipe(
      tap(() => {
        this.annotatingBy &&
          this.annotatingBy.userId &&
          this.documentId &&
          !CoreModel.Helper.isImageFile(this.fileExtension) &&
          this.store.dispatch(
            new DocumentsAction.UpdateActiveUserHeartBeat({
              documentId: this.documentId,
              userId: this.annotatingBy.userId
            })
          );
      })
    );
  }

  private smallScreenDetectionSideEffect$(): Observable<any> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(isSmallScreen => {
        this.isSmallScreen = isSmallScreen;
      })
    );
  }

  private getPreviewDocumentUrlSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.PreviewDocumentSuccess),
      tap(({ payload: url }) => {
        const isImage = CoreModel.Helper.isImageFile(this.fileExtension);
        const isOriginPdf = CoreModel.Helper.isPdfFile(this.fileExtension);
        this.isLoading = false;
        this.previewUrl = url;
        this.apiStillCreatingPdf = !!(!isImage && !isOriginPdf && url && (url as string).includes('//documents-'));

        if (!isImage) {
          this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, {
            id: this.documentId,
            tabId: 'comments'
          });
        }
      })
    );
  }

  private getPreviewDocumentUrlFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.PreviewDocumentFailure),
      tap(err => {
        this.isLoading = false;
        this.isError = true;
      })
    );
  }

  private getDownloadDocumentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DownloadDocumentSuccess),
      tap(() => {
        this.isDocumentDownloading = false;
      })
    );
  }

  private getDownloadDocumentFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DownloadDocumentFailure),
      tap(() => {
        this.isDocumentDownloading = false;
        this.isError = true;
      })
    );
  }

  private listenToCommentClickToViewRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      DOCUMENTS_COMMENT_CLICK_TO_VIEW,
      ({ pageId, seqId }: DocumentsModel.CommentClickToViewRequest) => {
        this.switchToPage = { pageId, seqId };
      }
    );
  }

  private documentAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentAnnotationSuccess),
      tap(({ payload }) => {
        if (payload && payload.length > 0) {
          this.comments = DocumentsModel.Helper.getCommentsInAscOrder(payload);
          this.commentSeqs = DocumentsModel.Helper.getCommentSeqs(this.comments);
          return;
        }

        this.comments = [];
        this.commentSeqs = [];
      })
    );
  }

  private listenToDeleteCommentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DeleteAnnotationSuccess),
      tap(({ payload: { success, annotationId: deletedAnnotationId } }) => {
        if (!success) {
          return;
        }

        this.comments = DocumentsModel.Helper.getLatestCommentsAfterDeletingComment(this.comments, deletedAnnotationId);
        this.commentSeqs = DocumentsModel.Helper.getLatestCommentSeqsAfterDeletingComment(
          this.commentSeqs,
          deletedAnnotationId
        );
      })
    );
  }

  private isLargeFileSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentActivitySuccess),
      tap(({ payload: { activities, info } }) => {
        if (info) {
          this.isBigFile = info.fileSizeKb >= previewFileSizeLimit;

          if (!this.isBigFile) {
            this.store.dispatch(
              new DocumentsAction.PreviewDocument({
                matterId: this.matterId,
                documentId: this.documentId,
                isImage: CoreModel.Helper.isImageFile(this.fileExtension)
              })
            );
          } else {
            if (!CoreModel.Helper.isImageFile(this.fileExtension)) {
              this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, {
                id: this.documentId,
                tabId: 'comments'
              });
            }
          }
        }

        this.isLoading = false;
      })
    );
  }

  private failToReadDocumentActivitySideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentActivityFailure),
      tap(error => {
        if (error) {
          this.isLoading = false;
          this.isError = true;
        }
      })
    );
  }

  private enrichActiveAnnotationDetail(
    currentActive: AnnotatorModel.AnnotationBeforeCreated,
    annotations: DocumentsModel.LawConnectDocumentAnnotation[]
  ): AnnotatorModel.AnnotationBeforeCreated {
    let seq = 1;

    if (annotations && annotations.length > 0) {
      const found = annotations.find(x => x.id === currentActive.id);
      seq = found ? found.annotationSeq : annotations.length + 1;
    }

    const newRanges = currentActive.ranges.map(x =>
      Object.assign({}, x, {
        start: x.start.replace('"', '').replace('"', ''),
        end: x.end.replace('"', '').replace('"', '')
      })
    );

    return <AnnotatorModel.AnnotationBeforeCreated>{ ...currentActive, seq, ranges: newRanges };
  }

  private addAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.AddAnnotationSuccess),
      tap(({ payload: success }) => {
        if (!success) {
          return this.store.dispatch(new DocumentsAction.AddAnnotationFailure('Add annotation failed'));
        }

        // delay on purpose: to provide enough time for endpoint to complete the updates.
        setTimeout(() => this.store.dispatch(new DocumentsAction.GetDocumentAnnotation(this.documentId)), 1000);
      })
    );
  }

  private updateAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.UpdateAnnotationSuccess),
      tap(({ payload: success }) => {
        if (!success) {
          return this.store.dispatch(new DocumentsAction.AddAnnotationFailure('Update annotation failed'));
        }

        // delay on purpose: to provide enough time for endpoint to complete the updates.
        setTimeout(() => this.store.dispatch(new DocumentsAction.GetDocumentAnnotation(this.documentId)), 1000);
      })
    );
  }
}
