import { DocumentsViewDetailsMobileComponent } from './documents-view-details-mobile/documents-view-details-mobile.component';
import { DocumentsSideComponent } from './documents-side/documents-side.component';
import { DocumentsListHeaderComponent } from './documents-list-header/documents-list-header.component';
import { DocumentsListComponent } from './documents-list/documents-list.component';
import { DocumentsDocumentPreviewComponent } from './documents-document-preview/documents-document-preview.component';
import { DocumentsSideMobileComponent } from './documents-side-mobile/documents-side-mobile.component';

export * from './documents-view-details-mobile/documents-view-details-mobile.component';
export * from './documents-side/documents-side.component';
export * from './documents-list-header/documents-list-header.component';
export * from './documents-list/documents-list.component';
export * from './documents-document-preview/documents-document-preview.component';
export * from './documents-side-mobile/documents-side-mobile.component';

export const documentsPages = [
  DocumentsViewDetailsMobileComponent,
  DocumentsSideComponent,
  DocumentsListHeaderComponent,
  DocumentsListComponent,
  DocumentsDocumentPreviewComponent,
  DocumentsSideMobileComponent
];
