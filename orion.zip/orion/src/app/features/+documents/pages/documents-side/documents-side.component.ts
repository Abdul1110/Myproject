import { Component, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { SignatureModel, CoreModel } from '@app/core/models';
import { AppState } from '@app/core/store/states';
import { Observable, Subject, merge } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { environment } from '@env/environment';
import {
  CustomEventService,
  DOCUMENTS_SIDE_TAB_SWITCH,
  DOCUMENTS_COMMENT_REPLIED_DELETE,
  MATTERS_SELECT_CLOSED
} from '@app/core/services';
import { DocumentsModel } from '../../models/documents.model';
import { DocumentsAction } from '../../store';
import { AnnotatorModel } from '@app/shared/models';

const { details, comments } = environment.locale.global.side_menu;
const tabIds = { details: 'details', comments: 'comments' };

@Component({
  selector: 'sc-documents-side',
  templateUrl: './documents-side.component.html'
})
export class DocumentsSideComponent implements OnDestroy {
  isPreview = false;
  documentId = '';
  matterId: '';
  selectedTabId = tabIds.details;
  documentDetail: DocumentsModel.DocumentItem = undefined;
  isLoading = true;
  currentUser = undefined;
  firmName = '';
  documentActivities: DocumentsModel.LawConnectDocumentHistory[] = [];
  comments: DocumentsModel.LawConnectDocumentAnnotation[] = [];
  replied: DocumentsModel.AnnotationRepliedList = {};
  commentSeqs: AnnotatorModel.AnnotationSeq[] = [];
  repliedDeletedIds: string[] = [];

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  changeDisplay(id: string): void {
    this.selectedTabId = id;
  }

  isSelected(tabId: string): boolean {
    return tabId == this.selectedTabId;
  }

  tabsFilter(data: DocumentsModel.DocumentItem): { title: string; id: string }[] {
    if (!data || !CoreModel.Helper.isImageFile(data.fileExtension)) {
      return this.tabs;
    }

    return this.tabs.filter(x => x.id !== tabIds.comments);
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private route: ActivatedRoute,
    private appActionSvc: AppActionService,
    private customEventSvc: CustomEventService,
    private actions$: Actions
  ) {
    this.documentId = this.route.snapshot.params['documentId'] || '';
    this.matterId = (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';

    merge(
      this.documentsSideEffect$(),
      this.logonUserSideEffect$(),
      this.firmSideEffect$(),
      this.documentActivitySuccessSideEffect$(),
      this.documentActivityFailureSideEffect$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.documentAnnotationSuccessSideEffect$(),
      this.documentAnnotationFailureSideEffect$(),
      this.documentAnnotationRepliedSuccessSideEffect$(),
      this.documentAnnotationRepliedFailureSideEffect$(),
      this.listenToCommentsRepliedDeleteRequestSideEffect$(),
      this.listenToNewCommentReplySuccessSideEffect$(),
      this.deleteAnnotationRepliedSuccessSideEffect$(),
      this.deleteAnnotationRepliedFailureSideEffect$(),
      this.listenToDeleteCommentSuccessSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.documentDetail = this.getLatestDocumentDetail(this.matterId, this.documentId);
  }

  private destroy$ = new Subject<boolean>();
  private tabs = [{ title: details, id: tabIds.details }, { title: comments, id: tabIds.comments }];

  private getLatestDocumentDetail(matterId: string, documentId: string): DocumentsModel.DocumentItem {
    const documents = DocumentsModel.Helper.getLatestDocumentList(
      matterId,
      this.store.selectSnapshot(AppState.getDocumentsByMatter)
    );

    return documents ? documents.find(d => d.id == documentId) : undefined;
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private firmSideEffect$(): Observable<any> {
    return this.appActionSvc.selectedFirm$.pipe(
      tap(firm => {
        this.firmName = (firm && firm.name) || '';
      })
    );
  }

  private documentsSideEffect$(): Observable<{}> {
    return this.appActionSvc.documentsByMatter$.pipe(
      tap((documentsByMatters: DocumentsModel.DocumentByMatter) => {
        const detail = this.getLatestDocumentDetail(this.matterId, this.documentId);
        this.documentDetail = detail
          ? { ...detail, fileSizeKb: this.documentDetail ? this.documentDetail.fileSizeKb : 0 }
          : undefined;

        if (documentsByMatters) {
          this.isLoading = false;
        }
      })
    );
  }

  private documentActivitySuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentActivitySuccess),
      tap(({ payload: { activities, info } }) => {
        this.documentActivities = activities || [];
        this.documentDetail = { ...this.documentDetail, fileSizeKb: info.fileSizeKb };

        if (this.selectedTabId == tabIds.details) {
          this.isLoading = false;
        }
      })
    );
  }

  private documentActivityFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentActivityFailure),
      tap((error: any) => {
        this.documentActivities = [];
        if (this.selectedTabId == tabIds.details) {
          this.isLoading = false;
        }
      })
    );
  }

  private documentAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentAnnotationSuccess),
      tap(({ payload }) => {
        if (payload && payload.length > 0) {
          this.comments = DocumentsModel.Helper.getCommentsInAscOrder(payload);
          this.commentSeqs = DocumentsModel.Helper.getCommentSeqs(this.comments);

          const annotationIds = payload.map(a => a.id);
          this.store.dispatch(new DocumentsAction.GetDocumentReplied(annotationIds));
          return;
        }

        this.comments = [];
        this.commentSeqs = [];

        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private documentAnnotationFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentAnnotationFailure),
      tap((error: any) => {
        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private documentAnnotationRepliedSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentRepliedSuccess),
      tap(({ payload }) => {
        this.replied = this.getLatestReplied(payload || {}, this.repliedDeletedIds);

        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private getLatestReplied(
    payload: DocumentsModel.AnnotationRepliedList,
    repliedDeletedIds: string[]
  ): DocumentsModel.AnnotationRepliedList {
    const repliedByAnnotation = payload;

    // exclude just deleted reply ids
    if (Object.keys(repliedByAnnotation).length > 0 && repliedDeletedIds.length > 0) {
      let replies = {};
      const old = { ...repliedByAnnotation };
      Object.keys(old).forEach(annotationId => {
        replies[annotationId] = old[annotationId].filter(x => repliedDeletedIds.findIndex(d => d == x.id) == -1) || [];
      });

      return { ...replies };
    }

    return { ...repliedByAnnotation };
  }

  private documentAnnotationRepliedFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.GetDocumentRepliedFailure),
      tap((error: any) => {
        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private deleteAnnotationRepliedSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DeleteRepliedSuccess),
      tap(({ payload: { success, annotationId, replyId } }) => {
        if (success !== undefined && !success) {
          this.repliedDeletedIds = this.repliedDeletedIds.filter(d => d !== replyId) || [];
          this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);
          return;
        }

        this.store.dispatch(new DocumentsAction.GetDocumentAnnotation(this.documentId));
      })
    );
  }

  private deleteAnnotationRepliedFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DeleteRepliedFailure),
      tap(({ payload: { data: { replyId }, err } }) => {
        this.repliedDeletedIds = this.repliedDeletedIds.filter(d => d !== replyId) || [];
        this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);

        if (err && err.status == '500') {
          return this.store.dispatch(new DocumentsAction.GetDocumentAnnotation(this.documentId));
        }
      })
    );
  }

  private listenToCommentsRepliedDeleteRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_COMMENT_REPLIED_DELETE, ({ replyId, annotationId }) => {
      this.repliedDeletedIds = [].concat(this.repliedDeletedIds).concat(replyId);
      this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);

      this.store.dispatch(new DocumentsAction.DeleteReplied({ replyId, annotationId }));
    });
  }

  private listenToNewCommentReplySuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.ReplyCommentSuccess),
      tap(({ payload }) => {
        const replied = { ...this.replied };
        let repliedUpdate = {};
        Object.keys(replied).forEach(annotationId => {
          repliedUpdate[annotationId] =
            annotationId === payload.annotationId ? replied[annotationId].concat(payload) : replied[annotationId];
        });

        this.replied = { ...repliedUpdate };
      })
    );
  }

  private listenToDeleteCommentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(DocumentsAction.DeleteAnnotationSuccess),
      tap(({ payload: { success, annotationId: deletedAnnotationId } }) => {
        if (!success) {
          return this.store.dispatch(new DocumentsAction.DeleteAnnotationFailure('Delete annotation failed'));
        }

        this.comments = DocumentsModel.Helper.getLatestCommentsAfterDeletingComment(this.comments, deletedAnnotationId);
        this.commentSeqs = DocumentsModel.Helper.getLatestCommentSeqsAfterDeletingComment(
          this.commentSeqs,
          deletedAnnotationId
        );
        this.replied = DocumentsModel.Helper.getLatestRepliedAfterDeletingComment(this.replied, deletedAnnotationId);
      })
    );
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(DOCUMENTS_SIDE_TAB_SWITCH, ({ tabId, id, ...others }) => {
      this.changeDisplay(tabId);

      if (!(this.documentId !== id)) {
        return;
      }

      let internalLoading = true;
      this.documentId = id;
      this.isLoading = true;

      const detail = this.getLatestDocumentDetail(this.matterId, this.documentId);
      this.documentDetail = detail
        ? { ...detail, fileSizeKb: this.documentDetail ? this.documentDetail.fileSizeKb : 0 }
        : undefined;

      // read details.
      id && this.store.dispatch(new DocumentsAction.GetDocumentActivity(this.documentId));
      if (!id) {
        internalLoading = false;
        this.documentActivities = [];
      }

      // read comments.
      id && this.store.dispatch(new DocumentsAction.GetDocumentAnnotation(this.documentId));
      if (!id) {
        internalLoading = false;
      }

      if (!internalLoading) {
        this.isLoading = false;
      }
    });
  }
}
