import { Component, OnDestroy } from '@angular/core';
import { CoreModel } from '@app/core/models';
import { DocumentsModel } from '../../models/documents.model';
import { CustomEventService, DOCUMENTS_LIST_SORTING, DOCUMENTS_LIST_MY_UPLOADS_ONLY } from '@app/core/services';
import { Subject } from 'rxjs';
import { Store } from '@ngxs/store';
import { DocumentsState } from '../../store';

@Component({
  selector: 'sc-documents-list-header',
  templateUrl: './documents-list-header.component.html'
})
export class DocumentsListHeaderComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  sortOptions: CoreModel.ColumnSorting[] = DocumentsModel.Helper.getDocSortingOptions();
  sortSelected: CoreModel.ColumnSorting = DocumentsModel.Helper.getDocDefaultSortingOption();
  filterOptions: CoreModel.ColumnFilter[] = DocumentsModel.Helper.getDocFilterOptions();
  filterSelected: CoreModel.ColumnFilter = undefined;

  changeSort(selected: CoreModel.ColumnSorting): void {
    this.sortSelected = selected;
    this.customEventSvc.dispatchEvent(DOCUMENTS_LIST_SORTING, { ...selected });
  }

  sortDescription(current: CoreModel.ColumnSorting): string {
    const orderBy = current.sort == 0 ? 'ascending' : 'descending';

    return `Sorted by ${current.title} in ${orderBy} order`;
  }

  showMyUploadsOnly(selected: CoreModel.ColumnFilter): void {
    this.filterSelected = this.filterSelected ? undefined : { ...selected };
    this.customEventSvc.dispatchEvent(DOCUMENTS_LIST_MY_UPLOADS_ONLY, { onlyMyUploads: !!this.filterSelected });
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(private customEventSvc: CustomEventService, private store: Store) {
    this.filterSelected = this.store.selectSnapshot(DocumentsState.getOnlyMyUploadsFlag)
      ? { ...this.filterOptions[0] }
      : undefined;
  }
}
