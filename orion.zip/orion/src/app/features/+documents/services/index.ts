import { LawConnectApiService } from './lawconnect-api.service';

export * from './lawconnect-api.service';

export const documentsServices = [LawConnectApiService];
