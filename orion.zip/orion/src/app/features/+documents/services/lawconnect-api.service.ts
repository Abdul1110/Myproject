import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DocumentsModel } from '../models/documents.model';
import { AnnotatorModel } from '@app/shared/models';

@Injectable({
  providedIn: 'root'
})
export class LawConnectApiService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  download(url: string): Observable<any> {
    return this.http.get(url, { responseType: 'blob' });
  }

  getDocumentDownloadUrl(docId: string, isImage: boolean): Observable<any> {
    const url = `${this.endpoint}/api/document/${docId}/download?preview=false`;
    return this.http.get(url);
  }

  getPreviewDocumentDownloadUrl(docId: string, isPreview: boolean): Observable<any> {
    const url = `${this.endpoint}/api/document/${docId}/download?preview=${isPreview}`;
    return this.http.get(url);
  }

  getDocumentActivities(docId: string): Observable<DocumentsModel.LawConnectDocumentWithActivity> {
    const url = `${this.endpoint}/api/document/details`;
    return this.http.post<DocumentsModel.LawConnectDocumentWithActivity>(url, { documentId: docId });
  }

  getDocumentAnnotations(docId: string): Observable<DocumentsModel.LawConnectDocumentAnnotation[]> {
    const url = `${this.endpoint}/api/document/annotations`;
    return this.http.post<DocumentsModel.LawConnectDocumentAnnotation[]>(url, { documentId: docId });
  }

  getDocumentAnnotationsReplied(annotationIds: string[]): Observable<DocumentsModel.AnnotationRepliedList> {
    const url = `${this.endpoint}/api/document/annotations/replied`;
    return this.http.post<DocumentsModel.AnnotationRepliedList>(url, {
      annotationIds: annotationIds
    });
  }

  getReplyDocumentAnnotation(
    reply: DocumentsModel.LawConnectDocumentAnnotationReply
  ): Observable<DocumentsModel.LawConnectDocumentAnnotationReplied> {
    const url = `${this.endpoint}/api/document/annotations/replied/new`;
    return this.http.post<DocumentsModel.LawConnectDocumentAnnotationReplied>(url, { reply: reply });
  }

  updateDocumentAnnotation(update: DocumentsModel.UpdateAnnotation): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/update/${update['id']}`;
    return this.http.put<DocumentsModel.UpdateAnnotation>(url, { ...update });
  }

  addDocumentAnnotation(add: AnnotatorModel.NewAnnotation): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/add`;
    return this.http.post<AnnotatorModel.NewAnnotation>(url, { ...add });
  }

  deleteDocumentAnnotation(annotationId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/delete/${annotationId}`;
    return this.http.delete<AnnotatorModel.DeleteAnnotation>(url);
  }

  deleteDocumentReply(commentId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/replied/delete/${commentId}`;
    return this.http.delete(url);
  }

  replyDocumentAnnotation(
    reply: DocumentsModel.LawConnectDocumentAnnotationReply
  ): Observable<DocumentsModel.LawConnectDocumentAnnotationReplied> {
    const url = `${this.endpoint}/api/document/annotations/replied/new`;
    return this.http.post<DocumentsModel.LawConnectDocumentAnnotationReplied>(url, { reply: reply });
  }

  activeUserInDocument(documentId: string, userId: string) {
    const url = `${this.endpoint}/api/document/activeuserindocument`;
    const req = { documentId, userId };
    return this.http.post(url, req);
  }

  activeUserHeartBeat(documentId: string, userId: string) {
    const url = `${this.endpoint}/api/document/activeuserheartbeat`;
    const req = { documentId, userId };
    return this.http.put(url, req);
  }
}
