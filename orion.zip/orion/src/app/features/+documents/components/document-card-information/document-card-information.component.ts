import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'sc-document-card-information',
  templateUrl: './document-card-information.component.html',
  host: { '[class.x-card-inline]': 'enabled' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DocumentCardInformationComponent {
  enabled = true;

  @Input('name')
  name: string;

  @Input('type')
  type: string;

  @Input('file-size')
  fileSize: string;

  @Input('created')
  created: string;

  @Input('modified')
  modified: string;

  constructor() {}

  ngOnInit() {}
}
