import { DocumentSideDetailsComponent } from './document-side-details/document-side-details.component';
import { DocumentListItemComponent } from './document-list-item/document-list-item.component';
import { DocumentSideCommentsComponent } from './document-side-comments/document-side-comments.component';
import { DocumentCardInformationComponent } from './document-card-information/document-card-information.component';
import { DocumentSideCommentsReplyComponent } from './document-side-comments-reply/document-side-comments-reply.component';

export * from './document-side-details/document-side-details.component';
export * from './document-list-item/document-list-item.component';
export * from './document-side-comments/document-side-comments.component';
export * from './document-card-information/document-card-information.component';
export * from './document-side-comments-reply/document-side-comments-reply.component';

export const documentsComponents = [
  DocumentSideDetailsComponent,
  DocumentListItemComponent,
  DocumentSideCommentsComponent,
  DocumentCardInformationComponent,
  DocumentSideCommentsReplyComponent
];
