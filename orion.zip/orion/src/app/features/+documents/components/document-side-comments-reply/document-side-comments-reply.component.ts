import { Component, Input, EventEmitter, Output, HostBinding } from '@angular/core';
import { LyraAnimation } from '@leap/lyra-design';
import { Store } from '@ngxs/store';
import { DocumentsAction } from '../../store';

@Component({
  selector: 'sc-document-side-comments-reply',
  templateUrl: './document-side-comments-reply.component.html',
  host: {
    '[@xAnimationCardFooterCollapse]': 'true'
  },
  animations: [LyraAnimation.xAnimationCardFooterCollapse]
})
export class DocumentSideCommentsReplyComponent {
  @Input('document-id') documentId: string;
  @Input('annotation-id') annotationId: string;
  @Input('page-id') pageId: string;
  @Output('cancel') cancel = new EventEmitter();

  constructor(private store: Store) {}

  @HostBinding('class.x-card-footer-reply')
  onCancel(): void {
    this.cancel.emit();
  }

  onReply(replyText: string): void {
    if (!replyText) {
      return;
    }

    this.store.dispatch(
      new DocumentsAction.ReplyComment({
        documentId: this.documentId,
        annotationId: this.annotationId,
        text: replyText,
        pageId: this.pageId
      })
    );

    this.onCancel();
  }
}
