import { ChangeDetectionStrategy, Component, Input, Inject, LOCALE_ID } from '@angular/core';
import { CoreModel } from '@app/core/models';
import {
  CustomEventService,
  DOCUMENTS_SIDE_TAB_SWITCH,
  DOCUMENTS_LIST_FILE_PREVIEW,
  DOCUMENTS_MULTIPLE_ACTIONS_OPEN
} from '@app/core/services';
import { DocumentsModel } from '../../models/documents.model';
import { Store } from '@ngxs/store';
import { DocumentsAction } from '../../store';

@Component({
  selector: 'sc-document-list-item',
  templateUrl: './document-list-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [
    `
      .mb-6 {
        margin-bottom: 60px;
      }

      .mb-8 {
        margin-bottom: 80px;
      }

      .mb-10 {
        margin-bottom: 100px;
      }

      .mb-12 {
        margin-bottom: 120px;
      }
    `
  ]
})
export class DocumentListItemComponent {
  @Input('data') data: DocumentsModel.DocumentItem;
  @Input('matter-id') matterId: string;
  @Input('last-item') isLastItem: boolean;
  @Input('current-user') currentUser: CoreModel.LogonUserInfo;
  @Input('small-screen') isSmallScreen: boolean;
  @Input('is-active') isActive: boolean;
  @Input('screen-height') screenHeight: Number;

  get isDeletable(): boolean {
    return !!(this.data && this.currentUser && this.data.ownerUserId == this.currentUser.userId);
  }

  getRootCss(isLast: boolean, isSmallScreen: boolean): string {
    if (isLast && this.screenHeight < 1300) {
      if (isSmallScreen) {
        // ipad
        if (this.screenHeight >= 1024) {
          return 'x-file-complex mb-8';
        }
        // iphone x
        if (this.screenHeight >= 812) {
          return 'x-file-complex mb-10';
        }
        // galaxy s5
        return 'x-file-complex mb-12';
      }

      return 'x-file-complex mb-6';
    }

    return 'x-file-complex';
  }

  getIcon(ext: string): string {
    return CoreModel.Helper.getDocTypeIcon(ext);
  }

  getLastModifiedDate(): string {
    if(!this.data)
    {
      return '';
    }
    else if(this.data.modifiedDate)
    {
      return `Modified: ${DocumentsModel.Helper.localeFormat(this.data.modifiedDate, this.locale)}`;
    }
    else if(this.data.createdDate)
    {
      return `Created: ${DocumentsModel.Helper.localeFormat(this.data.createdDate, this.locale)}`;
    }

    return '';
  }

  getOwnerInitial(): CoreModel.User {
    if (this.data) {
      return { initial: CoreModel.Helper.getUserInitial(this.data.ownerName), name: this.data.ownerName };
    }

    return { initial: '', name: '' };
  }

  openActionSheet(): void {
    this.customEventSvc.dispatchEvent(DOCUMENTS_MULTIPLE_ACTIONS_OPEN, {
      ...this.data,
      title: CoreModel.Helper.getValidDocumentNameWithExtension(this.data.name, this.data.fileExtension),
      subTitle: this.data.createdDate
        ? `Created on ${DocumentsModel.Helper.localeFormat(this.data.createdDate, this.locale)}`
        : ''
    });
  }

  preview(item: DocumentsModel.DocumentItem): void {
    if (!this.isImage(item)) {
      this.viewSideComment(item, true);
    } else {
      this.viewSideDetail(item);
    }
    this.customEventSvc.dispatchEvent(DOCUMENTS_LIST_FILE_PREVIEW, { ...item });
  }

  download(item: DocumentsModel.DocumentItem): void {
    this.viewSideDetail(item);
    const documentName = CoreModel.Helper.getValidDocumentNameWithExtension(item.name, item.fileExtension);
    const documentId = item.id;
    if (documentName && this.matterId) {
      this.store.dispatch(new DocumentsAction.DownloadDocument({ matterId: this.matterId, documentId, documentName }));
      return;
    }
  }

  viewSideDetail(item: DocumentsModel.DocumentItem): void {
    this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, { tabId: 'details', ...item });
  }

  viewSideComment(item: DocumentsModel.DocumentItem, skipListRender = false): void {
    this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, { tabId: 'comments', ...item, skipListRender });
  }

  isImage(item: DocumentsModel.DocumentItem): boolean {
    return item && CoreModel.Helper.isImageFile(item.fileExtension);
  }

  constructor(
    private customEventSvc: CustomEventService,
    private store: Store,
    @Inject(LOCALE_ID) private locale: string
  ) {}
}
