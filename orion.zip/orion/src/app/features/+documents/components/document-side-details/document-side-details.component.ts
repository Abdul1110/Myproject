import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { DocumentsModel } from '../../models/documents.model';
import { CoreModel, SignatureModel } from '@app/core/models';
import { environment } from '@env/environment';
const emptyComment = environment.locale.no_results.details.empty;

@Component({
  selector: 'sc-document-side-details',
  templateUrl: './document-side-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DocumentSideDetailsComponent {
  documentMessage = emptyComment;
  @Input('data') data: DocumentsModel.DocumentItem;
  @Input('current-user') currentUser: CoreModel.LogonUserInfo;
  @Input('firm-name') firmName: string;
  @Input('activities') activities: DocumentsModel.LawConnectDocumentHistory[];

  fileSize(fs: number): string {
    if (!fs || fs === 0) {
      return '0 KB';
    }

    const sizes = [' KB', ' MB', ' GB'];
    const i = Math.floor(Math.log(fs) / Math.log(1024));
    const fileSize =
      i < 3 ? Math.round(fs / Math.pow(1024, i)) + sizes[i] : Math.round(fs / Math.pow(1024, 2)) + sizes[2];
    return fileSize;
  }

  hasValidDetail(data: DocumentsModel.DocumentItem): boolean {
    if (!data || !(data.id && data.name)) {
      return false;
    }

    return true;
  }

  hasValidSharedBy(data: DocumentsModel.DocumentItem): boolean {
    if (!data || !data.ownerName) {
      return false;
    }

    return true;
  }

  getSharedByDescription(data) {
    if (data && this.currentUser && this.data.ownerUserId === this.currentUser.userId) {
      return '';
    }
    return this.firmName;
  }

  hasValidActivities(activities: DocumentsModel.LawConnectDocumentWithActivity[]): boolean {
    return activities && activities.length > 0;
  }

  getActivityDescription(
    activity: DocumentsModel.LawConnectDocumentHistory,
    currentUser: CoreModel.LogonUserInfo
  ): string {
    return DocumentsModel.Helper.getMatterActivityDescription(activity, currentUser.userId);
  }

  trackElement(index: number, element: any) {
    return index;
  }

  getName(lastName: string, firstName: string): string {
    return `${firstName || ''} ${lastName || ''}`;
  }

  constructor() {}
}
