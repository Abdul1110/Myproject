import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@app/shared/guards/auth.guard';
import { TermsGuard } from '@app/shared/guards';
import { MatterGuard } from '@app/shared/guards/matter.guard';
import { SignatureGuard } from '@app/shared/guards/signature.guard';
import { LayoutHomeComponent } from './layout';

const routes: Routes = [
  {
    path: '',
    component: LayoutHomeComponent,
    canActivate: [AuthGuard, TermsGuard, MatterGuard, SignatureGuard],
    children: [
      {
        path: 'recents',
        loadChildren: () => import('app/features/+recent/recent.module').then(m => m.RecentModule)
      },
      {
        path: 'matters/:matterId/collaborations',
        canActivateChild: [],
        loadChildren: () =>
          import('app/features/+collaborations/collaborations.module').then(m => m.CollaborationsModule)
      },
      {
        path: 'matters/:matterId/signatures',
        canActivateChild: [],
        loadChildren: () => import('app/features/+signatures/signatures.module').then(m => m.SignaturesModule)
      },
      {
        path: 'matters/:matterId/sharedocuments',
        canActivateChild: [],
        loadChildren: () => import('app/features/+documents/documents.module').then(m => m.DocumentsModule)
      },
      {
        path: 'matters/:matterId/billing',
        loadChildren: () => import('app/features/+billing/billing.module').then(m => m.BillingModule)
      },
      {
        path: 'matters/:matterId/trust',
        loadChildren: () => import('app/features/+trust/trust.module').then(m => m.TrustModule)
      },
      {
        path: 'matters/:matterId/apps',
        loadChildren: () => import('app/features/+app-store/app-store.module').then(m => m.AppStoreModule)
      },
      {
        path: '',
        redirectTo: 'recents',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: 'terms',
    canActivate: [AuthGuard],
    loadChildren: () => import('app/features/+terms/terms.module').then(m => m.TermsModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule {}
