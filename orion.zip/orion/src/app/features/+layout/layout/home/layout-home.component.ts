import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subject, merge } from 'rxjs';
import { tap, filter, takeUntil } from 'rxjs/operators';
import { StandardModel, BrowserService, LyraAnimation } from '@leap/lyra-design';

import { environment } from '@env/environment';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import {
  CustomEventService,
  NAVIGATION_SIDE_BAR_TOGGLE,
  NAVIGATION_SIDE_BAR_TOGGLE_MOBILE,
  LAYOUT_HOME_INIT_COMPLETED
} from '@app/core/services';

@Component({
  selector: 'sc-layout-home',
  templateUrl: './layout-home.component.html',
  animations: [LyraAnimation.xAnimationMenuCollapse]
})
export class LayoutHomeComponent implements OnInit, OnDestroy {
  isSmall = false;
  mobileAside = false;
  firmName = '';
  isAuthenticated$: Observable<boolean>;

  private desktopAsideToggle = false;
  private firmId = '';
  private isWhiteLabel = false;
  private destroy$ = new Subject<boolean>();

  showDesktopAside(isSmallScreen: boolean): boolean {
    return !isSmallScreen && this.desktopAsideToggle;
  }

  showMobileAside(isSmallScreen: boolean): boolean {
    return isSmallScreen && this.mobileAside;
  }

  hideMobileSide(): void {
    this.mobileAside = false;
  }

  toggleMobileAside(): void {
    this.mobileAside = !this.mobileAside;
  }

  constructor(
    private appActionSvc: AppActionService,
    private browserSvc: BrowserService,
    private customEventSvc: CustomEventService
  ) {
    this.isAuthenticated$ = this.appActionSvc.isAuthenticated$;
    this.customEventSvc.dispatchEvent(LAYOUT_HOME_INIT_COMPLETED, {});

    merge(
      this.whiteLabelStatusSideEffect$(),
      this.firmIdSideEffect$(),
      this.firmNameSideEffect$(),
      this.desktopAsideToggleRequest$(),
      this.mobileAsideToggleRequest$(),
      this.listenToIsSmallScreenSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  ngOnInit() {}

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }

  private listenToIsSmallScreenSideEffect$(): Observable<boolean> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(v => {
        this.isSmall = v;
      })
    );
  }

  private desktopAsideToggleRequest$(): Observable<any> {
    return this.customEventSvc.registerEvent(NAVIGATION_SIDE_BAR_TOGGLE, ({ open }) => {
      setTimeout(() => {
        this.desktopAsideToggle = open;
      }, 0);
    });
  }

  private mobileAsideToggleRequest$(): Observable<any> {
    return this.customEventSvc.registerEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, ({ open }) => {
      setTimeout(() => {
        this.mobileAside = open;
      }, 0);
    });
  }

  private whiteLabelStatusSideEffect$(): Observable<{ whiteLabel: boolean; firmId: string }> {
    return this.appActionSvc.whiteLabelStatus$.pipe(
      filter(s => !!s && s.whiteLabel),
      tap(s => (this.isWhiteLabel = true))
    );
  }

  private firmIdSideEffect$(): Observable<string> {
    return this.appActionSvc.firmId$.pipe(tap(v => (this.firmId = v)));
  }

  private firmNameSideEffect$(): Observable<StandardModel.ThemeSetting> {
    return this.appActionSvc.theme$.pipe(
      tap((t: StandardModel.ThemeSetting) => {
        if (t) {
          this.firmName = t.firmName;
          return;
        }
        this.firmName = 'LawConnect';
      })
    );
  }

  getSecondaryOutletCss(mobileScreen: boolean): string {
    if (this.browserSvc.isServer) {
      return '';
    }

    const path = `${this.browserSvc.window.location.pathname}`;
    const isMatterSelectOption = path.indexOf('(aside:select)') > -1;
    if (!mobileScreen && isMatterSelectOption) {
      return 'lt-container x-overlay';
    }
    return '';
  }

  getLogoUrl(): string {
    if (!this.firmId || !this.isWhiteLabel) {
      return '/assets/images/lawconnect/header-logo-dark.svg';
    }

    return `${environment.appSettings.apiBaseUrl}v1/dto/whitelabel/assets/firm/${this.firmId}/logo`;
  }

  getLogoName(theme: StandardModel.ThemeSetting): string {
    if (theme) {
      return theme.firmName;
    }

    return 'LawConnect';
  }

  showMobileHeader(isSmall: boolean, isAuthenticated: boolean): boolean {
    if (isSmall && isAuthenticated) {
      return true;
    }

    return false;
  }
}
