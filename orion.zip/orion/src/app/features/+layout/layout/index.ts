import { LayoutHomeComponent } from './home/layout-home.component';

export * from './home/layout-home.component';

export const layouts = [LayoutHomeComponent];
