import { NgModule } from '@angular/core';
import { InlineSVGModule } from 'ng-inline-svg';
import { CommonModule } from '@angular/common';
import {
  LyraDesignAnimationModule,
  LyraDesignAsideModule,
  LyraDesignCommonModule,
  LyraDesignIconModule,
  LyraDesignMenuModule
} from '@leap/lyra-design';

import { AppStateModule } from '@app/core/app-state.module';
import { LayoutRoutingModule } from './layout-routing.module';
import { layouts } from './layout';
import { SharedModule } from '@app/shared';
import { layoutPages } from './pages';
import { layoutComponents } from './components';

@NgModule({
  imports: [
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    AppStateModule,
    LayoutRoutingModule,
    SharedModule,
    LyraDesignMenuModule,
    LyraDesignIconModule,
    LyraDesignCommonModule,
    LyraDesignAsideModule,
    LyraDesignAnimationModule
  ],
  entryComponents: [...layouts, ...layoutPages, ...layoutComponents],
  declarations: [...layouts, ...layoutPages, ...layoutComponents],
  providers: []
})
export class LayoutModule {}
