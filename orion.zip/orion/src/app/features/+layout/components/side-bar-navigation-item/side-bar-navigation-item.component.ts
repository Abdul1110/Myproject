import { Component, ChangeDetectionStrategy, Input, EventEmitter, Output } from '@angular/core';
import { LayoutModel } from '../../models/layouts.model';

@Component({
  selector: 'sc-side-bar-navigation-item',
  templateUrl: './side-bar-navigation-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SideBarNavigationItemComponent {
  @Input('data') data: LayoutModel.SideItemDetail;

  @Input('is-active') isActive: boolean;

  @Input('is-slim') isSlim: boolean;

  @Output('selected') selected = new EventEmitter<string>();

  selectedAction(action: string): void {
    this.selected.emit(action);
  }
}
