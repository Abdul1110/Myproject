import { SideBarNavigationItemComponent } from './side-bar-navigation-item/side-bar-navigation-item.component';

export * from './side-bar-navigation-item/side-bar-navigation-item.component';

export const layoutComponents = [SideBarNavigationItemComponent];
