import { environment } from '@env/environment';
import { SideNavigationModel } from '@app/shared/models';
const { locale } = environment;

export namespace LayoutModel {
  export interface SideItemDetail {
    iconName: string;
    label: string;
    action: string;
    badge: string;
    rightIconName?: string;
  }

  export const SideItemAction: { [id: string]: SideItemDetail } = {
    [SideNavigationModel.SideActionId.recents]: {
      action: SideNavigationModel.SideActionId.recents,
      iconName: `${locale.global.menu.recents.icon}`,
      label: `${locale.global.menu.recents.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.matters]: {
      action: SideNavigationModel.SideActionId.matters,
      iconName: `${locale.global.menu.matters.icon}`,
      label: `${locale.global.menu.matters.title}`,
      badge: '',
      rightIconName: 'feedback'
    },
    [SideNavigationModel.SideActionId.documents]: {
      action: SideNavigationModel.SideActionId.documents,
      iconName: `${locale.global.menu.documents.icon}`,
      label: `${locale.global.menu.documents.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.signatures]: {
      action: SideNavigationModel.SideActionId.signatures,
      iconName: `${locale.global.menu.signatures.icon}`,
      label: `${locale.global.menu.signatures.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.collaborations]: {
      action: SideNavigationModel.SideActionId.collaborations,
      iconName: `${locale.global.menu.collaborations.icon}`,
      label: `${locale.global.menu.collaborations.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.billing]: {
      action: SideNavigationModel.SideActionId.billing,
      iconName: `${locale.global.menu.billing.icon}`,
      label: `${locale.global.menu.billing.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.trust]: {
      action: SideNavigationModel.SideActionId.trust,
      iconName: `${locale.global.menu.trust.icon}`,
      label: `${locale.global.menu.trust.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.apps]: {
      action: SideNavigationModel.SideActionId.apps,
      iconName: `${locale.global.menu.apps.icon}`,
      label: `${locale.global.menu.apps.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.support]: {
      action: SideNavigationModel.SideActionId.support,
      iconName: `${locale.global.menu.support.icon}`,
      label: `${locale.global.menu.support.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.feedback]: {
      action: SideNavigationModel.SideActionId.feedback,
      iconName: `${locale.global.menu.feedback.icon}`,
      label: `${locale.global.menu.feedback.title}`,
      badge: ''
    },
    [SideNavigationModel.SideActionId.communities]: {
      action: SideNavigationModel.SideActionId.communities,
      iconName: `${locale.global.menu.resources.icon}`,
      label: `${locale.global.menu.resources.title}`,
      badge: ''
    }
  };
}
