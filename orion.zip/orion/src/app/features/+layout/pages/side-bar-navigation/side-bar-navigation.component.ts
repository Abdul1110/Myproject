import { Component, ChangeDetectionStrategy, HostBinding, Input, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { LyraDesignMenuModel } from '@leap/lyra-design/menu/models/menu.model';
import { Store } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable, Subject, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';
import { BsModalService } from 'ngx-bootstrap';

import {
  CustomEventService,
  MATTERS_SELECT_CLOSED,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED,
  NAVIGATION_SIDE_BAR_TOGGLE_MOBILE,
  NAVIGATION_SIDE_BAR_UPDATE,
  AnalyticService,
  NavigationService
} from '@app/core/services';
import { LayoutModel } from '../../models/layouts.model';
import { SetNavigationActionId, Logout } from '@app/core/store/actions';
import { CoreModel, NodeModel } from '@app/core/models';
import { SideNavigationModel } from '@app/shared/models';
import { environment } from '@env/environment';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { AppState } from '@app/core/store/states';
import { UploadService } from '@app/core/services/lawconnect/upload.service';
import { DialogService } from '@app/shared/services';
import { FeedbackComponent } from '@app/shared/components/feedback/feedback.component';
import { DeviceService } from '@app/shared/services/device/device.service';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

declare const WalkMePlayerAPI;
const { locale, config } = environment;

@Component({
  selector: 'sc-side-bar-navigation',
  templateUrl: './side-bar-navigation.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SideBarNavigationComponent implements OnDestroy {
  private selectedActionId = `${SideNavigationModel.SideActionId.recents}`;
  private destroy$ = new Subject<boolean>();
  private notificationCount = -1;
  private sideMenuItems: { [matterId: string]: NodeModel.LawConnectNode[] } = {};

  slim: boolean;

  menuMain: LyraDesignMenuModel.SideActionInfo[];

  showSupportLink = false;
  isSmall = false;
  userName = '';
  userEmail = '';
  recentActionItem = LayoutModel.SideItemAction.recents;
  switchMatterActionItem = LayoutModel.SideItemAction.matters;
  supportActionItem = LayoutModel.SideItemAction.support;
  feedbackActionItem = LayoutModel.SideItemAction.feedback;
  communitiesActionItem = LayoutModel.SideItemAction.communities;
  thisMatterActionItems = [
    LayoutModel.SideItemAction.documents,
    LayoutModel.SideItemAction.signatures,
    LayoutModel.SideItemAction.collaborations,
    LayoutModel.SideItemAction.billing,
    LayoutModel.SideItemAction.trust
  ];

  isActiveAction(item: LayoutModel.SideItemDetail): boolean {
    return item && item.action == this.selectedActionId;
  }

  recentActionSelected(actionId: string): void {
    this.selectedActionId = actionId;
    this.sendAnalytic(actionId);

    this.thisMatterActionItems = this.showOrHideAppStoreSideMenu(false, this.thisMatterActionItems, '');
    this.cd && this.cd.markForCheck();

    this.store.dispatch(new SetNavigationActionId(actionId));

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/recents'
    });

    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, { open: false });
  }

  switchMatterActionSelected(actionId: string): void {
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, { open: false });
    if (this.selectedActionId !== actionId) {
      this.selectedActionId = actionId;
    }

    const path = this.location.path();
    !path.includes('/(aside:select)') &&
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: path.replace('/preview', '/').split('?')[0],
        outlet: 'aside',
        outletPath: 'select'
      });
  }

  thisMatterActionSelected(actionId: string): void {
    this.store.dispatch(new SetNavigationActionId(actionId));
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, { open: false });
    this.sendAnalytic(actionId);

    if (this.selectedActionId == actionId) {
      return;
    }

    this.selectedActionId = actionId;

    const { matterId } = this.route.children[0] && this.route.children[0].snapshot.params;

    if (!matterId || matterId == 'undefined') {
      this.switchMatterActionSelected(SideNavigationModel.SideActionId.matters);
      return;
    }

    if (actionId == SideNavigationModel.SideActionId.apps) {
      const stores = this.store.selectSnapshot(AppState.getAppStoreByMatter) || {};
      const hasSingleStore = stores[matterId] && stores[matterId].length == 1;
      const path = hasSingleStore
        ? `/matters/${matterId}/${actionId}/${stores[matterId][0].subType}/shares/${stores[matterId][0].id}`
        : `/matters/${matterId}/${actionId}/`;

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path
      });

      return;
    }

    const page = actionId == SideNavigationModel.SideActionId.documents ? 'sharedocuments' : actionId;
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${matterId}/${page}/`
    });
  }

  feedbackActionSelected(actionId: string): void {
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, { open: false });
    const firmId = this.store.selectSnapshot(AppState.getSelectedFirmId) || '';
    const initialState = {
      firm: firmId,
      email: this.userEmail,
      userName: this.userName
    };
    this.modalService.show(FeedbackComponent, { initialState });
  }

  supportActionSelected(actionId: string): void {
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, { open: false });
    WalkMePlayerAPI && WalkMePlayerAPI.toggleMenu();
  }

  communitiesActionSelected(actionId: string): void {
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, { open: false });
    this.browserSvc.isBrowser && this.browserSvc.window.open(config.support.communityUrl);
  }

  logmeOut(): void {
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE_MOBILE, { open: false });
    const pendingCollaborationUploads = this.store.selectSnapshot(AppState.getUploadDrafts) || [];
    const hasUploadedAll = this.uploaderSvc.canNavigate(pendingCollaborationUploads);

    if (hasUploadedAll) {
      this.store.dispatch(new Logout(undefined));
      return;
    }

    this.dialogSvc.confirm({
      title: 'Navigation Confirmation',
      message: locale.matters.upload.navigation_away_warning,
      actionText: 'Continue',
      closeText: 'Cancel',
      showCancel: true,
      onClose: (confirmed: boolean) => {
        if (confirmed) {
          this.appActionSvc.deletePendingUploads();
          this.store.dispatch(new Logout(undefined));
          return;
        }
      }
    });
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  @Input('logo-url')
  logoUrl: string;

  @Input('logo-name')
  logoName: string;

  @HostBinding('class')
  classes = 'layout-column w-100';

  onBtnToggle(action: string): void {
    this.slim = !this.slim;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private location: Location,
    private customEventSvc: CustomEventService,
    private cd: ChangeDetectorRef,
    private route: ActivatedRoute,
    private modalService: BsModalService,
    private browserSvc: BrowserService,
    private appActionSvc: AppActionService,
    private uploaderSvc: UploadService,
    private dialogSvc: DialogService,
    private deviceSvc: DeviceService,
    private analyticsSvc: AnalyticService,
    private navigationSvc: NavigationService
  ) {
    merge(
      this.navigationSideMenuUpdateRequest$(),
      this.closeMatterSideEffect$(),
      this.overrideSelectedActionId$(),
      this.getUserNameSideEffect$(),
      this.getIsSmallScreenSideEffect$(),
      this.getNotificationCountSideEffect$(),
      this.appStoreDisplayStatus$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.initActionId();
  }

  private sendAnalytic(actionId: string): void {
    if (this.browserSvc.isServer || !actionId) {
      return;
    }

    if (actionId == SideNavigationModel.SideActionId.apps) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.AppPreviewPage,
        action: `View ${actionId} from Side Menu`
      });
      return;
    }

    if (actionId == SideNavigationModel.SideActionId.documents) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersListDocument,
        action: `View ${actionId} from Side Menu`
      });
      return;
    }

    if (actionId == SideNavigationModel.SideActionId.billing) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersListBilling,
        action: `View ${actionId} from Side Menu`
      });
      return;
    }

    if (actionId == SideNavigationModel.SideActionId.signatures) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersListESignature,
        action: `View ${actionId} from Side Menu`
      });
      return;
    }

    if (actionId == SideNavigationModel.SideActionId.recents) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.RecentsPage,
        action: `View ${actionId} from Side Menu`
      });
      return;
    }
  }

  private initActionId(): void {
    if (this.location.path().includes('(aside:select)')) {
      this.selectedActionId = `${SideNavigationModel.SideActionId.matters}`;
      return;
    }
    if (this.location.path().includes('sharedocuments')) {
      this.selectedActionId = `${SideNavigationModel.SideActionId.documents}`;
      return;
    }
    if (this.location.path().includes('signatures')) {
      this.selectedActionId = `${SideNavigationModel.SideActionId.signatures}`;
      return;
    }
    if (this.location.path().includes('collaborations')) {
      this.selectedActionId = `${SideNavigationModel.SideActionId.collaborations}`;
      return;
    }
    if (this.location.path().includes('billing')) {
      this.selectedActionId = `${SideNavigationModel.SideActionId.billing}`;
      return;
    }
    if (this.location.path().includes('trust')) {
      this.selectedActionId = `${SideNavigationModel.SideActionId.trust}`;
      return;
    }
    if (this.location.path().includes('/apps')) {
      this.selectedActionId = `${SideNavigationModel.SideActionId.apps}`;
      return;
    }
  }

  private navigationSideMenuUpdateRequest$(): Observable<any> {
    return this.customEventSvc.registerEvent(NAVIGATION_SIDE_BAR_UPDATE, ({ matterId }) => {
      const hasAppStore = this.sideMenuItems && this.sideMenuItems[matterId] && this.sideMenuItems[matterId].length > 0;
      this.adjustSideMenu(matterId, hasAppStore);
      this.cd && this.cd.markForCheck();
    });
  }

  private closeMatterSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      this.selectedActionId = returnToActionId;

      const hasAppStore = this.sideMenuItems && this.sideMenuItems[matterId] && this.sideMenuItems[matterId].length > 0;
      this.adjustSideMenu(matterId, hasAppStore);
      this.cd && this.cd.markForCheck();

      if (this.selectedActionId == SideNavigationModel.SideActionId.apps && !hasAppStore) {
        this.selectedActionId = SideNavigationModel.SideActionId.documents;
        this.navigationSvc.goto(<CoreModel.NavigationData>{
          path: `matters/${matterId}/sharedocuments`
        });
        return;
      }

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path
      });
    });
  }

  private appStoreDisplayStatus$(): Observable<any> {
    return this.appActionSvc.appStoreByMatter$.pipe(
      tap(v => {
        this.sideMenuItems = { ...v };
        const { matterId } = this.route.children[0] && this.route.children[0].snapshot.params;
        const options = (this.sideMenuItems && (this.sideMenuItems[matterId] as any[])) || [];
        this.thisMatterActionItems = this.showOrHideAppStoreSideMenu(
          options.length > 0,
          this.thisMatterActionItems,
          options.length == 1 ? options[0].name : ''
        );
        this.cd && this.cd.markForCheck();
      })
    );
  }

  private showOrHideAppStoreSideMenu(
    hasAppStore: boolean,
    currentSideMenu: LayoutModel.SideItemDetail[],
    appStoreName = ''
  ): LayoutModel.SideItemDetail[] {
    if (hasAppStore) {
      if (!currentSideMenu.find(c => c.action == LayoutModel.SideItemAction.apps.action)) {
        return [
          ...currentSideMenu,
          appStoreName ? { ...LayoutModel.SideItemAction.apps, label: appStoreName } : LayoutModel.SideItemAction.apps
        ];
      }
      return [...currentSideMenu];
    }

    return currentSideMenu.filter(c => c.action !== LayoutModel.SideItemAction.apps.action);
  }

  private getNotificationCountSideEffect$(): Observable<number> {
    return this.appActionSvc.notificationCount$.pipe(
      tap(v => {
        this.recentActionItem = { ...this.recentActionItem, badge: v === 0 ? '' : `${v >= 100 ? '99+' : v}` };
        if (v != this.notificationCount) {
          this.notificationCount = v;
          this.cd && this.cd.markForCheck();
        }
      })
    );
  }

  private adjustSideMenu(matterId: string, hasAppStore: boolean): void {
    this.thisMatterActionItems = this.showOrHideAppStoreSideMenu(
      hasAppStore,
      this.thisMatterActionItems,
      hasAppStore && this.sideMenuItems[matterId].length == 1 ? this.sideMenuItems[matterId][0].name : ''
    );
  }

  private overrideSelectedActionId$(): Observable<any> {
    return this.customEventSvc.registerEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, ({ actionId }) => {
      if (actionId) {
        this.selectedActionId = actionId;
        this.cd && this.cd.markForCheck();
      }
    });
  }

  private getUserNameSideEffect$(): Observable<CoreModel.LogonUserInfo> {
    return this.appActionSvc.logonUser$.pipe(
      tap(user => {
        if (user.displayName) {
          this.userName = user.displayName;
          this.userEmail = user.email;
        }
      })
    );
  }

  private getIsSmallScreenSideEffect$(): Observable<boolean> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(isSmall => {
        this.isSmall = isSmall;
        this.showSupportLink = this.deviceSvc.isDesktop;
        this.cd && this.cd.markForCheck();
      })
    );
  }
}
