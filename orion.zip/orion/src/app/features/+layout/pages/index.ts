import { SideBarNavigationComponent } from './side-bar-navigation/side-bar-navigation.component';

export * from './side-bar-navigation/side-bar-navigation.component';

export const layoutPages = [SideBarNavigationComponent];
