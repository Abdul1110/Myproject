import { Component, OnDestroy, OnInit, HostBinding } from '@angular/core';
import { LyraAnimation } from '@leap/lyra-design';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { AppState } from '@app/core/store/states';
import { environment } from '@env/environment';
import {
  SetSharePreview,
  GetMattersStart,
  GetSignaturesStart,
  GetSignaturesSuccess,
  GetSignaturesFailure
} from '@app/core/store/actions';
import { CoreModel } from '@app/core/models';
import { RecentAction } from '../../store';
import {
  PubNubService,
  CustomEventService,
  NAVIGATION_SIDE_BAR_TOGGLE,
  MATTERS_SELECT_CLOSED,
  NavigationService
} from '@app/core/services';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';

@Component({
  selector: 'sc-recent-home',
  templateUrl: './recent-home.component.html',
  animations: [LyraAnimation.xAnimationMenuCollapse]
})
export class RecentHomeComponent implements OnDestroy, OnInit {
  private pubNubSub: CoreModel.PubNubSubscription;
  private destroy$ = new Subject<boolean>();

  privacyUrl = environment.appSettings.privacyUrl;

  constructor(
    private store: Store,
    private pubNubSvc: PubNubService,
    private actions$: Actions,
    private appActionSvc: AppActionService,
    private customEventSvc: CustomEventService,
    private navigationSvc: NavigationService
  ) {
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
  }

  @HostBinding('class.lt-container')
  @HostBinding('class.bg-light-secondary')
  ngOnDestroy(): void {
    this.destroy$.next(true);

    if (this.pubNubSub) {
      this.pubNubSub.unsubscribe();
    }
  }

  ngOnInit() {
    merge(
      this.firmIdSideEffect$(),
      this.userSideEffect$(),
      this.sharePreviewSideEffect$(),
      this.getDocumentsSuccessSideEffect$(),
      this.getSignaturesSuccessSideEffect$(),
      this.getSignatureSuccessSideEffect$(),
      this.getSignatureFailureSideEffect$(),
      this.listenToNoMatterSelectedFromOptionSideEffects$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private listenToNoMatterSelectedFromOptionSideEffects$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ matterId }) => {
      !!!matterId &&
        this.navigationSvc.goto(<CoreModel.NavigationData>{
          path: '/recents'
        });
    });
  }

  private firmIdSideEffect$(): Observable<string> {
    return this.appActionSvc.firmId$.pipe(
      tap(firmId => {
        if (firmId) {
          setTimeout(() => {
            this.store.dispatch([new RecentAction.GetDocumentsStart(firmId)]);
          }, 100);
        }
      })
    );
  }

  private getSignatureSuccessSideEffect$(): Actions {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesSuccess),
      tap(v => {
        const user = this.store.selectSnapshot(AppState.getLoginUser);
        const firmId = this.store.selectSnapshot(AppState.getSelectedFirmId);

        this.store.dispatch([
          new RecentAction.GetRecentsStart(user.userId),
          new RecentAction.GetDocumentsStart(firmId)
        ]);
      })
    );
  }

  private getSignatureFailureSideEffect$(): Actions {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesFailure),
      tap(v => {
        const user = this.store.selectSnapshot(AppState.getLoginUser);
        const firmId = this.store.selectSnapshot(AppState.getSelectedFirmId);

        this.store.dispatch([
          new RecentAction.GetRecentsStart(user.userId),
          new RecentAction.GetDocumentsStart(firmId)
        ]);
      })
    );
  }

  private userSideEffect$(): Observable<CoreModel.LogonUserInfo> {
    return this.appActionSvc.logonUser$.pipe(
      tap(user => {
        if (this.pubNubSub) {
          this.pubNubSub.unsubscribe();
        }

        if (user.userId) {
          this.pubNubSub = this.pubNubSvc.subscribeToChannels(user.userId, [user.userId], notification => {
            const msg = CoreModel.Helper.convertNotificationMessage(notification);
            if (
              msg.notificationType === CoreModel.PubNubNotificationType.esignatureUploading ||
              msg.notificationType === CoreModel.PubNubNotificationType.esignatureCreated ||
              msg.notificationType === CoreModel.PubNubNotificationType.revoking ||
              msg.notificationType === CoreModel.PubNubNotificationType.sharing ||
              msg.notificationType === CoreModel.PubNubNotificationType.delete
            ) {
              this.store.dispatch([new GetMattersStart(undefined), new GetSignaturesStart(true)]);
            }
          });
        }
      })
    );
  }

  private sharePreviewSideEffect$(): Observable<any> {
    return this.appActionSvc.sharePreview$.pipe(
      tap(sharePreview => {
        if (sharePreview && sharePreview.userEmail && sharePreview.id) {
          this.store.dispatch([
            new RecentAction.GetNodesStart({ id: sharePreview.id, isMatterShared: sharePreview.isMatterShared }),
            new SetSharePreview(undefined)
          ]);
        }
      })
    );
  }

  private getDocumentsSuccessSideEffect$(): Actions {
    return this.actions$.pipe(
      ofActionSuccessful(RecentAction.GetDocumentsSuccess),
      tap(v => {
        this.store.dispatch(new RecentAction.UpdateMatterSignaturesStatus(true));
      })
    );
  }

  private getSignaturesSuccessSideEffect$(): Actions {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesSuccess),
      tap(v => {
        this.store.dispatch(new RecentAction.UpdateMatterSignaturesStatus(true));
      })
    );
  }
}
