import { RecentHomeComponent } from './home/recent-home.component';

export * from './home/recent-home.component';

export const recentsLayouts = [RecentHomeComponent];
