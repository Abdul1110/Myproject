import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RecentsFileComponent } from './pages';
import { RecentHomeComponent } from './layout';
import { MatterSelectComponent } from '@app/shared/components/matter-select/matter-select.component';

const routes: Routes = [
  {
    path: '',
    component: RecentHomeComponent,
    children: [
      {
        path: '',
        component: RecentsFileComponent
      },
      { path: '', redirectTo: '', pathMatch: 'full' }
    ]
  },
  {
    path: 'select',
    component: MatterSelectComponent,
    outlet: 'aside',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecentRoutingModule {}
