import { NgModule } from '@angular/core';
import { NgxsModule } from '@ngxs/store';
import { RecentsStates } from './store';

@NgModule({
  declarations: [],
  imports: [NgxsModule.forFeature([...RecentsStates])]
})
export class RecentStateModule {}
