import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UUID } from 'angular2-uuid';

import { CoreModel } from '@app/core/models';
import { RecentsModel } from '../models/recent.model';

@Injectable({
  providedIn: 'root'
})
export class LawConnectApiService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  getNotifications(): Observable<CoreModel.RecentNotification[]> {
    // Random ID is currently used to circumvent unwarrented caching,
    // until caching is configured to handle this
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/notifications?rid=${randomId}`;
    return this.http.get<CoreModel.RecentNotification[]>(url, {
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=0'
      })
    });
  }

  getNotificationsByFirm(firmId: string): Observable<CoreModel.RecentNotification[]> {
    const url = `${this.endpoint}/api/document/notifications/${firmId}`;
    return this.http.get<CoreModel.RecentNotification[]>(url, {
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=0'
      })
    });
  }

  deleteNotification(notificationId: string): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/notification/${notificationId}`; //?rdid=${randomId}
    return this.http.delete<any>(url);
  }

  deleteAllNotifications(): Observable<any> {
    const url = `${this.endpoint}/api/document/notifications`;
    return this.http.delete<any>(url);
  }

  getDocuments(firmId: string = 'all'): Observable<RecentsModel.RecentDocument[]> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/recent/${firmId}`;
    return this.http.get<RecentsModel.RecentDocument[]>(url, {
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=0'
      })
    });
  }

  documents(userId: string): Observable<RecentsModel.LawConnectNode[]> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/nodes?noid=${userId || randomId}`; //?rdid=${randomId}
    return this.http.get<RecentsModel.LawConnectNode[]>(url, {
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=0'
      })
    });
  }

  documentsByFirm(firmId: string): Observable<RecentsModel.LawConnectNode[]> {
    const url = `${this.endpoint}/api/document/nodes/${firmId}`;
    return this.http.get<RecentsModel.LawConnectNode[]>(url, {
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=0'
      })
    });
  }

  download(url: string): Observable<any> {
    return this.http.get(url, { responseType: 'blob' });
  }

  downloadDocument(docId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/${docId}/download?preview=false`;
    return this.http.get(url);
  }

  downloadCollaborationDocument(matterId: string, docId: string, preview: boolean): Observable<any> {
    const url = `${this.endpoint}/api/document/${docId}/collaboration/download?preview=${preview}&matterId=${matterId}`;
    return this.http.get(url);
  }

  getSignatures(): Observable<RecentsModel.ESignature[]> {
    const url = `${this.endpoint}/api/document/signatures`;
    return this.http.get<RecentsModel.ESignature[]>(url);
  }
}
