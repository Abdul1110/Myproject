import { RecentsModel } from './recent.model';

export namespace SignatureModel {
  export interface DocumentMaps {
    oldEsignedDocumentId: string;
    newEsignedDocumentId: string;
  }

  export interface DocumentSignatureRequest {
    userId: string;
    orderId: string;
  }

  export interface DocumentSignature {
    url: string;
    isSucceeded: boolean;
    message: string;
    code: number;
  }

  export interface ESignature {
    orderId: string;
    esignedDocumentId: string;
    esignedDocumentName: string;
    esignedDocumentStatus: ESignatureDocumentStatus;
    staffId: string;
    staffName: string;
    matterId: string;
    matterNumber: string;
    matterDescription: string;
    requestedDocuments: ESignatureDocumentItem[];
    requestedSigners: ESigner[];
    createdDate: Date;
    modifiedDate: Date;
  }

  export enum ESignatureDocumentStatus {
    Pending = 0,
    Signed = 1,
    Declined = 2,
    Error = 3,
    WaitingForOthers = 4,
    Notified = 5,
    InvalidRequest = 6
  }

  export class ESignatureDocumentItem {
    id: string;
    name: string;
    fileType: RecentsModel.FileType;
  }

  export class ESigner {
    id: string; // UserID
    initials: string;
    firstName: string;
    lastName: string;
    status: ESignerStatus;
  }

  export enum ESignerStatus {
    Pending = 0,
    Viewed = 1,
    Signed = 2,
    Declined = 3
  }

  export interface SignStateTextAndStyle {
    text: string;
    cssClass: string;
    signStatus: ESignatureDocumentStatus;
  }

  export interface BadgeUpdatedRequest {
    triggerUpdated: boolean;
    badges: { [documentId: string]: RecentsModel.DocumentBadgeState };
    badgeType: RecentsModel.BadgeType;
  }

  export class Helper {
    static SignatureText(signState: ESignatureDocumentStatus): SignStateTextAndStyle {
      switch (signState) {
        case ESignatureDocumentStatus.Pending:
          return { text: 'signature request', cssClass: 'badge-warning', signStatus: signState }; // Label: action required
        case ESignatureDocumentStatus.Signed:
          return { text: 'signature signed', cssClass: 'badge-success', signStatus: signState }; // Label: signed
        case ESignatureDocumentStatus.WaitingForOthers:
          return { text: 'signature pending', cssClass: 'badge-warning', signStatus: signState }; // Label: waiting for others
        case ESignatureDocumentStatus.Declined:
          return { text: 'signature declined', cssClass: 'badge-danger', signStatus: signState }; // Label: declined
      }
    }

    static SignerStatusText(signState: ESignerStatus): string {
      switch (signState) {
        case ESignerStatus.Pending:
          return 'Action required';
        case ESignerStatus.Signed:
          return 'Signed';
        case ESignerStatus.Declined:
          return 'Declined';
        case ESignerStatus.Viewed:
          return 'Viewed';
        default:
          return '';
      }
    }

    static ESignatureDocumentStatusToText(signState: ESignatureDocumentStatus): string {
      if (signState == ESignatureDocumentStatus.Pending) {
        return 'Pending';
      }
      if (signState == ESignatureDocumentStatus.Signed) {
        return 'Signed';
      }
      if (signState == ESignatureDocumentStatus.Declined) {
        return 'Declined';
      }
      if (signState == ESignatureDocumentStatus.Error) {
        return 'Error';
      }
      if (signState == ESignatureDocumentStatus.WaitingForOthers) {
        return 'WaitingForOthers';
      }
      if (signState == ESignatureDocumentStatus.Notified) {
        return 'Notified';
      }
      if (signState == ESignatureDocumentStatus.InvalidRequest) {
        return 'InvalidRequest';
      }
      return undefined;
    }
  }
}
