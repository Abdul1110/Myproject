import { CoreModel } from '@app/core/models';
import { AnnotatorModel } from '@app/shared/models';

export namespace RecentsModel {
  export interface LawConnectNode {
    accessType: AccessType;
    creationDate: string; // map from createDate
    entityId: string; // map from id
    fileExtension: string; // map from ext
    fileType: FileType; // map from ext
    id: string; // map from id
    isRequestedEsignature: boolean;
    isSharedMatter: boolean; // set to true
    lastCommentDate: string;
    lastSignActionDate: string;
    lastVisitDate: string;
    modifiedDate: string;
    name: string; // map from name
    nodeType: NodeType; // Folder (if from folders) or Document (if from fullDocuments)
    ownerFullName: string;
    ownerId: string;
    parentId: string;
    signState: SignState;
    status: string;
    thumbnailUrl: string;
    userId: string; // map from userId
    visited: boolean;
    staffName?: string; // map from staffName
    previewUrl?: string; // map from previewUrl
    attachments?: DocAttachment[]; // map from attachments
    iconClass?: string; // map from iconClass
    iconTooltip?: string; // map from iconTooltp
    toFrom?: string; // map from toFrom
    subType: string;
    isCollaborationFile: boolean;
  }

  export interface LawConnectDocument {
    created: string;
    documentUrl: string;
    fileName: string;
    fileSizeKb: number;
    folderId: string;
    id: string;
    modified: string;
    name: string;
    ownerInitials: string;
    ownerName: string;
    ownerUserId: string;
    pages: number;
    thumbnailUrl: string;
    type: string;
    isCollaborationFile: boolean;
  }

  export interface LawConnectDocumentItem {
    name: string;
    fileType: FileType;
    fileExtension: string;
    creationDate: string;
    modifiedDate: string;
    nodeType: NodeType;
    id: string;
    signState: SignState; //this signState always 0??
    accessType: AccessType;
    commentCount: number;
    modifiedBy: string;
    isRequestedEsignature: boolean; // this isRequestedEsignature has integrity issue e.g. some doc is esignature, but the value is false.
    isSharedMatter: boolean; // this is only applicable to Matter's Share
    attachments?: DocAttachment[]; // this is only applicable to Matter's Share Correspondence
    previewUrl?: string; // this is only applicable to Matter's Share Correspondence
    isCollaboration?: boolean; // this is only applicable to Collaboration.
    collaborationRootId?: string; //this is only applicablel to Collaboration.
    isDeletable: boolean;
    currentVersionId: string;
    deleted: boolean;
    status?: string;
    ownerFullName: string;
    ownerInitials?: string;
    otherUsers?: CoreModel.OtherUser[];
  }

  export enum AccessType {
    na = 0,
    none = 1,
    view,
    addComment,
    sign,
    modify,
    owner,
    publicView
  }

  export enum FileType {
    na = 0,
    pdf = 1,
    png,
    jpg,
    jpeg,
    docx,
    doc,
    msg
  }
  export interface DocAttachment {
    id: string;
    name: string;
    ext: string;
    deleted: boolean;
    previewUrl?: string; // docs-api pdf version url
  }

  export enum SignState {
    NA = 0,
    Pending = 1,
    Signed = 2,
    Declined = 3,
    Error = 4,
    WaitingForOthers = 5,
    Notified = 6,
    InvalidRequest = 7
  }

  export enum NodeType {
    Firm = 1,
    Matter,
    Folder,
    Document,
    Esignature
  }

  export interface Notification {
    id: string;
    staffName: string;
    message: string;
    eventDate: Date;
    documentId: string;
    matterId: string;
    documentExtension: string;
    notificationType: CoreModel.PubNubNotificationType;
    meta?: any;
  }

  export interface RecentDocument {
    id: string;
    firmId: string;
    matterId: string;
    matterName: string;
    name: string;
    fileType: string;
    eventType: string | EventType;
    eventDate: string;
    sourceUserId: string;
    sourceUserName: string;
    destinationUserId: string;
    destinationUserName: string;
    eSignatureOrderId: string;
    eSignatureStatus: string | ESignatureDocumentStatus;
    isCollaboration: boolean;
    isRequestedEsignature?: boolean;
  }

  export enum BadgeType {
    comment = 0,
    signature,
    correspondence,
    attachment
  }

  export enum ESignatureDocumentStatus {
    Pending = 0,
    Signed = 1,
    Declined = 2,
    Error = 3,
    WaitingForOthers = 4,
    Notified = 5,
    InvalidRequest = 6
  }

  export enum EventType {
    created = 1,
    shared = 2,
    viewed = 3,
    revokedAccess = 4,
    signed = 7,
    signingRequested = 9,
    signingDeclined = 10
  }

  export interface SignStateTextAndStyle {
    text: string;
    cssClass: string;
  }

  export interface DocumentDownload {
    documentId: string;
    documentName: string;
    isCollaboration: boolean;
    matterId: string;
  }

  export class ESigner {
    id: string; // UserID
    initials: string;
    firstName: string;
    lastName: string;
    status: ESignerStatus;
  }

  export enum ESignerStatus {
    Pending = 0,
    Viewed = 1,
    Signed = 2,
    Declined = 3
  }

  export interface DocumentBadgeState {
    badgeType: BadgeType;
    info: string;
    cssClass: string;
    signStatus?: ESignatureDocumentStatus;
    signDocumentName?: string;
    signer?: ESigner[];
  }

  export interface ESignature {
    orderId: string;
    esignedDocumentId: string;
    esignedDocumentName: string;
    esignedDocumentStatus: ESignatureDocumentStatus;
    staffId: string;
    staffName: string;
    matterId: string;
    matterNumber: string;
    matterDescription: string;
    requestedDocuments: ESignatureDocumentItem[];
    requestedSigners: ESigner[];
    createdDate: Date;
    modifiedDate: Date;
  }

  export class ESignatureDocumentItem {
    id: string;
    name: string;
    fileType: FileType;
  }

  export interface LawConnectDocumentAnnotation extends AnnotatorModel.DocumentAnnotation {
    events: AnnotatorModel.AnnotatedEvent[];
    user: AnnotatorModel.AnnotatedUser;
  }

  export class Helper {
    static getNotificationBody(logonUserId: string, notification: CoreModel.RecentNotification): string {
      const notificationDocumentName = `<b>${notification.documentName}</b>`;
      const messages = {
        [CoreModel.PubNubNotificationType.sharing]: `shared ${notificationDocumentName} with`,
        [CoreModel.PubNubNotificationType.revoking]: `revoked access to ${notificationDocumentName} from`,
        [CoreModel.PubNubNotificationType.uploading]: `uploaded ${notificationDocumentName}`,
        [CoreModel.PubNubNotificationType.esignatureUploading]: `${notificationDocumentName} is uploaded`,
        [CoreModel.PubNubNotificationType.esignatureCreated]: `Signature requested on ${notificationDocumentName}`,
        [CoreModel.PubNubNotificationType
          .esignatureDecline]: `Esignature document ${notificationDocumentName} declined`,
        [CoreModel.PubNubNotificationType.accountStatementShared]: `shared <b>${this.getOfficeOrTrustAccount(
          notification
        )}</b> with`,
        [CoreModel.PubNubNotificationType
          .accountStatementRevoked]: `revoked access to <b>${this.getOfficeOrTrustAccount(notification)}</b> from`,
        [CoreModel.PubNubNotificationType.appStore]: `granted you access to <b>${this.getAppIdInUpperCase(
          notification
        )}</b>`,
        [CoreModel.PubNubNotificationType.appStoreRevoke]: `revoked access to <b>${this.getAppIdInUpperCase(
          notification
        )}</b> from`
      };

      const finalMessage =
        notification.notificationType === CoreModel.PubNubNotificationType.esignatureUploading ||
        notification.notificationType === CoreModel.PubNubNotificationType.esignatureCreated ||
        notification.notificationType === CoreModel.PubNubNotificationType.esignatureDecline
          ? messages[notification.notificationType].trim()
          : `<b>${this.getUserFullName(logonUserId, notification.sourceUserId, notification.sourceUserFullName)}</b>
          ${messages[notification.notificationType]}
          ${
            notification.notificationType !== CoreModel.PubNubNotificationType.uploading &&
            notification.notificationType !== CoreModel.PubNubNotificationType.appStore
              ? `<b>${this.getUserFullName(
                  logonUserId,
                  notification.destinationUserId,
                  notification.destinationUserFullName
                )}</b>`
              : ''
          }
          `.trim();

      return finalMessage;
    }

    static getUserFullName(logonUserId: string, userId: string, fullName: string): string {
      return logonUserId === userId ? 'You' : fullName;
    }

    static getDocTypeIcon(fileExtension: string): string {
      if (!fileExtension) {
        return `doctype-default-24`;
      }

      const ext = fileExtension.replace('.', '');
      let icon = 'doctype-';
      switch (ext) {
        case 'doc':
        case 'docx':
          icon += 'doc';
          break;
        case 'xls':
        case 'xlsx':
          icon += 'excel';
          break;
        case 'pdf':
          icon += 'pdf';
          break;
        case 'jpeg':
        case 'jpg':
        case 'png':
          icon += 'image';
          break;
        case 'msg':
        case 'eml':
          icon += 'email-default';
          break;
        case 'folder':
          icon += 'folder';
          break;
        default:
          icon += 'default';
      }
      icon += '-24';

      return icon;
    }

    static toEventTypeEnum(event: string): EventType {
      const eventType = event.toLowerCase();

      switch (eventType) {
        case 'created':
          return EventType.created;
        case 'shared':
          return EventType.shared;
        case 'viewed':
          return EventType.viewed;
        case 'revokedaccess':
          return EventType.revokedAccess;
        case 'signed':
          return EventType.signed;
        case 'signingrequested':
          return EventType.signingRequested;
        case 'signingdeclined':
          return EventType.signingDeclined;
        default:
          return undefined;
      }
    }

    static toESignatureStatusEnum(event: string): ESignatureDocumentStatus {
      if (!event) {
        return undefined;
      }

      const eventType = event.toLowerCase();

      switch (eventType) {
        case 'pending':
          return ESignatureDocumentStatus.Pending;
        case 'signed':
          return ESignatureDocumentStatus.Signed;
        case 'declined':
          return ESignatureDocumentStatus.Declined;
        case 'error':
          return ESignatureDocumentStatus.Error;
        case 'waitingforothers':
          return ESignatureDocumentStatus.WaitingForOthers;
        case 'notified':
          return ESignatureDocumentStatus.Notified;
        case 'invalidrequest':
          return ESignatureDocumentStatus.InvalidRequest;
        default:
          return undefined;
      }
    }

    static SignatureText(signState: ESignatureDocumentStatus): SignStateTextAndStyle {
      switch (signState) {
        case ESignatureDocumentStatus.Pending:
          return { text: 'signature request', cssClass: 'badge-warning' }; // Label: action required
        case ESignatureDocumentStatus.Signed:
          return { text: 'signature signed', cssClass: 'badge-success' }; // Label: signed
        case ESignatureDocumentStatus.WaitingForOthers:
          return { text: 'signature pending', cssClass: 'badge-warning' }; // Label: waiting for others
        case ESignatureDocumentStatus.Declined:
          return { text: 'signature declined', cssClass: 'badge-danger' }; // Label: declined
      }
    }

    private static getAppIdInUpperCase(notification: CoreModel.RecentNotification): string {
      return (
        (notification &&
          notification.meta &&
          notification.meta.appId &&
          notification.meta.appId &&
          notification.meta.appId.toUpperCase()) ||
        ''
      );
    }

    private static getOfficeOrTrustAccount(notification: CoreModel.RecentNotification): string {
      if (notification && notification.meta && notification.meta && notification.meta.type) {
        if (notification.meta.type.includes('trust')) {
          return 'Trust Account';
        }

        if (notification.meta.type.includes('office')) {
          return 'Office Account';
        }
      }

      return 'Account Statement';
    }
  }
}
