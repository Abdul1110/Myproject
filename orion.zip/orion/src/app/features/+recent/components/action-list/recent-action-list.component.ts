import {
  Component,
  EventEmitter,
  Input,
  Output,
  OnInit,
  OnDestroy,
  HostBinding,
  Inject,
  LOCALE_ID
} from '@angular/core';
import { formatDate } from '@angular/common';
import { MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { Observable, Subject } from 'rxjs';
import { takeUntil, delay, tap } from 'rxjs/operators';
import { RecentsModel } from '../../models';

@Component({
  selector: 'sc-recent-action-list',
  templateUrl: './recent-action-list.component.html'
})
export class RecentActionListComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<boolean>();
  attachments: RecentsModel.DocAttachment[];
  comments: RecentsModel.LawConnectDocumentAnnotation[];
  displayHeader: boolean;
  documentInfo: RecentsModel.LawConnectDocument;

  @Input('signed-request') isSignedRequest: boolean;

  @Input('document-item') documentItem: RecentsModel.LawConnectDocumentItem;

  @Input('document-item') recentDocumentItem: RecentsModel.RecentDocument;

  @Input('document-loading') documentLoading$: Observable<boolean>;

  @Input('display-view-action') displayViewAction: boolean;

  @Input('display-download-action') displayDownloadAction: boolean;

  @Input('display-upload-action') displayUploadAction: boolean;

  @Input('display-view-info-action') displayViewInfoAction: boolean;

  @Input('display-view-comments-action') displayViewCommentsAction: boolean;

  @Input('display-view-attachments-action') displayViewAttachmentsAction: boolean;

  @Input('display-open-matter-action') displayOpenMatterAction: boolean;

  @Input('matter-selected') matterSelected: RecentsModel.LawConnectNode;

  @Input('attachments') attachments$: Observable<RecentsModel.DocAttachment[]>;

  @Input('comments') comments$: Observable<RecentsModel.LawConnectDocumentAnnotation[]>;

  @Input('display-delete-action') displayDeleteAction: boolean;

  @Output('preview-item') previewItem = new EventEmitter<any>();

  @Output('download-document') downloadDocument = new EventEmitter<string>();

  @Output('upload-document') uploadDocument = new EventEmitter<string>();

  @Output('sign-document') signDocument = new EventEmitter<any>();

  @Output('view-document-info') viewDocumentInfo = new EventEmitter<any>();

  @Output('view-comments') viewComments = new EventEmitter<any>();

  @Output('view-attachments') viewAttachments = new EventEmitter<any>();

  @Output('open-matter') openMatter = new EventEmitter<any>();

  @Output('delete-document') deleteDocument = new EventEmitter<any>();

  @Output('close') close = new EventEmitter();

  constructor(
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    @Inject(LOCALE_ID) private locale: string,
    private bottomSheetRef: MatBottomSheetRef<RecentActionListComponent>
  ) {}

  @HostBinding('class.x-action-list')
  ngOnInit() {
    if (this.data.item) {
      this.documentItem = this.data.item;
    }

    if (this.data.isSignedRequest) {
      this.isSignedRequest = this.data.isSignedRequest;
    }

    if (this.data.displayViewAction) {
      this.displayViewAction = this.data.displayViewAction;
    }

    if (this.data.displayDownloadAction) {
      this.displayDownloadAction = this.data.displayDownloadAction;
    }

    if (this.data.displayUploadAction) {
      this.displayUploadAction = this.data.displayUploadAction;
    }

    if (this.data.displayViewInfoAction) {
      this.displayViewInfoAction = this.data.displayViewInfoAction;
    }

    if (this.data.displayDeleteAction) {
      this.displayDeleteAction = this.data.displayDeleteAction;
    }

    if (this.data.displayViewCommentsAction) {
      this.displayViewCommentsAction = this.data.displayViewCommentsAction;
    }

    if (this.data.displayViewAttachmentsAction) {
      this.displayViewAttachmentsAction = this.data.displayViewAttachmentsAction;
    }

    if (this.data.matterSelected) {
      this.matterSelected = this.data.matterSelected;
    }

    if (this.data.documentInfo) {
      this.documentInfo = this.data.documentInfo;
    }

    if (this.data.documentLoading$) {
      this.documentLoading$ = this.data.documentLoading$;
    }

    if (this.data.displayHeader) {
      this.displayHeader = this.data.displayHeader;
    }

    if (this.data.comments$) {
      this.comments$ = this.data.comments$;

      this.comments$.pipe(takeUntil(this.destroy$)).subscribe(comments => {
        this.comments = comments;
      });
    }

    if (this.data.recentDocumentItem) {
      this.recentDocumentItem = this.data.recentDocumentItem;
    }

    if (this.data.attachments$) {
      this.attachments$ = this.data.attachments$;
    }

    if (this.data.displayOpenMatterAction) {
      this.displayOpenMatterAction = this.data.displayOpenMatterAction;
    }

    this.subscribeEvents();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  download(documentId: string): void {
    this.bottomSheetRef.dismiss();
    this.downloadDocument.emit(documentId);
  }

  upload(): void {
    this.uploadDocument.emit();
  }

  getTitle(): string {
    if (this.recentDocumentItem) {
      return this.recentDocumentItem.name + '.' + this.recentDocumentItem.fileType;
    } else {
      return this.documentInfo
        ? this.documentInfo.fileName
        : this.documentItem.name + '.' + this.documentItem.fileExtension;
    }
  }

  getSubtitle(): string {
    if (this.recentDocumentItem) {
      return 'Modified on ' + formatDate(this.recentDocumentItem.eventDate, 'd MMMM y', this.locale);
    } else if (this.matterSelected.isSharedMatter) {
      return;
    } else {
      return this.documentInfo && this.documentInfo.created
        ? 'Created on ' + formatDate(this.documentInfo.created, 'd MMMM y', this.locale)
        : this.documentItem && this.documentItem.creationDate
        ? 'Created on ' + formatDate(this.documentItem.creationDate, 'd MMMM y', this.locale)
        : '';
    }
  }

  isFolder(): boolean {
    if (!this.data) {
      return false;
    }

    if (this.data.recentDocumentItem) {
      return this.data.recentDocumentItem.fileType == 'folder';
    }

    return this.data.item && this.data.item.fileExtension == 'folder';
  }

  signNow(document: any): void {
    this.bottomSheetRef.dismiss();
    this.signDocument.emit(document);
  }

  previewDocument(document: any): void {
    this.bottomSheetRef.dismiss();
    this.previewItem.emit(document);
  }

  viewInfo(document: any): void {
    this.bottomSheetRef.dismiss();
    this.viewDocumentInfo.emit(document);
  }

  viewDocumentComments(document: any): void {
    this.bottomSheetRef.dismiss();
    this.viewComments.emit(document);
  }

  delete(document: any): void {
    this.bottomSheetRef.dismiss();
    this.deleteDocument.emit(document);
  }

  openSharedMatter(): void {
    this.openMatter.emit(null);
  }

  viewFileAttachments(): void {
    this.viewAttachments.emit();
  }

  hasAttachments(matter: any): boolean {
    if (this.attachments && this.attachments.length > 0 && matter && matter.isSharedMatter) {
      return true;
    }

    if (
      this.documentItem &&
      this.documentItem.attachments &&
      this.documentItem.attachments.length > 0 &&
      this.documentItem.isCollaboration
    ) {
      return true;
    }

    return false;
  }

  closeBottomSheet(): void {
    this.close.emit(null);
  }

  private subscribeEvents(): void {
    if (this.attachments$) {
      this.attachments$
        .pipe(
          takeUntil(this.destroy$),
          delay(0),
          tap(attachments => {
            this.attachments = attachments;
          })
        )
        .subscribe();
    }
  }
}
