import {
  ChangeDetectionStrategy,
  Component,
  Input,
  EventEmitter,
  Output,
  ViewChild,
  HostListener
} from '@angular/core';
import { RecentsModel } from '../../models/recent.model';
import { SignatureModel } from '../../models/signature.model';

@Component({
  selector: 'sc-notification-list',
  templateUrl: './notification-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NotificationListComponent {
  @Input('activities') activities: RecentsModel.Notification[];
  @Input('signature-maps') signatureMaps: SignatureModel.DocumentMaps[];

  @Output('delete-activity') deleteActivity = new EventEmitter<string>();
  @Output('preview-notification') previewNotification = new EventEmitter<string>();
  @ViewChild('vp', { static: false }) vpScroll: any;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (this.vpScroll) {
      this.vpScroll.checkViewportSize();
    }
  }

  constructor() {}

  trackElement(index: number, element: any) {
    if (element && element.id) {
      return element.id;
    }
    return index;
  }

  deleteNotification(notificationId: string): void {
    this.deleteActivity.emit(notificationId);
  }

  preview(notificationId: string): void {
    const documentId = this.activities.find(x => x.id === notificationId).documentId;
    const foundOldSignature =
      this.signatureMaps && this.signatureMaps.length > 0
        ? this.signatureMaps.find(y => y.oldEsignedDocumentId === documentId)
        : undefined;
    if (foundOldSignature) {
      this.previewNotification.emit(foundOldSignature.newEsignedDocumentId);
      this.deleteNotification(notificationId);
      return;
    }

    this.previewNotification.emit(notificationId);
    this.deleteNotification(notificationId);
  }

  zeroNotification(): boolean {
    return !this.activities || this.activities.length === 0;
  }
}
