import { NotificationListComponent } from './notification-list/notification-list.component';
import { DocumentItemComponent } from './document-item/document-item.component';
import { RecentActionListComponent } from './action-list/recent-action-list.component';

export * from './notification-list/notification-list.component';
export * from './document-item/document-item.component';
export * from './action-list/recent-action-list.component';

export const recentComponents = [NotificationListComponent, DocumentItemComponent, RecentActionListComponent];
