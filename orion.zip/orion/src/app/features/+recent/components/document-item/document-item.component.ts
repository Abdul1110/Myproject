import { ChangeDetectionStrategy, Component, Input, EventEmitter, Output, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';
import { map, takeUntil } from 'rxjs/operators';
import * as moment from 'moment';

import { RecentsModel } from '../../models/recent.model';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { RecentActionListComponent } from '../action-list/recent-action-list.component';

@Component({
  selector: 'sc-document-item',
  templateUrl: './document-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DocumentItemComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<boolean>();

  get isSignedRequest(): boolean {
    if (this.badges && this.badges.length > 0) {
      return this.badges.findIndex(b => b.signStatus !== undefined && +b.signStatus === 0) >= 0;
    }
    return false;
  }

  get isFolder(): boolean {
    return !!(this.item && this.item.fileType == 'folder');
  }

  get showDownload(): boolean {
    const blacklist = ['folder', 'trust', 'office'];
    return !!!(this.item && blacklist.includes(this.item.fileType));
  }

  isSmallScreen$: Observable<boolean>;

  @Input('last-item') lastItem: boolean;

  @Input('item') item: RecentsModel.RecentDocument;

  @Input('badges') badges: RecentsModel.DocumentBadgeState[];

  @Input('selected') selectedDocumentId: string;

  @Input('document-downloading') documentDownloading: boolean;

  @Output('preview-item') previewItem = new EventEmitter<RecentsModel.RecentDocument>();

  @Output('sign-document') signDocument = new EventEmitter<RecentsModel.RecentDocument>();

  @Output('download-document') downloadDocument = new EventEmitter<RecentsModel.RecentDocument>();

  constructor(private _breakpointObserver: BreakpointObserver, private bottomSheet: MatBottomSheet) {}

  ngOnInit() {
    this.isSmallScreen$ = this._breakpointObserver.observe(['(max-width: 992px)']).pipe(
      takeUntil(this.destroy$),
      map((state: BreakpointState) => state.matches)
    );
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }

  getModified(doc: RecentsModel.RecentDocument): string {
    if (!doc || !doc.eventDate) {
      return '';
    }

    return `Modified: ${moment(doc.eventDate).format('ll')} by ${doc.sourceUserName}`;
  }

  getIcon(ext: string): string {
    return RecentsModel.Helper.getDocTypeIcon(ext);
  }

  getColor(): string {
    if (this.item && this.selectedDocumentId && this.item.id === this.selectedDocumentId) {
      return 'lemonchiffon';
    }
    return '';
  }

  signNow(document: RecentsModel.RecentDocument): void {
    this.signDocument.emit(document);
  }

  previewDocument(document: RecentsModel.RecentDocument): void {
    this.previewItem.emit(document);
  }

  selectItem = (document: RecentsModel.RecentDocument, isSignedRequest: boolean): void => {
    if (isSignedRequest) {
      this.signNow(document);
      return;
    }

    this.previewDocument(document);
  };

  getDocumentName(badges: RecentsModel.DocumentBadgeState[], defaultDocumentName: string): string {
    return defaultDocumentName;
  }

  getBadgeText(badge: RecentsModel.DocumentBadgeState): string {
    if (badge.badgeType === RecentsModel.BadgeType.comment) {
      return `0 comment`;
    }

    if (badge.badgeType === RecentsModel.BadgeType.signature) {
      return badge.info || 'signature';
    }

    if (badge.badgeType === RecentsModel.BadgeType.correspondence) {
      return badge.info || 'correspondence';
    }

    if (badge.badgeType === RecentsModel.BadgeType.attachment) {
      return badge.info || 'attachment';
    }

    return `?`;
  }

  getBadgeCss(badge: RecentsModel.DocumentBadgeState): string {
    return badge ? `badge ${badge.cssClass}` : 'badge';
  }

  download() {
    this.downloadDocument.emit(this.item);
  }

  openActionSheet(): void {
    const actionListComponentRef = this.bottomSheet.open(RecentActionListComponent, {
      panelClass: 'x-bottom-sheet',
      data: {
        recentDocumentItem: this.item,
        isSignedRequest: this.isSignedRequest,
        displayViewAction: true,
        displayDownloadAction: !!(this.item && this.item.fileType != 'folder'),
        displayViewInfoAction: false,
        displayViewCommentsAction: false,
        displayHeader: true
      }
    });

    actionListComponentRef.instance.signDocument.pipe(takeUntil(this.destroy$)).subscribe((data: any) => {
      this.signNow(this.item);
    });

    actionListComponentRef.instance.previewItem
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: RecentsModel.RecentDocument) => {
        this.previewDocument(this.item);
      });

    actionListComponentRef.instance.downloadDocument.pipe(takeUntil(this.destroy$)).subscribe((data: any) => {
      this.downloadDocument.emit(this.item);
    });

    actionListComponentRef.instance.close.pipe(takeUntil(this.destroy$)).subscribe((data: any) => {
      this.bottomSheet.dismiss();
    });
  }

  getPreviewOrOpenTitle = (item: RecentsModel.RecentDocument): string => {
    if (item && item.fileType.includes('folder')) {
      return 'Open';
    }
    return 'Preview';
  };
}
