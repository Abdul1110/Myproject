import { NgModule } from '@angular/core';
import { InlineSVGModule } from 'ng-inline-svg';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { AppStateModule } from '@app/core/app-state.module';
import { RecentRoutingModule } from './recent-routing.module';
import { recentsPages } from './pages';
import {
  GalaxyPreLoaderComponentModule,
  LyraDesignEmptyStateModule,
  LyraDesignPanelModule,
  LyraDesignMenuModule,
  LyraDesignCommonModule,
  LyraDesignAsideModule,
  LyraDesignIconModule,
  LyraDesignMainModule,
  LyraDesignNavbarModule,
  LyraDesignCardModule,
  LyraDesignFilesModule,
  LyraDesignTypeModule,
  LyraDesignSectionModule
} from '@leap/lyra-design';
import { recentsLayouts } from './layout';
import { recentServices } from './services';
import { recentComponents } from './components';
import { SharedModule } from '@app/shared';
import { RecentStateModule } from './recent-state.module';

@NgModule({
  imports: [
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule,
    MatBottomSheetModule,
    AppStateModule,
    RecentStateModule,
    RecentRoutingModule,
    GalaxyPreLoaderComponentModule,
    LyraDesignEmptyStateModule,
    LyraDesignPanelModule,
    LyraDesignMenuModule,
    LyraDesignCommonModule,
    LyraDesignIconModule,
    LyraDesignAsideModule,
    LyraDesignMainModule,
    LyraDesignNavbarModule,
    LyraDesignCardModule,
    LyraDesignFilesModule,
    LyraDesignTypeModule,
    LyraDesignSectionModule,
    BsDropdownModule.forRoot()
  ],
  entryComponents: [...recentsLayouts, ...recentsPages, ...recentComponents],
  declarations: [...recentsLayouts, ...recentsPages, ...recentComponents],
  providers: [...recentServices]
})
export class RecentModule {}
