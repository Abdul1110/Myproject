import { Component, OnDestroy, HostBinding } from '@angular/core';
import { takeUntil, tap, take } from 'rxjs/operators';
import { Subject, Observable, merge } from 'rxjs';
import { Store, Select } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';

import { AppState } from '@app/core/store/states';
import { CoreModel, NodeModel } from '@app/core/models';
import { environment } from '@env/environment';
import { AnalyticService, NAVIGATION_SIDE_BAR_UPDATE, CustomEventService, NavigationService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { RecentState, RecentAction } from '../../store';
import { RecentsModel } from '../../models/recent.model';
import { SignatureModel } from '../../models/signature.model';

const { locale } = environment;
const { document: no_results } = (<any>environment.locale).no_results.documents;

@Component({
  selector: 'sc-recents-file',
  templateUrl: './recents-file.component.html'
})
export class RecentsFileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private documentBadges: { [documentId: string]: RecentsModel.DocumentBadgeState[] } = {};
  private documentId = '';
  recent_document: any;
  recentLoading = false;

  @Select(RecentState.getDocumentBadges)
  documentBadges$: Observable<{
    [documentId: string]: RecentsModel.DocumentBadgeState[];
  }>;

  @Select(RecentState.getLoadingStatus) loading$: Observable<boolean>;

  @Select(RecentState.getDeleteLoading) deleteLoading$: Observable<boolean>;

  @Select(RecentState.getError) error$: Observable<string>;

  @Select(RecentState.getNotifications) notification$: Observable<RecentsModel.Notification[]>;

  @Select(RecentState.getNoDocument) noDocumentFlag$: Observable<boolean>;

  @Select(RecentState.getDocuments) documents$: Observable<RecentsModel.RecentDocument[]>;

  @Select(RecentState.getSelectedDocumentId) documentId$: Observable<string>;

  @Select(RecentState.getSelectedMatterSignatureMapping) signatureMaps$: Observable<SignatureModel.DocumentMaps[]>;

  @Select(RecentState.getSelectedFirmName) selectedFirmName$: Observable<string>;

  @Select(AppState.getLoginUser) logonUser$: Observable<CoreModel.LogonUserInfo>;

  @Select(RecentState.getDownloadDocuments) downloadDocumentsStatus$: Observable<{ [documentId: string]: boolean }>;

  constructor(
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private customEventSvc: CustomEventService,
    private navigationSvc: NavigationService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.RecentsPage, action: 'View recents' });
    }

    this.recent_document = no_results.recent_document;

    merge(
      this.loadingSideEffect$(),
      this.logonUserSideEffect$(),
      this.documentIdSideEffect$(),
      this.documentBadgesSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  @HostBinding('class.layout-column')
  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  markAllAsRead(): void {
    this.store.dispatch(new RecentAction.DeleteNotificationStart(undefined));
  }

  deleteNotification(notificationId: string): void {
    this.store.dispatch(new RecentAction.DeleteNotificationStart(notificationId));
  }

  trackElement(index: number, element: any) {
    return index;
  }

  previewDocument(document: RecentsModel.RecentDocument): void {
    this.store.dispatch(new RecentAction.ViewDocument(Object.assign({}, document)));
  }

  signDocument(document: RecentsModel.RecentDocument): void {
    this.store.dispatch(new RecentAction.SignDocument(document));
  }

  isActiveItem(documentId: string): boolean {
    return this.documentId === documentId;
  }

  getDocumentBadges(item: RecentsModel.RecentDocument): RecentsModel.DocumentBadgeState[] {
    if (!!this.documentBadges && Object.keys(this.documentBadges).length > 0 && !!item) {
      return this.documentBadges[item.id] || [];
    }
    return [];
  }

  getDocuments(docs: any): any {
    return docs;
  }

  previewNotification(notificationId: string): void {
    const notifications = this.store.selectSnapshot(RecentState.getNotifications);
    const notification = notifications ? notifications.find(x => x.id === notificationId) : undefined;

    if (!notification || notification.notificationType === CoreModel.PubNubNotificationType.revoking) {
      const error = { message: 'This document link is no longer valid!' };
      this.store.dispatch(new RecentAction.ViewDocumentFailure(error));
      return;
    }

    if (notification.notificationType === CoreModel.PubNubNotificationType.accountStatementRevoked) {
      return;
    }

    const firmId = this.store.selectSnapshot(AppState.getSelectedFirmId);
    const document = <RecentsModel.RecentDocument>{
      id: notification.documentId,
      matterId: notification.matterId,
      firmId: firmId,
      fileType: notification.documentExtension
    };

    if (notification.notificationType === CoreModel.PubNubNotificationType.sharing) {
      this.previewDocument(document);
      return;
    }

    if (notification.notificationType === CoreModel.PubNubNotificationType.esignatureCreated) {
      this.signDocument(document);
      return;
    }

    if (notification.notificationType === CoreModel.PubNubNotificationType.accountStatementShared) {
      const isTrustSharing = notification.meta && notification.meta.type && notification.meta.type.includes('trust');

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${document.matterId}/${isTrustSharing ? 'trust' : 'billing'}`
      });
      return;
    }

    if (notification.notificationType === CoreModel.PubNubNotificationType.appStore) {
      const { matterId, id: appId, documentId: shareId } = notification;

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${matterId}/apps/${appId}/shares/${shareId}`
      });

      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_UPDATE, {
        matterId
      });
      return;
    }

    if (notification.notificationType === CoreModel.PubNubNotificationType.appStoreRevoke) {
      const error = { message: 'This app link is no longer valid!' };
      this.store.dispatch(new RecentAction.ViewAppFailure(error));
      return;
    }
  }

  getFileTitle(firmName: string): string {
    return firmName ? `${firmName} > ${locale.recents.document_header}` : `${locale.recents.document_header}`;
  }

  getRecentsTitle(): string {
    return `${locale.recents.title}`;
  }

  download(document: RecentsModel.RecentDocument): void {
    if (document) {
      const { id, name, fileType } = document;

      const rawNodes = this.store.selectSnapshot(AppState.getNodes) as NodeModel.LawConnectNode[];
      const node = rawNodes && rawNodes.find(x => x.id == id);
      const isCollaboration = node && node.isCollaborationFile;

      const documentDownloadPayload = <RecentsModel.DocumentDownload>{
        documentId: id,
        documentName: `${name}.${fileType}`,
        isCollaboration,
        matterId: isCollaboration ? node.parentId : ''
      };

      this.store.dispatch(new RecentAction.DownloadDocument(documentDownloadPayload));
    }
  }

  isDownload(downloadStatus: {}, documentId: string): boolean {
    return downloadStatus && Object.keys(downloadStatus).length > 0 && downloadStatus[documentId];
  }

  getUnreadNotificationTitle(): string {
    return `${locale.recents.notification_header}`;
  }

  private loadingSideEffect$(): Observable<boolean> {
    return this.loading$.pipe(
      tap(loading => {
        setTimeout(() => (this.recentLoading = loading), 0);
      })
    );
  }

  private logonUserSideEffect$(): Observable<CoreModel.LogonUserInfo> {
    return this.logonUser$.pipe(
      take(1),
      tap(user => {
        if (user && user.userId) {
          this.store.dispatch(new RecentAction.GetRecentsStart(user.userId));
        }
      })
    );
  }

  private documentIdSideEffect$(): Observable<string> {
    return this.documentId$.pipe(tap(docId => (this.documentId = docId)));
  }

  private documentBadgesSideEffect$(): Observable<{ [documentId: string]: RecentsModel.DocumentBadgeState[] }> {
    return this.documentBadges$.pipe(tap(badges => (this.documentBadges = badges)));
  }
}
