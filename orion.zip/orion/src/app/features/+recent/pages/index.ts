import { RecentsFileComponent } from './recents-file/recents-file.component';

export * from './recents-file/recents-file.component';

export const recentsPages = [RecentsFileComponent];
