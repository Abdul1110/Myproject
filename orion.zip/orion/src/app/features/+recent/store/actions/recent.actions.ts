import { CoreModel, NodeModel } from '@app/core/models';
import { RecentsModel } from '../../models/recent.model';
import { SignatureModel } from '../../models';

export namespace RecentAction {
  const prefix = '[Recent]';

  export const ActionTypes = {
    GET_RECENTS_START: `${prefix} get recents start`,
    GET_RECENTS_SUCCESS: `${prefix} get recents success`,
    GET_RECENTS_FAILURE: `${prefix} Failed to get recents`,

    DELETE_NOTIFICATION_START: `${prefix} delete notification start`,
    DELETE_NOTIFICATION_SUCCESS: `${prefix} delete notification success`,
    DELETE_NOTIFICATION_FAILURE: `${prefix} Failed to delete notification`,

    GET_DOCUMENTS_START: `${prefix} get documents start`,
    GET_DOCUMENTS_SUCCESS: `${prefix} get documents success`,
    GET_DOCUMENTS_FAILURE: `${prefix} Failed to get documents`,

    GET_NODES_START: `${prefix} get nodes start`,
    GET_NODES_SUCCESS: `${prefix} get nodes success`,
    GET_NODES_FAILURE: `${prefix} Failed to get nodes`,

    VIEW_DOCUMENT: `${prefix} view document`,
    VIEW_DOCUMENT_FAILURE: `${prefix} Failed to view document`,
    SIGN_DOCUMENT: `${prefix} sign document`,

    SET_VIEW_FROM_RECENT: `${prefix} set view from recent`,
    SET_USER_ID: `${prefix} set user id`,

    DOWNLOAD_DOCUMENT: `${prefix} download document`,
    DOWNLOAD_DOCUMENT_SUCCESS: `${prefix} download document success`,
    DOWNLOAD_DOCUMENT_FAILURE: `${prefix} Failed to download document`,

    UPDATE_SIGNATURES_STATUS: `${prefix} update signature status`,
    UPDATE_MATTER_SIGNATURES_STATUS: `${prefix} update matter signatures status`,
    UPDATE_DOCUMENT_BADGE: `${prefix} update document badge status`,

    VIEW_APP_FAILURE: `${prefix} Failed to view the app`
  };

  export class DownloadDocument {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT;
    constructor(public payload: RecentsModel.DocumentDownload) {}
  }

  export class DownloadDocumentSuccess {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT_SUCCESS;
    constructor(public payload: string) {}
  }

  export class DownloadDocumentFailure {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class SetUserId {
    static readonly type = ActionTypes.SET_USER_ID;
    constructor(public payload: string) {} // user id
  }

  export class GetRecentsStart {
    static readonly type = ActionTypes.GET_RECENTS_START;
    constructor(public payload: string) {} //logon user id
  }

  export class GetRecentsSuccess {
    static readonly type = ActionTypes.GET_RECENTS_SUCCESS;
    constructor(public payload: { logonUserId; data: CoreModel.RecentNotification[] }) {}
  }

  export class GetRecentsFailure {
    static readonly type = ActionTypes.GET_RECENTS_FAILURE;
    constructor(public payload: any) {}
  }

  export class GetNodesStart {
    static readonly type = ActionTypes.GET_NODES_START;
    constructor(public payload: CoreModel.SharePreviewInfoId) {}
  }
  export class GetNodesSuccess {
    static readonly type = ActionTypes.GET_NODES_SUCCESS;
    constructor(public payload: { preview: CoreModel.SharePreviewInfoId; nodes: NodeModel.LawConnectNode[] }) {}
  }
  export class GetNodesFailure {
    static readonly type = ActionTypes.GET_NODES_FAILURE;
    constructor(public payload: any) {}
  }

  export class DeleteNotificationStart {
    static readonly type = ActionTypes.DELETE_NOTIFICATION_START;
    constructor(public payload: string) {} //notification id
  }

  export class DeleteNotificationSuccess {
    static readonly type = ActionTypes.DELETE_NOTIFICATION_SUCCESS;
    constructor(public payload: { notificationId: string; result: { success: boolean } }) {} //notification id
  }

  export class DeleteNotificationFailure {
    static readonly type = ActionTypes.DELETE_NOTIFICATION_FAILURE;
    constructor(public payload: any) {}
  }

  export class GetDocumentsStart {
    static readonly type = ActionTypes.GET_DOCUMENTS_START;
    constructor(public payload: string) {} //firm id
  }

  export class GetDocumentsSuccess {
    static readonly type = ActionTypes.GET_DOCUMENTS_SUCCESS;
    constructor(public payload: RecentsModel.RecentDocument[]) {}
  }

  export class GetDocumentsFailure {
    static readonly type = ActionTypes.GET_DOCUMENTS_FAILURE;
    constructor(public payload: any) {}
  }

  export class ViewDocument {
    static readonly type = ActionTypes.VIEW_DOCUMENT;
    constructor(public payload: RecentsModel.RecentDocument) {}
  }

  export class ViewDocumentFailure {
    static readonly type = ActionTypes.VIEW_DOCUMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class ViewAppFailure {
    static readonly type = ActionTypes.VIEW_APP_FAILURE;
    constructor(public payload: any) {}
  }

  export class SignDocument {
    static readonly type = ActionTypes.SIGN_DOCUMENT;
    constructor(public payload: RecentsModel.RecentDocument) {}
  }

  export class SetViewFromRecent {
    static readonly type = ActionTypes.SET_VIEW_FROM_RECENT;
    constructor(public payload: boolean) {} //true or false
  }

  export class UpdateSignatureStatus {
    static readonly type = ActionTypes.UPDATE_SIGNATURES_STATUS;
    constructor(public payload: boolean) {} //reload
  }

  export class UpdateMatterSignaturesStatus {
    static readonly type = ActionTypes.UPDATE_MATTER_SIGNATURES_STATUS;
    constructor(public payload: any) {}
  }

  export class UpdateDocumentBadge {
    static readonly type = ActionTypes.UPDATE_DOCUMENT_BADGE;
    constructor(public payload: SignatureModel.BadgeUpdatedRequest[]) {}
  }
}
