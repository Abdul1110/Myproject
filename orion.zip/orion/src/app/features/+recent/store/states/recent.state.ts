import { State, Selector, StateContext, Action, Store } from '@ngxs/store';
import { map, catchError, switchMap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { BrowserService } from '@leap/lyra-design';
import { saveAs as FileSaver } from 'file-saver';

import { RecentAction } from '../actions';
import { LawConnectApiService } from '../../services';
import { CoreModel } from '@app/core/models';
import {
  SetMatterFirmId,
  SetMatterId,
  SetNotificationCount,
  RedirectToLogin,
  SetSharePreview,
  RemoveSignaturePendingUpdateFromList
} from '@app/core/store/actions';
import { CoreStateModel, AppState } from '@app/core/store/states';
import { SignatureModel as AppSignatureModel } from '@core/models';
import { NavigationService } from '@app/core/services';
import { RecentsModel, SignatureModel } from '../../models';

export interface RecentsStateModel {
  error: string;
  userId: string;
  loading: boolean;
  deleteLoading: boolean;
  notifications: CoreModel.RecentNotification[];
  briefNotifications: RecentsModel.Notification[];
  noDocument: boolean;
  documents: RecentsModel.RecentDocument[];
  documentsLoading: boolean;
  documentId: string;
  viewFromRecent: boolean;
  nodesLoading: boolean;
  nodes: RecentsModel.LawConnectNode[];
  downloadDocuments: { [documentId: string]: boolean };
  badges: { [documentId: string]: RecentsModel.DocumentBadgeState[] };
}

@State<RecentsStateModel>({
  name: 'recents_file',
  defaults: {
    userId: undefined,
    error: undefined,
    loading: false,
    deleteLoading: false,
    notifications: [],
    briefNotifications: [],
    noDocument: true,
    documents: [],
    documentsLoading: false,
    documentId: '',
    viewFromRecent: false,
    nodesLoading: false,
    nodes: [],
    downloadDocuments: {},
    badges: {}
  }
})
export class RecentState {
  constructor(
    private browserSvc: BrowserService,
    private lawConnectSvc: LawConnectApiService,
    private store: Store,
    private router: Router,
    private navigationSvc: NavigationService
  ) {}

  @Selector()
  static getViewFromRecent(state: RecentsStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.viewFromRecent;
  }

  @Selector()
  static getSelectedDocumentId(state: RecentsStateModel): string {
    if (!state || !state.documents) {
      return '';
    }

    return state.documentId;
  }

  @Selector([AppState])
  static getDocuments(state: RecentsStateModel, appState: CoreStateModel): RecentsModel.RecentDocument[] {
    if (!state || !state.documents) {
      return [];
    }

    return state.documents;
  }

  @Selector()
  static hasESignatureDocument(state: RecentsStateModel): boolean {
    if (!state || !state.documents || state.documents.length == 0) {
      return false;
    }

    return !!state.documents.find(d => !!d.eSignatureOrderId);
  }

  @Selector()
  static getDocumentsLoading(state: RecentsStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.documentsLoading;
  }

  @Selector()
  static getNoDocument(state: RecentsStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.noDocument;
  }

  @Selector()
  static getNotifications(state: RecentsStateModel): RecentsModel.Notification[] {
    if (!state) {
      return [];
    }

    return state.briefNotifications;
  }

  @Selector()
  static getDeleteLoading(state: RecentsStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.deleteLoading;
  }

  @Selector()
  static getLoadingStatus(state: RecentsStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.loading;
  }

  @Selector()
  static getError(state: RecentsStateModel): string {
    if (!state) {
      return undefined;
    }

    return state.error;
  }

  @Selector()
  static getNodes(state: RecentsStateModel): RecentsModel.LawConnectNode[] {
    if (!state) {
      return undefined;
    }

    return state.nodes;
  }
  @Selector()
  static getDownloadDocuments(state: RecentsStateModel): { [documentId: string]: boolean } {
    if (!state) {
      return undefined;
    }

    return state.downloadDocuments;
  }

  @Selector([AppState])
  static getSelectedFirmName(state: RecentsStateModel, appState: CoreStateModel): string {
    if (!state || !state.nodes || state.nodes.length == 0 || !appState.firmId) {
      return '';
    }

    return state.nodes.find(n => n.nodeType == RecentsModel.NodeType.Firm && n.id == appState.firmId).name;
  }

  @Selector([AppState])
  static getSelectedMatterSignature(state: RecentsStateModel, appState: CoreStateModel): SignatureModel.ESignature[] {
    if (!appState || !appState.signatures || appState.signatures.length === 0) {
      return [];
    }

    const signatures = appState.signatures.filter(s => s.matterId === appState.matterId);
    return signatures;
  }

  @Selector([AppState])
  static getOtherMatterSignature(state: RecentsStateModel, appState: CoreStateModel): SignatureModel.ESignature[] {
    if (!appState || !appState.signatures || appState.signatures.length === 0) {
      return [];
    }

    const signatures = appState.signatures.filter(s => s.matterId !== appState.matterId);
    return signatures;
  }

  @Selector([AppState])
  static getSelectedMatterSignatureMapping(
    state: RecentsStateModel,
    appState: CoreStateModel
  ): SignatureModel.DocumentMaps[] {
    if (!state || !appState.signatures || appState.signatures.length === 0) {
      return [];
    }

    const signatures = appState.signatures.filter(s => s.matterId === appState.matterId && s.esignedDocumentId);
    const mappings = signatures
      .map(m => {
        return m.requestedDocuments.map<SignatureModel.DocumentMaps>(
          x => <SignatureModel.DocumentMaps>{ oldEsignedDocumentId: x.id, newEsignedDocumentId: m.esignedDocumentId }
        );
      })
      .reduce((a, b) => a.concat(b));

    return mappings;
  }

  @Selector()
  static getDocumentBadges(state: RecentsStateModel): { [documentId: string]: RecentsModel.DocumentBadgeState[] } {
    return !!state ? state.badges : {};
  }

  @Action(RecentAction.UpdateSignatureStatus)
  UpdateSignatureStatus({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const reload = payload.payload as boolean;
    const signatures = this.store.selectSnapshot(AppState.getSignatures);

    if (signatures && signatures.length > 0) {
      const sharePreview = this.store.selectSnapshot(AppState.getSharePreviewInfo);
      const eSignature = sharePreview ? sharePreview.eSignature : undefined;
      const { userId } = this.store.selectSnapshot(AppState.getLoginUser);
      if (eSignature && eSignature.orderId) {
        const signature = signatures.find(
          s => s.orderId == eSignature.orderId && (s.esignedDocumentId == null || s.esignedDocumentId == undefined)
        );
        if (signature && signature.requestedSigners.findIndex(x => x.id == userId) !== -1) {
          const documentId = signature.requestedDocuments[0].id;
          return this.store.dispatch([
            new SetSharePreview(undefined),
            new RecentAction.GetNodesStart({ id: documentId, isMatterShared: false })
          ]);
        } else {
          // todo: alert user about the esignature has been signed.
        }
      }
    }

    //update signature status
    if (reload) {
      return dispatch(new RecentAction.UpdateMatterSignaturesStatus(undefined));
    }
  }

  @Action(RecentAction.UpdateMatterSignaturesStatus)
  UpdateMatterSignaturesStatus({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const currentMatterSignatures = this.store.selectSnapshot(RecentState.getSelectedMatterSignature) || [];
    const otherMatterSignatures = this.store.selectSnapshot(RecentState.getOtherMatterSignature) || [];
    const signatures = [].concat(currentMatterSignatures).concat(otherMatterSignatures);
    const currentUser = this.store.selectSnapshot(AppState.getLoginUser);

    if (signatures.length === 0) {
      return;
    }

    const nodesX = this.store.selectSnapshot(AppState.getNodes);
    if (nodesX && nodesX.length > 0) {
      const state = getState();
      const signatureShowOrHideList = CoreModel.Helper.getSignatureDocumentShowOrHideList(
        nodesX,
        signatures,
        currentUser.userId
      );

      if (signatureShowOrHideList.length > 0) {
        const docs =
          state &&
          state.documents &&
          state.documents.filter(doc => {
            const idx = signatureShowOrHideList.findIndex(x => x.documentId === doc.id);
            if (idx == -1) {
              return true;
            }
            return signatureShowOrHideList[idx].show;
          });

        setState({
          ...state,
          documents: docs || []
        });
      }
    }

    const user = this.store.selectSnapshot(AppState.getLoginUser);
    const anyPendingUpdates = this.store.selectSnapshot(AppState.getSignaturesPendingUpdate);
    let status: { [documentId: string]: RecentsModel.DocumentBadgeState } = {};
    const reupdated = [];

    signatures.forEach(s => {
      const { text, cssClass, signStatus } = SignatureModel.Helper.SignatureText(s.esignedDocumentStatus);

      // signed copy has esignedDocumentId value.
      if (text && cssClass && status && s.esignedDocumentId) {
        const documentId = s.esignedDocumentId;
        if (!status[documentId]) {
          status[documentId] = Object.assign(
            {},
            {
              badgeType: RecentsModel.BadgeType.signature,
              info: text,
              cssClass,
              signStatus,
              signDocumentName: s.esignedDocumentName,
              signer: s.requestedSigners
            }
          );
        } else {
          reupdated.push(documentId);
          // console.log('1. document signature badge update again?? ', documentId);
        }
      }
      // declined, pending, or requested copy has no esignedDocumentId value.
      else if (s.requestedDocuments && s.requestedDocuments.length > 0) {
        const documentIds = s.requestedDocuments.map(d => d.id) || [];

        documentIds.forEach(documentId => {
          const { text, cssClass, signStatus } = AppSignatureModel.Helper.SignatureTextIncludePendingUpdate(
            anyPendingUpdates && anyPendingUpdates[documentId],
            s.esignedDocumentStatus,
            user && user.userId
          );

          if (anyPendingUpdates[documentId] && s.esignedDocumentStatus == signStatus) {
            this.store.dispatch(new RemoveSignaturePendingUpdateFromList(documentId));
          }

          if (!status[documentId]) {
            status[documentId] = Object.assign(
              {},
              {
                badgeType: RecentsModel.BadgeType.signature,
                info: text,
                cssClass,
                signStatus,
                signDocumentName: s.esignedDocumentName,
                signer: s.requestedSigners
              }
            );
          } else {
            reupdated.push(documentId);
            // console.log('2. document signature badge update again?? ', documentId);
          }
        });
      }
    });

    // perform reupdated with latest signature copy state
    if (reupdated.length > 0) {
      const uniqueDocumentIds = Array.of<string>(...new Set(reupdated));

      uniqueDocumentIds.forEach(documentId => {
        const relatedSignatures = signatures.filter(x => x.requestedDocuments.findIndex(y => y.id === documentId) >= 0);
        if (relatedSignatures && relatedSignatures.length > 0) {
          const latestSignature = relatedSignatures.sort((c, d) => {
            return new Date(d.createdDate).getTime() - new Date(c.createdDate).getTime();
          })[0];

          const { text, cssClass, signStatus } = AppSignatureModel.Helper.SignatureTextIncludePendingUpdate(
            anyPendingUpdates && anyPendingUpdates[documentId],
            latestSignature.esignedDocumentStatus,
            user && user.userId
          );

          if (anyPendingUpdates[documentId] && latestSignature.esignedDocumentStatus == signStatus) {
            this.store.dispatch(new RemoveSignaturePendingUpdateFromList(documentId));
          }

          status[documentId] = Object.assign(
            {},
            {
              badgeType: RecentsModel.BadgeType.signature,
              info: text,
              cssClass,
              signStatus,
              signDocumentName: latestSignature.esignedDocumentName,
              signer: latestSignature.requestedSigners
            }
          );
        }
      });
    }

    return dispatch(
      new RecentAction.UpdateDocumentBadge([
        { triggerUpdated: true, badges: status, badgeType: RecentsModel.BadgeType.signature }
      ])
    );
  }

  @Action(RecentAction.UpdateDocumentBadge)
  UpdateDocumentBadge({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const newBadges = payload.payload as SignatureModel.BadgeUpdatedRequest[];

    if (!newBadges || newBadges.length === 0) {
      setState({
        ...state,
        badges: {}
      });
      return;
    }

    const updateUI = newBadges.map(y => y.triggerUpdated).find(z => z) || false;

    newBadges.forEach(x => {
      const { triggerUpdated, badges, badgeType } = x;
      let skip = false;

      if (!badges || Object.keys(badges).length === 0) {
        const stateOne = getState();
        const olds = stateOne.badges;
        let badges = {};
        Object.keys(stateOne.badges).forEach(b => {
          const hasOtherData = olds[b].filter(c => c.badgeType !== badgeType);
          badges[b] = hasOtherData;
        });

        setState({
          ...stateOne,
          badges: badges
        });
        skip = true;
      }

      if (!skip) {
        const stateTwo = getState();
        const oldBadges = (stateTwo && stateTwo.badges) || {};
        let updateBadge = {};

        if (!oldBadges || Object.keys(oldBadges).length === 0) {
          Object.keys(badges).forEach(documentId => {
            updateBadge[documentId] = [badges[documentId]];
          });

          setState({
            ...stateTwo,
            badges: updateBadge
          });

          skip = true;
        }

        if (!skip) {
          const stateThree = getState();
          Object.keys(oldBadges).forEach(oldDocId => {
            // if new badge has document id in old badge list? perform update
            if (badges[oldDocId]) {
              const current = oldBadges[oldDocId].filter(b => b.badgeType !== badgeType);
              updateBadge[oldDocId] =
                current && current.length > 0 ? [].concat(current, badges[oldDocId]) : [badges[oldDocId]];
            } else {
              updateBadge[oldDocId] = Object.assign([], oldBadges[oldDocId]);
            }
          });

          // loop any new badge not in update list? perform insert
          Object.keys(badges).forEach(documentId => {
            if (!updateBadge[documentId]) {
              updateBadge[documentId] = [badges[documentId]];
            }
          });

          setState({
            ...stateThree,
            badges: updateBadge //Object.assign({}, )
          });
        }
      }
    });
  }

  @Action(RecentAction.DownloadDocument, { cancelUncompleted: true })
  DownloadDocument({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const state = getState();
    const downloadDocument = payload.payload as RecentsModel.DocumentDownload;

    if (!downloadDocument.documentId) {
      return;
    }

    const downloadDocuments = this.getLatestDownloadStatus(downloadDocument.documentId, true, state.downloadDocuments);

    setState({
      ...state,
      downloadDocuments
    });

    const downloadSvc = downloadDocument.isCollaboration
      ? this.lawConnectSvc.downloadCollaborationDocument(downloadDocument.matterId, downloadDocument.documentId, false)
      : this.lawConnectSvc.downloadDocument(downloadDocument.documentId);

    return downloadSvc.pipe(
      switchMap(downloadResponse => this.lawConnectSvc.download(downloadResponse.downloadUrl)),
      map(bl => FileSaver.saveAs(bl, downloadDocument.documentName)),
      map(res => dispatch(new RecentAction.DownloadDocumentSuccess(downloadDocument.documentId))),
      catchError(error => {
        const newState = getState();
        const downloadDocuments = this.getLatestDownloadStatus(
          downloadDocument.documentId,
          false,
          newState.downloadDocuments
        );
        setState({
          ...newState,
          downloadDocuments
        });

        return dispatch(new RecentAction.DownloadDocumentFailure(error));
      })
    );
  }

  private getLatestDownloadStatus(documentId: string, downloadStatus: boolean, current = {}): {} {
    const newDownloadStatus = {};
    newDownloadStatus[documentId] = downloadStatus;

    if (current) {
      Object.keys(current)
        .filter(id => id != documentId)
        .forEach(documentId => {
          newDownloadStatus[documentId] = current[documentId];
        });
    }

    return newDownloadStatus;
  }

  @Action(RecentAction.DownloadDocumentSuccess)
  DownloadDocumentSuccess({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const documentId = payload.payload as string;
    const downloadDocuments = this.getLatestDownloadStatus(documentId, false, state.downloadDocuments);

    setState({
      ...state,
      downloadDocuments
    });
  }

  @Action(RecentAction.DownloadDocumentFailure)
  DownloadDocumentFailure({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const { error, docId } = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);
    const oldDownloadDocumentsState = state.downloadDocuments;
    const newDownloadDocumentsState = {};
    if (oldDownloadDocumentsState) {
      Object.keys(oldDownloadDocumentsState)
        .filter(id => id != docId)
        .forEach(documentId => {
          newDownloadDocumentsState[documentId] = oldDownloadDocumentsState[documentId];
        });
    }

    setState({
      ...state,
      error: err.message,
      downloadDocuments: newDownloadDocumentsState
    });

    if (err && err.status == '403') {
      return dispatch(new RedirectToLogin(`${this.router.url}`));
    }
  }

  @Action(RecentAction.SetViewFromRecent)
  SetViewFromRecent({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const isViewFromRecent = payload.payload as boolean;

    setState({
      ...state,
      viewFromRecent: !!isViewFromRecent
    });
  }

  @Action(RecentAction.ViewDocument)
  ViewDocument({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const document = payload.payload as RecentsModel.RecentDocument;

    if (document.isCollaboration) {
      dispatch(new SetMatterFirmId({ matterId: document.matterId, firmId: document.firmId }));
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${document.matterId}/collaborations/${document.id}${
          document.fileType === 'folder' ? '' : '/preview'
        }`
      });

      return;
    }

    const isRequestedEsignature = !!document.isRequestedEsignature;
    let pageSlot = isRequestedEsignature ? 'signatures' : 'sharedocuments';
    const billingOrTrust = ['trust', 'office'];
    if (!isRequestedEsignature && billingOrTrust.includes(document.fileType)) {
      pageSlot = document.fileType.includes('trust') ? 'trust' : 'billing';
    }

    let signatureDeclined = false;
    if (isRequestedEsignature) {
      const signatures = this.store.selectSnapshot(AppState.getSignatures) || [];
      const signatureDocuments = signatures.map(s => {
        return {
          esignedDocumentStatus: s.esignedDocumentStatus,
          documentIds: s.requestedDocuments.map(d => d.id).toString()
        };
      });
      const signature = signatureDocuments.find(x => x.documentIds.includes(document.id));
      signatureDeclined = !!(
        signature && signature.esignedDocumentStatus == AppSignatureModel.ESignatureDocumentStatus.Declined
      );
    }

    // if not declined, the document may not up to date!!
    if (isRequestedEsignature && !signatureDeclined) {
      const error = { message: 'This document link is no longer valid!' };
      return this.store.dispatch(new RecentAction.ViewDocumentFailure({ error }));
    }

    dispatch(new SetMatterFirmId({ matterId: document.matterId, firmId: document.firmId }));

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${document.matterId}/${pageSlot}/${document.id}/${signatureDeclined ? '' : '/preview'}`
    });
  }

  @Action(RecentAction.SignDocument)
  SignDocument({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const document = payload.payload as RecentsModel.RecentDocument;

    setState({
      ...state,
      documentId: document.id,
      viewFromRecent: true
    });

    let orderId = document.eSignatureOrderId;

    if (!orderId) {
      const signatures = this.store.selectSnapshot(AppState.getSignatures) || [];
      const signatureDocuments = signatures.map(s => {
        return { orderId: s.orderId, documentIds: s.requestedDocuments.map(d => d.id).toString() };
      });

      const orderDocument = signatureDocuments.find(x => x.documentIds.includes(document.id));
      orderId = orderDocument ? orderDocument.orderId : '';
    }

    dispatch(new SetMatterFirmId({ matterId: document.matterId, firmId: document.firmId }));

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${document.matterId}/signatures/${orderId}/sign`
    });
  }

  @Action(RecentAction.DeleteNotificationStart)
  DeleteNotificationStart({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const notificationId = payload.payload as string;

    setState({
      ...state,
      deleteLoading: true,
      error: undefined
    });

    if (notificationId) {
      return this.lawConnectSvc.deleteNotification(notificationId).pipe(
        map(result => dispatch(new RecentAction.DeleteNotificationSuccess({ notificationId, result }))),
        catchError(error => dispatch(new RecentAction.DeleteNotificationFailure(error)))
      );
    }

    return this.lawConnectSvc.deleteAllNotifications().pipe(
      map(result => dispatch(new RecentAction.DeleteNotificationSuccess({ notificationId, result }))),
      catchError(error => dispatch(new RecentAction.DeleteNotificationFailure(error)))
    );
  }

  @Action(RecentAction.DeleteNotificationSuccess)
  DeleteNotificationSuccess({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const { notificationId, result } = payload.payload as { notificationId: string; result: { success: boolean } };

    if (!result.success) {
      return this.store.dispatch(new RecentAction.DeleteNotificationFailure('Fail to delete notification'));
    }

    if (notificationId) {
      const notifications = state.notifications.filter(n =>
        [CoreModel.PubNubNotificationType.appStore, CoreModel.PubNubNotificationType.appStoreRevoke].includes(
          n.notificationType
        ) && n.meta
          ? n.meta.appId !== notificationId
          : n.id !== notificationId
      );

      const briefNotifications =
        notifications && notifications && notifications.length > 0
          ? state.briefNotifications.filter(n => n.id !== notificationId)
          : [];

      setState({
        ...state,
        deleteLoading: false,
        error: undefined,
        notifications,
        briefNotifications
      });

      dispatch([new SetNotificationCount(briefNotifications.length)]);

      return;
    }

    setState({
      ...state,
      deleteLoading: false,
      error: undefined,
      notifications: [],
      briefNotifications: []
    });
    dispatch([new SetNotificationCount(0)]);
  }

  @Action(RecentAction.DeleteNotificationFailure)
  DeleteNotificationFailure({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      deleteLoading: false,
      error: err.message
    });

    if (err && err.status == '403') {
      return dispatch(new RedirectToLogin(`${this.router.url}`));
    }
  }

  @Action(RecentAction.GetNodesStart)
  GetNodesStart({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const preview = payload.payload as CoreModel.SharePreviewInfoId;

    setState({
      ...state,
      nodesLoading: true,
      error: undefined
    });

    const nodes = this.store.selectSnapshot(AppState.getNodes);
    return dispatch(new RecentAction.GetNodesSuccess({ preview, nodes }));
  }

  @Action(RecentAction.GetNodesSuccess)
  GetNodesSuccess({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const { preview, nodes } = payload.payload as {
      preview: CoreModel.SharePreviewInfoId;
      nodes: RecentsModel.LawConnectNode[];
    };

    setState({
      ...state,
      nodesLoading: false,
      error: undefined,
      nodes: nodes
    });

    if (preview && preview.id && !preview.isMatterShared && nodes.find(n => n.id === preview.id)) {
      const document = nodes.find(n => n.id === preview.id);
      const matter = nodes.find(m => m.id == document.parentId);

      dispatch(new SetMatterFirmId({ matterId: matter.id, firmId: matter.parentId }));
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${matter.id}/sharedocuments/${document.id}/preview`
      });
      return;
    }
  }

  @Action(RecentAction.GetNodesFailure)
  GetNodesFailure({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      nodesLoading: false,
      error: err.message
    });

    if (err && err.status == '403') {
      return dispatch(new RedirectToLogin(`${this.router.url}`));
    }
  }

  @Action(RecentAction.GetDocumentsStart, { cancelUncompleted: true })
  GetDocumentsStart({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const firmId = payload.payload as string;
    const siteEnv = this.store.selectSnapshot(AppState.isWhiteLabel);

    setState({
      ...state,
      documentsLoading: true,
      error: undefined
    });

    if (siteEnv && siteEnv.whiteLabel) {
      return this.lawConnectSvc.getDocuments(firmId).pipe(
        map(documents => dispatch(new RecentAction.GetDocumentsSuccess(documents))),
        catchError(error => dispatch(new RecentAction.GetDocumentsFailure(error)))
      );
    }

    return this.lawConnectSvc.getDocuments().pipe(
      map(documents => dispatch(new RecentAction.GetDocumentsSuccess(documents))),
      catchError(error => dispatch(new RecentAction.GetDocumentsFailure(error)))
    );
  }

  @Action(RecentAction.GetDocumentsSuccess)
  GetDocumentsSuccess({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const documents = payload.payload as RecentsModel.RecentDocument[];
    const nodes = this.store.selectSnapshot(AppState.getNodes) || [];
    const empty = [undefined, null, ''];
    const documentsWithEnumType = documents.map(d => {
      let eSignatureStatus =
        d.eSignatureStatus !== undefined && d.eSignatureStatus !== null ? d.eSignatureStatus : undefined;

      if (eSignatureStatus == undefined) {
        const matterSignatures = this.store.selectSnapshot(RecentState.getSelectedMatterSignature);
        const found = matterSignatures.find(m => m.esignedDocumentId && m.esignedDocumentId == d.id);
        if (found) {
          eSignatureStatus = SignatureModel.Helper.ESignatureDocumentStatusToText(found.esignedDocumentStatus);
        }
      }

      const node = nodes.find(n => n.id == d.id);
      return <RecentsModel.RecentDocument>{
        ...d,
        eventType: RecentsModel.Helper.toEventTypeEnum(d.eventType as string),
        eSignatureStatus: RecentsModel.Helper.toESignatureStatusEnum(eSignatureStatus as string),
        isCollaboration: !!(node && node.isCollaborationFile) || d.fileType == 'folder',
        isRequestedEsignature:
          !!(node && node.isRequestedEsignature) || !(empty.findIndex(e => e == eSignatureStatus) !== -1)
      };
    });

    const noDocument = !(documentsWithEnumType && documentsWithEnumType.length > 0);
    setState({
      ...state,
      documentsLoading: false,
      error: undefined,
      documents: documentsWithEnumType,
      noDocument
    });

    if (noDocument) {
      return;
    }

    // set with default document
    const { matterId, firmId } = this.store.selectSnapshot(AppState.getSelectedMatterAndFirmId);
    if (firmId && !matterId) {
      const firstDocument = documentsWithEnumType.find(x => x.firmId == firmId);
      if (firstDocument) {
        this.store.dispatch(new SetMatterId(firstDocument.matterId));
      }
    }
  }

  @Action(RecentAction.GetDocumentsFailure)
  GetDocumentsFailure({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      documentsLoading: false,
      error: err.message
    });

    if (err && err.status == '403') {
      return dispatch(new RedirectToLogin(`${this.router.url}`));
    }
  }

  @Action(RecentAction.GetRecentsStart, { cancelUncompleted: true })
  GetRecentsStart({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const logonUserId = payload.payload as string;

    setState({
      ...state,
      loading: true,
      error: undefined
    });

    const siteEnv = this.store.selectSnapshot(AppState.isWhiteLabel);

    if (siteEnv && siteEnv.whiteLabel) {
      return this.lawConnectSvc.getNotificationsByFirm(siteEnv.firmId).pipe(
        map(notifications => dispatch(new RecentAction.GetRecentsSuccess({ logonUserId, data: notifications }))),
        catchError(error => dispatch(new RecentAction.GetRecentsFailure(error)))
      );
    }

    // Generic LC shows all notifications regardless selected firm.
    return this.lawConnectSvc.getNotifications().pipe(
      map(notifications => dispatch(new RecentAction.GetRecentsSuccess({ logonUserId, data: notifications }))),
      catchError(error => dispatch(new RecentAction.GetRecentsFailure(error)))
    );
  }

  @Action(RecentAction.GetRecentsSuccess)
  GetRecentsSuccess({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const notifications = payload.payload as { logonUserId; data: CoreModel.RecentNotification[] };

    const briefNotifications =
      notifications && notifications.data && notifications.data.length > 0
        ? notifications.data.map(
            n =>
              <RecentsModel.Notification>{
                id:
                  [CoreModel.PubNubNotificationType.appStore, CoreModel.PubNubNotificationType.appStoreRevoke].includes(
                    n.notificationType
                  ) && n.meta
                    ? n.meta.appId
                    : n.id,
                message: RecentsModel.Helper.getNotificationBody(notifications.logonUserId, n),
                eventDate: n.notificationDate,
                staffName: RecentsModel.Helper.getUserFullName(
                  notifications.logonUserId,
                  n.sourceUserId,
                  n.sourceUserFullName
                ),
                documentId: n.documentId,
                matterId: n.matterId,
                notificationType: n.notificationType,
                documentExtension: n.documentExtension,
                meta: n.meta
              }
          )
        : [];

    setState({
      ...state,
      loading: false,
      error: undefined,
      notifications: notifications.data,
      briefNotifications
    });

    dispatch([new SetNotificationCount(briefNotifications.length)]);
  }

  @Action(RecentAction.GetRecentsFailure)
  GetRecentsFailure({ getState, setState, dispatch }: StateContext<RecentsStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      loading: false,
      error: err.message
    });

    if (err && err.status == '403') {
      return dispatch(new RedirectToLogin(`${this.router.url}`));
    }
  }
}
