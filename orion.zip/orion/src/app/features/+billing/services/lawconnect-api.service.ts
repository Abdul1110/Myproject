import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LawConnectApiService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  getBillingAccount(matterId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/billing/${matterId}`;
    return this.http.get(url);
  }

  downloadOfficeStatement(matterId: string, summary: boolean): Observable<any> {
    const url = `${this.endpoint}/api/document/billing/${matterId}/office/statement?summary=${summary}`;
    return this.http.get(url);
  }
}
