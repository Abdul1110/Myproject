import { NgModule } from '@angular/core';
import { InlineSVGModule } from 'ng-inline-svg';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatBottomSheetModule, MatProgressBarModule } from '@angular/material';
import { AppStateModule } from '@app/core/app-state.module';
import {
  GalaxyPreLoaderComponentModule,
  LyraDesignEmptyStateModule,
  LyraDesignPanelModule,
  LyraDesignAvatarModule,
  LyraDesignMenuModule,
  LyraDesignCommonModule,
  LyraDesignIconModule,
  LyraDesignAsideModule,
  LyraDesignMainModule,
  LyraDesignNavbarModule,
  LyraDesignCardModule,
  LyraDesignFilesModule,
  LyraDesignTabsModule,
  LyraDesignTypeModule,
  LyraDesignSectionModule
} from '@leap/lyra-design';
import { BsDropdownModule, CarouselModule } from 'ngx-bootstrap';
import { BillingRoutingModule } from './billing-routing.module';
import { billingLayouts } from './layout';
import { billingPages } from './pages';
import { billingComponents } from './components';
import { billingsServices } from './services';
import { BillingStateModule } from './billing-state.module';

@NgModule({
  imports: [
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule,
    MatBottomSheetModule,
    MatProgressBarModule,
    AppStateModule,
    BillingStateModule,
    BillingRoutingModule,
    GalaxyPreLoaderComponentModule,
    LyraDesignEmptyStateModule,
    LyraDesignPanelModule,
    LyraDesignAvatarModule,
    LyraDesignMenuModule,
    LyraDesignCommonModule,
    LyraDesignIconModule,
    LyraDesignAsideModule,
    LyraDesignMainModule,
    LyraDesignNavbarModule,
    LyraDesignTabsModule,
    LyraDesignCardModule,
    LyraDesignFilesModule,
    LyraDesignTypeModule,
    LyraDesignSectionModule,
    BsDropdownModule.forRoot(),
    CarouselModule.forRoot()
  ],
  entryComponents: [...billingLayouts, ...billingPages, ...billingComponents],
  declarations: [...billingLayouts, ...billingPages, ...billingComponents],
  providers: [...billingsServices]
})
export class BillingModule {}
