import { BillingModel } from '../../models/billing.model';

export namespace BillingAction {
  const prefix = '[Billing]';

  export const ActionTypes = {
    GET_BILLING_ACCOUNT: `${prefix} get billing account`,
    GET_BILLING_ACCOUNT_SUCCESS: `${prefix} get billing account success`,
    GET_BILLING_ACCOUNT_FAILURE: `${prefix} Failed to get billing account`,
    CANCEL_GET_BILLING_ACCOUNT: `${prefix} cancel the get billing account`,
    SET_STATEMENT_FILTER: `${prefix} set statement filter`,
    DOWNLOAD_BILLING_ACCOUNT: `${prefix} download billing account statement`,
    DOWNLOAD_BILLING_ACCOUNT_FAILURE: `${prefix} Failed to download statement of account`
  };

  export class SetStatementFilter {
    static readonly type = ActionTypes.SET_STATEMENT_FILTER;
    constructor(public payload: string) {} //filter title.
  }

  export class GetBillingAccount {
    static readonly type = ActionTypes.GET_BILLING_ACCOUNT;
    constructor(public payload: string) {} //matterId
  }

  export class GetBillingAccountSuccess {
    static readonly type = ActionTypes.GET_BILLING_ACCOUNT_SUCCESS;
    constructor(public payload: BillingModel.BillingAccount) {}
  }

  export class GetBillingAccountFailure {
    static readonly type = ActionTypes.GET_BILLING_ACCOUNT_FAILURE;
    constructor(public payload: any) {}
  }

  export class CancelGetBillingAccount {
    static readonly type = ActionTypes.CANCEL_GET_BILLING_ACCOUNT;
    constructor(public payload: any) {}
  }

  export class DonwloadBillingAccount {
    static readonly type = ActionTypes.DOWNLOAD_BILLING_ACCOUNT;
    constructor(public payload: { matterId: string; summary: boolean }) {}
  }

  export class DonwloadBillingAccountFailure {
    static readonly type = ActionTypes.DOWNLOAD_BILLING_ACCOUNT_FAILURE;
    constructor(public payload: any) {} //matterId
  }
}
