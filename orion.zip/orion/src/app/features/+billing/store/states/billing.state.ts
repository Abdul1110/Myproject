import { State, Action, StateContext, Selector, ofAction, Actions } from '@ngxs/store';
import { switchMap, catchError, takeUntil } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';

import { environment } from '@env/environment';
import { BillingAction } from '../actions';
import { LawConnectApiService } from '../../services';
import { BillingModel } from '../../models/billing.model';
import { AccountStatementModel } from '../../models/account-statement.model';

export interface BillingStateModel {
  error: string;
  loading: boolean;
  statementFilterBy: string;
  data: {
    officeInfo: AccountStatementModel.Info;
  };
}

@State<BillingStateModel>({
  name: 'billing',
  defaults: {
    statementFilterBy: environment.locale.billing.statement_of_account.filter.summary,
    error: undefined,
    loading: false,
    data: undefined
  }
})
export class BillingState {
  @Action(BillingAction.GetBillingAccount, { cancelUncompleted: true })
  GetBillingAccount({ getState, setState, dispatch }: StateContext<BillingStateModel>, payload) {
    const matterId = payload.payload as string;

    const billing$ = this.lcApiSvc
      .getBillingAccount(matterId)
      .pipe(takeUntil(this.actions$.pipe(ofAction(BillingAction.CancelGetBillingAccount))));

    setState({
      ...getState(),
      loading: true,
      error: undefined
    });

    return billing$.pipe(
      switchMap((response: any) => dispatch(new BillingAction.GetBillingAccountSuccess(response))),
      catchError(error => dispatch(new BillingAction.GetBillingAccountFailure(error)))
    );
  }

  @Action(BillingAction.GetBillingAccountSuccess)
  GetBillingAccountSuccess({ getState, setState, dispatch }: StateContext<BillingStateModel>, payload) {
    const data = payload.payload as BillingModel.BillingAccount;

    if (!data || !data.success) {
      return dispatch(new BillingAction.GetBillingAccountFailure(data.errorMessage));
    }

    setState({
      ...getState(),
      loading: false,
      data: data.data,
      error: undefined
    });
  }

  @Action(BillingAction.GetBillingAccountFailure)
  GetBillingAccountFailure({ getState, setState, dispatch }: StateContext<BillingStateModel>, payload) {
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);
    setState({
      ...getState(),
      loading: false,
      error: err.message,
      data: undefined
    });
  }

  @Action(BillingAction.SetStatementFilter)
  SetStatementFilter({ getState, setState, dispatch }: StateContext<BillingStateModel>, payload) {
    const filterBy = payload.payload as string;

    setState({
      ...getState(),
      statementFilterBy: filterBy
    });
  }

  @Action(BillingAction.DonwloadBillingAccount, { cancelUncompleted: true })
  DonwloadBillingAccount({ getState, setState, dispatch }: StateContext<BillingStateModel>, payload) {
    const { matterId, summary } = payload.payload as { matterId: string; summary: boolean };

    return this.lcApiSvc.downloadOfficeStatement(matterId, summary).pipe(
      switchMap((response: any) => {
        const { downloadUrl } = response;
        if (downloadUrl && this.browserSvc.isBrowser) {
          const browserWindow = this.browserSvc.window.open(downloadUrl, '_blank');
          if (!browserWindow || browserWindow.closed || typeof browserWindow.closed === 'undefined') {
            return dispatch(new BillingAction.DonwloadBillingAccountFailure('Please allow Pop up open from the site.'));
          }
        }
        return [];
      }),
      catchError(error => dispatch(new BillingAction.DonwloadBillingAccountFailure(error)))
    );
  }

  @Selector()
  static getStatementFilterBy(state: BillingStateModel): string {
    if (!state) {
      return environment.locale.billing.statement_of_account.filter.summary;
    }

    return state.statementFilterBy;
  }

  @Selector()
  static getError(state: BillingStateModel): string {
    if (!state) {
      return '';
    }

    return state.error;
  }

  @Selector()
  static getLoading(state: BillingStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.loading;
  }

  @Selector()
  static getOfficeAccount(state: BillingStateModel): AccountStatementModel.Info {
    if (!state) {
      return undefined;
    }

    return state.data.officeInfo;
  }

  constructor(private lcApiSvc: LawConnectApiService, private browserSvc: BrowserService, private actions$: Actions) {}
}
