import { NgModule } from '@angular/core';
import { NgxsModule } from '@ngxs/store';
import { BillingStates } from './store';

@NgModule({
  declarations: [],
  imports: [NgxsModule.forFeature([...BillingStates])]
})
export class BillingStateModule {}
