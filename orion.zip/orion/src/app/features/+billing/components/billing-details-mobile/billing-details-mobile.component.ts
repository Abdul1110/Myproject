import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'sc-billing-details-mobile',
  templateUrl: './billing-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BillingDetailsMobileComponent {
  @Input('data') data: any;

  constructor() {}
}
