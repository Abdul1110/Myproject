import { ChangeDetectionStrategy, Component, Input, HostBinding, Inject, LOCALE_ID } from '@angular/core';
import { UUID } from 'angular2-uuid';

import { AccountStatementModel } from '../../models/account-statement.model';
import { BILLING_ACCOUNT_MAKE_PAYMENT, CustomEventService } from '@app/core/services';
import { BillingModel } from '../../models/billing.model';

@Component({
  selector: 'sc-account-statement-item-mobile',
  templateUrl: './account-statement-item-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementItemMobileComponent {
  @Input('item-id') id: number;
  @Input('item') item: AccountStatementModel.StatementListItem;
  @Input('active') isActive: boolean;
  @Input('is-last') isLast: boolean;

  @HostBinding('class.pb-4') last = this.isLast;

  source = BillingModel.ActionType.StatementDetails;
  componentId = `${UUID.UUID()}`;

  localeCurrency(amount: number): string {
    return amount == 0 ? '-' : AccountStatementModel.Helper.localeCurrency(amount, this.locale);
  }

  localDateFormat(dt: Date): string {
    return AccountStatementModel.Helper.localeFormat(dt, this.locale);
  }

  handlePay(paymentUrl: string): void {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MAKE_PAYMENT, { paymentUrl });
  }

  prefixWithInv(invNo: string): string {
    return BillingModel.Helper.prefixWithInv(invNo);
  }

  constructor(@Inject(LOCALE_ID) private locale: string, private customEventSvc: CustomEventService) {}
}
