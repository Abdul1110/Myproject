import { ChangeDetectionStrategy, Component, Input, LOCALE_ID, Inject } from '@angular/core';
import { BillingModel } from '../../models/billing.model';
@Component({
  selector: 'sc-statement-item-total',
  templateUrl: './statement-item-total.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StatementItemTotalComponent {
  @Input('item-id') id: number;
  @Input('item') item: number;

  constructor(@Inject(LOCALE_ID) private locale: string) {}

  localeCurrency(amount: number): string {
    return BillingModel.Helper.localeCurrency(amount, this.locale);
  }

  getTransactionValue(transaction): any {
    return transaction >= 1 ? '+' + transaction : transaction;
  }
}
