import { Component, ChangeDetectionStrategy, Input, Inject, LOCALE_ID, HostBinding } from '@angular/core';
import { formatCurrency } from '@angular/common';
import { environment } from '@env/environment';

@Component({
  selector: 'sc-account-balance-indicator',
  templateUrl: './account-balance-indicator.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [
    `
      ::ng-deep .mat-progress-bar-fill::after {
        background-color: var(--custom-theme-primary, #0e5fe3);
        height: 1rem;
      }

      ::ng-deep .mat-progress-bar-buffer {
        background: #e4e8eb;
        height: 1rem;
      }
      ::ng-deep .mat-progress-bar {
        border-radius: 4px;
        margin-top: 1rem;
        height: 1rem !important;
      }
    `
  ]
})
export class AccountBalanceIndicatorComponent {
  @Input('total-in') totalIn: number = 0;
  @Input('total-out') totalOut: number = 0;
  @Input('in-desc') inDesc: string;
  @Input('out-desc') outDesc: string;
  @Input('reverse') reverse: boolean;

  @HostBinding('class.w-100') fullWidth = true;
  get difference(): number {
    if (this.reverse) {
      return this.getReverseValue();
    }

    if (this.totalIn > this.totalOut) {
      return 100;
    }

    if (this.totalOut >= this.totalIn && this.totalIn > 0 && this.totalOut > 0) {
      return (this.totalIn / this.totalOut) * 100.0;
    }

    return 0;
  }

  getReverseValue(): number {
    if (this.totalOut > this.totalIn) {
      return 0;
    }

    if (this.totalIn >= this.totalOut && this.totalIn > 0 && this.totalOut > 0) {
      return ((this.totalIn - this.totalOut) / this.totalIn) * 100.0;
    }

    return 100;
  }

  localeCurrency(amount: number): string {
    const { currency } = environment.locale.global;
    return formatCurrency(amount, this.locale, currency.symbol);
  }

  constructor(@Inject(LOCALE_ID) private locale: string) {}
}
