import { ChangeDetectionStrategy, Component, Input, Inject, LOCALE_ID } from '@angular/core';
import { BillingModel } from '../../models/billing.model';

@Component({
  selector: 'sc-statement-details-mobile',
  templateUrl: './statement-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class StatementDetailsMobileComponent {
  @Input('data') data: any;

  prefixWithInv(invNo: string): string {
    return BillingModel.Helper.prefixWithInv(invNo);
  }

  localDateFormat(dt: Date): string {
    return BillingModel.Helper.localeDate(dt, this.locale);
  }

  localCurrencyFormat(v: number): string {
    return v == 0 ? '-' : BillingModel.Helper.localeCurrency(v, this.locale);
  }

  constructor(@Inject(LOCALE_ID) private locale: string) {}
}
