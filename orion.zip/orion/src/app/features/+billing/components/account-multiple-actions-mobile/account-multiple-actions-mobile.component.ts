import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
// import { MatBottomSheet } from '@angular/material';

// import { AccountMultipleActionsOptionMobileComponent } from '../account-multiple-actions-option-mobile/account-multiple-actions-option-mobile.component';
import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { BillingModel } from '../../models/billing.model';

@Component({
  selector: 'sc-account-multiple-actions-mobile',
  templateUrl: './account-multiple-actions-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountMultipleActionsMobileComponent {
  @Input('data') data: any;
  @Input('display-for') displayFor: string;

  constructor(private customEventSvc: CustomEventService) {} //private bottomSheet: MatBottomSheet,

  prefixWithInv(invNo: string): string {
    return BillingModel.Helper.prefixWithInv(invNo);
  }

  onActionClick() {
    // noted: at this stage, if we have more than on option, then can turn on below code to have another selection step.
    // this.bottomSheet.open(AccountMultipleActionsOptionMobileComponent, {
    //   panelClass: 'x-bottom-sheet',
    //   data: { ...this.data, displayFor: this.displayFor }
    // });

    if (this.data) {
      const subTitle = this.prefixWithInv(this.data.invoiceNo) || this.data.transactionNo;
      this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
        actionType: BillingModel.ActionType.StatementEntryDetail,
        value: {
          title: 'Transaction Details',
          subTitle,
          displayFor: this.displayFor,
          ...this.data
        }
      });
    }
  }
}
