import { Component, ChangeDetectionStrategy, Input, Inject, LOCALE_ID, ViewChild } from '@angular/core';
import Chart from 'chart.js';
import { Store } from '@ngxs/store';

import { AccountStatementModel } from '../../models/account-statement.model';
import { AppState } from '@app/core/store/states';

@Component({
  selector: 'sc-account-statement-ageing-graph-card',
  templateUrl: './account-statement-ageing-graph-card.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementAgeingGraphCardComponent {
  hasData = false;
  primaryColor: string;
  @Input('as-of') asOf: Date;
  @Input('data')
  set data(d: AccountStatementModel.AgeingPeriod[]) {
    this.hasData = d && d.length > 0;
    this.hasData &&
      setTimeout(() => {
        this.chartData(this.chartSetup(), d, this.locale);
      }, 0);
  }

  @ViewChild('chartRef', { static: false }) myChartRef: any;

  localeFormat(dt: Date): string {
    return AccountStatementModel.Helper.localeFormat(dt, this.locale);
  }

  constructor(private store: Store, @Inject(LOCALE_ID) private locale: string) {
    const primary = this.store.selectSnapshot(AppState.getAppTheme);
    this.primaryColor = primary.primaryColor ? primary.primaryColor : '#0E5FE3';
  }

  private chartSetup(): any {
    const ctx = this.myChartRef.nativeElement.getContext('2d');

    Chart.helpers.drawRoundedTopRectangle = function(ctx, x, y, width, height, radius) {
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + width - radius, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
      ctx.lineTo(x + width, y + height);
      ctx.lineTo(x, y + height);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    };
    Chart.elements.RoundedTopRectangle = Chart.elements.Rectangle.extend({
      draw: function() {
        const ctx = this._chart.ctx;
        const vm = this._view;
        let left, right, top, bottom, signX, signY, borderSkipped;
        const borderWidth = vm.borderWidth;

        if (!vm.horizontal) {
          // bar
          left = vm.x - vm.width / 2;
          right = vm.x + vm.width / 2;
          top = vm.y;
          bottom = vm.base;
          signX = 1;
          signY = bottom > top ? 1 : -1;
          borderSkipped = vm.borderSkipped || 'bottom';
        } else {
          // horizontal bar
          left = vm.base;
          right = vm.x;
          top = vm.y - vm.height / 2;
          bottom = vm.y + vm.height / 2;
          signX = right > left ? 1 : -1;
          signY = 1;
          borderSkipped = vm.borderSkipped || 'left';
        }

        // calculate the bar width and roundess
        const barWidth = Math.abs(left - right);
        const roundness = this._chart.config.options.barRoundness || 0.25;
        const radius = barWidth * roundness * 0.25;

        // keep track of the original top of the bar
        const prevTop = top;

        // move the top down so there is room to draw the rounded top
        top = prevTop + radius;
        const barRadius = top - prevTop;

        ctx.beginPath();
        ctx.fillStyle = vm.backgroundColor;
        ctx.strokeStyle = vm.borderColor;
        ctx.lineWidth = borderWidth;

        // draw the rounded top rectangle
        Chart.helpers.drawRoundedTopRectangle(ctx, left, top - barRadius + 1, barWidth, bottom - prevTop, barRadius);
        ctx.fill();
        top = prevTop;
      }
    });
    Chart.defaults.roundedBar = Chart.helpers.clone(Chart.defaults.bar);
    Chart.controllers.roundedBar = Chart.controllers.bar.extend({
      dataElementType: Chart.elements.RoundedTopRectangle
    });

    return ctx;
  }

  private chartData(ctx: any, data: AccountStatementModel.AgeingPeriod[], locale: any): void {
    const labels = data.map(d => `${d.period} ${d.period > 1 ? 'days' : 'day'}`);
    const values = data.map(d => d.balance);
    const maxChecked = values && values.length > 0 ? [].concat(values) : [0];
    const maxValues = Math.ceil(Math.max(...maxChecked)) + 150;
    const myBarChart = new Chart(ctx, {
      type: 'roundedBar',
      data: {
        labels,
        datasets: [
          {
            data: values,
            borderColor: '#3cb371',
            backgroundColor: [this.primaryColor, this.primaryColor, this.primaryColor, this.primaryColor]
          }
        ]
      },
      options: {
        legend: {
          display: false
        },
        tooltips: {
          enabled: false
        },
        hover: {
          animationDuration: 0
        },
        events: [],
        animation: {
          onComplete: function() {
            myBarChart.data.datasets.forEach(function(dataset, i) {
              const meta = myBarChart.controller.getDatasetMeta(i);
              meta.data.forEach(function(bar, index) {
                const data = dataset.data[index];
                myBarChart.ctx.font = '12px "Heebo", "Helvetica Neue", Helvetica, Arial, sans-serif';
                (myBarChart.ctx.fillStyle = '#6D7278'),
                  myBarChart.ctx.fillText(
                    AccountStatementModel.Helper.localeCurrency(data, locale),
                    bar._model.x - 15,
                    bar._model.y - 5
                  );
              });
            });
          }
        },
        scales: {
          xAxes: [
            {
              display: true,
              gridLines: {
                display: false
              }
            }
          ],
          yAxes: [
            {
              display: false,
              ticks: {
                // Include a dollar sign in the ticks
                callback: function(value, index, values) {
                  return `${AccountStatementModel.Helper.localeCurrency(value, locale)}`;
                },
                beginAtZero: true,
                stepSize: 10,
                max: maxValues
              }
            }
          ]
        }
      }
    });
  }
}
