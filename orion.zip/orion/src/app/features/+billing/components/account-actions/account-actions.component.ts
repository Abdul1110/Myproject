import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { BillingModel } from '../../models/billing.model';

@Component({
  selector: 'sc-account-actions',
  templateUrl: './account-actions.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountActionsComponent {
  @Input('has-statement') hasStatement: boolean;

  statementPayInFull = BillingModel.ActionType.StatementPayInFull;
  statementDownload = BillingModel.ActionType.StatementDownload;

  constructor(private customEventSvc: CustomEventService) {}

  onActionClick(actionType: string) {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
      actionType,
      value: {}
    });
  }
}
