import { ChangeDetectionStrategy, Component, HostBinding, Inject } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';

import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { BillingModel } from '../../models/billing.model';

@Component({
  selector: 'sc-account-multiple-actions-option-mobile',
  templateUrl: './account-multiple-actions-option-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountMultipleActionsOptionMobileComponent {
  viewStatementEntryDetail = BillingModel.ActionType.StatementEntryDetail;
  viewStatementDetail = BillingModel.ActionType.StatementDetails;

  statementDetailActions = [this.viewStatementDetail];

  titles = {
    [this.viewStatementEntryDetail]: { title: 'Transaction Details', icon: 'creditcard' },
    [this.viewStatementDetail]: { title: `Statement Details`, icon: 'creditcard' }
  };

  constructor(
    private customEventSvc: CustomEventService,
    private bottomSheetRef: MatBottomSheetRef<AccountMultipleActionsOptionMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {}

  @HostBinding('class.x-action-list')
  keys(): string[] {
    if (!this.data || !this.titles[this.data.displayFor]) {
      return [];
    }

    if (this.statementDetailActions.includes(this.data.displayFor)) {
      return this.statementDetailActions;
    }

    return [];
  }

  onActionClick(actionType: string) {
    let subTitle = '';

    if (this.data) {
      if (actionType == this.viewStatementEntryDetail) subTitle = this.data.invoiceNo || this.data.transactionNo;
    }

    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
      actionType,
      value: {
        title: this.titles[actionType].title,
        subTitle,
        ...this.data
      }
    });
  }

  onClose() {
    this.bottomSheetRef.dismiss();
  }
}
