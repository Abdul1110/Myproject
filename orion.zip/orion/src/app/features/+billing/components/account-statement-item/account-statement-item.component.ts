import {
  ChangeDetectionStrategy,
  Component,
  Input,
  HostBinding,
  EventEmitter,
  Output,
  Inject,
  LOCALE_ID
} from '@angular/core';
import { UUID } from 'angular2-uuid';

import { AccountStatementModel } from '../../models/account-statement.model';
import { CustomEventService, BILLING_ACCOUNT_MAKE_PAYMENT } from '@app/core/services';
import { BillingModel } from '../../models/billing.model';

@Component({
  selector: 'sc-account-statement-item',
  templateUrl: './account-statement-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementItemComponent {
  @Input('item-id') id: number;
  @Input('item') item: AccountStatementModel.StatementListItem;
  @Input('active') isActive: boolean;
  @Input('is-paid') isPaid: boolean;
  @Input('is-odd') isOdd: boolean;
  @Input('is-even') isEven: boolean;
  @Input('is-checked')
  set isChecked(v: boolean) {
    this.checked = v;
  }
  @Input('is-last') isLast: boolean;
  @Output('check-onchange') checkOnChange = new EventEmitter<{ idx: number; checked: boolean }>();

  @HostBinding('class.pb-4') last = this.isLast;

  checked = false;
  componentId = `${UUID.UUID()}`;

  onChecked(e: any) {
    this.checkOnChange.emit({ idx: this.id, checked: this.checked });
  }

  localeCurrency(amount: number): string {
    return amount == 0 ? '-' : AccountStatementModel.Helper.localeCurrency(amount, this.locale);
  }

  handlePay(paymentUrl: string): void {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MAKE_PAYMENT, { paymentUrl });
  }

  handleDownload(item: AccountStatementModel.StatementListItem): void {}

  prefixWithInv(invNo: string): string {
    return BillingModel.Helper.prefixWithInv(invNo);
  }

  constructor(@Inject(LOCALE_ID) private locale: string, private customEventSvc: CustomEventService) {}
}
