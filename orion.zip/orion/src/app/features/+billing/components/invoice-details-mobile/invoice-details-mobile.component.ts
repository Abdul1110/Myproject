import { ChangeDetectionStrategy, Component, Input, Inject, LOCALE_ID } from '@angular/core';

import { AccountStatementModel } from '../../models/account-statement.model';

@Component({
  selector: 'sc-invoice-details-mobile',
  templateUrl: './invoice-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InvoiceDetailsMobileComponent {
  @Input('data') data: any;

  localeDate(dt: Date): string {
    return AccountStatementModel.Helper.localeFormat(dt, this.locale);
  }

  localeCurrency(amount: number): string {
    return AccountStatementModel.Helper.localeCurrency(amount, this.locale);
  }

  constructor(@Inject(LOCALE_ID) private locale: string) {}
}
