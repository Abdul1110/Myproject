import { Component, ChangeDetectionStrategy, Input } from '@angular/core';

@Component({
  selector: 'sc-account-statement-payment-status',
  templateUrl: './account-statement-payment-status.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementPaymentStatusComponent {
  @Input('status-title') title: string;
  @Input('status-desc') description: string;
}
