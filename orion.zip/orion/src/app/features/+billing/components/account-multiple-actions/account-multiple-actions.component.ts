import { ChangeDetectionStrategy, Component, Input, HostBinding } from '@angular/core';
import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { BillingModel } from '../../models/billing.model';
import { environment } from '@env/environment';

@Component({
  selector: 'sc-account-multiple-actions',
  templateUrl: './account-multiple-actions.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountMultipleActionsComponent {
  @Input('small-screen') isSmallScreen: boolean;

  viewStatementSummary = BillingModel.ActionType.ViewStatementSummary;
  viewStatementDetail = BillingModel.ActionType.ViewStatementDetail;

  constructor(private customEventSvc: CustomEventService) {}

  onActionClick(actionType: string) {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
      actionType,
      value: {}
    });
  }
}
