import { ChangeDetectionStrategy, Component, Input, HostBinding } from '@angular/core';
import { CustomEventService, BILLING_ACCOUNT_CHECKLIST } from '@app/core/services';

@Component({
  selector: 'sc-account-statement-header',
  templateUrl: './account-statement-header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementHeaderComponent {
  @Input('is-summary')
  set isSummary(b: boolean) {
    this.dateLabel = b ? 'Inv. Date' : 'Trans. Date';
    this.descLabel = b ? 'Inv. No. & Description' : 'Trans. No. & Description';
  }

  checked = false;
  dateLabel = 'Inv. Date';
  descLabel = 'Inv. No. & Description';

  constructor(private customEventSvc: CustomEventService) {}

  onChange(e: any) {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_CHECKLIST, { all: this.checked });
  }
}
