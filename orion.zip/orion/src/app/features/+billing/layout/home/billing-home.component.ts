import { Component, HostBinding, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { MatBottomSheet } from '@angular/material';
import { ActivatedRoute } from '@angular/router';

import { SetNavigationActionId, SetMatterFirmId, GetNotification } from '@app/core/store/actions';
import { CoreModel } from '@app/core/models';
import { environment } from '@env/environment';
import {
  CustomEventService,
  BILLING_ACCOUNT_SIDE_DISPLAY,
  CustomEventModel,
  BILLING_VIEW_DETAILS_DISPLAY,
  BILLING_ACCOUNT_MULTIPLE_ACTIONS,
  NAVIGATION_SIDE_BAR_TOGGLE,
  COLLABORATIONS_SIDE_TAB_TOGGLE,
  MATTERS_SELECT_CLOSED,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED
} from '@app/core/services';
import { AccountStatementModel } from '../../models/account-statement.model';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { BillingModel } from '../../models/billing.model';
import { BillingViewDetailsMobileComponent } from '../../pages';
import { BillingAction, BillingState } from '../../store';
import { AppState } from '@app/core/store/states';
import { SideNavigationModel } from '@app/shared/models';
import { AccountMultipleActionsOptionMobileComponent } from '../../components';
import { xAnimationAsideCollapse } from '@app/shared/components/animation/animation';

const { locale } = environment;
const billingIcon = locale.global.menu.billing.icon;

@Component({
  selector: 'sc-billing-home',
  templateUrl: './billing-home.component.html',
  animations: [xAnimationAsideCollapse]
})
export class BillingHomeComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  pageSlot = '';
  matterId = '';
  matterName = '';
  selectedFilter: BillingModel.FilterOption = null;
  selectedFilterTitle = '';
  filterOptions: BillingModel.FilterOption[] = [];
  isSmallScreen = false;
  showMobileDetails = false;
  asideDetails: boolean;
  currentStatementFilter: BillingModel.FilterOption = null;
  firm: CoreModel.FirmDetail = null;
  hasStatement = false;
  hasStatementPayInFullUrlProvided = false;

  documentTitle(): string {
    return 'Billing & Statements';
  }

  toggleAside(): void {
    this.asideDetails = !this.asideDetails;
  }

  isSelected(item: any): boolean {
    return this.selectedFilter && item.title == this.selectedFilter.title;
  }

  changeFilter(newFilter: BillingModel.FilterOption): void {
    const current = { ...newFilter };

    // update the value in seperate task to avoid ux render issue.
    this.updateFilter(current, current.title);

    this.currentStatementFilter = current;
    this.store.dispatch(new BillingAction.SetStatementFilter(current.title));
  }

  showMobileViewDetails(isSmallScreen: boolean, viewDetails: boolean): boolean {
    if (!isSmallScreen) {
      return false;
    }

    return viewDetails;
  }

  openGlobalActionSheet(): void {
    this.bottomSheet.open(AccountMultipleActionsOptionMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { displayHeader: true, displayFor: BillingModel.ActionType.StatementDetails }
    });
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  getMatterName(): string {
    return this.matterName;
  }

  getNavbarIcon(): string {
    return billingIcon;
  }

  getFirmName(): string {
    return (this.firm && this.firm.name) || locale.matters.title;
  }

  constructor(
    private store: Store,
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService,
    private bottomSheet: MatBottomSheet,
    private route: ActivatedRoute,
    private actions: Actions
  ) {
    this.updateFromPathParams();
    this.updateMatterName(this.matterId);
    this.updateGlobalFirmAndMatterId(this.matterId);
    this.triggerRecentNotificationDataPulledIfCountZero();
    this.updateDefaultStatementOfAccountFilterBy();

    merge(
      this.listenToOfficeSideDetailDisplaySideEffect$(),
      this.listenToMobileSideDetailDisplaySideEffect$(),
      this.listenToMobileMultiActionSideEffect$(),
      this.listenToSmallScreenSideEffect$(),
      this.getFirmDetailsSideEffect$(),
      this.listenToRemoteSideDetailToggleRequestSideEffect$(),
      this.listenToMatterSelectedFromOptions$(),
      this.listenToGetBillingAccountSuccessSideEffect$(),
      this.listenToGetBillingAccountFailureSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.store.dispatch(new SetNavigationActionId(SideNavigationModel.SideActionId.billing));
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, {
      actionId: SideNavigationModel.SideActionId.billing
    });
  }

  @HostBinding('class.lt-container')
  @HostBinding('class.bg-light-secondary')
  ngOnDestroy() {
    this.destroy$.next(true);
    this.store.dispatch(new BillingAction.CancelGetBillingAccount(undefined));
  }

  private listenToGetBillingAccountFailureSideEffect$(): Observable<any> {
    return this.actions.pipe(
      ofActionSuccessful(BillingAction.GetBillingAccountFailure),
      tap(payload => {
        if (payload && payload.payload) {
          this.hasStatement = false;
          this.hasStatementPayInFullUrlProvided = false;
        }
      })
    );
  }

  private listenToGetBillingAccountSuccessSideEffect$(): Observable<any> {
    return this.actions.pipe(
      ofActionSuccessful(BillingAction.GetBillingAccountSuccess),
      tap(payload => {
        const data = payload.payload as BillingModel.BillingAccount;
        const success = data.success;
        if (!success) {
          this.hasStatement = false;
          this.hasStatementPayInFullUrlProvided = false;
          return;
        }

        // statement of account
        const statement = data && data.data && data.data.officeInfo;
        this.hasStatementPayInFullUrlProvided = false;
        this.hasStatement = false;

        if (statement) {
          const { officeStatement } = statement;
          this.hasStatementPayInFullUrlProvided = !!(officeStatement && officeStatement.paymentUrl);
          this.hasStatement = officeStatement && officeStatement.invoiceItems.length > 0;
        }
      })
    );
  }

  private updateDefaultStatementOfAccountFilterBy(): void {
    const filterTitle = this.store.selectSnapshot(BillingState.getStatementFilterBy) || null;
    const allFilters = AccountStatementModel.Helper.accountOfStatementFilterOptions();
    const filter = allFilters.find(x => x.title == filterTitle);
    this.currentStatementFilter = filter;
  }

  private triggerRecentNotificationDataPulledIfCountZero(): void {
    const user = this.store.selectSnapshot(AppState.getLoginUser);
    const notificationCount = this.store.selectSnapshot(AppState.getNotificationCount) || 0;
    user && user.userId && notificationCount == 0 && this.store.dispatch(new GetNotification(user.userId));
  }

  private updateGlobalFirmAndMatterId(currentMatterId: string): void {
    const matterAndFirm = this.store.selectSnapshot(AppState.getSelectedMatterAndFirmId);
    const { matterId, firmId } = matterAndFirm || { matterId: '', firmId: '' };
    if (matterId != currentMatterId) {
      const documents = this.store.selectSnapshot(AppState.getNodes) || [];
      const matter = currentMatterId && documents.length > 0 && documents.find(x => x.id == currentMatterId);
      const firmId = matter && matter.parentId;
      firmId && currentMatterId && this.store.dispatch(new SetMatterFirmId({ matterId: currentMatterId, firmId }));
    }
  }

  private updateFilter(filter: BillingModel.FilterOption, title: string): void {
    //update the value in seperate task to avoid ux render issue.
    setTimeout(() => {
      this.selectedFilter = filter;
      this.selectedFilterTitle = title;
    }, 0);
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      this.updateFromPathParams(matterId);
      this.updateMatterName(this.matterId);

      // this.toAccount();
    });
  }

  private updateFromPathParams(matterId: string = undefined): void {
    this.matterId = matterId || (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';
    this.matterId && this.store.dispatch(new BillingAction.GetBillingAccount(this.matterId));
  }

  private listenToRemoteSideDetailToggleRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_SIDE_TAB_TOGGLE, ({ show }) => {
      if (show !== undefined) {
        this.asideDetails = show;
        return;
      }
    });
  }

  private updateMatterName(matterId: string): void {
    const matterDetail = CoreModel.Helper.getMatterDetail(
      matterId,
      this.store.selectSnapshot(AppState.getMattersByFirm)
    );

    this.matterName = (matterDetail && matterDetail.name) || '';
  }

  private getFirmDetailsSideEffect$(): Observable<any> {
    return this.appActionSvc.selectedFirm$.pipe(tap(x => (this.firm = x)));
  }

  private listenToSmallScreenSideEffect$(): Observable<boolean> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(v => {
        this.isSmallScreen = v;
      })
    );
  }

  private listenToOfficeSideDetailDisplaySideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_ACCOUNT_SIDE_DISPLAY,
      (data: CustomEventModel.BillingAccountSideDisplayEventDetail) => {
        if (data.show !== undefined) {
          this.filterOptions = AccountStatementModel.Helper.accountOfStatementFilterOptions();

          const current = this.currentStatementFilter || this.filterOptions[0];
          this.updateFilter(current, current.title);
        }
      }
    );
  }

  private listenToMobileSideDetailDisplaySideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_VIEW_DETAILS_DISPLAY,
      (data: CustomEventModel.BillingViewDetailsDisplayEventDetail) => {
        if (data.show !== undefined) {
          this.showMobileDetails = data.show;
          return;
        }
      }
    );
  }

  private listenToMobileMultiActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_ACCOUNT_MULTIPLE_ACTIONS,
      (data: CustomEventModel.BillingAccountMultipleActionEventDetail) => {
        if (data.actionType !== undefined && data.actionType) {
          if (
            data.actionType == BillingModel.ActionType.StatementPayInFull ||
            data.actionType == BillingModel.ActionType.NewTrustPayment
          ) {
            return;
          }

          if (data.actionType == BillingModel.ActionType.ViewStatementSummary) {
            this.changeFilter(this.filterOptions[0]);
            return;
          }

          if (data.actionType == BillingModel.ActionType.ViewStatementDetail) {
            this.changeFilter(this.filterOptions[1]);
            return;
          }

          if (data.actionType == BillingModel.ActionType.StatementDownload) {
            this.store.dispatch(
              new BillingAction.DonwloadBillingAccount({
                matterId: this.matterId,
                summary:
                  this.selectedFilter == null
                    ? true
                    : this.selectedFilter && this.selectedFilter.title == this.filterOptions[0].title
              })
            );
            return;
          }

          this.bottomSheet.open(BillingViewDetailsMobileComponent, {
            panelClass: 'x-bottom-sheet',
            data: { ...data.value, actionType: data.actionType }
          });
          return;
        }
      }
    );
  }
}
