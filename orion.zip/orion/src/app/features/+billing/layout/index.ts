import { BillingHomeComponent } from './home/billing-home.component';

export * from './home/billing-home.component';

export const billingLayouts = [BillingHomeComponent];
