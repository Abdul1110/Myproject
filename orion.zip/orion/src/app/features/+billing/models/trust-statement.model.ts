import { BillingModel } from './billing.model';
import { environment } from '@env/environment';

export namespace TrustStatementModel {
  export interface StatementListItem {
    entryDate: Date;
    transactionNo: string;
    description: string;
    paymentType: string;
    transaction: number;
    trustAccount: string;
  }

  export interface TrustAccountItem {
    bank: string;
    account: string;
    bsb: string;
    accountNo: string;
    balance: number;
  }

  export interface LedgerItem {
    abSeqNo: number;
    balance: number;
    deposit: number;
    entryDate: Date;
    paymentUrl: string;
    transactionDate: Date;
    transactionDescription: string;
    transactionNo: string;
    withdrawal: number;
  }

  export interface Info {
    accountBSB: string;
    accountName: string;
    accountNumber: string;
    institutionName: string;
    paymentUrl: string;
    pendingBalance: number;
    statementDate: Date;
    ledgerItems: LedgerItem[];
    trustAccountId: string;
  }

  export class Helper {
    static trustStatementFilterOptions(): BillingModel.FilterOption[] {
      return [
        {
          title: environment.locale.billing.trust_account.filter.all,
          value: environment.locale.billing.trust_account.filter.all
        } as BillingModel.FilterOption
      ];
    }
  }
}
