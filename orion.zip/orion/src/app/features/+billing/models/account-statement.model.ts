import { environment } from '@env/environment';
import { formatDate, formatCurrency } from '@angular/common';
import { BillingModel } from './billing.model';

export namespace AccountStatementModel {
  export interface StatementListItem {
    dueDate: Date;
    invoiceNo: string;
    description: string;
    invoiceTotal: number;
    amountPaid: number;
    balanceDue: number;
    paymentUrl: string;
  }

  // export type StatementofAccountFilter = {
  //   id: string;
  //   value: string;
  // };

  // export type TrustAccountFilter = {
  //   id: string;
  //   value: string;
  // };

  // export type BillingFilter = StatementofAccountFilter | TrustAccountFilter;

  export interface AgeingPeriod {
    period: number;
    balance: number;
  }

  export interface DebtorLedgerItem {
    transactionDate: Date;
    transactionNo: string;
    transactionDescription: string;
    debitAmount: number;
    creditAmount: number;
    runningBalance: number;
    itemRowNumber: number;
    paymentUrl: string;
  }

  export interface InvoiceItem {
    invoiceDate: Date;
    invoiceNo: string;
    matterDescription: string;
    invoiceTotal: number;
    amountPaid: number;
    balanceDue: number;
    itemRowNumber: number;
    paymentUrl: string;
  }

  export interface OfficeStatement {
    statementDate: Date;
    invoiceBalanceDue: number;
    lessCredit: number;
    lessTrust: number;
    totalDue: number;
    debtorBalanceCurrent: number;
    ageingPeriods: AgeingPeriod[];
    paymentUrl: string;
    pendingBalance: number;
    invoiceItems: InvoiceItem[];
  }

  export interface DebtorLedger {
    statementDate: Date;
    invoiceBalanceDue: number;
    lessCredit: number;
    lessTrust: number;
    totalDue: number;
    debtorBalanceCurrent: number;
    ageingPeriods: AgeingPeriod[];
    paymentUrl: string;
    pendingBalance: number;
    debtorLedgerItems: DebtorLedgerItem[];
  }

  export interface Info {
    debtorLedger: DebtorLedger;
    officeStatement: OfficeStatement;
  }

  export class Helper {
    static localeFormat(dt: Date, locale: string, format: string = 'mediumDate'): string {
      return formatDate(dt, format, locale);
    }

    static localeCurrency(amount: number, locale: string): string {
      const { currency } = environment.locale.global;
      return formatCurrency(amount, locale, currency.symbol);
    }

    static accountOfStatementFilterOptions(): BillingModel.FilterOption[] {
      return [
        {
          title: environment.locale.billing.statement_of_account.filter.summary,
          value: environment.locale.billing.statement_of_account.filter.summary
        } as BillingModel.FilterOption,
        {
          title: environment.locale.billing.statement_of_account.filter.debtorLedger,
          value: environment.locale.billing.statement_of_account.filter.debtorLedger
        } as BillingModel.FilterOption
      ];
    }
  }
}
