import { Component, ChangeDetectionStrategy, OnDestroy, Inject } from '@angular/core';
import { Subject } from 'rxjs';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { BillingModel } from '../../models/billing.model';

@Component({
  selector: 'sc-billing-view-details-mobile',
  templateUrl: './billing-view-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BillingViewDetailsMobileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  isStatementEntryDetail = false;
  isStatementDetail = false;

  title = '';
  subtitle = '';

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  constructor(
    private bottomSheetRef: MatBottomSheetRef<BillingViewDetailsMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';

    if (data.displayFor == BillingModel.ActionType.StatementDetails) {
      this.isStatementEntryDetail = data.actionType == BillingModel.ActionType.StatementEntryDetail;
      this.isStatementDetail = data.actionType == BillingModel.ActionType.StatementDetails;
    }
  }

  ngOnDestroy() {
    this.destroy$.next();
  }
}
