import { Component, ChangeDetectionStrategy, OnDestroy, ChangeDetectorRef, Inject, LOCALE_ID } from '@angular/core';
import { Select } from '@ngxs/store';
import { Observable, merge, Subject } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { environment } from '@env/environment';
import { AccountStatementModel } from '../../models/account-statement.model';
import { BillingState } from '../../store';

const emptyComment = environment.locale.no_results.billing.details;

@Component({
  selector: 'sc-account-statement-side',
  templateUrl: './account-statement-side.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountStatementSideComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  lastAgeingPulled = new Date();
  isLoading = false;
  noStatement = false;
  noStatementText = 'No detail available';
  data: AccountStatementModel.DebtorLedger = undefined;
  pendingPaymentDesc = '';

  @Select(BillingState.getLoading) isLoading$: Observable<boolean>;
  @Select(BillingState.getStatementFilterBy) filterBy$: Observable<string>;
  @Select(BillingState.getError) errorMessage$: Observable<string>;
  @Select(BillingState.getOfficeAccount) data$: Observable<AccountStatementModel.Info>;

  get emptyComment(): any {
    return emptyComment;
  }

  getPendingPayment(): string {
    return this.data && this.data.pendingBalance > 0
      ? `${AccountStatementModel.Helper.localeCurrency(this.data.pendingBalance, this.locale)} Payment Pending`
      : `${AccountStatementModel.Helper.localeCurrency(0, this.locale)} Payment Pending`;
  }

  totalDue(paid: number, due: number): number {
    return (paid || 0) + (due || 0);
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(@Inject(LOCALE_ID) private locale: string, private cd: ChangeDetectorRef) {
    merge(
      this.listenToDataPullingProgressSideEffect$(),
      this.listenToDataFailedSideEffect$(),
      this.listenToDataLoadedSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private listenToDataPullingProgressSideEffect$(): Observable<boolean> {
    return this.isLoading$.pipe(
      tap(v => {
        this.isLoading = v;
      })
    );
  }

  private listenToDataFailedSideEffect$(): Observable<string> {
    return this.errorMessage$.pipe(
      tap(message => {
        this.noStatement = true;
        this.isLoading = false;
      })
    );
  }

  private listenToDataLoadedSideEffect$(): Observable<AccountStatementModel.Info> {
    return this.data$.pipe(
      tap(data => {
        if (!data) {
          this.data = undefined;
          this.noStatement = true;
        } else {
          const { debtorLedger } = data;
          this.data = debtorLedger;
          this.noStatement = debtorLedger ? false : true;
        }
        this.cd && this.cd.markForCheck();
      })
    );
  }
}
