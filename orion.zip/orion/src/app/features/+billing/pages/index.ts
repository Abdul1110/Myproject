import { AccountStatementComponent } from './account-statement/account-statement.component';
import { AccountStatementSideComponent } from './account-statement-side/account-statement-side.component';
import { BillingViewDetailsMobileComponent } from './billing-view-details-mobile/billing-view-details-mobile.component';

export * from './account-statement/account-statement.component';
export * from './account-statement-side/account-statement-side.component';
export * from './billing-view-details-mobile/billing-view-details-mobile.component';

export const billingPages = [
  AccountStatementComponent,
  AccountStatementSideComponent,
  BillingViewDetailsMobileComponent
];
