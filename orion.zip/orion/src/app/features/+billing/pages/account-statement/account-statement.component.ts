import { Component, ViewChild, OnDestroy } from '@angular/core';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { LyraAnimation, BrowserService } from '@leap/lyra-design';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { Select } from '@ngxs/store';

import { environment } from '@env/environment';
import { AccountStatementModel } from '../../models/account-statement.model';
import {
  CustomEventService,
  BILLING_ACCOUNT_CHECKLIST,
  CustomEventModel,
  BILLING_ACCOUNT_SIDE_DISPLAY,
  BILLING_ACCOUNT_MAKE_PAYMENT,
  BILLING_ACCOUNT_MULTIPLE_ACTIONS,
  COLLABORATIONS_SIDE_TAB_TOGGLE
} from '@app/core/services';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { BillingState } from '../../store';
import { BillingModel } from '../../models/billing.model';

const { filter } = environment.locale.billing.statement_of_account;
const emptyComment = environment.locale.no_results.billing;

@Component({
  selector: 'sc-account-statement',
  templateUrl: './account-statement.component.html',
  animations: [LyraAnimation.xAnimationAsideCollapse]
})
export class AccountStatementComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private payInFullUrl = '';

  noStatement = false;
  hasError = false;
  isLoading = true;
  statements: AccountStatementModel.StatementListItem[] = [];
  isSmallScreen = false;
  filterBy = filter.summary;
  debtorLedger: AccountStatementModel.DebtorLedger = undefined;
  officeStatement: AccountStatementModel.OfficeStatement = undefined;
  isSummaryView = false;
  totalDue = 0;

  @Select(BillingState.getLoading) isLoading$: Observable<boolean>;
  @Select(BillingState.getStatementFilterBy) filterBy$: Observable<string>;
  @Select(BillingState.getError) errorMessage$: Observable<string>;
  @Select(BillingState.getOfficeAccount) data$: Observable<AccountStatementModel.Info>;

  @ViewChild(CdkVirtualScrollViewport, { static: false }) cdkVirtualScrollViewport: CdkVirtualScrollViewport;

  scrollToViewRecord = (currentScrollIndex: number): void => {
    // console.log('current index ', currentScrollIndex);
  };

  get emptyComment(): any {
    return emptyComment;
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  isChecked = (idx: number): boolean => {
    return idx == 1;
  };

  onCheckChange({ idx, checked }) {
    this.myCheckList[idx] = checked;
  }

  myCheckList: { [id: string]: boolean } = {};

  ngOnDestroy() {
    this.destroy$.next();
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_SIDE_DISPLAY, { show: false });
  }

  constructor(
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService,
    private browserSvc: BrowserService
  ) {
    merge(
      this.listenToSmallScreenSideEffect$(),
      this.listenToCheckListSideEffect$(),
      this.listenToDataPullingProgressSideEffect$(),
      this.listenToDataFailedSideEffect$(),
      this.listenToDataLoadedSideEffect$(),
      this.listenToStatementFilterSideEffect$(),
      this.listenToPaymentRequestSideEffect$(),
      this.listenToMultiActionSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_SIDE_DISPLAY, { show: true });
    this.customEventSvc.dispatchEvent(COLLABORATIONS_SIDE_TAB_TOGGLE, { show: true });
  }

  private listenToMultiActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_ACCOUNT_MULTIPLE_ACTIONS,
      (data: CustomEventModel.BillingAccountMultipleActionEventDetail) => {
        if (data.actionType !== undefined && data.actionType) {
          if (data.actionType == BillingModel.ActionType.StatementPayInFull) {
            this.makePayment(this.payInFullUrl);
            return;
          }
        }
      }
    );
  }

  private listenToPaymentRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(BILLING_ACCOUNT_MAKE_PAYMENT, ({ paymentUrl }) => {
      this.makePayment(paymentUrl);
    });
  }

  private makePayment(url: string): void {
    url && this.browserSvc.isBrowser && this.browserSvc.window.open(url, '_blank');
  }

  private listenToStatementFilterSideEffect$(): Observable<string> {
    return this.filterBy$.pipe(
      tap(fb => {
        this.filterBy = fb;
        this.updateStatementListView(this.debtorLedger, this.officeStatement);
      })
    );
  }

  private listenToSmallScreenSideEffect$(): Observable<boolean> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(v => {
        this.isSmallScreen = v;
      })
    );
  }

  private listenToCheckListSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_ACCOUNT_CHECKLIST,
      (data: CustomEventModel.BillingAccountChecklistEventDetail) => {
        if (data['all'] !== undefined) {
          let value = {};
          Object.keys(this.myCheckList).forEach(id => {
            value[id] = !!data['all'];
          });

          this.myCheckList = { ...value };
          return;
        }
      }
    );
  }

  private listenToDataPullingProgressSideEffect$(): Observable<boolean> {
    return this.isLoading$.pipe(
      tap(v => {
        this.isLoading = v;
      })
    );
  }

  private listenToDataFailedSideEffect$(): Observable<string> {
    return this.errorMessage$.pipe(
      tap(message => {
        if (!message) {
          this.hasError = false;
          return;
        }

        this.hasError = true;
        this.noStatement = true;
        this.isLoading = false;
      })
    );
  }

  private listenToDataLoadedSideEffect$(): Observable<AccountStatementModel.Info> {
    return this.data$.pipe(
      tap(data => {
        if (!data) {
          this.debtorLedger = undefined;
          this.officeStatement = undefined;
        } else {
          const { debtorLedger, officeStatement } = data;
          this.debtorLedger = debtorLedger;
          this.officeStatement = officeStatement;
        }

        this.updateStatementListView(this.debtorLedger, this.officeStatement);
      })
    );
  }

  private updateStatementListView(
    debtorLedger: AccountStatementModel.DebtorLedger,
    officeStatement: AccountStatementModel.OfficeStatement
  ): void {
    this.noStatement = false;

    if (!debtorLedger && !officeStatement) {
      this.noStatement = true;
      return;
    }

    if (
      this.filterBy == filter.debtorLedger &&
      debtorLedger &&
      debtorLedger.statementDate &&
      debtorLedger.debtorLedgerItems &&
      debtorLedger.debtorLedgerItems.length > 0
    ) {
      this.payInFullUrl = debtorLedger.paymentUrl;
      this.totalDue = debtorLedger.totalDue;
      this.statements = debtorLedger.debtorLedgerItems.map(
        d =>
          <AccountStatementModel.StatementListItem>{
            invoiceTotal: d.debitAmount,
            amountPaid: d.creditAmount,
            balanceDue: d.runningBalance,
            description: d.transactionDescription,
            dueDate: d.transactionDate,
            invoiceNo: d.transactionNo,
            paymentUrl: d.paymentUrl
          }
      );

      this.isSummaryView = false;
      this.resetCheckList(this.statements);
      return;
    }

    if (
      this.filterBy == filter.summary &&
      officeStatement &&
      officeStatement.statementDate &&
      officeStatement.invoiceItems &&
      officeStatement.invoiceItems.length > 0
    ) {
      this.payInFullUrl = officeStatement.paymentUrl;
      this.totalDue = officeStatement.totalDue + officeStatement.lessCredit;
      this.statements = officeStatement.invoiceItems.map(
        d =>
          <AccountStatementModel.StatementListItem>{
            invoiceTotal: d.invoiceTotal,
            amountPaid: d.amountPaid,
            balanceDue: d.balanceDue,
            description: d.matterDescription,
            dueDate: d.invoiceDate,
            invoiceNo: d.invoiceNo,
            paymentUrl: d.paymentUrl
          }
      );

      this.isSummaryView = true;
      this.resetCheckList(this.statements);
      return;
    }

    this.payInFullUrl = '';
    this.noStatement = true;
  }

  private resetCheckList(statements: AccountStatementModel.StatementListItem[]): void {
    this.myCheckList = {};
    statements.forEach((x, idx) => {
      this.myCheckList[idx] = false;
    });
  }
}
