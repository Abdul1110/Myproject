import { NgModule } from '@angular/core';

import { LyraDesignButtonModule, LyraDesignCommonModule } from '@leap/lyra-design';
import { SharedModule } from '@app/shared';
import { AppStateModule } from '@app/core/app-state.module';
import { termsPages } from './pages';
import { TermsRoutingModule } from './terms-routing.module';

@NgModule({
  imports: [SharedModule, AppStateModule, LyraDesignCommonModule, LyraDesignButtonModule, TermsRoutingModule],
  entryComponents: [...termsPages],
  declarations: [...termsPages]
})
export class TermsModule {}
