import { TermsPageComponent } from './terms/terms-page.component';

export * from './terms/terms-page.component';

export const termsPages = [TermsPageComponent];
