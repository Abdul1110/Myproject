import { Component, OnInit, HostBinding } from '@angular/core';
import { Store, Select } from '@ngxs/store';
import { environment } from '@env/environment';
import { AppState } from '@app/core/store/states';
import { Observable } from 'rxjs';
import { SetTermsAndConditionsStatus } from '@app/core/store/actions';
import { BrowserService } from '@leap/lyra-design';
import { AnalyticService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

@Component({
  selector: 'sc-terms',
  templateUrl: './terms-page.component.html'
})
export class TermsPageComponent implements OnInit {
  privacyUrl = environment.appSettings.privacyUrl;

  @HostBinding('class.w-100')
  @Select(AppState.getUserTermsAndConditionsStatus)
  termsAndConditionsStatus$: Observable<boolean>;

  constructor(private _store: Store, private browserSvc: BrowserService, private analyticsSvc: AnalyticService) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.TermsPage, action: 'View terms and conditions' });
    }
  }

  ngOnInit() {}

  userAgreesTo(): void {
    this._store.dispatch(new SetTermsAndConditionsStatus(true));
  }
}
