import { Component, HostBinding, OnDestroy } from '@angular/core';
import { Store, Select, Actions, ofActionSuccessful } from '@ngxs/store';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MatBottomSheet } from '@angular/material';

import { SetNavigationActionId, SetMatterFirmId, GetNotification } from '@app/core/store/actions';
import { CoreModel } from '@app/core/models';
import { environment } from '@env/environment';
import { tap } from 'rxjs/operators';
import {
  CustomEventService,
  CustomEventModel,
  BILLING_TRUST_SIDE_DISPLAY,
  BILLING_VIEW_DETAILS_DISPLAY,
  BILLING_ACCOUNT_MULTIPLE_ACTIONS,
  NAVIGATION_SIDE_BAR_TOGGLE,
  COLLABORATIONS_SIDE_TAB_TOGGLE,
  MATTERS_SELECT_CLOSED,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED
} from '@app/core/services';
import { ActivatedRoute } from '@angular/router';

import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { TrustModel } from '../../models/trust.model';
import { TrustViewDetailsMobileComponent } from '../../pages';
import { TrustAction, TrustState } from '../../store';
import { AppState } from '@app/core/store/states';
import { SideNavigationModel } from '@app/shared/models';
import { TrustMultipleActionsOptionMobileComponent } from '../../components';
import { xAnimationAsideCollapse } from '@app/shared/components/animation/animation';

const { locale } = environment;
const billingIcon = locale.global.menu.billing.icon;

@Component({
  selector: 'sc-trust-home',
  templateUrl: './trust-home.component.html',
  animations: [xAnimationAsideCollapse]
})
export class TrustHomeComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  pageSlot = '';
  matterId = '';
  matterName = '';
  selectedFilter: TrustModel.FilterOption = null;
  selectedFilterTitle = '';
  filterOptions: TrustModel.FilterOption[] = [];
  isSmallScreen = false;
  showMobileDetails = false;
  asideDetails: boolean;
  trustFilterOptions: TrustModel.FilterOption[] = [];
  currentTrustFilter: TrustModel.FilterOption = null;
  firm: CoreModel.FirmDetail = null;
  hasTrust = false;
  hasValue = false;

  @Select(TrustState.getTrustFilterBy) trustFilterBy$: Observable<string>;
  @Select(TrustState.getTrustFilterOption) trustFilterOption$: Observable<TrustModel.FilterOption[]>;

  documentTitle(): string {
    return 'Trust';
  }

  toggleAside(): void {
    this.asideDetails = !this.asideDetails;
  }

  isSelected(item: any): boolean {
    return this.selectedFilter && item.title == this.selectedFilter.title;
  }

  changeFilter(newFilter: TrustModel.FilterOption): void {
    const current = { ...newFilter };

    // update the value in seperate task to avoid ux render issue.
    this.updateFilter(current, current.title);

    this.currentTrustFilter = current;
    this.store.dispatch(new TrustAction.SetTrustFilter(current.value.accountNumber || current.value));
  }

  showMobileViewDetails(isSmallScreen: boolean, viewDetails: boolean): boolean {
    if (!isSmallScreen) {
      return false;
    }

    return viewDetails;
  }

  openGlobalActionSheet(): void {
    this.bottomSheet.open(TrustMultipleActionsOptionMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { displayHeader: true, displayFor: TrustModel.ActionType.TrustDetails }
    });
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  getMatterName(): string {
    return this.matterName;
  }

  getNavbarIcon(): string {
    return billingIcon;
  }

  getFirmName(): string {
    return (this.firm && this.firm.name) || locale.matters.title;
  }

  constructor(
    private store: Store,
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService,
    private bottomSheet: MatBottomSheet,
    private route: ActivatedRoute,
    private actions: Actions
  ) {
    this.updateFromPathParams();
    this.updateMatterName(this.matterId);
    this.updateGlobalFirmAndMatterId(this.matterId);
    this.triggerRecentNotificationDataPulledIfCountZero();

    merge(
      this.listenToTrustSideDetailDisplaySideEffect$(),
      this.listenToMobileSideDetailDisplaySideEffect$(),
      this.listenToMobileMultiActionSideEffect$(),
      this.listenToSmallScreenSideEffect$(),
      this.listenToTrustFilterByOptionSideEffect$(),
      this.getFirmDetailsSideEffect$(),
      this.listenToRemoteSideDetailToggleRequestSideEffect$(),
      this.listenToMatterSelectedFromOptions$(),
      this.listenToGetBillingAccountSuccessSideEffect$(),
      this.listenToGetBillingAccountFailureSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.store.dispatch(new SetNavigationActionId(SideNavigationModel.SideActionId.trust));
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, {
      actionId: SideNavigationModel.SideActionId.trust
    });
  }

  @HostBinding('class.lt-container')
  @HostBinding('class.bg-light-secondary')
  ngOnDestroy() {
    this.destroy$.next(true);
    this.store.dispatch([
      new TrustAction.CancelGetBillingAccount(undefined),
      new TrustAction.CleanTrustFilterOption(undefined)
    ]);
  }

  private listenToGetBillingAccountFailureSideEffect$(): Observable<any> {
    return this.actions.pipe(
      ofActionSuccessful(TrustAction.GetBillingAccountFailure),
      tap(payload => {
        if (payload && payload.payload) {
          this.hasTrust = false;
          this.hasValue = false;
        }
      })
    );
  }

  private listenToGetBillingAccountSuccessSideEffect$(): Observable<any> {
    return this.actions.pipe(
      ofActionSuccessful(TrustAction.GetBillingAccountSuccess),
      tap(payload => {
        const data = payload.payload as TrustModel.TrustAccount;
        const success = data.success;
        if (!success) {
          this.hasTrust = false;
          return;
        }

        // trust account
        const trust = data && data.data && data.data.trustLedgers;
        this.hasTrust = !!(trust && trust.length > 0);

        // update has value indicator
        this.hasValue = this.hasTrust;
      })
    );
  }

  private triggerRecentNotificationDataPulledIfCountZero(): void {
    const user = this.store.selectSnapshot(AppState.getLoginUser);
    const notificationCount = this.store.selectSnapshot(AppState.getNotificationCount) || 0;
    user && user.userId && notificationCount == 0 && this.store.dispatch(new GetNotification(user.userId));
  }

  private updateGlobalFirmAndMatterId(currentMatterId: string): void {
    const matterAndFirm = this.store.selectSnapshot(AppState.getSelectedMatterAndFirmId);
    const { matterId, firmId } = matterAndFirm || { matterId: '', firmId: '' };
    if (matterId != currentMatterId) {
      const documents = this.store.selectSnapshot(AppState.getNodes) || [];
      const matter = currentMatterId && documents.length > 0 && documents.find(x => x.id == currentMatterId);
      const firmId = matter && matter.parentId;
      firmId && currentMatterId && this.store.dispatch(new SetMatterFirmId({ matterId: currentMatterId, firmId }));
    }
  }

  private updateFilter(filter: TrustModel.FilterOption, title: string): void {
    //update the value in seperate task to avoid ux render issue.
    setTimeout(() => {
      this.selectedFilter = filter;
      this.selectedFilterTitle = title;
    }, 0);
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      this.updateFromPathParams(matterId);
      this.updateMatterName(this.matterId);
    });
  }

  private updateFromPathParams(matterId: string = undefined): void {
    this.matterId = matterId || (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';
    this.matterId && this.store.dispatch(new TrustAction.GetBillingAccount(this.matterId));
  }

  private listenToRemoteSideDetailToggleRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(COLLABORATIONS_SIDE_TAB_TOGGLE, ({ show }) => {
      if (show !== undefined) {
        this.asideDetails = show;
        return;
      }
    });
  }

  private updateMatterName(matterId: string): void {
    const matterDetail = CoreModel.Helper.getMatterDetail(
      matterId,
      this.store.selectSnapshot(AppState.getMattersByFirm)
    );

    this.matterName = (matterDetail && matterDetail.name) || '';
  }

  private getFirmDetailsSideEffect$(): Observable<any> {
    return this.appActionSvc.selectedFirm$.pipe(tap(x => (this.firm = x)));
  }

  private listenToSmallScreenSideEffect$(): Observable<boolean> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(v => {
        this.isSmallScreen = v;
      })
    );
  }

  private listenToTrustFilterByOptionSideEffect$(): Observable<any> {
    return this.trustFilterOption$.pipe(
      tap(fo => {
        this.trustFilterOptions = [].concat(fo || []);
        this.filterOptions = this.trustFilterOptions;
        if (this.trustFilterOptions.length == 2) {
          this.changeFilter(this.trustFilterOptions[1]);
          this.currentTrustFilter = this.trustFilterOptions[1];
        }
      })
    );
  }

  private listenToTrustSideDetailDisplaySideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_TRUST_SIDE_DISPLAY,
      (data: CustomEventModel.BillingTrustSideDisplayEventDetail) => {
        if (data.show !== undefined) {
          this.filterOptions = this.trustFilterOptions;
          const current = this.currentTrustFilter || this.filterOptions[0];

          this.updateFilter(current, current.title);
        }
      }
    );
  }

  private listenToMobileSideDetailDisplaySideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_VIEW_DETAILS_DISPLAY,
      (data: CustomEventModel.BillingViewDetailsDisplayEventDetail) => {
        if (data.show !== undefined) {
          this.showMobileDetails = data.show;
          return;
        }
      }
    );
  }

  private listenToMobileMultiActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_ACCOUNT_MULTIPLE_ACTIONS,
      (data: CustomEventModel.BillingAccountMultipleActionEventDetail) => {
        if (data.actionType !== undefined && data.actionType) {
          if (data.actionType == TrustModel.ActionType.ViewSelectedTrustAccount) {
            this.changeFilter(data.value.filterBy);
            return;
          }

          if (data.actionType == TrustModel.ActionType.TrustDownload) {
            this.store.dispatch(
              new TrustAction.DonwloadBillingTrustAccount({
                matterId: this.matterId,
                accountId: this.selectedFilter.value.accountId
              })
            );
            return;
          }

          this.bottomSheet.open(TrustViewDetailsMobileComponent, {
            panelClass: 'x-bottom-sheet',
            data: { ...data.value, actionType: data.actionType }
          });
          return;
        }
      }
    );
  }
}
