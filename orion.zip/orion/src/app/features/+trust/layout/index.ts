import { TrustHomeComponent } from './home/trust-home.component';

export * from './home/trust-home.component';

export const trustLayouts = [TrustHomeComponent];
