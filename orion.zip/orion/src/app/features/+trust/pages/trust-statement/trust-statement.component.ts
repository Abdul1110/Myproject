import { Component, ViewChild, OnDestroy } from '@angular/core';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { Subject, Observable, merge } from 'rxjs';
import {
  BILLING_TRUST_SIDE_DISPLAY,
  CustomEventService,
  BILLING_ACCOUNT_MULTIPLE_ACTIONS,
  CustomEventModel,
  COLLABORATIONS_SIDE_TAB_TOGGLE
} from '@app/core/services';
import { TrustStatementModel } from '../../models/trust-statement.model';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { takeUntil, tap } from 'rxjs/operators';
import { Select } from '@ngxs/store';
import { TrustState } from '../../store';
import { environment } from '@env/environment';
import { TrustModel } from '../../models/trust.model';
import { BrowserService } from '@leap/lyra-design';

const { filter } = environment.locale.billing.trust_account;
const emptyComment = environment.locale.no_results.billing.trust;

@Component({
  selector: 'sc-trust-statement',
  templateUrl: './trust-statement.component.html'
})
export class TrustStatementComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private trustLedgers: TrustStatementModel.Info[] = [];
  private newPaymentUrl = '';

  filterBy = filter.all;
  noStatement = false;
  hasError = false;
  isLoading = true;
  statements: TrustStatementModel.StatementListItem[] = [];
  isSmallScreen$: Observable<boolean>;

  @Select(TrustState.getLoading) isLoading$: Observable<boolean>;
  @Select(TrustState.getTrustFilterBy) filterBy$: Observable<string>;
  @Select(TrustState.getError) errorMessage$: Observable<string>;
  @Select(TrustState.getTrustAccount) data$: Observable<TrustStatementModel.Info[]>;

  @ViewChild(CdkVirtualScrollViewport, { static: false }) cdkVirtualScrollViewport: CdkVirtualScrollViewport;

  scrollToViewRecord = (currentScrollIndex: number): void => {
    // console.log('current index ', currentScrollIndex);
  };

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  get emptyComment(): any {
    return emptyComment;
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.customEventSvc.dispatchEvent(BILLING_TRUST_SIDE_DISPLAY, { show: false });
  }

  constructor(
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService,
    private browserSvc: BrowserService
  ) {
    merge(
      this.listenToDataPullingProgressSideEffect$(),
      this.listenToDataFailedSideEffect$(),
      this.listenToDataLoadedSideEffect$(),
      this.listenToTrustFilterSideEffect$(),
      this.listenToMultiActionSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.customEventSvc.dispatchEvent(BILLING_TRUST_SIDE_DISPLAY, { show: true });
    this.customEventSvc.dispatchEvent(COLLABORATIONS_SIDE_TAB_TOGGLE, { show: true });

    this.isSmallScreen$ = this.appActionSvc.isSmallScreen$.pipe(takeUntil(this.destroy$));
  }

  private listenToMultiActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      BILLING_ACCOUNT_MULTIPLE_ACTIONS,
      (data: CustomEventModel.BillingAccountMultipleActionEventDetail) => {
        if (data.actionType !== undefined && data.actionType) {
          if (data.actionType == TrustModel.ActionType.NewTrustPayment) {
            this.makePayment(this.newPaymentUrl);
            return;
          }
        }
      }
    );
  }

  private makePayment(url: string): void {
    url && this.browserSvc.isBrowser && this.browserSvc.window.open(url, '_blank');
  }

  private listenToTrustFilterSideEffect$(): Observable<string> {
    return this.filterBy$.pipe(
      tap(fb => {
        this.filterBy = fb;
        this.updateStatementListView(this.trustLedgers);
      })
    );
  }

  private listenToDataPullingProgressSideEffect$(): Observable<boolean> {
    return this.isLoading$.pipe(
      tap(v => {
        this.isLoading = v;
      })
    );
  }

  private listenToDataFailedSideEffect$(): Observable<string> {
    return this.errorMessage$.pipe(
      tap(message => {
        if (!message) {
          this.hasError = false;
          return;
        }

        this.noStatement = true;
        this.hasError = true;
        this.isLoading = false;
      })
    );
  }

  private listenToDataLoadedSideEffect$(): Observable<TrustStatementModel.Info[]> {
    return this.data$.pipe(
      tap(data => {
        if (!data) {
          this.trustLedgers = [];
        } else {
          this.trustLedgers = [].concat(data || []);
        }

        this.updateStatementListView(this.trustLedgers);
      })
    );
  }

  private updateStatementListView(ledgers: TrustStatementModel.Info[]): void {
    this.noStatement = false;

    if (!ledgers || ledgers.length == 0) {
      this.noStatement = true;
      this.newPaymentUrl = '';
      return;
    }

    if (this.filterBy != filter.all && ledgers.findIndex(r => r.accountNumber == this.filterBy) !== -1) {
      const selectedLedger = ledgers.find(x => x.accountNumber == this.filterBy);
      this.newPaymentUrl = selectedLedger.paymentUrl;

      this.statements = selectedLedger.ledgerItems.map(
        d =>
          <TrustStatementModel.StatementListItem>{
            entryDate: d.entryDate,
            transactionNo: d.transactionNo,
            description: d.transactionDescription && d.transactionDescription.replace(/\n/g, '<br/>'),
            paymentType: '',
            transaction: (d.withdrawal && -d.withdrawal) || d.deposit || 0,
            trustAccount: selectedLedger.accountName
          }
      );

      this.noStatement = this.statements.length == 0;
      return;
    }

    const allLedgers = ledgers
      .map(x => {
        return x.ledgerItems.map(
          d =>
            <TrustStatementModel.StatementListItem>{
              entryDate: d.entryDate,
              transactionNo: d.transactionNo,
              description: d.transactionDescription && d.transactionDescription.replace(/\n/g, '<br/>'),
              paymentType: '',
              transaction: (d.withdrawal && -d.withdrawal) || d.deposit || 0,
              trustAccount: x.accountName
            }
        );
      })
      .reduce((a, b) => a.concat(b));

    this.newPaymentUrl = '';
    this.statements = [].concat(allLedgers || []);
    this.noStatement = this.statements.length == 0;
  }
}
