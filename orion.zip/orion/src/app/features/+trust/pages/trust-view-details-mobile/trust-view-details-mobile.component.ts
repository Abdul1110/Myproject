import { Component, ChangeDetectionStrategy, OnDestroy, Inject } from '@angular/core';
import { Subject } from 'rxjs';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { TrustModel } from '../../models/trust.model';

@Component({
  selector: 'sc-trust-view-details-mobile',
  templateUrl: './trust-view-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustViewDetailsMobileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  title = '';
  subtitle = '';
  isStatementEntryDetail = false;
  isStatementDetail = false;

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  constructor(
    private bottomSheetRef: MatBottomSheetRef<TrustViewDetailsMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';
    this.isStatementEntryDetail = data.actionType == TrustModel.ActionType.StatementEntryDetail;
    this.isStatementDetail = data.actionType == TrustModel.ActionType.TrustDetails;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }
}
