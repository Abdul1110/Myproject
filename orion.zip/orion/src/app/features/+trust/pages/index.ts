import { TrustStatementComponent } from './trust-statement/trust-statement.component';
import { TrustStatementSideComponent } from './trust-statement-side/trust-statement-side.component';
import { TrustViewDetailsMobileComponent } from './trust-view-details-mobile/trust-view-details-mobile.component';

export * from './trust-statement/trust-statement.component';
export * from './trust-statement-side/trust-statement-side.component';
export * from './trust-view-details-mobile/trust-view-details-mobile.component';

export const trustPages = [TrustStatementComponent, TrustStatementSideComponent, TrustViewDetailsMobileComponent];
