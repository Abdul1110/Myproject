import { Component, ChangeDetectionStrategy, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { TrustStatementModel } from '../../models/trust-statement.model';
import { Select } from '@ngxs/store';
import { TrustState } from '../../store';
import { Observable, Subject, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { environment } from '@env/environment';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';

const { filter, side_info } = environment.locale.billing.trust_account;
const emptyComment = environment.locale.no_results.billing.details;

@Component({
  selector: 'sc-trust-statement-side',
  templateUrl: './trust-statement-side.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustStatementSideComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private trustLedgers: TrustStatementModel.Info[] = [];
  private filterBy = filter.all;

  isSmallScreen$: Observable<boolean>;
  title: string;

  noStatement = false;
  isLoading = false;
  grandTotalDeposit = 0;
  grandTotalWithdrawal = 0;

  @Select(TrustState.getLoading) isLoading$: Observable<boolean>;
  @Select(TrustState.getTrustFilterBy) filterBy$: Observable<string>;
  @Select(TrustState.getError) errorMessage$: Observable<string>;
  @Select(TrustState.getTrustAccount) data$: Observable<TrustStatementModel.Info[]>;

  trustAccounts: TrustStatementModel.TrustAccountItem[] = [];

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  get emptyComment(): any {
    return emptyComment;
  }

  constructor(private cd: ChangeDetectorRef, private appActionSvc: AppActionService) {
    merge(
      this.listenToDataPullingProgressSideEffect$(),
      this.listenToDataFailedSideEffect$(),
      this.listenToDataLoadedSideEffect$(),
      this.listenToTrustFilterSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.isSmallScreen$ = this.appActionSvc.isSmallScreen$.pipe(takeUntil(this.destroy$));
    this.title = this.trustAccounts.length > 1 ? side_info.trust_accounts : side_info.trust_account;
  }

  private listenToTrustFilterSideEffect$(): Observable<string> {
    return this.filterBy$.pipe(
      tap(fb => {
        this.filterBy = fb;
        this.updateListView(this.trustLedgers);
      })
    );
  }

  private listenToDataPullingProgressSideEffect$(): Observable<boolean> {
    return this.isLoading$.pipe(
      tap(v => {
        this.isLoading = v;
        this.cd && this.cd.markForCheck();
      })
    );
  }

  private listenToDataFailedSideEffect$(): Observable<string> {
    return this.errorMessage$.pipe(
      tap(message => {
        this.noStatement = true;
        this.isLoading = false;
        this.cd && this.cd.markForCheck();
      })
    );
  }

  private listenToDataLoadedSideEffect$(): Observable<TrustStatementModel.Info[]> {
    return this.data$.pipe(
      tap(data => {
        if (!data) {
          this.trustLedgers = [];
        } else {
          this.trustLedgers = [].concat(data || []);
        }

        this.updateListView(this.trustLedgers);
      })
    );
  }

  private updateListView(ledgers: TrustStatementModel.Info[]): void {
    if (!ledgers || ledgers.length == 0) {
      this.noStatement = true;
      this.updateTitle();
      this.cd && this.cd.markForCheck();
      return;
    }

    this.noStatement = false;

    if (this.filterBy !== filter.all && ledgers.findIndex(r => r.accountNumber == this.filterBy) !== -1) {
      const selectedLedger = ledgers.find(x => x.accountNumber == this.filterBy);
      const hasValue = !!(selectedLedger && selectedLedger.ledgerItems && selectedLedger.ledgerItems.length > 0);
      const totalDeposit = hasValue ? selectedLedger.ledgerItems.map(l => l.deposit).reduce((a, b) => a + b) : 0;
      const totalWithdrawal = hasValue ? selectedLedger.ledgerItems.map(l => l.withdrawal).reduce((a, b) => a + b) : 0;

      this.grandTotalDeposit = totalDeposit;
      this.grandTotalWithdrawal = totalWithdrawal;

      this.trustAccounts = [
        {
          bank: selectedLedger.institutionName,
          account: selectedLedger.accountName,
          accountNo: selectedLedger.accountNumber,
          balance: totalDeposit - totalWithdrawal,
          bsb: selectedLedger.accountBSB
        }
      ];
      this.updateTitle();
      this.cd && this.cd.markForCheck();

      return;
    }

    this.grandTotalDeposit = 0;
    this.grandTotalWithdrawal = 0;

    this.trustAccounts = ledgers.map(ledger => {
      const hasValue = !!(ledger && ledger.ledgerItems && ledger.ledgerItems.length > 0);
      const totalDeposit = hasValue ? ledger.ledgerItems.map(l => l.deposit).reduce((a, b) => a + b) : 0;
      const totalWithdrawal = hasValue ? ledger.ledgerItems.map(l => l.withdrawal).reduce((a, b) => a + b) : 0;
      this.grandTotalDeposit += totalDeposit;
      this.grandTotalWithdrawal += totalWithdrawal;
      return {
        bank: ledger.institutionName,
        account: ledger.accountName,
        accountNo: ledger.accountNumber,
        balance: totalDeposit - totalWithdrawal,
        bsb: ledger.accountBSB
      };
    });
    this.updateTitle();

    this.cd && this.cd.markForCheck();
  }

  private updateTitle(): void {
    this.title = `Trust Account${this.trustAccounts.length > 1 ? `s` : ``}`;
  }
}
