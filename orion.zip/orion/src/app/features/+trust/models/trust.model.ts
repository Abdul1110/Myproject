import { TrustStatementModel } from './trust-statement.model';
import { formatDate, formatCurrency } from '@angular/common';
import { environment } from '@env/environment';

export namespace TrustModel {
  export enum ActionType {
    TrustDetails = 'trust-details',
    ViewStatementSummary = 'view-statement-summary',
    ViewStatementDetail = 'view-statement-detail',
    TrustDownload = 'trust-download',
    NewTrustPayment = 'new-trust-payment',
    ViewSelectedTrustAccount = 'view-selected-trust-account',
    StatementEntryDetail = 'statement-entry-detail'
  }

  export interface TrustAccount {
    success: boolean;
    data: {
      trustLedgers: TrustStatementModel.Info[];
    };
    errorCode: number;
    errorMessage: string;
  }

  export interface FilterOption {
    title: string;
    value: any;
  }

  export class Helper {
    static localeDate(dt: Date, locale: string, format: string = 'mediumDate'): string {
      return formatDate(dt, format, locale);
    }

    static localeCurrency(amount: number, locale: string): string {
      const { currency } = environment.locale.global;
      return formatCurrency(amount, locale, currency.symbol);
    }

    static prefixWithInv(invNo: string): string {
      if (!invNo) {
        return invNo;
      }
      return invNo && invNo.toLowerCase().includes('inv') ? invNo : `Inv${invNo}`;
    }
  }
}
