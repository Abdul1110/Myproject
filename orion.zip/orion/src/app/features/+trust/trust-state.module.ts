import { NgModule } from '@angular/core';
import { NgxsModule } from '@ngxs/store';
import { TrustStates } from './store';

@NgModule({
  declarations: [],
  imports: [NgxsModule.forFeature([...TrustStates])]
})
export class TrustStateModule {}
