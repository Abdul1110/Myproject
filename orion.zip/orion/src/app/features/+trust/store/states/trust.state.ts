import { State, Action, StateContext, Selector, ofAction, Actions } from '@ngxs/store';
import { switchMap, catchError, takeUntil } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';

import { environment } from '@env/environment';
import { TrustModel } from '../../models/trust.model';
import { TrustAction } from '../actions';
import { LawConnectApiService } from '../../services';
import { TrustStatementModel } from '../../models/trust-statement.model';

export interface TrustStateModel {
  error: string;
  loading: boolean;
  trustFilterBy: string;
  trustFilterOption: TrustModel.FilterOption[];
  data: {
    trustLedgers: TrustStatementModel.Info[];
  };
}

@State<TrustStateModel>({
  name: 'trust',
  defaults: {
    trustFilterBy: environment.locale.billing.trust_account.filter.all,
    trustFilterOption: [
      {
        title: environment.locale.billing.trust_account.filter.all,
        value: environment.locale.billing.trust_account.filter.all
      }
    ],
    error: undefined,
    loading: false,
    data: undefined
  }
})
export class TrustState {
  @Action(TrustAction.GetBillingAccount, { cancelUncompleted: true })
  GetBillingAccount({ getState, setState, dispatch }: StateContext<TrustStateModel>, payload) {
    const matterId = payload.payload as string;

    const billing$ = this.lcApiSvc
      .getBillingAccount(matterId)
      .pipe(takeUntil(this.actions$.pipe(ofAction(TrustAction.CancelGetBillingAccount))));

    setState({
      ...getState(),
      loading: true,
      error: undefined
    });

    return billing$.pipe(
      switchMap((response: any) => dispatch(new TrustAction.GetBillingAccountSuccess(response))),
      catchError(error => dispatch(new TrustAction.GetBillingAccountFailure(error)))
    );
  }

  @Action(TrustAction.GetBillingAccountSuccess)
  GetBillingAccountSuccess({ getState, setState, dispatch }: StateContext<TrustStateModel>, payload) {
    const data = payload.payload as TrustModel.TrustAccount;

    if (!data || !data.success) {
      return dispatch(new TrustAction.GetBillingAccountFailure(data.errorMessage));
    }

    const { trustLedgers } = data.data;
    const trustFilterOption = trustLedgers.map(
      t =>
        <TrustModel.FilterOption>{
          title: t.accountName,
          value: {
            accountNumber: t.accountNumber,
            accountId: t.trustAccountId
          }
        }
    );

    setState({
      ...getState(),
      loading: false,
      data: data.data,
      error: undefined,
      trustFilterOption: [
        {
          title: environment.locale.billing.trust_account.filter.all,
          value: environment.locale.billing.trust_account.filter.all
        }
      ].concat(trustFilterOption) || [
        {
          title: environment.locale.billing.trust_account.filter.all,
          value: environment.locale.billing.trust_account.filter.all
        }
      ]
    });
  }

  @Action(TrustAction.GetBillingAccountFailure)
  GetBillingAccountFailure({ getState, setState, dispatch }: StateContext<TrustStateModel>, payload) {
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);
    setState({
      ...getState(),
      loading: false,
      error: err.message,
      data: undefined
    });
  }

  @Action(TrustAction.SetTrustFilter)
  SetTrustFilter({ getState, setState, dispatch }: StateContext<TrustStateModel>, payload) {
    const filterBy = payload.payload as string;

    setState({
      ...getState(),
      trustFilterBy: filterBy
    });
  }

  @Action(TrustAction.DonwloadBillingTrustAccount, { cancelUncompleted: true })
  DonwloadBillingTrustAccount({ getState, setState, dispatch }: StateContext<TrustStateModel>, payload) {
    const { matterId, accountId } = payload.payload as { matterId: string; accountId: string };

    return this.lcApiSvc.downloadTrustStatement(matterId, accountId).pipe(
      switchMap((response: any) => {
        const { downloadUrl } = response;
        if (downloadUrl && this.browserSvc.isBrowser) {
          const browserWindow = this.browserSvc.window.open(downloadUrl, '_blank');
          if (!browserWindow || browserWindow.closed || typeof browserWindow.closed === 'undefined') {
            return dispatch(
              new TrustAction.DonwloadBillingTrustAccountFailure('Please allow Pop up open from the site.')
            );
          }
        }
        return [];
      })
    );
  }

  @Action(TrustAction.CleanTrustFilterOption)
  CleanTrustFilterOption({ getState, setState, dispatch }: StateContext<TrustStateModel>, payload) {
    setState({
      ...getState(),
      trustFilterBy: environment.locale.billing.trust_account.filter.all,
      trustFilterOption: [
        {
          title: environment.locale.billing.trust_account.filter.all,
          value: environment.locale.billing.trust_account.filter.all
        }
      ]
    });
  }

  @Selector()
  static getError(state: TrustStateModel): string {
    if (!state) {
      return '';
    }

    return state.error;
  }

  @Selector()
  static getLoading(state: TrustStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.loading;
  }

  @Selector()
  static getTrustAccount(state: TrustStateModel): TrustStatementModel.Info[] {
    if (!state) {
      return undefined;
    }

    return state.data.trustLedgers;
  }

  @Selector()
  static getTrustFilterBy(state: TrustStateModel): string {
    if (!state) {
      return environment.locale.billing.trust_account.filter.all;
    }

    return state.trustFilterBy;
  }

  @Selector()
  static getTrustFilterOption(state: TrustStateModel): TrustModel.FilterOption[] {
    if (!state) {
      return [
        {
          title: environment.locale.billing.trust_account.filter.all,
          value: environment.locale.billing.trust_account.filter.all
        }
      ];
    }

    return state.trustFilterOption;
  }

  constructor(private lcApiSvc: LawConnectApiService, private browserSvc: BrowserService, private actions$: Actions) {}
}
