import { TrustModel } from '../../models/trust.model';

export namespace TrustAction {
  const prefix = '[Trust]';

  export const ActionTypes = {
    GET_BILLING_ACCOUNT: `${prefix} get billing account`,
    GET_BILLING_ACCOUNT_SUCCESS: `${prefix} get billing account success`,
    GET_BILLING_ACCOUNT_FAILURE: `${prefix} Failed to get billing account`,
    CANCEL_GET_BILLING_ACCOUNT: `${prefix} cancel the get billing account`,
    SET_TRUST_FILTER: `${prefix} set trust filter`,
    DOWNLOAD_BILLING_TRUST_ACCOUNT: `${prefix} download billing trust account statement`,
    DOWNLOAD_BILLING_TRUST_ACCOUNT_FAILURE: `${prefix} Failed to download trust account statement`,
    CLEAN_TRUST_FILTER_OPTION: `${prefix} clean trust filter options`
  };

  export class GetBillingAccount {
    static readonly type = ActionTypes.GET_BILLING_ACCOUNT;
    constructor(public payload: string) {} //matterId
  }

  export class GetBillingAccountSuccess {
    static readonly type = ActionTypes.GET_BILLING_ACCOUNT_SUCCESS;
    constructor(public payload: TrustModel.TrustAccount) {}
  }

  export class GetBillingAccountFailure {
    static readonly type = ActionTypes.GET_BILLING_ACCOUNT_FAILURE;
    constructor(public payload: any) {}
  }

  export class CancelGetBillingAccount {
    static readonly type = ActionTypes.CANCEL_GET_BILLING_ACCOUNT;
    constructor(public payload: any) {}
  }

  export class DonwloadBillingTrustAccount {
    static readonly type = ActionTypes.DOWNLOAD_BILLING_TRUST_ACCOUNT;
    constructor(public payload: { matterId: string; accountId: string }) {}
  }

  export class DonwloadBillingTrustAccountFailure {
    static readonly type = ActionTypes.DOWNLOAD_BILLING_TRUST_ACCOUNT_FAILURE;
    constructor(public payload: any) {}
  }

  export class SetTrustFilter {
    static readonly type = ActionTypes.SET_TRUST_FILTER;
    constructor(public payload: string) {} //filter title.
  }

  export class CleanTrustFilterOption {
    static readonly type = ActionTypes.CLEAN_TRUST_FILTER_OPTION;
    constructor(public payload: any) {}
  }
}
