import { ChangeDetectionStrategy, Component, Input, Inject, LOCALE_ID, ViewChild } from '@angular/core';
import { TrustModel } from '../../models/trust.model';

import Chart from 'chart.js';
@Component({
  selector: 'sc-trust-account-card',
  templateUrl: './trust-account-card.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustAccountCardComponent {
  @Input('bank') bank: string;
  @Input('account') accountName: string;
  @Input('account-number') accountNo: string;
  @Input('bsb') bsb: string;
  @Input('balance') balance: number;

  @ViewChild('chartRef', { static: false }) myChartRef: any;

  localeCurrency(amount: number): string {
    return TrustModel.Helper.localeCurrency(amount, this.locale);
  }

  constructor(@Inject(LOCALE_ID) private locale: string) {
    const self = this;
    setTimeout(() => {
      const ctx = this.myChartRef.nativeElement.getContext('2d');
      const myBarChart = new Chart(ctx, {
        type: 'line',
        data: {
          datasets: [
            {
              data: [200, 400, 300, 500],
              borderWidth: 0
            }
          ]
        },
        options: {
          responsive: true,
          legend: {
            display: false
          },
          tooltips: {
            enabled: false
          },
          hover: {
            animationDuration: 0
          },
          events: [],
          animation: {},
          scales: {
            xAxes: [
              {
                display: false,
                gridLines: {
                  display: false
                }
              }
            ],
            yAxes: [
              {
                display: false,
                ticks: {
                  beginAtZero: true
                }
              }
            ]
          }
        }
      });
    }, 0);
  }
}
