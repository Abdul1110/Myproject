import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { TrustModel } from '../../models/trust.model';

@Component({
  selector: 'sc-trust-multiple-actions',
  templateUrl: './trust-multiple-actions.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustMultipleActionsComponent {
  @Input('small-screen') isSmallScreen: boolean;
  @Input('trust-account-option') trustAccountOptions: TrustModel.FilterOption[];
  @Input('selected-trust-account-option') selectedTrustAccountOption: TrustModel.FilterOption;

  viewSelectedTrustAccount = TrustModel.ActionType.ViewSelectedTrustAccount;

  constructor(private customEventSvc: CustomEventService) {}

  onViewSelectedTrust(acc: TrustModel.FilterOption): void {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
      actionType: this.viewSelectedTrustAccount,
      value: {
        filterBy: acc
      }
    });
  }
}
