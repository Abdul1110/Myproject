import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { TrustModel } from '../../models/trust.model';

@Component({
  selector: 'sc-trust-multiple-actions-mobile',
  templateUrl: './trust-multiple-actions-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustMultipleActionsMobileComponent {
  @Input('data') data: any;
  @Input('display-for') displayFor: string;

  constructor(private customEventSvc: CustomEventService) {}

  prefixWithInv(invNo: string): string {
    return TrustModel.Helper.prefixWithInv(invNo);
  }

  onActionClick() {
    if (this.data) {
      const subTitle = this.prefixWithInv(this.data.invoiceNo) || this.data.transactionNo;
      this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
        actionType: TrustModel.ActionType.StatementEntryDetail,
        value: {
          title: 'Transaction Details',
          subTitle,
          displayFor: this.displayFor,
          ...this.data
        }
      });
    }
  }
}
