import { TrustStatementInvoiceCardComponent } from './trust-statement-invoice-card/trust-statement-invoice-card.component';
import { TrustStatementItemComponent } from './trust-statement-item/trust-statement-item.component';
import { TrustStatementHeaderComponent } from './trust-statement-header/trust-statement-header.component';
import { TrustAccountCardComponent } from './trust-account-card/trust-account-card.component';
import { TrustMultipleActionsComponent } from './trust-multiple-actions/trust-multiple-actions.component';
import { TrustStatementItemMobileComponent } from './trust-statement-item-mobile/trust-statement-item-mobile.component';
import { TrustDetailsMobileComponent } from './trust-details-mobile/trust-details-mobile.component';
import { TrustHeaderActionsComponent } from './trust-header-actions/trust-header-actions.component';
import { TrustMultipleActionsOptionMobileComponent } from './trust-multiple-actions-option-mobile/trust-multiple-actions-option-mobile.component';
import { TrustMultipleActionsMobileComponent } from './trust-multiple-actions-mobile/trust-multiple-actions-mobile.component';
import { TrustBalanceIndicatorComponent } from './trust-balance-indicator/trust-balance-indicator.component';

export * from './trust-statement-invoice-card/trust-statement-invoice-card.component';
export * from './trust-statement-item/trust-statement-item.component';
export * from './trust-statement-header/trust-statement-header.component';
export * from './trust-account-card/trust-account-card.component';
export * from './trust-multiple-actions/trust-multiple-actions.component';
export * from './trust-header-actions/trust-header-actions.component';
export * from './trust-statement-item-mobile/trust-statement-item-mobile.component';
export * from './trust-details-mobile/trust-details-mobile.component';
export * from './trust-multiple-actions-option-mobile/trust-multiple-actions-option-mobile.component';
export * from './trust-multiple-actions-mobile/trust-multiple-actions-mobile.component';
export * from './trust-balance-indicator/trust-balance-indicator.component';

export const trustComponents = [
  TrustHeaderActionsComponent,
  TrustStatementInvoiceCardComponent,
  TrustStatementItemComponent,
  TrustStatementHeaderComponent,
  TrustAccountCardComponent,
  TrustMultipleActionsComponent,
  TrustStatementItemMobileComponent,
  TrustDetailsMobileComponent,
  TrustMultipleActionsMobileComponent,
  TrustMultipleActionsOptionMobileComponent,
  TrustBalanceIndicatorComponent
];
