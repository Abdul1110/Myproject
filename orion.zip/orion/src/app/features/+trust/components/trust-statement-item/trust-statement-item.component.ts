import { ChangeDetectionStrategy, Component, Input, HostBinding, LOCALE_ID, Inject } from '@angular/core';
import { UUID } from 'angular2-uuid';
import { TrustModel } from '../../models/trust.model';
import { TrustStatementModel } from '../../models/trust-statement.model';
@Component({
  selector: 'sc-trust-statement-item',
  templateUrl: './trust-statement-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustStatementItemComponent {
  @Input('item-id') id: number;
  @Input('item') item: TrustStatementModel.StatementListItem;
  @Input('active') isActive: boolean;
  @Input('is-last') isLast: boolean;
  @Input('is-odd') isOdd: boolean;
  @Input('is-even') isEven: boolean;

  @HostBinding('class.mb-4') last = this.isLast;
  componentId = `${UUID.UUID()}`;

  getTransactionClass(transaction): string {
    return transaction >= 1 ? 'text-success' : transaction <= -1 ? 'text-danger' : 'text-default';
  }

  localeCurrency(amount: number): string {
    return TrustModel.Helper.localeCurrency(amount, this.locale);
  }

  getTransactionValue(transaction): any {
    return transaction >= 1 ? '+' + transaction : transaction;
  }

  constructor(@Inject(LOCALE_ID) private locale: string) {}
}
