import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { TrustModel } from '../../models/trust.model';
import { environment } from '@env/environment';

@Component({
  selector: 'sc-trust-header-actions',
  templateUrl: './trust-header-actions.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustHeaderActionsComponent {
  @Input('selected-trust-account-option') selectedTrustAccountOption: TrustModel.FilterOption;
  @Input('has-statement') hasStatement: boolean;

  trustDownload = TrustModel.ActionType.TrustDownload;
  viewSelectedTrustAccount = TrustModel.ActionType.ViewSelectedTrustAccount;

  isAllTrustAccountSelected(): boolean {
    if (!this.selectedTrustAccountOption) {
      return false;
    }
    return this.selectedTrustAccountOption.title == environment.locale.billing.trust_account.filter.all;
  }

  constructor(private customEventSvc: CustomEventService) {}

  onActionClick(actionType: string) {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
      actionType,
      value: {}
    });
  }

  onViewSelectedTrust(acc: TrustModel.FilterOption): void {
    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
      actionType: this.viewSelectedTrustAccount,
      value: {
        filterBy: acc
      }
    });
  }
}
