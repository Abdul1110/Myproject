import { ChangeDetectionStrategy, Component, HostBinding, Inject } from '@angular/core';
import { CustomEventService, BILLING_ACCOUNT_MULTIPLE_ACTIONS } from '@app/core/services';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { TrustModel } from '../../models/trust.model';

@Component({
  selector: 'sc-trust-multiple-actions-option-mobile',
  templateUrl: './trust-multiple-actions-option-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustMultipleActionsOptionMobileComponent {
  viewStatementEntryDetail = TrustModel.ActionType.StatementEntryDetail;
  viewTrustDetail = TrustModel.ActionType.TrustDetails;

  trustDetailActions = [this.viewTrustDetail];

  titles = {
    [this.viewStatementEntryDetail]: { title: 'Transaction Details', icon: 'creditcard' },
    [this.viewTrustDetail]: { title: `Trust Account Details`, icon: 'creditcard' }
  };

  constructor(
    private customEventSvc: CustomEventService,
    private bottomSheetRef: MatBottomSheetRef<TrustMultipleActionsOptionMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {}

  @HostBinding('class.x-action-list')
  keys(): string[] {
    if (!this.data || !this.titles[this.data.displayFor]) {
      return [];
    }

    if (this.trustDetailActions.includes(this.data.displayFor)) {
      return this.trustDetailActions;
    }

    return [];
  }

  onActionClick(actionType: string) {
    let subTitle = '';

    if (this.data) {
      if (actionType == this.viewStatementEntryDetail) subTitle = this.data.invoiceNo || this.data.transactionNo;
    }

    this.customEventSvc.dispatchEvent(BILLING_ACCOUNT_MULTIPLE_ACTIONS, {
      actionType,
      value: {
        title: this.titles[actionType].title,
        subTitle,
        ...this.data
      }
    });
  }

  onClose() {
    this.bottomSheetRef.dismiss();
  }
}
