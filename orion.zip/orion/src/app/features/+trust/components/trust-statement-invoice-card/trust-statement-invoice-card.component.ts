import { Component, ChangeDetectionStrategy, Input } from '@angular/core';

@Component({
  selector: 'sc-trust-statement-invoice-card',
  templateUrl: './trust-statement-invoice-card.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustStatementInvoiceCardComponent {
  @Input('total-in') totalIn: number = 0;
  @Input('total-out') totalOut: number = 0;
  @Input('in-desc') inDesc: string;
  @Input('out-desc') outDesc: string;
  @Input('reverse') reverse: boolean;
  @Input('title') title: string;
}
