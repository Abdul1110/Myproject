import { ChangeDetectionStrategy, Component, Input, Inject, LOCALE_ID } from '@angular/core';
import { TrustModel } from '../../models/trust.model';

@Component({
  selector: 'sc-trust-details-mobile',
  templateUrl: './trust-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustDetailsMobileComponent {
  @Input('data') data: any;

  localDateFormat(dt: Date): string {
    if (!dt) {
      return '';
    }
    return TrustModel.Helper.localeDate(dt, this.locale);
  }

  localCurrencyFormat(v: number): string {
    return TrustModel.Helper.localeCurrency(v, this.locale);
  }

  constructor(@Inject(LOCALE_ID) private locale: string) {}
}
