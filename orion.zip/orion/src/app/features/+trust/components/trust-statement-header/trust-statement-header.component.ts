import { ChangeDetectionStrategy, Component, Input, HostBinding } from '@angular/core';

@Component({
  selector: 'sc-trust-statement-header',
  templateUrl: './trust-statement-header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustStatementHeaderComponent {
  constructor() {}
}
