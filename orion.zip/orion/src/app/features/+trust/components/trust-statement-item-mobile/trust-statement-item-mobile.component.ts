import { ChangeDetectionStrategy, Component, Input, HostBinding, Inject, LOCALE_ID } from '@angular/core';
import { UUID } from 'angular2-uuid';
import { TrustStatementModel } from '../../models/trust-statement.model';
import { TrustModel } from '../../models/trust.model';

@Component({
  selector: 'sc-trust-statement-item-mobile',
  templateUrl: './trust-statement-item-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TrustStatementItemMobileComponent {
  @Input('item-id') id: number;
  @Input('item') item: TrustStatementModel.StatementListItem;
  @Input('active') isActive: boolean;
  @Input('is-last') isLast: boolean;

  @HostBinding('class.mb-4') last = this.isLast;

  source = TrustModel.ActionType.TrustDetails;

  componentId = `${UUID.UUID()}`;

  localDateFormat(dt: Date): string {
    return TrustModel.Helper.localeDate(dt, this.locale);
  }

  localeCurrency(amount: number): string {
    return TrustModel.Helper.localeCurrency(amount, this.locale);
  }

  constructor(@Inject(LOCALE_ID) private locale: string) {}
}
