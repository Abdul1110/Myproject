import { NgModule } from '@angular/core';
import { InlineSVGModule } from 'ng-inline-svg';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@app/shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatBottomSheetModule, MatProgressBarModule } from '@angular/material';
import { AppStateModule } from '@app/core/app-state.module';
import {
  GalaxyPreLoaderComponentModule,
  LyraDesignEmptyStateModule,
  LyraDesignPanelModule,
  LyraDesignAvatarModule,
  LyraDesignMenuModule,
  LyraDesignCommonModule,
  LyraDesignIconModule,
  LyraDesignAsideModule,
  LyraDesignMainModule,
  LyraDesignNavbarModule,
  LyraDesignCardModule,
  LyraDesignFilesModule,
  LyraDesignTabsModule,
  LyraDesignTypeModule,
  LyraDesignSectionModule
} from '@leap/lyra-design';
import { BsDropdownModule, CarouselModule } from 'ngx-bootstrap';
import { TrustRoutingModule } from './trust-routing.module';
import { trustLayouts } from './layout';
import { trustPages } from './pages';
import { trustComponents } from './components';
import { trustServices } from './services';
import { TrustStateModule } from './trust-state.module';

@NgModule({
  imports: [
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule,
    MatBottomSheetModule,
    MatProgressBarModule,
    AppStateModule,
    TrustStateModule,
    TrustRoutingModule,
    GalaxyPreLoaderComponentModule,
    LyraDesignEmptyStateModule,
    LyraDesignPanelModule,
    LyraDesignAvatarModule,
    LyraDesignMenuModule,
    LyraDesignCommonModule,
    LyraDesignIconModule,
    LyraDesignAsideModule,
    LyraDesignMainModule,
    LyraDesignNavbarModule,
    LyraDesignTabsModule,
    LyraDesignCardModule,
    LyraDesignFilesModule,
    LyraDesignTypeModule,
    LyraDesignSectionModule,
    BsDropdownModule.forRoot(),
    CarouselModule.forRoot()
  ],
  entryComponents: [...trustLayouts, ...trustPages, ...trustComponents],
  declarations: [...trustLayouts, ...trustPages, ...trustComponents],
  providers: [...trustServices]
})
export class TrustModule {}
