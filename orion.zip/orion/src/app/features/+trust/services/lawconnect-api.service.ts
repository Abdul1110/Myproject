import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LawConnectApiService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  getBillingAccount(matterId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/billing/${matterId}`;
    return this.http.get(url);
  }

  downloadTrustStatement(matterId: string, trustAccountId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/billing/${matterId}/trust/${trustAccountId}/statement`;
    return this.http.get(url);
  }
}
