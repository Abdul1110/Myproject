import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TrustHomeComponent } from './layout';
import { MatterSelectComponent } from '@app/shared/components/matter-select/matter-select.component';

const routes: Routes = [
  {
    path: '',
    component: TrustHomeComponent
  },
  {
    path: 'select',
    component: MatterSelectComponent,
    outlet: 'aside'
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TrustRoutingModule {}
