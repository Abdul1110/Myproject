import { NgModule } from '@angular/core';
import { InlineSVGModule } from 'ng-inline-svg';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { AppStateModule } from '@app/core/app-state.module';
import { SignaturesRoutingModule } from './signatures-routing.module';
import { signaturesPages } from './pages';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { MatBottomSheetModule, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { MAT_BOTTOM_SHEET_DATA } from '@angular/material';

import {
  LyraDesignEmptyStateModule,
  GalaxyPreLoaderComponentModule,
  LyraDesignPanelModule,
  LyraDesignMenuModule,
  LyraDesignAvatarModule,
  LyraDesignCommonModule,
  LyraDesignButtonModule,
  LyraDesignCardModule,
  LyraDesignAsideModule,
  LyraDesignIconModule,
  LyraDesignFormModule,
  LyraDesignTabsModule,
  LyraDesignMainModule,
  LyraDesignNavbarModule,
  LyraDesignTypeModule,
  LyraDesignFilesModule,
  LyraDesignUserModule,
  LyraDesignSectionModule,
  LyraDesignAnimationModule
} from '@leap/lyra-design';

import { signaturesLayouts } from './layout';
import { signaturesServices } from './services';
import { signaturesComponents } from './components';
import { SharedModule } from '@app/shared';
import { SignaturesStateModule } from './signatures-state.module';

@NgModule({
  imports: [
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ScrollingModule,
    SharedModule,
    AppStateModule,
    SignaturesStateModule,
    SignaturesRoutingModule,
    LyraDesignEmptyStateModule,
    GalaxyPreLoaderComponentModule,
    LyraDesignIconModule,
    LyraDesignAvatarModule,
    LyraDesignPanelModule,
    LyraDesignMenuModule,
    LyraDesignCommonModule,
    LyraDesignButtonModule,
    LyraDesignCardModule,
    LyraDesignAsideModule,
    LyraDesignFormModule,
    LyraDesignTabsModule,
    LyraDesignMainModule,
    LyraDesignNavbarModule,
    LyraDesignUserModule,
    LyraDesignFilesModule,
    LyraDesignTypeModule,
    LyraDesignSectionModule,
    LyraDesignAnimationModule,
    BsDropdownModule.forRoot(),
    ProgressbarModule.forRoot(),
    MatBottomSheetModule
  ],
  entryComponents: [...signaturesLayouts, ...signaturesPages, ...signaturesComponents],
  declarations: [...signaturesLayouts, ...signaturesPages, ...signaturesComponents],
  providers: [
    ...signaturesServices,
    { provide: MatBottomSheetRef, useValue: [] },
    { provide: MAT_BOTTOM_SHEET_DATA, useValue: [] }
  ]
})
export class SignaturesModule {}
