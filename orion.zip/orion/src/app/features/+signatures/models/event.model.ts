export namespace SignaturesEvent {
  export interface MultipleActionEventDetail {
    actionType: string;
    value: any;
  }

  export enum MultipleActionDispatchType {
    preview = 'preview',
    download = 'download',
    viewInfo = 'view-info',
    sign = 'sign',
    viewComment = 'view-comment'
  }
}
