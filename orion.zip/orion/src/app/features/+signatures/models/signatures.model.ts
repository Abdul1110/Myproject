import { CoreModel, SignatureModel } from '@app/core/models';
import { formatDate } from '@angular/common';
import { AnnotatorModel } from '@app/shared/models';

export namespace SignaturesModel {
  export interface SignatureItem extends SignatureModel.ESignature {
    fileExtension: string;
    fileSizeKb: number;
  }

  export interface PreviewDocumentRequest {
    matterId: string;
    documentId: string;
  }

  export interface DownloadDocumentRequest {
    matterId: string;
    documentId: string;
    documentName: string;
  }

  export interface LawConnectDocument {
    created: string;
    documentUrl: string;
    fileName: string;
    fileSizeKb: number;
    folderId: string;
    id: string;
    modified: string;
    name: string;
    ownerInitials: string;
    ownerName: string;
    ownerUserId: string;
    pages: number;
    thumbnailUrl: string;
    type: string;
    isCollaborationFile: boolean;
  }

  export interface LawConnectDocumentWithActivity {
    info: LawConnectDocument;
    activities: LawConnectDocumentHistory[];
  }

  export interface LawConnectDocumentHistory {
    documentId: string;
    eventDate: string;
    eventType: EventType;
    staffFirstName: string;
    staffId: string;
    staffInitials: string;
    staffLastName: string;
    userFirstName: string;
    userId: string;
    userInitials: string;
    userLastName: string;
  }

  export enum EventType {
    created = 1,
    shared = 2,
    viewed = 3,
    revokedAccess = 4,
    signed = 7,
    signingRequested = 9,
    signingDeclined = 10
  }

  export interface LawConnectDocumentAnnotation extends AnnotatorModel.DocumentAnnotation {
    events: AnnotatorModel.AnnotatedEvent[];
    user: AnnotatorModel.AnnotatedUser;
  }

  export interface LawConnectDocumentAnnotationReplied {
    id: string;
    text: string;
    annotationId: string;
    documentId: string;
    createdDate: string;
    modifiedDate: string;
    userInfo: AnnotatorModel.AnnotatedBy;
    events: AnnotatorModel.AnnotatedEvent[];
    pageId: number;
  }

  export interface LawConnectDocumentAnnotationReply {
    annotationId: string;
    text: string;
    documentId: string;
    pageId: string;
  }

  export interface UpdateAnnotation extends AnnotatorModel.AnnotationDataForUpdated {
    id: string;
    fileId: string;
    pageId: number;
    user: AnnotatorModel.AnnotatedUser;
    quote: string;
    ranges: AnnotatorModel.AnnotatedRange[];
    text: string;
  }

  export interface DocumentSignatureRequest {
    userId: string;
    orderId: string;
  }

  export interface DocumentSignature {
    url: string;
    isSucceeded: boolean;
    message: string;
    code: number;
  }

  export interface DeleteAnnotationResponse {
    success: boolean;
    annotationId: string;
  }

  export interface CommentClickToViewRequest {
    pageId: number;
    seqId: string;
  }

  export interface AnnotationRepliedList {
    [annotationId: string]: SignaturesModel.LawConnectDocumentAnnotationReplied[];
  }

  export interface NewAnnotationRequest extends AnnotatorModel.AnnotationData {
    userId: string;
    displayName: string;
  }

  export interface UpdateAnnotationRequest extends AnnotatorModel.AnnotationDataForUpdated {
    id: string;
    fileId: string;
    pageId: number;
    user: AnnotatorModel.AnnotatedUser;
    quote: string;
    ranges: AnnotatorModel.AnnotatedRange[];
    text: string;
  }

  export interface UserIsPreviewingTheDocument {
    userId: string;
    documentId: string;
  }

  export class Helper {
    static localeFormat(dt: Date, locale: string, format: string = 'mediumDate'): string {
      return formatDate(dt, format, locale);
    }

    static getDocSortingOptions(): CoreModel.ColumnSorting[] {
      return [].concat([
        <CoreModel.ColumnSorting>{ column: 'createdDate', title: 'Created', sort: 0 },
        <CoreModel.ColumnSorting>{ column: 'esignedDocumentName', title: 'Document Name', sort: 0 },
        <CoreModel.ColumnSorting>{ column: 'staffName', title: 'Owner', sort: 0 },
        <CoreModel.ColumnSorting>{ column: 'esignedDocumentStatus', title: 'Status', sort: 0 }
      ]);
    }

    static getDocDefaultSortingOption(): CoreModel.ColumnSorting {
      return <CoreModel.ColumnSorting>{ column: 'createdDate', title: 'Created', sort: 1 };
    }

    static getMatterActivityDescription(activity: LawConnectDocumentHistory, currentUserId: string): string {
      if (activity) {
        const staffName =
          activity.staffId === currentUserId ? 'You' : `<b>${activity.staffFirstName} ${activity.staffLastName}</b>`;
        const userName =
          activity.userId === currentUserId ? 'You' : `<b>${activity.userFirstName} ${activity.userLastName}</b>`;

        const formatName = (name: string) => {
          return `<b>${name}</b>`;
        };

        switch (activity.eventType) {
          case EventType.viewed:
            return `${formatName(staffName)} viewed this file`;
          case EventType.shared:
            return `${formatName(staffName)} shared this file with ${formatName(userName)}`;
          case EventType.revokedAccess:
            return `${formatName(staffName)} stopped sharing this file with ${formatName(userName)}`;
          case EventType.created:
            return `${formatName(staffName)} uploaded this file`;
          case EventType.signingRequested:
            return `${formatName(staffName)} requested eSignatures on this file`;
          case EventType.signed:
            return `${formatName(staffName)} signed this file`;
          case EventType.signingDeclined:
            return `${formatName(staffName)} declined esigning this file`;
        }
      }

      return '';
    }

    static isSignaturePendingOrDecline(data: SignaturesModel.SignatureItem): boolean {
      return (
        data &&
        (data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.Pending ||
          data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.WaitingForOthers ||
          data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.Declined)
      );
    }

    static getSignatureDetail(
      signatures: SignatureModel.ESignature[],
      matterId: string,
      documentId: string
    ): SignaturesModel.SignatureItem {
      if (matterId && documentId) {
        const result =
          signatures &&
          signatures.find(
            s =>
              s.matterId == matterId &&
              (s.esignedDocumentId == documentId ||
                s.orderId == documentId ||
                s.requestedDocuments.findIndex(x => x.id == documentId) !== -1)
          );

        return result ? { ...result, fileExtension: 'pdf', fileSizeKb: 0 } : undefined;
      }
      return undefined;
    }

    static getCommentsInAscOrder(comments: any): SignaturesModel.LawConnectDocumentAnnotation[] {
      if (!comments || comments.length == 0) {
        return [];
      }

      return comments
        .sort((a, b) => {
          if (b.creationDate > a.creationDate) {
            return -1;
          }
          if (b.creationDate < a.creationDate) {
            return 1;
          }
          return 0;
        })
        .map((c, i) => <SignaturesModel.LawConnectDocumentAnnotation>{ ...c, annotationSeq: i + 1 });
    }

    static getCommentSeqs(comments: SignaturesModel.LawConnectDocumentAnnotation[]): AnnotatorModel.AnnotationSeq[] {
      if (!comments || comments.length == 0) {
        return [];
      }

      return comments.map(
        x =>
          <AnnotatorModel.AnnotationSeq>{
            annotationId: x.id,
            seq: x.annotationSeq || 1,
            quote: x.quote,
            page: x.pageId
          }
      );
    }

    static getLatestRepliedAfterDeletingComment(
      replied: AnnotationRepliedList,
      deletedAnnotationId: string
    ): AnnotationRepliedList {
      let newReplied = {};
      const oldReplied = replied;
      Object.keys(oldReplied).forEach(annotationId => {
        if (annotationId !== deletedAnnotationId) {
          newReplied[annotationId] = oldReplied[annotationId];
        }
      });
      return { ...newReplied };
    }

    static getLatestCommentSeqsAfterDeletingComment(
      commentSeqs: AnnotatorModel.AnnotationSeq[],
      deletedAnnotationId: string
    ): AnnotatorModel.AnnotationSeq[] {
      const annotationSeqs = commentSeqs.filter(x => x.annotationId != deletedAnnotationId) || [];
      const updatedAnnotationSeq =
        annotationSeqs && annotationSeqs.length > 0
          ? annotationSeqs.map((c, i) => <AnnotatorModel.AnnotationSeq>{ ...c, seq: i + 1 })
          : annotationSeqs;
      return updatedAnnotationSeq || [];
    }

    static getLatestCommentsAfterDeletingComment(
      oldAnnotations: SignaturesModel.LawConnectDocumentAnnotation[],
      deletedAnnotationId: string
    ): SignaturesModel.LawConnectDocumentAnnotation[] {
      const annotations = oldAnnotations.filter(x => x.id !== deletedAnnotationId);
      const updatedAnnotations =
        annotations && annotations.length > 0
          ? annotations.map((c, i) => <SignaturesModel.LawConnectDocumentAnnotation>{ ...c, annotationSeq: i + 1 })
          : annotations;
      return updatedAnnotations || [];
    }

    private static mergeTwoArrays(a: any, b: any): any {
      return a && a.length > 0 ? a.concat(b) : [].concat(b);
    }
  }
}
