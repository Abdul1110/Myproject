import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SignaturesModel } from '../models/signatures.model';
import { AnnotatorModel } from '@app/shared/models';

@Injectable({
  providedIn: 'root'
})
export class LawConnectApiService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  getSignaturesDocumentDownloadUrl(matterId: string, documentId: string, isPreview: boolean = true): Observable<any> {
    const url = `${this.endpoint}/api/document/${documentId}/collaboration/download?preview=${isPreview}&matterId=${matterId}`;
    return this.http.get(url);
  }

  download(url: string): Observable<any> {
    return this.http.get(url, { responseType: 'blob' });
  }

  getSignatureDocumentDownloadUrl(docId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/${docId}/download?preview=false`;
    return this.http.get(url);
  }

  getDocumentActivities(docId: string): Observable<SignaturesModel.LawConnectDocumentWithActivity> {
    const url = `${this.endpoint}/api/document/details`;
    return this.http.post<SignaturesModel.LawConnectDocumentWithActivity>(url, { documentId: docId });
  }

  getDocumentAnnotations(docId: string): Observable<SignaturesModel.LawConnectDocumentAnnotation[]> {
    const url = `${this.endpoint}/api/document/annotations`;
    return this.http.post<SignaturesModel.LawConnectDocumentAnnotation[]>(url, { documentId: docId });
  }

  getDocumentAnnotationsReplied(annotationIds: string[]): Observable<SignaturesModel.AnnotationRepliedList> {
    const url = `${this.endpoint}/api/document/annotations/replied`;
    return this.http.post<SignaturesModel.AnnotationRepliedList>(url, {
      annotationIds: annotationIds
    });
  }

  getReplyDocumentAnnotation(
    reply: SignaturesModel.LawConnectDocumentAnnotationReply
  ): Observable<SignaturesModel.LawConnectDocumentAnnotationReplied> {
    const url = `${this.endpoint}/api/document/annotations/replied/new`;
    return this.http.post<SignaturesModel.LawConnectDocumentAnnotationReplied>(url, { reply: reply });
  }

  updateDocumentAnnotation(update: SignaturesModel.UpdateAnnotation): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/update/${update['id']}`;
    return this.http.put<SignaturesModel.UpdateAnnotation>(url, { ...update });
  }

  addDocumentAnnotation(add: AnnotatorModel.NewAnnotation): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/add`;
    return this.http.post<AnnotatorModel.NewAnnotation>(url, { ...add });
  }

  deleteDocumentAnnotation(annotationId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/delete/${annotationId}`;
    return this.http.delete<AnnotatorModel.DeleteAnnotation>(url);
  }

  deleteDocumentReply(commentId: string): Observable<any> {
    const url = `${this.endpoint}/api/document/annotations/replied/delete/${commentId}`;
    return this.http.delete(url);
  }

  replyDocumentAnnotation(
    reply: SignaturesModel.LawConnectDocumentAnnotationReply
  ): Observable<SignaturesModel.LawConnectDocumentAnnotationReplied> {
    const url = `${this.endpoint}/api/document/annotations/replied/new`;
    return this.http.post<SignaturesModel.LawConnectDocumentAnnotationReplied>(url, { reply: reply });
  }

  getSignatureUrl(order: SignaturesModel.DocumentSignatureRequest): Observable<SignaturesModel.DocumentSignature> {
    const url = `${this.endpoint}/api/document/signature`;
    return this.http.post<SignaturesModel.DocumentSignature>(url, { ...order });
  }

  activeUserInDocument(documentId: string, userId: string) {
    const url = `${this.endpoint}/api/document/activeuserindocument`;
    const req = { documentId, userId };
    return this.http.post(url, req);
  }

  activeUserHeartBeat(documentId: string, userId: string) {
    const url = `${this.endpoint}/api/document/activeuserheartbeat`;
    const req = { documentId, userId };
    return this.http.put(url, req);
  }
}
