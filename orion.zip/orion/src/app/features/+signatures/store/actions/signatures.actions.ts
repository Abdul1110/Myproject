import { SignaturesModel } from '../../models/signatures.model';
import { AnnotatorModel } from '@app/shared/models';
import { SignatureModel } from '@app/core/models';

export namespace SignaturesAction {
  const prefix = '[Signatures]';

  export const ActionTypes = {
    GET_DOCUMENT_ACTIVITY: `${prefix} get document activity`,
    GET_DOCUMENT_ACTIVITY_SUCCESS: `${prefix} get document activity success`,
    GET_DOCUMENT_ACTIVITY_FAILURE: `${prefix} Failed to get document activity`,

    GET_DOCUMENT_ANNOTATION: `${prefix} get document annotation`,
    GET_DOCUMENT_ANNOTATION_SUCCESS: `${prefix} get document annotation success`,
    GET_DOCUMENT_ANNOTATION_FAILURE: `${prefix} Failed to get document annotation`,

    GET_DOCUMENT_REPLIED: `${prefix} get document replied`,
    GET_DOCUMENT_REPLIED_SUCCESS: `${prefix} get document replied success`,
    GET_DOCUMENT_REPLIED_FAILURE: `${prefix} Failed to get document replied`,

    DELETE_REPLIED: `${prefix} delete document replied`,
    DELETE_REPLIED_SUCCESS: `${prefix} delete document replied success`,
    DELETE_REPLIED_FAILURE: `${prefix} Failed to delete document replied`,

    GET_SIGNATURE_URL: `${prefix} get signature url`,
    GET_SIGNATURE_URL_SUCCESS: `${prefix} get signature url success`,
    GET_SIGNATURE_URL_FAILURE: `${prefix} Failed to get signature url`,
    LOAD_SIGNATURE_PAGE_FAILURE: `${prefix} Failed to load signature page`,
    USER_SIGNATURE_STATUS: `${prefix} user signature status`,

    PREVIEW_DOCUMENT: `${prefix} preview document`,
    PREVIEW_DOCUMENT_SUCCESS: `${prefix} preview document succcess`,
    PREVIEW_DOCUMENT_FAILURE: `${prefix} Failed to preview document`,
    DOWNLOAD_DOCUMENT: `${prefix} download document`,
    DOWNLOAD_DOCUMENT_SUCCESS: `${prefix} download document succcess`,
    DOWNLOAD_DOCUMENT_FAILURE: `${prefix} Failed to download document`,

    REPLY_COMMENT: `${prefix} reply comment`,
    REPLY_COMMENT_SUCCESS: `${prefix} reply comment success`,
    REPLY_COMMENT_FAILURE: `${prefix} Failed to reply comment`,

    DELETE_ANNOTATION: `${prefix} delete annotation`,
    DELETE_ANNOTATION_SUCCESS: `${prefix} delete annotation success`,
    DELETE_ANNOTATION_FAILURE: `${prefix} Failed to delete annotation`,

    ADD_ANNOTATION: `${prefix} add annotation`,
    ADD_ANNOTATION_SUCCESS: `${prefix} add annotation success`,
    ADD_ANNOTATION_FAILURE: `${prefix} Failed to add annotation`,

    UPDATE_ANNOTATION: `${prefix} update annotation`,
    UPDATE_ANNOTATION_SUCCESS: `${prefix} update annotation success`,
    UPDATE_ANNOTATION_FAILURE: `${prefix} Failed to update annotation`,

    START_ACTIVE_USER_IN_DOCUMENT: `${prefix} start active user in document`,
    UPDATE_ACTIVE_USER_HEARTBEAT: `${prefix} update active user heartbeat`
  };

  export class StartActiveUserInDocument {
    static readonly type = ActionTypes.START_ACTIVE_USER_IN_DOCUMENT;
    constructor(public payload: SignaturesModel.UserIsPreviewingTheDocument) {}
  }

  export class UpdateActiveUserHeartBeat {
    static readonly type = ActionTypes.UPDATE_ACTIVE_USER_HEARTBEAT;
    constructor(public payload: SignaturesModel.UserIsPreviewingTheDocument) {}
  }

  export class GetDocumentActivity {
    static readonly type = ActionTypes.GET_DOCUMENT_ACTIVITY;
    constructor(public payload: string) {} //document id
  }

  export class GetDocumentActivitySuccess {
    static readonly type = ActionTypes.GET_DOCUMENT_ACTIVITY_SUCCESS;
    constructor(public payload: SignaturesModel.LawConnectDocumentWithActivity) {}
  }

  export class GetDocumentActivityFailure {
    static readonly type = ActionTypes.GET_DOCUMENT_ACTIVITY_FAILURE;
    constructor(public payload: any) {}
  }

  export class GetDocumentAnnotation {
    static readonly type = ActionTypes.GET_DOCUMENT_ANNOTATION;
    constructor(public payload: string) {} //document id
  }

  export class GetDocumentAnnotationSuccess {
    static readonly type = ActionTypes.GET_DOCUMENT_ANNOTATION_SUCCESS;
    constructor(public payload: SignaturesModel.LawConnectDocumentAnnotation[]) {}
  }

  export class GetDocumentAnnotationFailure {
    static readonly type = ActionTypes.GET_DOCUMENT_ANNOTATION_FAILURE;
    constructor(public payload: any) {}
  }

  export class GetDocumentReplied {
    static readonly type = ActionTypes.GET_DOCUMENT_REPLIED;
    constructor(public payload: string[]) {} // annotation ids
  }

  export class GetDocumentRepliedSuccess {
    static readonly type = ActionTypes.GET_DOCUMENT_REPLIED_SUCCESS;
    constructor(public payload: SignaturesModel.AnnotationRepliedList) {}
  }

  export class GetDocumentRepliedFailure {
    static readonly type = ActionTypes.GET_DOCUMENT_REPLIED_FAILURE;
    constructor(public payload: any) {}
  }

  export class DeleteReplied {
    static readonly type = ActionTypes.DELETE_REPLIED;
    constructor(public payload: AnnotatorModel.DeleteAnnotationReply) {}
  }

  export class DeleteRepliedSuccess {
    static readonly type = ActionTypes.DELETE_REPLIED_SUCCESS;
    constructor(public payload: any) {}
  }

  export class DeleteRepliedFailure {
    static readonly type = ActionTypes.DELETE_REPLIED_FAILURE;
    constructor(public payload: { data: AnnotatorModel.DeleteAnnotationReply; err: any }) {}
  }

  export class GetSignatureUrl {
    static readonly type = ActionTypes.GET_SIGNATURE_URL;
    constructor(public payload: SignaturesModel.DocumentSignatureRequest) {}
  }

  export class GetSignatureUrlSuccess {
    static readonly type = ActionTypes.GET_SIGNATURE_URL_SUCCESS;
    constructor(public payload: SignaturesModel.DocumentSignature) {}
  }

  export class GetSignatureUrlFailure {
    static readonly type = ActionTypes.GET_SIGNATURE_URL_FAILURE;
    constructor(public payload: any) {}
  }

  export class LoadSignaturePageFailure {
    static readonly type = ActionTypes.LOAD_SIGNATURE_PAGE_FAILURE;
    constructor(public payload: any) {}
  }

  export class UserSignatureStatus {
    static readonly type = ActionTypes.USER_SIGNATURE_STATUS;
    constructor(public payload: { message: string }) {}
  }

  export class PreviewDocument {
    static readonly type = ActionTypes.PREVIEW_DOCUMENT;
    constructor(public payload: SignaturesModel.PreviewDocumentRequest) {}
  }

  export class PreviewDocumentSuccess {
    static readonly type = ActionTypes.PREVIEW_DOCUMENT_SUCCESS;
    constructor(public payload: string) {}
  }

  export class PreviewDocumentFailure {
    static readonly type = ActionTypes.PREVIEW_DOCUMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class DownloadDocument {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT;
    constructor(public payload: SignaturesModel.DownloadDocumentRequest) {}
  }

  export class DownloadDocumentSuccess {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT_SUCCESS;
    constructor() {}
  }

  export class DownloadDocumentFailure {
    static readonly type = ActionTypes.DOWNLOAD_DOCUMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class ReplyComment {
    static readonly type = ActionTypes.REPLY_COMMENT;
    constructor(public payload: SignaturesModel.LawConnectDocumentAnnotationReply) {}
  }

  export class ReplyCommentSuccess {
    static readonly type = ActionTypes.REPLY_COMMENT_SUCCESS;
    constructor(public payload: SignaturesModel.LawConnectDocumentAnnotationReplied) {}
  }

  export class ReplyCommentFailure {
    static readonly type = ActionTypes.REPLY_COMMENT_FAILURE;
    constructor(public payload: any) {}
  }

  export class DeleteAnnotation {
    static readonly type = ActionTypes.DELETE_ANNOTATION;
    constructor(public payload: string) {} //annotationId
  }

  export class DeleteAnnotationSuccess {
    static readonly type = ActionTypes.DELETE_ANNOTATION_SUCCESS;
    constructor(public payload: SignaturesModel.DeleteAnnotationResponse) {}
  }

  export class DeleteAnnotationFailure {
    static readonly type = ActionTypes.DELETE_ANNOTATION_FAILURE;
    constructor(public payload: any) {}
  }

  export class AddAnnotation {
    static readonly type = ActionTypes.ADD_ANNOTATION;
    constructor(public payload: SignaturesModel.NewAnnotationRequest) {}
  }

  export class AddAnnotationSuccess {
    static readonly type = ActionTypes.ADD_ANNOTATION_SUCCESS;
    constructor(public payload: boolean) {} // success or fail
  }

  export class AddAnnotationFailure {
    static readonly type = ActionTypes.ADD_ANNOTATION_FAILURE;
    constructor(public payload: any) {}
  }

  export class UpdateAnnotation {
    static readonly type = ActionTypes.UPDATE_ANNOTATION;
    constructor(public payload: SignaturesModel.NewAnnotationRequest) {}
  }

  export class UpdateAnnotationSuccess {
    static readonly type = ActionTypes.UPDATE_ANNOTATION_SUCCESS;
    constructor(public payload: boolean) {} // success or fail
  }

  export class UpdateAnnotationFailure {
    static readonly type = ActionTypes.UPDATE_ANNOTATION_FAILURE;
    constructor(public payload: any) {}
  }
}
