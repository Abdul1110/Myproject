import { State, Action, StateContext } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { switchMap, catchError, map } from 'rxjs/operators';
import { saveAs as FileSaver } from 'file-saver';

import { SignaturesAction } from '../actions';
import { SignaturesModel } from '../../models/signatures.model';
import { LawConnectApiService } from '../../services';
import { AnnotatorModel } from '@app/shared/models';
import { UUID } from 'angular2-uuid';
import { of } from 'rxjs';

export interface SignaturesStateModel {
  error: string;
  loading: boolean;
}

@State<SignaturesStateModel>({
  name: 'signatures',
  defaults: {
    error: undefined,
    loading: false
  }
})
export class SignaturesState {
  constructor(private browserSvc: BrowserService, private lcApiSvc: LawConnectApiService) {}

  // Email depends on this to send out list of changes at scheduled time e.g. end of day.
  @Action(SignaturesAction.StartActiveUserInDocument)
  StartActiveUserInDocument({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const { userId, documentId } = payload.payload as SignaturesModel.UserIsPreviewingTheDocument;
    return this.lcApiSvc.activeUserInDocument(documentId, userId).pipe(
      catchError(err => {
        // it is ok to ignore the error; normally, it has been notified before and still active.
        return of();
      })
    );
  }

  // Email depends on this to send out list of changes at scheduled time e.g. end of day.
  @Action(SignaturesAction.UpdateActiveUserHeartBeat)
  UpdateActiveUserHeartBeat({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const { userId, documentId } = payload.payload as SignaturesModel.UserIsPreviewingTheDocument;

    return this.lcApiSvc.activeUserHeartBeat(documentId, userId).pipe(
      catchError(err => {
        // it is ok to ignore the error; normally, it has expired.
        return of();
      })
    );
  }

  @Action(SignaturesAction.GetDocumentActivity, { cancelUncompleted: true })
  GetDocumentActivity({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const documentId = payload.payload as string;

    const activity$ = this.lcApiSvc.getDocumentActivities(documentId);

    return activity$.pipe(
      switchMap(response => dispatch(new SignaturesAction.GetDocumentActivitySuccess(response))),
      catchError(error => dispatch(new SignaturesAction.GetDocumentActivityFailure(error)))
    );
  }

  @Action(SignaturesAction.GetDocumentAnnotation)
  GetDocumentAnnotation({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const documentId = payload.payload as string;

    const annotation$ = this.lcApiSvc.getDocumentAnnotations(documentId);

    return annotation$.pipe(
      switchMap(response => dispatch(new SignaturesAction.GetDocumentAnnotationSuccess(response))),
      catchError(error => dispatch(new SignaturesAction.GetDocumentAnnotationFailure(error)))
    );
  }

  @Action(SignaturesAction.GetDocumentReplied)
  GetDocumentReplied({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const annotationIds = payload.payload as string[];

    const replied$ = this.lcApiSvc.getDocumentAnnotationsReplied(annotationIds);

    return replied$.pipe(
      switchMap(response => dispatch(new SignaturesAction.GetDocumentRepliedSuccess(response))),
      catchError(error => dispatch(new SignaturesAction.GetDocumentRepliedFailure(error)))
    );
  }

  @Action(SignaturesAction.DeleteReplied)
  DeleteReplied({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const state = getState();
    const data = payload.payload as AnnotatorModel.DeleteAnnotationReply;

    if (!data || !data.annotationId || !data.replyId) {
      return;
    }

    return this.lcApiSvc.deleteDocumentReply(data.replyId).pipe(
      map(deleted =>
        dispatch(
          new SignaturesAction.DeleteRepliedSuccess({
            success: deleted,
            annotationId: data.annotationId,
            replyId: data.replyId
          })
        )
      ),
      catchError(error => dispatch(new SignaturesAction.DeleteRepliedFailure({ data, err: error })))
    );
  }

  @Action(SignaturesAction.GetSignatureUrl, { cancelUncompleted: true })
  GetSignatureUrl({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const state = getState();
    const data = payload.payload as SignaturesModel.DocumentSignatureRequest;

    if (!data || !data.orderId || !data.userId) {
      return;
    }

    return this.lcApiSvc.getSignatureUrl(data).pipe(
      map(signature => dispatch(new SignaturesAction.GetSignatureUrlSuccess({ ...signature, ...data }))),
      catchError(error => dispatch(new SignaturesAction.GetSignatureUrlFailure(error)))
    );
  }

  @Action(SignaturesAction.PreviewDocument, { cancelUncompleted: true })
  PreviewDocument({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { matterId, documentId } = payload.payload as SignaturesModel.PreviewDocumentRequest;

    const downloadSvc = this.lcApiSvc.getSignatureDocumentDownloadUrl(documentId);

    return downloadSvc.pipe(
      switchMap(response => dispatch(new SignaturesAction.PreviewDocumentSuccess(response.downloadUrl))),
      catchError(error => dispatch(new SignaturesAction.PreviewDocumentFailure(error)))
    );
  }

  @Action(SignaturesAction.DownloadDocument, { cancelUncompleted: true })
  DownloadDocument({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    if (!this.browserSvc.isBrowser) {
      return;
    }

    const { matterId, documentId, documentName } = payload.payload as SignaturesModel.DownloadDocumentRequest;

    const downloadSvc = this.lcApiSvc.getSignatureDocumentDownloadUrl(documentId);

    return downloadSvc.pipe(
      switchMap(res => this.lcApiSvc.download(res.downloadUrl)),
      map(bl => FileSaver.saveAs(bl, documentName)),
      map(() => dispatch(new SignaturesAction.DownloadDocumentSuccess())),
      catchError(error => dispatch(new SignaturesAction.DownloadDocumentFailure(error)))
    );
  }

  @Action(SignaturesAction.ReplyComment)
  ReplyComment({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const reply = payload.payload as SignaturesModel.LawConnectDocumentAnnotationReply;
    const detail = <SignaturesModel.LawConnectDocumentAnnotationReply>{
      ...reply
    };

    return this.lcApiSvc.replyDocumentAnnotation(detail).pipe(
      map(replied => dispatch(new SignaturesAction.ReplyCommentSuccess(replied))),
      catchError(error => dispatch(new SignaturesAction.ReplyCommentFailure(error)))
    );
  }

  @Action(SignaturesAction.DeleteAnnotation)
  DeleteAnnotation({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const state = getState();
    const annotationId = payload.payload as string;

    if (!annotationId) {
      return;
    }

    return this.lcApiSvc.deleteDocumentAnnotation(annotationId).pipe(
      map(deleted => dispatch(new SignaturesAction.DeleteAnnotationSuccess({ success: !!deleted, annotationId }))),
      catchError(error => dispatch(new SignaturesAction.DeleteAnnotationFailure(error)))
    );
  }

  @Action(SignaturesAction.AddAnnotation)
  AddAnnotation({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const data = payload.payload as SignaturesModel.NewAnnotationRequest;

    if (!data) {
      return;
    }

    const { userId, displayName, quote, ranges, comment, aboutPage, allowAnyoneView } = data;
    const user = <AnnotatorModel.AnnotatedUser>{ userId, userName: displayName };
    const { page, fileId } = aboutPage;
    const readPermission = allowAnyoneView ? [] : [userId];
    const permissions = <AnnotatorModel.AnnotatedPermission>{
      admin: [userId],
      delete: [userId],
      read: readPermission,
      update: [userId]
    };

    const newAnnotation = <AnnotatorModel.NewAnnotation>{
      fileId,
      id: UUID.UUID(),
      user,
      pageId: page,
      permissions,
      quote,
      ranges,
      text: comment
    };

    return this.lcApiSvc.addDocumentAnnotation(newAnnotation).pipe(
      map(updated => dispatch(new SignaturesAction.AddAnnotationSuccess(updated && !!updated['id']))),
      catchError(error => dispatch(new SignaturesAction.AddAnnotationFailure(error)))
    );
  }

  @Action(SignaturesAction.UpdateAnnotation)
  UpdateAnnotation({ getState, setState, dispatch }: StateContext<SignaturesStateModel>, payload) {
    const state = getState();
    const data = payload.payload as SignaturesModel.NewAnnotationRequest;

    if (!data || !data.annotationId) {
      return;
    }

    const { userId, displayName, quote, ranges, comment, aboutPage, allowAnyoneView, aboutUpdate } = data;
    const { page, fileId } = aboutPage;
    const { creationDate, events, isDuringUpdate, oldText, versionId } = aboutUpdate;

    const user = <AnnotatorModel.AnnotatedUser>{ userId, userName: displayName };
    const updateDate = new Date().toString();
    const readPermission = allowAnyoneView ? [] : [userId];
    const permissions = <AnnotatorModel.AnnotatedPermission>{
      admin: [userId],
      delete: [userId],
      read: readPermission,
      update: [userId]
    };

    const updatedAnnotation = <SignaturesModel.UpdateAnnotationRequest>{
      fileId,
      id: data.annotationId,
      user,
      pageId: page,
      permissions,
      quote,
      ranges,
      text: comment,
      creationDate,
      events,
      isDuringUpdate,
      oldText,
      updateDate,
      versionId
    };

    return this.lcApiSvc.updateDocumentAnnotation(updatedAnnotation).pipe(
      map(updated => dispatch(new SignaturesAction.UpdateAnnotationSuccess(updated.success))),
      catchError(error => dispatch(new SignaturesAction.UpdateAnnotationFailure(error)))
    );
  }
}
