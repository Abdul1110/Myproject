import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignaturesHomeComponent } from './layout';
import { SignaturesDocumentSignComponent, SignaturesDocumentPreviewComponent } from './pages';
import { MatterSelectComponent } from '@app/shared/components/matter-select/matter-select.component';

const routes: Routes = [
  {
    path: '',
    component: SignaturesHomeComponent
  },
  {
    path: ':documentId',
    component: SignaturesHomeComponent,
    children: [
      {
        path: 'preview',
        component: SignaturesDocumentPreviewComponent
      },
      {
        path: 'sign',
        component: SignaturesDocumentSignComponent
      },
      {
        path: 'select',
        component: MatterSelectComponent,
        outlet: 'aside'
      }
    ]
  },
  {
    path: 'select',
    component: MatterSelectComponent,
    outlet: 'aside'
  },
  {
    path: '**',
    component: SignaturesHomeComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SignaturesRoutingModule {}
