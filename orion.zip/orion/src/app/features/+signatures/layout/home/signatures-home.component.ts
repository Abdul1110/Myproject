import { Component, HostBinding, HostListener, Inject, LOCALE_ID } from '@angular/core';
import { Subject, Observable, merge, fromEvent } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { OnDestroy, OnInit } from '@angular/core';
import { Store, Select, ofActionSuccessful, Actions } from '@ngxs/store';
import { ActivatedRoute, Params } from '@angular/router';
import { xAnimationAsideCollapse } from '@app/shared/components/animation/animation';
import { MatBottomSheet } from '@angular/material';

import { AppState } from '@app/core/store/states';
import {
  PopulateMatter,
  GetSignaturesStart,
  GetSignaturesSuccess,
  SetNavigationActionId,
  GetSignaturesFailure,
  GetNotification
} from '@app/core/store/actions';
import { CoreModel, NodeModel } from '@app/core/models';
import {
  PubNubService,
  CustomEventService,
  SIGNATURES_SIDE_TAB_SWITCH,
  SIGNATURES_LIST_FILE_PREVIEW,
  SIGNATURES_SIDE_TAB_TOGGLE,
  SIGNATURES_MULTIPLE_ACTIONS,
  SIGNATURES_MULTIPLE_ACTIONS_OPEN,
  SIGNATURES_LIST_FILE_SIGN,
  SIGNATURES_LIST_VIEW,
  SIGNATURES_PREVIEW_HEADER_DISPLAY,
  NAVIGATION_SIDE_BAR_TOGGLE,
  MATTERS_SELECT_CLOSED,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED,
  NavigationService
} from '@app/core/services';

import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { environment } from '@env/environment';
import { SignaturesViewDetailsMobileComponent, SignaturesSideMobileComponent } from '../../pages';
import { UUID } from 'angular2-uuid';
import { SignaturesAction } from '../../store';
import { SignaturesEvent } from '../../models/event.model';
import { SignaturesModel } from '../../models/signatures.model';
import { SideNavigationModel } from '@app/shared/models';

const { locale } = environment;
const icon = locale.global.menu.signatures.icon;

@Component({
  selector: 'sc-signatures-home',
  templateUrl: './signatures-home.component.html',
  animations: [xAnimationAsideCollapse]
})
export class SignaturesHomeComponent implements OnDestroy, OnInit {
  @HostBinding('class') classes;
  private pubNubSub: CoreModel.PubNubSubscription;
  private destroy$ = new Subject<boolean>();

  isSmallScreen$: Observable<boolean>;
  showHeader = true;
  isPreviewMode = false;
  isSignatureMode = false;
  matterId = '';
  documentId = '';
  documentName = '';
  matterName = '';
  firmId = '';
  asideDetails = true;
  isDownloading = false;

  @Select(AppState.getLoginUser) logonUser$: Observable<CoreModel.LogonUserInfo>;

  @Select(AppState.getDocumentsByMatter) matterDocs$: Observable<{ [matterId: string]: NodeModel.LawConnectNode[] }>;

  renderListView(): void {
    this.isPreviewMode = false;
    this.isSignatureMode = false;

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${this.matterId}/signatures/${this.documentId || ''}`,
      queryParams: <Params>{
        t: UUID.UUID()
      }
    });
  }

  getFirmName(firm: CoreModel.FirmDetail): string {
    return (firm && firm.name) || locale.matters.title;
  }

  getNavbarIcon(): string {
    return this.isPreviewMode || this.isSignatureMode ? 'Back' : icon;
  }

  openGlobalActionSheet(): void {
    this.bottomSheet.open(SignaturesViewDetailsMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { isGlobal: true, title: 'Please select' }
    });
  }

  openActionSheet(): void {
    const signatureDetail = SignaturesModel.Helper.getSignatureDetail(
      this.store.selectSnapshot(AppState.getSignatures),
      this.matterId,
      this.documentId
    );

    if (signatureDetail) {
      const title = CoreModel.Helper.getValidDocumentNameWithExtension(signatureDetail.esignedDocumentName, 'pdf');
      const subTitle = `Created on ${SignaturesModel.Helper.localeFormat(signatureDetail.createdDate, this.locale)}`;
      this.bottomSheet.open(SignaturesViewDetailsMobileComponent, {
        panelClass: 'x-bottom-sheet',
        data: { isGlobal: false, ...signatureDetail, title, subTitle, hidePreview: true }
      });
    }
  }

  documentTitle(): string {
    return this.documentName ? this.documentName : 'Signature Requests';
  }

  getMatterName(): string {
    return this.matterName;
  }

  showSideDetail(isSmallScreen: boolean): boolean {
    return !isSmallScreen && this.asideDetails;
  }

  toggleAside(): void {
    this.asideDetails = !this.asideDetails;
  }

  downloadDocument(matterId: string, documentId: string, documentName: string): void {
    this.isDownloading = true;
    this.updateFromPathParams(matterId);
    this.updateDocumentName(matterId, documentId);

    if (documentName) {
      this.store.dispatch(
        new SignaturesAction.DownloadDocument({
          matterId,
          documentId,
          documentName
        })
      );
      return;
    }

    this.isDownloading = false;
  }

  gotoHomeView(): void {
    this.renderListView();
    this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_TAB_SWITCH, {
      tabId: 'details',
      esignedDocumentId: this.documentId
    });
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
  }

  layoutCss(isPreview: boolean): string {
    if (isPreview) {
      return 'position-relative h-100 overflow-auto x-scroll-hidden';
    }
    return 'layout-column position-relative h-100';
  }

  constructor(
    private store: Store,
    private pubNubSvc: PubNubService,
    private actions$: Actions,
    private appActionSvc: AppActionService,
    private route: ActivatedRoute,
    private bottomSheet: MatBottomSheet,
    private customEventSvc: CustomEventService,
    private navigationSvc: NavigationService,
    @Inject(LOCALE_ID) private locale: string
  ) {
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, {
      actionId: SideNavigationModel.SideActionId.signatures
    });

    this.updateFromPathParams();
    this.updateMatterName(this.matterId);

    this.triggerRecentNotificationDataPulledIfCountZero();
    this.store.dispatch([new GetSignaturesStart(false)]);

    this.classes = 'lt-container bg-light-secondary';

    if (this.matterId && this.documentId) {
      this.updateDocumentName(this.matterId, this.documentId, '', true);
    }

    // handle no matter match from the list.
    if (
      !this.matterName &&
      !CoreModel.Helper.getMatterDetail(this.matterId, this.store.selectSnapshot(AppState.getMattersByFirm))
    ) {
      this.store.dispatch(new GetSignaturesFailure('No matter detail available'));
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/signatures/${this.documentId || ''}`,
        outlet: 'aside',
        outletPath: 'select'
      });
    }
  }

  ngOnInit() {
    this.isSmallScreen$ = this.appActionSvc.isSmallScreen$;
    this.store.dispatch(new SetNavigationActionId(SideNavigationModel.SideActionId.signatures));

    merge(
      this.logonUserSideEffect$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.previewDocumentSideEffect$(),
      this.signDocumentSideEffect$(),
      this.getDownloadDocumentSuccessSideEffect$(),
      this.getDownloadDocumentFailureSideEffect$(),
      this.getMattersSuccessSideEffect$(),
      this.listenToRemoteSideDetailToggleRequestSideEffect$(),
      this.listenToMobileActionSideEffect$(),
      this.listenToMobileActionOpenRequestSideEffect$(),
      this.getSignatureDetailFSuccess$(),
      this.signatureDocumentListViewSideEffect$(),
      this.showOrHideHeaderSideEffect$(),
      this.listenToMatterSelectedFromOptions$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);

    if (this.pubNubSub) {
      this.pubNubSub.unsubscribe();
    }
  }

  private triggerRecentNotificationDataPulledIfCountZero(): void {
    const user = this.store.selectSnapshot(AppState.getLoginUser);
    const notificationCount = this.store.selectSnapshot(AppState.getNotificationCount) || 0;
    user && user.userId && notificationCount == 0 && this.store.dispatch(new GetNotification(user.userId));
  }

  private openMobileItemActionSheet(data: any): void {
    this.bottomSheet.open(SignaturesViewDetailsMobileComponent, {
      panelClass: 'x-bottom-sheet',
      data: { ...data, isGlobal: false }
    });
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      this.updateFromPathParams(matterId);
      this.updateMatterName(this.matterId);
    });
  }

  private getSignatureDetailFSuccess$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesSuccess),
      tap(e => {
        this.updateDocumentName(this.matterId, this.documentName);
      })
    );
  }

  private getMattersSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateMatter),
      tap(success => this.updateMatterName(this.matterId))
    );
  }

  private updateFromPathParams(matterId: string = undefined): void {
    this.documentId = (this.route.snapshot.params && this.route.snapshot.params['documentId']) || '';
    this.matterId = matterId || (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';
    this.isPreviewMode =
      this.route.snapshot &&
      this.route.snapshot.firstChild &&
      this.route.snapshot.firstChild.routeConfig.path.toLowerCase() == 'preview';

    this.isSignatureMode =
      this.route.snapshot &&
      this.route.snapshot.firstChild &&
      this.route.snapshot.firstChild.routeConfig.path.toLowerCase() == 'sign';
  }

  private updateMatterName(matterId: string): void {
    const matterDetail = CoreModel.Helper.getMatterDetail(
      matterId,
      this.store.selectSnapshot(AppState.getMattersByFirm)
    );

    this.matterName = (matterDetail && matterDetail.name) || '';
    this.firmId = (matterDetail && matterDetail.parentId) || '';
  }

  private updateDocumentName(
    matterId: string,
    documentId: string,
    documentName: string = '',
    triggerSideDetail = false
  ): void {
    if (documentName) {
      this.documentName = documentName;
      return;
    }

    const signatureDetail = SignaturesModel.Helper.getSignatureDetail(
      this.store.selectSnapshot(AppState.getSignatures),
      matterId,
      documentId
    );

    if (
      signatureDetail &&
      (signatureDetail.orderId == documentId ||
        signatureDetail.esignedDocumentId == documentId ||
        signatureDetail.requestedDocuments.findIndex(x => x.id == documentId) !== -1)
    ) {
      this.documentName = signatureDetail.esignedDocumentName;
      if (triggerSideDetail) {
        setTimeout(
          () => this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_TAB_SWITCH, { tabId: 'details', ...signatureDetail }),
          0
        );
      }
    }
  }

  private previewDocumentSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_LIST_FILE_PREVIEW, ({ esignedDocumentId, ...others }) => {
      this.isPreviewMode = true;
      this.isSignatureMode = false;
      this.documentId = esignedDocumentId || this.documentId;
      this.matterId = (this.route.parent && this.route.parent.snapshot.params['matterId']) || this.matterId;
      this.updateDocumentName(this.matterId, this.documentId);

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/signatures/${this.documentId}/preview`,
        queryParams: <Params>{
          t: UUID.UUID()
        }
      });
    });
  }

  private showOrHideHeaderSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_PREVIEW_HEADER_DISPLAY, ({ showHeader }) => {
      this.showHeader = showHeader;
    });
  }

  private signDocumentSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_LIST_FILE_SIGN, ({ orderId, ...others }) => {
      this.isSignatureMode = true;
      this.isPreviewMode = false;
      this.documentId = orderId || this.documentId;
      this.matterId = (this.route.parent && this.route.parent.snapshot.params['matterId']) || this.matterId;

      this.updateDocumentName(this.matterId, this.documentId);

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `/matters/${this.matterId}/signatures/${this.documentId}/sign`,
        queryParams: <Params>{
          t: UUID.UUID()
        }
      });

      this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_TAB_SWITCH, { id: this.documentId, tabId: 'details', orderId });
    });
  }

  private signatureDocumentListViewSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_LIST_VIEW, () => {
      this.isPreviewMode = false;
      this.isSignatureMode = false;
    });
  }

  private logonUserSideEffect$(): Observable<CoreModel.LogonUserInfo> {
    return this.logonUser$.pipe(
      tap(user => {
        if (this.pubNubSub) {
          this.pubNubSub.unsubscribe();
        }

        if (!user) {
          return;
        }

        if (user.userId) {
          this.pubNubSub = this.pubNubSvc.subscribeToChannels(user.userId, [user.userId], notification => {
            const msg = CoreModel.Helper.convertNotificationMessage(notification);
            console.log('signatues ', msg);

            if (
              msg.notificationType === CoreModel.PubNubNotificationType.esignatureUploading ||
              msg.notificationType === CoreModel.PubNubNotificationType.esignatureCreated ||
              msg.notificationType === CoreModel.PubNubNotificationType.esignatureDecline
            ) {
              this.store.dispatch([new GetSignaturesStart(false)]);
            }
          });
        }
      })
    );
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      SIGNATURES_SIDE_TAB_SWITCH,
      ({ esignedDocumentId, orderId, esignedDocumentName, skipListRender, ...others }) => {
        if (this.documentId !== esignedDocumentId && this.documentId !== orderId) {
          this.documentId = esignedDocumentId || orderId;
          skipListRender !== undefined && !skipListRender && this.renderListView();
          this.updateDocumentName(this.matterId, this.documentId, esignedDocumentName);
        }
      }
    );
  }

  private listenToRemoteSideDetailToggleRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_SIDE_TAB_TOGGLE, ({ show }) => {
      if (show !== undefined) {
        this.asideDetails = show;
        return;
      }
    });
  }

  private listenToMobileActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_MULTIPLE_ACTIONS, ({ actionType, value }) => {
      if (actionType == SignaturesEvent.MultipleActionDispatchType.download) {
        this.isDifferentDocumentId(value.esignedDocumentId, value.orderId) &&
          this.mobileNavigateTo(value.esignedDocumentId, value.orderId);
        this.downloadDocument(
          this.matterId,
          value.esignedDocumentId,
          CoreModel.Helper.getValidDocumentNameWithExtension(value.esignedDocumentName, 'pdf')
        );
        return;
      }

      if (actionType == SignaturesEvent.MultipleActionDispatchType.preview) {
        value && this.customEventSvc.dispatchEvent(SIGNATURES_LIST_FILE_PREVIEW, { ...value });
        return;
      }

      if (actionType == SignaturesEvent.MultipleActionDispatchType.viewInfo) {
        this.isDifferentDocumentId(value.esignedDocumentId, value.orderId) &&
          this.mobileNavigateTo(value.esignedDocumentId, value.orderId);
        this.bottomSheet.open(SignaturesSideMobileComponent, {
          panelClass: 'x-bottom-sheet',
          data: { isGlobal: false, value, actionType, title: 'Details' }
        });
      }

      if (actionType == SignaturesEvent.MultipleActionDispatchType.viewComment) {
        this.isDifferentDocumentId(value.esignedDocumentId, value.orderId) &&
          this.mobileNavigateTo(value.esignedDocumentId, value.orderId);
        this.bottomSheet.open(SignaturesSideMobileComponent, {
          panelClass: 'x-bottom-sheet',
          data: { isGlobal: false, value, actionType, title: 'Comments' }
        });
      }

      if (actionType == SignaturesEvent.MultipleActionDispatchType.sign) {
        this.isDifferentDocumentId(value.esignedDocumentId, value.orderId) &&
          this.mobileNavigateTo(value.esignedDocumentId, value.orderId);
        this.customEventSvc.dispatchEvent(SIGNATURES_LIST_FILE_SIGN, { ...value });
      }
    });
  }

  private isDifferentDocumentId(esignedDocumentId: string, orderId: string): boolean {
    return this.documentId !== esignedDocumentId && this.documentId !== orderId;
  }

  private mobileNavigateTo(esignedDocumentId: string, orderId: string): void {
    this.documentId = esignedDocumentId || orderId;
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${this.matterId}/signatures/${this.documentId || ''}`,
      queryParams: <Params>{
        t: UUID.UUID()
      }
    });
  }

  private listenToMobileActionOpenRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_MULTIPLE_ACTIONS_OPEN, data => {
      this.openMobileItemActionSheet(data);
    });
  }

  private getDownloadDocumentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DownloadDocumentSuccess),
      tap(() => {
        this.isDownloading = false;
      })
    );
  }

  private getDownloadDocumentFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DownloadDocumentFailure),
      tap(() => {
        this.isDownloading = false;
      })
    );
  }
}
