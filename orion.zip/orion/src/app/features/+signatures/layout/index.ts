import { SignaturesHomeComponent } from './home/signatures-home.component';

export * from './home/signatures-home.component';

export const signaturesLayouts = [SignaturesHomeComponent];
