import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { CoreModel } from '@app/core/models';
import { SignaturesModel } from '../../models/signatures.model';
import { CustomEventService, SIGNATURES_LIST_SORTING } from '@app/core/services';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { Subject, Observable, merge } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { Actions, ofActionSuccessful, Store } from '@ngxs/store';
import { PopulateCurrentCollaboration } from '@app/core/store/actions';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'sc-signatures-list-header',
  templateUrl: './signatures-list-header.component.html'
})
export class SignaturesListHeaderComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private init = true;

  sortOptions: CoreModel.ColumnSorting[] = SignaturesModel.Helper.getDocSortingOptions();
  sortSelected: CoreModel.ColumnSorting = SignaturesModel.Helper.getDocDefaultSortingOption();

  changeSort(selected: CoreModel.ColumnSorting): void {
    this.sortSelected = selected;
    this.customEventSvc.dispatchEvent(SIGNATURES_LIST_SORTING, { ...selected });
  }

  sortDescription(current: CoreModel.ColumnSorting): string {
    const orderBy = current.sort == 0 ? 'ascending' : 'descending';

    return `Sorted by ${current.title} in ${orderBy} order`;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService,
    private actions$: Actions,
    private route: ActivatedRoute,
    private store: Store
  ) {
    merge(this.initNavigationPaths$())
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private initNavigationPaths$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateCurrentCollaboration),
      tap(data => {
        if (this.init) {
          const { documentId, matterId } = this.route.snapshot.params;

          // if (folders && folders.length > 0) {
          //   const rootFolder = folders[0].parent;

          //   this.store.dispatch(
          //     new GotoCollaborationFolder({
          //       rootId: rootFolder.id,
          //       folderId: folders[folders.length - 1].id,
          //       matterId
          //     })
          //   );
          // }

          this.init = false;
        }
      })
    );
  }
}
