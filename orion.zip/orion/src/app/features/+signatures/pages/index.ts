import { SignaturesViewDetailsMobileComponent } from './signatures-view-details-mobile/signatures-view-details-mobile.component';
import { SignaturesSideComponent } from './signatures-side/signatures-side.component';
import { SignaturesListHeaderComponent } from './signatures-list-header/signatures-list-header.component';
import { SignaturesListComponent } from './signatures-list/signatures-list.component';
import { SignaturesDocumentPreviewComponent } from './signatures-document-preview/signatures-document-preview.component';
import { SignaturesDocumentSignComponent } from './signatures-document-sign/signatures-document-sign.component';
import { SignaturesSideMobileComponent } from './signatures-side-mobile/signatures-side-mobile.component';

export * from './signatures-view-details-mobile/signatures-view-details-mobile.component';
export * from './signatures-side/signatures-side.component';
export * from './signatures-list-header/signatures-list-header.component';
export * from './signatures-list/signatures-list.component';
export * from './signatures-document-preview/signatures-document-preview.component';
export * from './signatures-document-sign/signatures-document-sign.component';
export * from './signatures-side-mobile/signatures-side-mobile.component';

export const signaturesPages = [
  SignaturesViewDetailsMobileComponent,
  SignaturesSideComponent,
  SignaturesListHeaderComponent,
  SignaturesListComponent,
  SignaturesDocumentPreviewComponent,
  SignaturesDocumentSignComponent,
  SignaturesSideMobileComponent
];
