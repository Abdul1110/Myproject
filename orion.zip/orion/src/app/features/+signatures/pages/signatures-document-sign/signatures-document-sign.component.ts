import { Component, OnDestroy, ViewChild, HostBinding } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { ActivatedRoute, Params } from '@angular/router';
import { tap, takeUntil } from 'rxjs/operators';
import { Observable, Subject, merge, fromEvent } from 'rxjs';
import { UUID } from 'angular2-uuid';

import { CoreModel, SignatureModel } from '@app/core/models';
import {
  GetSignaturesStart,
  GetSignaturesFailure,
  GetSignaturesSuccess,
  AddSignaturePendingUpdateEntry
} from '@app/core/store/actions';
import {
  AnalyticService,
  CustomEventService,
  SIGNATURES_LIST_VIEW,
  NAVIGATION_SIDE_BAR_TOGGLE,
  NavigationService
} from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { AppState } from '@app/core/store/states';
import { SignaturesAction } from '../../store';
import { environment } from '@env/environment';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { SignaturesModel } from '../../models/signatures.model';

const { error } = environment.locale.no_results.comments;

@Component({
  selector: 'sc-signatures-document-sign',
  templateUrl: './signatures-document-sign.component.html'
})
export class SignaturesDocumentSignComponent implements OnDestroy {
  private getDataSuccess = false;
  private destroy$ = new Subject<boolean>();
  private currentUser: CoreModel.LogonUserInfo = undefined;
  private signatureDetail: SignaturesModel.SignatureItem = undefined;
  private maxRetryConsiderNotFound = 2;
  private retry = 0;
  @HostBinding('class.layout-column')
  isLoading = true;
  isError = false;
  documentName = '';
  documentNameWithExtension = '';
  documentId = '';
  matterId = '';
  signatureUrl = '';
  fileExtension = '';
  errorMessage = '';
  errorTitle = error.title;

  @ViewChild('signature_frame', { static: false }) signatureFrame: HTMLElement;

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private route: ActivatedRoute,
    private actions$: Actions,
    private appActionSvc: AppActionService,
    private customEventSvc: CustomEventService,
    private navigationSvc: NavigationService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersESignature,
        action: 'Sign document'
      });

      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: false });
      this.documentId = (this.route.parent && this.route.parent.snapshot.params['documentId']) || '';
      this.matterId = (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';

      merge(
        this.logonUserSideEffect$(),
        this.getSignatureDetailSuccess$(),
        this.getSignatureDetailFailure$(),
        this.listenToDocSignStatusSideEffect$(),
        this.getSignatureUrlSuccess$(),
        this.getSignatureUrlFailure$()
      )
        .pipe(takeUntil(this.destroy$))
        .subscribe();

      this.signatureDetail = SignaturesModel.Helper.getSignatureDetail(
        this.store.selectSnapshot(AppState.getSignatures),
        this.matterId,
        this.documentId
      );

      if (!this.signatureDetail) {
        this.store.dispatch(new GetSignaturesStart(false));
      } else {
        this.store.dispatch(
          new SignaturesAction.GetSignatureUrl({ orderId: this.documentId, userId: this.currentUser.userId })
        );
      }
    }
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private getSignatureDetailSuccess$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesSuccess),
      tap(({ payload: { signatures } }) => {
        if (this.signatureDetail) {
          if (
            this.signatureDetail.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.Pending &&
            this.currentUser
          ) {
            this.retry = 0;
            this.store.dispatch(
              new SignaturesAction.GetSignatureUrl({ orderId: this.documentId, userId: this.currentUser.userId })
            );
            return;
          }

          this.displayErrorAndRedirectToListView();
          return;
        }

        this.retry += 1;
        if (this.retry == this.maxRetryConsiderNotFound) {
          this.displayErrorAndRedirectToListView(true, 'Document not found');
          return;
        }

        this.signatureDetail = SignaturesModel.Helper.getSignatureDetail(signatures, this.matterId, this.documentId);
        if (this.signatureDetail && this.currentUser && this.documentName) {
          this.store.dispatch(
            new SignaturesAction.GetSignatureUrl({ orderId: this.documentId, userId: this.currentUser.userId })
          );
        }
      })
    );
  }

  private displayErrorAndRedirectToListView(invalidDocId: boolean = false, message = ''): void {
    this.isLoading = false;
    this.isError = true;
    this.errorMessage = invalidDocId
      ? message
      : message ||
        `This document has been ${SignatureModel.Helper.ESignatureDocumentStatusToText(
          this.signatureDetail.esignedDocumentStatus
        )}`;

    this.store.dispatch(new SignaturesAction.LoadSignaturePageFailure(this.errorMessage));

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: invalidDocId
        ? `/matters/${this.matterId}/signatures/`
        : `/matters/${this.matterId}/signatures/${this.documentId}/`,
      queryParams: <Params>{
        t: UUID.UUID()
      }
    });

    this.customEventSvc.dispatchEvent(SIGNATURES_LIST_VIEW, {});
  }

  private displaySuccessAndRedirectToListView(message: string): void {
    this.isLoading = false;
    this.isError = false;
    this.errorMessage = '';

    this.store.dispatch(new SignaturesAction.UserSignatureStatus({ message }));

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: `/matters/${this.matterId}/signatures/${this.documentId}/`,
      queryParams: <Params>{
        t: UUID.UUID()
      }
    });

    this.customEventSvc.dispatchEvent(SIGNATURES_LIST_VIEW, {});
  }

  private getSignatureDetailFailure$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesFailure),
      tap(e => {
        this.isLoading = false;
        this.isError = true;
        this.errorMessage = 'Fail to read signature detail';
      })
    );
  }

  private getSignatureUrlSuccess$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetSignatureUrlSuccess),
      tap(({ payload: { code, isSucceeded, message, url } }) => {
        this.isLoading = false;
        this.isError = !isSucceeded;
        this.errorMessage = message;
        this.signatureUrl = url;

        if (this.isError) {
          this.displayErrorAndRedirectToListView(false, message);
        }
      })
    );
  }

  private getSignatureUrlFailure$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetSignatureUrlFailure),
      tap(e => {
        this.isLoading = false;
        this.isError = true;
        this.errorMessage = 'Fail to get signature url';
      })
    );
  }

  private isLastSigner(userId: string, signatureDetail: SignaturesModel.SignatureItem): boolean {
    if (userId && signatureDetail) {
      const { requestedSigners } = signatureDetail;
      if (!requestedSigners || requestedSigners.length == 1) {
        return true;
      }
      const otherSignaturesStatus = requestedSigners && requestedSigners.filter(x => x.id !== userId);
      const otherStillPending = otherSignaturesStatus.every(x => x.status === SignatureModel.ESignerStatus.Pending);

      return !otherStillPending;
    }

    return true;
  }

  private listenToDocSignStatusSideEffect$(): Observable<any> {
    return fromEvent(this.browserSvc.window, 'message').pipe(
      tap(msg => {
        if (msg && msg['type'] === 'message' && msg['origin'].indexOf('infotrack') > 0) {
          if (msg['data'].indexOf('=exchanged') >= 0 || msg['data'].indexOf('=signed') >= 0) {
            const status = this.isLastSigner(this.currentUser && this.currentUser.userId, this.signatureDetail)
              ? SignatureModel.ESignatureDocumentStatus.Signed
              : SignatureModel.ESignatureDocumentStatus.WaitingForOthers;

            this.store.dispatch([
              new AddSignaturePendingUpdateEntry({
                orderId: this.documentId, //a.k.a. order id
                signerId: this.currentUser.userId,
                signStatus: status,
                documentId: this.documentId
              })
            ]);

            this.displaySuccessAndRedirectToListView(
              `Document status ${SignatureModel.Helper.ESignatureDocumentStatusToText(status)}`
            );
            return;
          }

          if (msg['data'].indexOf('=declined') >= 0) {
            this.store.dispatch([
              new AddSignaturePendingUpdateEntry({
                orderId: this.documentId, //a.k.a. order id
                signerId: this.currentUser.userId,
                signStatus: SignatureModel.ESignatureDocumentStatus.Declined,
                documentId: this.documentId
              })
            ]);

            this.displaySuccessAndRedirectToListView(`Document status Declined`);
            return;
          }

          if (msg['data'].indexOf('=cancel') >= 0) {
            this.displaySuccessAndRedirectToListView(undefined);
            return;
          }
        }
      })
    );
  }
}
