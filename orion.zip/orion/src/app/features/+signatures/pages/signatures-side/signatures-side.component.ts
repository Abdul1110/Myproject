import { Component, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { CoreModel, SignatureModel } from '@app/core/models';
import { AppState } from '@app/core/store/states';
import { Observable, Subject, merge } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { environment } from '@env/environment';
import {
  CustomEventService,
  SIGNATURES_SIDE_TAB_SWITCH,
  SIGNATURES_SIDE_TAB_TOGGLE,
  SIGNATURES_COMMENT_REPLIED_DELETE
} from '@app/core/services';
import { SignaturesModel } from '../../models/signatures.model';
import { SignaturesAction } from '../../store';
import { AnnotatorModel } from '@app/shared/models';

const { details, comments } = environment.locale.global.side_menu;
const tabIds = { details: 'details', comments: 'comments' };

@Component({
  selector: 'sc-signatures-side',
  templateUrl: './signatures-side.component.html'
})
export class SignaturesSideComponent implements OnDestroy {
  isPreview = false;
  documentId = '';
  matterId: '';
  selectedTabId = tabIds.details;
  signatureDetail = undefined;
  isLoading = true;
  currentUser = undefined;
  firmName = '';
  documentActivities: SignaturesModel.LawConnectDocumentHistory[] = [];
  comments: SignaturesModel.LawConnectDocumentAnnotation[] = [];
  replied: SignaturesModel.AnnotationRepliedList = {};
  commentSeqs: AnnotatorModel.AnnotationSeq[] = [];
  repliedDeletedIds: string[] = [];

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  changeDisplay(id: string): void {
    this.selectedTabId = id;
  }

  isSelected(tabId: string): boolean {
    return tabId == this.selectedTabId;
  }

  tabsFilter(document: SignaturesModel.SignatureItem): { title: string; id: string }[] {
    if (document && !SignaturesModel.Helper.isSignaturePendingOrDecline(document)) {
      return this.tabs;
    }
    return this.tabs.filter(t => t.id !== tabIds.comments);
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private route: ActivatedRoute,
    private appActionSvc: AppActionService,
    private customEventSvc: CustomEventService,
    private actions$: Actions
  ) {
    this.documentId = this.route.snapshot.params['documentId'] || '';
    this.matterId = (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';

    merge(
      this.signaturesSideEffect$(),
      this.logonUserSideEffect$(),
      this.firmSideEffect$(),
      this.signatureActivitySuccessSideEffect$(),
      this.signatureActivityFailureSideEffect$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.signatureAnnotationSuccessSideEffect$(),
      this.signatureAnnotationFailureSideEffect$(),
      this.signatureAnnotationRepliedSuccessSideEffect$(),
      this.signatureAnnotationRepliedFailureSideEffect$(),
      this.listenToCommentsRepliedDeleteRequestSideEffect$(),
      this.listenToNewCommentReplySuccessSideEffect$(),
      this.deleteAnnotationRepliedSuccessSideEffect$(),
      this.deleteAnnotationRepliedFailureSideEffect$(),
      this.listenToDeleteCommentSuccessSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.signatureDetail = SignaturesModel.Helper.getSignatureDetail(
      this.store.selectSnapshot(AppState.getSignatures),
      this.matterId,
      this.documentId
    );
  }

  private destroy$ = new Subject<boolean>();
  private tabs = [{ title: details, id: tabIds.details }, { title: comments, id: tabIds.comments }];

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private firmSideEffect$(): Observable<any> {
    return this.appActionSvc.selectedFirm$.pipe(
      tap(firm => {
        this.firmName = (firm && firm.name) || '';
      })
    );
  }

  private signaturesSideEffect$(): Observable<{}> {
    return this.appActionSvc.signatures$.pipe(
      tap((signatures: SignatureModel.ESignature[]) => {
        this.signatureDetail = SignaturesModel.Helper.getSignatureDetail(signatures, this.matterId, this.documentId);

        if (signatures) {
          this.isLoading = false;
        }
      })
    );
  }

  private signatureActivitySuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentActivitySuccess),
      tap(({ payload: { activities } }) => {
        this.documentActivities = activities || [];
        if (this.selectedTabId == tabIds.details) {
          this.isLoading = false;
        }
      })
    );
  }

  private signatureActivityFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentActivityFailure),
      tap((error: any) => {
        this.documentActivities = [];
        if (this.selectedTabId == tabIds.details) {
          this.isLoading = false;
        }
      })
    );
  }

  private signatureAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentAnnotationSuccess),
      tap(({ payload }) => {
        if (payload && payload.length > 0) {
          this.comments = SignaturesModel.Helper.getCommentsInAscOrder(payload);
          this.commentSeqs = SignaturesModel.Helper.getCommentSeqs(this.comments);

          const annotationIds = payload.map(a => a.id);
          this.store.dispatch(new SignaturesAction.GetDocumentReplied(annotationIds));
          return;
        }

        this.comments = [];
        this.commentSeqs = [];

        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private signatureAnnotationFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentAnnotationFailure),
      tap((error: any) => {
        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private signatureAnnotationRepliedSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentRepliedSuccess),
      tap(({ payload }) => {
        this.replied = this.getLatestReplied(payload || {}, this.repliedDeletedIds);

        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private getLatestReplied(
    payload: SignaturesModel.AnnotationRepliedList,
    repliedDeletedIds: string[]
  ): SignaturesModel.AnnotationRepliedList {
    const repliedByAnnotation = payload;

    // exclude just deleted reply ids
    if (Object.keys(repliedByAnnotation).length > 0 && repliedDeletedIds.length > 0) {
      let replies = {};
      const old = { ...repliedByAnnotation };
      Object.keys(old).forEach(annotationId => {
        replies[annotationId] = old[annotationId].filter(x => repliedDeletedIds.findIndex(d => d == x.id) == -1) || [];
      });

      return { ...replies };
    }

    return { ...repliedByAnnotation };
  }

  private signatureAnnotationRepliedFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentRepliedFailure),
      tap((error: any) => {
        if (this.selectedTabId == tabIds.comments) {
          this.isLoading = false;
        }
      })
    );
  }

  private deleteAnnotationRepliedSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DeleteRepliedSuccess),
      tap(({ payload: { success, annotationId, replyId } }) => {
        if (success !== undefined && !success) {
          this.repliedDeletedIds = this.repliedDeletedIds.filter(d => d !== replyId) || [];
          this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);
          return;
        }

        this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId));
      })
    );
  }

  private deleteAnnotationRepliedFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DeleteRepliedFailure),
      tap(({ payload: { data: { replyId }, err } }) => {
        this.repliedDeletedIds = this.repliedDeletedIds.filter(d => d !== replyId) || [];
        this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);

        if (err && err.status == '500') {
          return this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId));
        }
      })
    );
  }

  private listenToCommentsRepliedDeleteRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_COMMENT_REPLIED_DELETE, ({ replyId, annotationId }) => {
      this.repliedDeletedIds = [].concat(this.repliedDeletedIds).concat(replyId);
      this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);

      this.store.dispatch(new SignaturesAction.DeleteReplied({ replyId, annotationId }));
    });
  }

  private listenToNewCommentReplySuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.ReplyCommentSuccess),
      tap(({ payload }) => {
        const replied = { ...this.replied };
        let repliedUpdate = {};
        Object.keys(replied).forEach(annotationId => {
          repliedUpdate[annotationId] =
            annotationId === payload.annotationId ? replied[annotationId].concat(payload) : replied[annotationId];
        });

        this.replied = { ...repliedUpdate };
      })
    );
  }

  private listenToDeleteCommentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DeleteAnnotationSuccess),
      tap(({ payload: { success, annotationId: deletedAnnotationId } }) => {
        if (!success) {
          return this.store.dispatch(new SignaturesAction.DeleteAnnotationFailure('Delete annotation failed'));
        }

        this.comments = SignaturesModel.Helper.getLatestCommentsAfterDeletingComment(
          this.comments,
          deletedAnnotationId
        );
        this.commentSeqs = SignaturesModel.Helper.getLatestCommentSeqsAfterDeletingComment(
          this.commentSeqs,
          deletedAnnotationId
        );
        this.replied = SignaturesModel.Helper.getLatestRepliedAfterDeletingComment(this.replied, deletedAnnotationId);
      })
    );
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      SIGNATURES_SIDE_TAB_SWITCH,
      ({ tabId, esignedDocumentId, orderId, ...others }) => {
        this.changeDisplay(tabId);

        if (!(this.documentId !== esignedDocumentId && this.documentId !== orderId)) {
          return;
        }

        let internalLoading = true;
        this.documentId = esignedDocumentId || orderId;
        this.isLoading = true;
        this.signatureDetail = SignaturesModel.Helper.getSignatureDetail(
          this.store.selectSnapshot(AppState.getSignatures),
          this.matterId,
          this.documentId
        );

        // read details.
        esignedDocumentId && this.store.dispatch(new SignaturesAction.GetDocumentActivity(this.documentId));
        if (!esignedDocumentId) {
          internalLoading = false;
          this.documentActivities = [];
        }

        // read comments.
        if (!SignaturesModel.Helper.isSignaturePendingOrDecline(others)) {
          internalLoading = true;
          esignedDocumentId && this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId));
        }

        if (!internalLoading) {
          this.isLoading = false;
        }
      }
    );
  }
}
