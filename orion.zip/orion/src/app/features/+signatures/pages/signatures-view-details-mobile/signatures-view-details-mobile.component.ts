import { Component, ChangeDetectionStrategy, OnDestroy, Inject, HostBinding } from '@angular/core';
import { Subject } from 'rxjs';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { CustomEventService, SIGNATURES_MULTIPLE_ACTIONS } from '@app/core/services';
import { SignaturesEvent } from '../../models/event.model';
import { SignaturesModel } from '../../models/signatures.model';
import { SignatureModel } from '@app/core/models';

@Component({
  selector: 'sc-signatures-view-details-mobile',
  templateUrl: './signatures-view-details-mobile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignaturesViewDetailsMobileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  title = '';
  subtitle = '';

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  isGlobal(data: any): boolean {
    return data && data.isGlobal;
  }

  isSignatureRequest(data: SignaturesModel.SignatureItem): boolean {
    return data && data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.Pending;
  }

  isSignaturePendingOrDecline(data: SignaturesModel.SignatureItem): boolean {
    return (
      data &&
      (data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.WaitingForOthers ||
        data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.Declined)
    );
  }

  previewDocument(data: any): void {
    this.dispatchEvent(SignaturesEvent.MultipleActionDispatchType.preview, data);
    this.bottomSheetRef.dismiss();
  }

  download(data: any): void {
    this.dispatchEvent(SignaturesEvent.MultipleActionDispatchType.download, data);
    this.bottomSheetRef.dismiss();
  }

  viewSideDetail(data: any): void {
    this.dispatchEvent(SignaturesEvent.MultipleActionDispatchType.viewInfo, data);
    this.bottomSheetRef.dismiss();
  }

  signDocument(data: any): void {
    this.dispatchEvent(SignaturesEvent.MultipleActionDispatchType.sign, data);
    this.bottomSheetRef.dismiss();
  }

  viewSideComment(data: any): void {
    this.dispatchEvent(SignaturesEvent.MultipleActionDispatchType.viewComment, data);
    this.bottomSheetRef.dismiss();
  }

  hidePreview(data: any): boolean {
    return data && data.hidePreview;
  }

  constructor(
    private customEventSvc: CustomEventService,
    private bottomSheetRef: MatBottomSheetRef<SignaturesViewDetailsMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';
  }

  @HostBinding('class.x-action-list')
  ngOnDestroy() {
    this.destroy$.next();
  }

  private dispatchEvent(actionType: string, data: any): void {
    this.customEventSvc.dispatchEvent(SIGNATURES_MULTIPLE_ACTIONS, {
      actionType,
      value: { ...this.data }
    });
  }
}
