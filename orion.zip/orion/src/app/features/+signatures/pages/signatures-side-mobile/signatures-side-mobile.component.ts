import { Component, Inject, OnDestroy } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material';
import { SignaturesEvent } from '../../models/event.model';
import { Actions, ofActionSuccessful, Store } from '@ngxs/store';
import { Observable, merge, Subject } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { SignaturesAction } from '../../store';
import { SignaturesModel } from '../../models/signatures.model';
import { AnnotatorModel } from '@app/shared/models';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { ActivatedRoute } from '@angular/router';
import { CustomEventService, SIGNATURES_COMMENT_REPLIED_DELETE, SIGNATURES_SIDE_REFRESH_ME } from '@app/core/services';

@Component({
  selector: 'sc-signatures-side-mobile',
  templateUrl: './signatures-side-mobile.component.html'
})
export class SignaturesSideMobileComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private repliedDeletedIds: string[] = [];
  title = '';
  subtitle = '';
  comments: SignaturesModel.LawConnectDocumentAnnotation[] = [];
  replied: SignaturesModel.AnnotationRepliedList = undefined;
  commentSeqs: AnnotatorModel.AnnotationSeq[] = [];
  documentActivities: SignaturesModel.LawConnectDocumentHistory[] = [];
  documentId = '';
  currentUser = undefined;
  firmName = '';

  isViewDetail(): boolean {
    return this.data && this.data.actionType == SignaturesEvent.MultipleActionDispatchType.viewInfo;
  }

  isViewComment(): boolean {
    return this.data && this.data.actionType == SignaturesEvent.MultipleActionDispatchType.viewComment;
  }

  isSign(): boolean {
    return this.data && this.data.actionType == SignaturesEvent.MultipleActionDispatchType.sign;
  }

  onClose(): void {
    this.bottomSheetRef.dismiss();
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private bottomSheetRef: MatBottomSheetRef<SignaturesSideMobileComponent>,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private actions$: Actions,
    private store: Store,
    private appActionSvc: AppActionService,
    private route: ActivatedRoute,
    private customEventSvc: CustomEventService
  ) {
    this.title = data.title || '';
    this.subtitle = data.subTitle || '';

    merge(
      this.firmSideEffect$(),
      this.signatureAnnotationSuccessSideEffect$(),
      this.listenToDeleteCommentSuccessSideEffect$(),
      this.signatureActivitySuccessSideEffect$(),
      this.signatureActivityFailureSideEffect$(),
      this.logonUserSideEffect$(),
      this.listenToCommentsRepliedDeleteRequestSideEffect$(),
      this.listenToNewCommentReplySuccessSideEffect$(),
      this.deleteAnnotationRepliedFailureSideEffect$(),
      this.signatureAnnotationRepliedSuccessSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    const { esignedDocumentId, orderId } = this.data.value;
    this.documentId = esignedDocumentId || orderId;
    esignedDocumentId && this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId));
    esignedDocumentId && this.store.dispatch(new SignaturesAction.GetDocumentActivity(this.documentId));
  }

  private signatureAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentAnnotationSuccess),
      tap(({ payload }) => {
        if (payload && payload.length > 0) {
          this.comments = SignaturesModel.Helper.getCommentsInAscOrder(payload);
          this.commentSeqs = SignaturesModel.Helper.getCommentSeqs(this.comments);

          const annotationIds = payload.map(a => a.id);
          this.store.dispatch(new SignaturesAction.GetDocumentReplied(annotationIds));
          return;
        }

        this.comments = [];
        this.commentSeqs = [];
      })
    );
  }

  private listenToCommentsRepliedDeleteRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_COMMENT_REPLIED_DELETE, ({ replyId, annotationId }) => {
      this.repliedDeletedIds = [].concat(this.repliedDeletedIds).concat(replyId);
      this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);
      this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_REFRESH_ME, {});

      this.store.dispatch(new SignaturesAction.DeleteReplied({ replyId, annotationId }));
    });
  }

  private getLatestReplied(
    payload: SignaturesModel.AnnotationRepliedList,
    repliedDeletedIds: string[]
  ): SignaturesModel.AnnotationRepliedList {
    const repliedByAnnotation = payload;

    // exclude just deleted reply ids
    if (Object.keys(repliedByAnnotation).length > 0 && repliedDeletedIds.length > 0) {
      let replies = {};
      const old = { ...repliedByAnnotation };
      Object.keys(old).forEach(annotationId => {
        replies[annotationId] = old[annotationId].filter(x => repliedDeletedIds.findIndex(d => d == x.id) == -1) || [];
      });

      return { ...replies };
    }

    return { ...repliedByAnnotation };
  }

  private listenToDeleteCommentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DeleteAnnotationSuccess),
      tap(({ payload: { success, annotationId: deletedAnnotationId } }) => {
        if (!success) {
          return this.store.dispatch(new SignaturesAction.DeleteAnnotationFailure('Delete annotation failed'));
        }

        this.comments = SignaturesModel.Helper.getLatestCommentsAfterDeletingComment(
          this.comments,
          deletedAnnotationId
        );

        this.commentSeqs = SignaturesModel.Helper.getLatestCommentSeqsAfterDeletingComment(
          this.commentSeqs,
          deletedAnnotationId
        );

        this.replied = SignaturesModel.Helper.getLatestRepliedAfterDeletingComment(this.replied, deletedAnnotationId);
        this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_REFRESH_ME, {});
      })
    );
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private signatureActivitySuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentActivitySuccess),
      tap(({ payload: { activities } }) => {
        this.documentActivities = activities || [];
      })
    );
  }

  private signatureActivityFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentActivityFailure),
      tap((error: any) => {
        this.documentActivities = [];
      })
    );
  }

  private firmSideEffect$(): Observable<any> {
    return this.appActionSvc.selectedFirm$.pipe(
      tap(firm => {
        this.firmName = (firm && firm.name) || '';
      })
    );
  }

  private listenToNewCommentReplySuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.ReplyCommentSuccess),
      tap(({ payload }) => {
        const replied = { ...this.replied };
        let repliedUpdate = {};
        Object.keys(replied).forEach(annotationId => {
          repliedUpdate[annotationId] =
            annotationId === payload.annotationId ? replied[annotationId].concat(payload) : replied[annotationId];
        });

        this.replied = { ...repliedUpdate };
        this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_REFRESH_ME, {});
      })
    );
  }

  private deleteAnnotationRepliedFailureSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DeleteRepliedFailure),
      tap(({ payload: { data: { replyId }, err } }) => {
        this.repliedDeletedIds = this.repliedDeletedIds.filter(d => d !== replyId) || [];
        this.replied = this.getLatestReplied(this.replied, this.repliedDeletedIds);

        if (err && err.status == '500') {
          return this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId));
        }
      })
    );
  }

  private signatureAnnotationRepliedSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentRepliedSuccess),
      tap(({ payload }) => {
        this.replied = this.getLatestReplied(payload || {}, this.repliedDeletedIds);
        this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_REFRESH_ME, {});
      })
    );
  }
}
