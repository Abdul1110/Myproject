import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { CoreModel, SignatureModel } from '@app/core/models';
import { SignaturesModel } from '../../models/signatures.model';
import { environment } from '@env/environment';
import {
  CustomEventService,
  SIGNATURES_LIST_SORTING,
  SIGNATURES_SIDE_TAB_SWITCH,
  SIGNATURES_LIST_VIEW,
  SIGNATURES_MULTIPLE_ACTIONS,
  MATTERS_SELECT_CLOSED,
  DOCUMENTS_SIDE_TAB_SWITCH,
  NAVIGATION_SIDE_BAR_TOGGLE
} from '@app/core/services';
import { AppState } from '@app/core/store/states';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { GetSignaturesSuccess, GetSignaturesFailure } from '@app/core/store/actions';
import { DialogService } from '@app/shared/services';
import { SignaturesAction } from '../../store';
// import { SignaturesAction } from '../../store';

const { delete: document_delete } = environment.locale.document_actions;

@Component({
  selector: 'sc-signatures-list',
  templateUrl: './signatures-list.component.html'
})
export class SignaturesListComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private matterId = '';
  private documentId = '';
  private activeSorting: CoreModel.ColumnSorting = SignaturesModel.Helper.getDocDefaultSortingOption();
  emptyDocument = environment.locale.no_results.documents.empty;
  serverError = environment.locale.no_results.documents.server_error;
  hasNoDocument = false;
  hasError = false;
  isLoading = true;
  signatures: SignaturesModel.SignatureItem[] = [];
  currentUser = undefined;
  isSmallScreen = false;

  scrollObserver(scrollIndex: number): void {}

  isActiveItem(document: SignaturesModel.SignatureItem): boolean {
    if (this.documentId == undefined) {
      return false;
    }

    const { esignedDocumentId, orderId } = document;
    return this.documentId == esignedDocumentId || this.documentId == orderId;
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private customEventSvc: CustomEventService,
    private store: Store,
    private route: ActivatedRoute,
    private appActionSvc: AppActionService,
    private actions$: Actions,
    private dialogSvc: DialogService
  ) {
    this.matterId = this.route.snapshot.params['matterId'];
    this.documentId = this.route.snapshot.params['documentId'];

    merge(
      this.changeListOrderSideEffect$(),
      this.logonUserSideEffect$(),
      this.detectSmallScreen$(),
      this.listenToRemoteTabSwitchSideEffect$(),
      this.getSignaturesSuccessSideEffect$(),
      this.getSignaturesFailureSideEffect$(),
      this.loadSignaturePageFailureSideEffet$(),
      this.listenToMobileMultipleActionSideEffect$(),
      this.listenToMatterSelectedFromOptions$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.renderSignatureList(this.activeSorting);
    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId) {
        return;
      }

      this.matterId = matterId;
      this.renderSignatureList(this.activeSorting);
      this.customEventSvc.dispatchEvent(DOCUMENTS_SIDE_TAB_SWITCH, {
        tabId: 'details',
        id: '',
        skipListRender: true
      });
    });
  }

  private listenToMobileMultipleActionSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      SIGNATURES_MULTIPLE_ACTIONS,
      ({ value: { esignedDocumentId, orderId, ...others } }) => {
        if (this.documentId !== esignedDocumentId && this.documentId !== orderId) {
          this.documentId = esignedDocumentId || orderId;
        }
      }
    );
  }

  private listenToRemoteTabSwitchSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      SIGNATURES_SIDE_TAB_SWITCH,
      ({ esignedDocumentId, orderId, ...others }) => {
        if (this.documentId !== esignedDocumentId && this.documentId !== orderId) {
          this.documentId = esignedDocumentId || orderId;
        }
      }
    );
  }

  private detectSmallScreen$(): Observable<any> {
    return this.appActionSvc.isSmallScreen$.pipe(tap(isSmall => (this.isSmallScreen = isSmall)));
  }

  private changeListOrderSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(SIGNATURES_LIST_SORTING, (sorting: CoreModel.ColumnSorting) => {
      this.renderSignatureList(sorting);
    });
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(tap(u => (this.currentUser = u)));
  }

  private getSignaturesSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesSuccess),
      tap(v => {
        this.renderSignatureList(this.activeSorting);
        if (
          this.documentId &&
          !this.hasNoDocument &&
          this.signatures.filter(s => s.esignedDocumentId == this.documentId).length > 0
        ) {
          this.store.dispatch(new SignaturesAction.GetDocumentActivity(this.documentId));
          const doc = this.signatures.find(s => s.esignedDocumentId == this.documentId);
          !SignaturesModel.Helper.isSignaturePendingOrDecline(doc) &&
            this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId));
        }
      })
    );
  }

  private loadSignaturePageFailureSideEffet$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.LoadSignaturePageFailure),
      tap(v => {
        this.renderSignatureList(this.activeSorting);
      })
    );
  }

  private getSignaturesFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(GetSignaturesFailure),
      tap(v => {
        this.renderSignatureList(this.activeSorting);
      })
    );
  }

  private getLatestSignatureList(sortBy: CoreModel.ColumnSorting): SignaturesModel.SignatureItem[] {
    const signatures = this.store.selectSnapshot(AppState.getSignatures);
    const latestLocalStatus = this.store.selectSnapshot(AppState.getSignaturesPendingUpdate) || undefined;

    if (signatures && signatures.length == 0) {
      return [];
    }

    const matterSignatures = signatures.filter(s => s.matterId == this.matterId);
    const matterSignaturesWithLocalUpdates =
      (latestLocalStatus &&
        matterSignatures &&
        matterSignatures.map(x => {
          if (latestLocalStatus[x.orderId]) {
            return { ...x, esignedDocumentStatus: latestLocalStatus[x.orderId].signStatus };
          }
          return x;
        })) ||
      matterSignatures;

    if (!sortBy) {
      return [].concat(matterSignaturesWithLocalUpdates);
    }

    const defaultSort = SignaturesModel.Helper.getDocDefaultSortingOption();
    if (sortBy.column == defaultSort.column) {
      const signRequests =
        matterSignaturesWithLocalUpdates &&
        matterSignaturesWithLocalUpdates.filter(
          s => s.esignedDocumentStatus === SignatureModel.ESignatureDocumentStatus.Pending
        );
      const otherSigns =
        matterSignaturesWithLocalUpdates &&
        matterSignaturesWithLocalUpdates.filter(
          s => s.esignedDocumentStatus !== SignatureModel.ESignatureDocumentStatus.Pending
        );
      const pendingSignatures: SignaturesModel.SignatureItem[] = [].concat(
        CoreModel.Helper.sortBy(signRequests, sortBy)
      );
      const otherSignatures: SignaturesModel.SignatureItem[] = [].concat(CoreModel.Helper.sortBy(otherSigns, sortBy));
      const allSignatures = [].concat(pendingSignatures).concat(otherSignatures);

      return allSignatures;
    }

    return [].concat(CoreModel.Helper.sortBy(matterSignaturesWithLocalUpdates, sortBy));
  }

  private renderSignatureList(sorting: CoreModel.ColumnSorting): void {
    this.signatures = this.getLatestSignatureList(sorting);
    this.hasNoDocument = this.signatures.length == 0;
    this.activeSorting = { ...sorting };
    this.isLoading = false;
  }
}
