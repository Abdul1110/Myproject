import { Component, OnDestroy, HostBinding } from '@angular/core';
import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { ActivatedRoute } from '@angular/router';
import { tap, takeUntil } from 'rxjs/operators';
import { Observable, Subject, merge, interval } from 'rxjs';

import { CoreModel } from '@app/core/models';
import { GetCollaborationSuccess, GetSignaturesSuccess, GetSignaturesStart } from '@app/core/store/actions';
import {
  AnalyticService,
  CustomEventService,
  SIGNATURES_SIDE_TAB_SWITCH,
  SIGNATURES_COMMENT_CLICK_TO_VIEW,
  SIGNATURES_PREVIEW_HEADER_DISPLAY,
  NAVIGATION_SIDE_BAR_TOGGLE
} from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { AppState } from '@app/core/store/states';
// import { SignaturesAction } from '../../store';
import { environment } from '@env/environment';
import { SignaturesAction } from '../../store';
import { SignaturesModel } from '../../models/signatures.model';
import { AnnotatorModel } from '@app/shared/models';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';

const { server_error } = environment.locale.no_results.documents.document;

@Component({
  selector: 'sc-signatures-document-preview',
  templateUrl: './signatures-document-preview.component.html'
})
export class SignaturesDocumentPreviewComponent implements OnDestroy {
  // private getDataSuccess = false;
  @HostBinding('class.layout-column')
  private destroy$ = new Subject<boolean>();
  private comments: SignaturesModel.LawConnectDocumentAnnotation[] = [];
  private commentSeqs: AnnotatorModel.AnnotationSeq[] = [];
  private isSmallScreen = false;

  // private signatureDetail: SignaturesModel.SignatureItem = undefined;

  enableAnnotator = true;
  isLoading = true;
  isError = false;
  isDocumentDownloading = false;
  documentName = '';
  documentNameWithExtension = '';
  documentId = '';
  matterId = '';
  previewUrl = '';
  fileExtension = 'pdf';
  switchToPage: SignaturesModel.CommentClickToViewRequest = undefined;
  annotatingBy: AnnotatorModel.AnnotatingBy = undefined;
  activeAnnotation: AnnotatorModel.AnnotationBeforeCreated = undefined;

  download(matterId: string, documentId: string, documentName: string): void {
    this.isDocumentDownloading = true;
    this.store.dispatch(new SignaturesAction.DownloadDocument({ matterId, documentId, documentName }));
  }

  getServerErrorIcon(): string {
    return server_error.icon;
  }

  getServerErrorTitle(): string {
    return server_error.title;
  }

  setActiveCommentStatus(currentActive: AnnotatorModel.AnnotationBeforeCreated): void {
    this.activeAnnotation = this.enrichActiveAnnotationDetail(currentActive, this.comments);
  }

  addOrUpdateComment(comment: AnnotatorModel.AnnotationData): void {
    const newAnnotation = <AnnotatorModel.AnnotationData>{
      ...comment,
      aboutPage: <AnnotatorModel.AnnotatedPage>{
        ...comment.aboutPage,
        fileId: this.documentId
      }
    };

    const { userId, userName } = this.annotatingBy;
    if (comment.isNew) {
      this.store.dispatch(new SignaturesAction.AddAnnotation({ ...newAnnotation, userId, displayName: userName }));
      return;
    }

    this.store.dispatch(new SignaturesAction.UpdateAnnotation({ ...newAnnotation, userId, displayName: userName }));
  }

  deleteComment(comment: AnnotatorModel.DeleteAnnotation): void {
    this.store.dispatch(new SignaturesAction.DeleteAnnotation(comment.annotationId));
  }

  togglePageHeader(direction: string): void {
    this.isSmallScreen &&
      this.customEventSvc.dispatchEvent(SIGNATURES_PREVIEW_HEADER_DISPLAY, { showHeader: direction === 'up' });
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private router: ActivatedRoute,
    private actions$: Actions,
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.MattersPreviewDocument,
        action: "View selected shared's document"
      });

      const { matterId, documentId } = this.router.parent.snapshot.params;

      this.documentId = documentId;
      this.matterId = matterId;

      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: false });

      merge(
        this.logonUserSideEffect$(),
        this.getPreviewDocumentUrlSuccessSideEffect$(),
        this.getPreviewDocumentUrlFailureSideEffect$(),
        this.getDownloadDocumentSuccessSideEffect$(),
        this.getDownloadDocumentFailureSideEffect$(),
        this.listenToCommentClickToViewRequestSideEffect$(),
        this.signatureAnnotationSuccessSideEffect$(),
        this.listenToDeleteCommentSuccessSideEffect$(),
        this.addAnnotationSuccessSideEffect$(),
        this.updateAnnotationSuccessSideEffect$(),
        this.smallScreenDetectionSideEffect$(),
        this.updateEvery60SecondsIfUserStillPreviewingDocumentHeartBeat$()
      )
        .pipe(takeUntil(this.destroy$))
        .subscribe();

      this.store.dispatch(
        new SignaturesAction.PreviewDocument({ matterId: this.matterId, documentId: this.documentId })
      );

      const signatureDetail = SignaturesModel.Helper.getSignatureDetail(
        this.store.selectSnapshot(AppState.getSignatures),
        this.matterId,
        this.documentId
      );

      if (signatureDetail && !SignaturesModel.Helper.isSignaturePendingOrDecline(signatureDetail)) {
        const { esignedDocumentId } = signatureDetail;
        esignedDocumentId && this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId));
      }
    }
  }

  private updateEvery60SecondsIfUserStillPreviewingDocumentHeartBeat$(): Observable<any> {
    return interval(60000).pipe(
      tap(() => {
        this.annotatingBy &&
          this.annotatingBy.userId &&
          this.documentId &&
          this.store.dispatch(
            new SignaturesAction.UpdateActiveUserHeartBeat({
              documentId: this.documentId,
              userId: this.annotatingBy.userId
            })
          );
      })
    );
  }

  private logonUserSideEffect$(): Observable<any> {
    return this.appActionSvc.logonUser$.pipe(
      tap(user => {
        if (user && user.userId && this.documentId) {
          this.store.dispatch(
            new SignaturesAction.StartActiveUserInDocument({ documentId: this.documentId, userId: user.userId })
          );
        }

        this.annotatingBy = <AnnotatorModel.AnnotatingBy>{
          documentId: this.documentId,
          userId: user.userId,
          userName: user.displayName
        };
      })
    );
  }

  private smallScreenDetectionSideEffect$(): Observable<any> {
    return this.appActionSvc.isSmallScreen$.pipe(
      tap(isSmallScreen => {
        this.isSmallScreen = isSmallScreen;
      })
    );
  }

  private getPreviewDocumentUrlSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.PreviewDocumentSuccess),
      tap(({ payload: url }) => {
        this.isLoading = false;
        this.previewUrl = url;

        this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_TAB_SWITCH, {
          esignedDocumentId: this.documentId,
          tabId: 'comments'
        });
      })
    );
  }

  private getPreviewDocumentUrlFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.PreviewDocumentFailure),
      tap(err => {
        this.isLoading = false;
        this.isError = true;
      })
    );
  }

  private getDownloadDocumentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DownloadDocumentSuccess),
      tap(() => {
        this.isDocumentDownloading = false;
      })
    );
  }

  private getDownloadDocumentFailureSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DownloadDocumentFailure),
      tap(() => {
        this.isDocumentDownloading = false;
        this.isError = true;
      })
    );
  }

  private listenToCommentClickToViewRequestSideEffect$(): Observable<any> {
    return this.customEventSvc.registerEvent(
      SIGNATURES_COMMENT_CLICK_TO_VIEW,
      ({ pageId, seqId }: SignaturesModel.CommentClickToViewRequest) => {
        this.switchToPage = { pageId, seqId };
      }
    );
  }

  private signatureAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.GetDocumentAnnotationSuccess),
      tap(({ payload }) => {
        if (payload && payload.length > 0) {
          this.comments = SignaturesModel.Helper.getCommentsInAscOrder(payload);
          this.commentSeqs = SignaturesModel.Helper.getCommentSeqs(this.comments);
          return;
        }

        this.comments = [];
        this.commentSeqs = [];
      })
    );
  }

  private listenToDeleteCommentSuccessSideEffect$(): Observable<any> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.DeleteAnnotationSuccess),
      tap(({ payload: { success, annotationId: deletedAnnotationId } }) => {
        if (!success) {
          return;
        }

        this.comments = SignaturesModel.Helper.getLatestCommentsAfterDeletingComment(
          this.comments,
          deletedAnnotationId
        );
        this.commentSeqs = SignaturesModel.Helper.getLatestCommentSeqsAfterDeletingComment(
          this.commentSeqs,
          deletedAnnotationId
        );
      })
    );
  }

  private enrichActiveAnnotationDetail(
    currentActive: AnnotatorModel.AnnotationBeforeCreated,
    annotations: SignaturesModel.LawConnectDocumentAnnotation[]
  ): AnnotatorModel.AnnotationBeforeCreated {
    let seq = 1;

    if (annotations && annotations.length > 0) {
      const found = annotations.find(x => x.id === currentActive.id);
      seq = found ? found.annotationSeq : annotations.length + 1;
    }

    const newRanges = currentActive.ranges.map(x =>
      Object.assign({}, x, {
        start: x.start.replace('"', '').replace('"', ''),
        end: x.end.replace('"', '').replace('"', '')
      })
    );

    return <AnnotatorModel.AnnotationBeforeCreated>{ ...currentActive, seq, ranges: newRanges };
  }

  private addAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.AddAnnotationSuccess),
      tap(({ payload: success }) => {
        if (!success) {
          return this.store.dispatch(new SignaturesAction.AddAnnotationFailure('Add annotation failed'));
        }

        // delay on purpose: to provide enough time for endpoint to complete the updates.
        setTimeout(() => this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId)), 1000);
      })
    );
  }

  private updateAnnotationSuccessSideEffect$(): Observable<{}> {
    return this.actions$.pipe(
      ofActionSuccessful(SignaturesAction.UpdateAnnotationSuccess),
      tap(({ payload: success }) => {
        if (!success) {
          return this.store.dispatch(new SignaturesAction.AddAnnotationFailure('Update annotation failed'));
        }

        // delay on purpose: to provide enough time for endpoint to complete the updates.
        setTimeout(() => this.store.dispatch(new SignaturesAction.GetDocumentAnnotation(this.documentId)), 1000);
      })
    );
  }
}
