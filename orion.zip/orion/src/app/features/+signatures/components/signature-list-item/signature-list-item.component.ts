import { ChangeDetectionStrategy, Component, Input, Inject, LOCALE_ID } from '@angular/core';
import { CoreModel, SignatureModel } from '@app/core/models';
import {
  CustomEventService,
  SIGNATURES_SIDE_TAB_SWITCH,
  SIGNATURES_LIST_FILE_PREVIEW,
  SIGNATURES_MULTIPLE_ACTIONS_OPEN,
  SIGNATURES_MULTIPLE_ACTIONS,
  SIGNATURES_LIST_FILE_SIGN
} from '@app/core/services';
import { SignaturesModel } from '../../models/signatures.model';
import { Store } from '@ngxs/store';
import { SignaturesAction } from '../../store';
// import { SignaturesAction } from '../../store';

@Component({
  selector: 'sc-signature-list-item',
  templateUrl: './signature-list-item.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignatureListItemComponent {
  @Input('data') data: SignaturesModel.SignatureItem;
  @Input('matter-id') matterId: string;
  @Input('last-item') isLastItem: boolean;
  @Input('current-user') currentUser: CoreModel.LogonUserInfo;
  @Input('small-screen') isSmallScreen: boolean;
  @Input('is-active') isActive: boolean;

  getIcon(ext: string): string {
    return CoreModel.Helper.getDocTypeIcon(ext);
  }

  getBadgeCss(data: SignaturesModel.SignatureItem): SignatureModel.SignStateTextAndStyle {
    return SignatureModel.Helper.SignatureText(data.esignedDocumentStatus);
  }

  isSignatureRequest(data: SignaturesModel.SignatureItem): boolean {
    return data && data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.Pending;
  }

  isSignaturePendingOrDecline(data: SignaturesModel.SignatureItem): boolean {
    return (
      data &&
      (data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.WaitingForOthers ||
        data.esignedDocumentStatus == SignatureModel.ESignatureDocumentStatus.Declined)
    );
  }

  getLastModifiedDate(): Date {
    return this.data.modifiedDate || this.data.createdDate;
  }

  getOwnerInitial(): CoreModel.User {
    if (this.data) {
      return { initial: CoreModel.Helper.getUserInitial(this.data.staffName), name: this.data.staffName };
    }

    return { initial: '', name: '' };
  }

  openActionSheet(): void {
    this.customEventSvc.dispatchEvent(SIGNATURES_MULTIPLE_ACTIONS_OPEN, {
      ...this.data,
      title: CoreModel.Helper.getValidDocumentNameWithExtension(this.data.esignedDocumentName, 'pdf'),
      subTitle: this.data.createdDate
        ? `Created on ${SignaturesModel.Helper.localeFormat(this.data.createdDate, this.locale)}`
        : ''
    });
  }

  preview(item: SignaturesModel.SignatureItem): void {
    if (item.esignedDocumentId) {
      this.viewSideComment(item, true);
      this.customEventSvc.dispatchEvent(SIGNATURES_LIST_FILE_PREVIEW, { ...item });
      return;
    }

    this.viewSideDetail(item);
    this.customEventSvc.dispatchEvent(SIGNATURES_LIST_FILE_SIGN, { orderId: item.orderId });
  }

  download(item: SignaturesModel.SignatureItem): void {
    this.viewSideDetail(item);
    const documentName = CoreModel.Helper.getValidDocumentNameWithExtension(item.esignedDocumentName, 'pdf');
    const documentId = item.esignedDocumentId;
    if (documentName && this.matterId) {
      this.store.dispatch(new SignaturesAction.DownloadDocument({ matterId: this.matterId, documentId, documentName }));
      return;
    }
  }

  viewSideDetail(item: SignaturesModel.SignatureItem): void {
    this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_TAB_SWITCH, { tabId: 'details', ...item });
  }

  viewSideComment(item: SignaturesModel.SignatureItem, skipListRender = false): void {
    this.customEventSvc.dispatchEvent(SIGNATURES_SIDE_TAB_SWITCH, { tabId: 'comments', ...item, skipListRender });
  }

  sign(item: SignaturesModel.SignatureItem): void {
    this.customEventSvc.dispatchEvent(SIGNATURES_LIST_FILE_SIGN, { orderId: item.orderId });
  }

  constructor(
    private customEventSvc: CustomEventService,
    private store: Store,
    @Inject(LOCALE_ID) private locale: string
  ) {}
}
