import { SignatureSideDetailsComponent } from './signature-side-details/signature-side-details.component';
import { SignatureListItemComponent } from './signature-list-item/signature-list-item.component';
import { SignatureSideCommentsComponent } from './signature-side-comments/signature-side-comments.component';
import { SignatureCardInformationComponent } from './signature-card-information/signature-card-information.component';
import { SignatureSideCommentsReplyComponent } from './signature-side-comments-reply/signature-side-comments-reply.component';

export * from './signature-side-details/signature-side-details.component';
export * from './signature-list-item/signature-list-item.component';
export * from './signature-side-comments/signature-side-comments.component';
export * from './signature-card-information/signature-card-information.component';
export * from './signature-side-comments-reply/signature-side-comments-reply.component';

export const signaturesComponents = [
  SignatureSideDetailsComponent,
  SignatureListItemComponent,
  SignatureSideCommentsComponent,
  SignatureCardInformationComponent,
  SignatureSideCommentsReplyComponent
];
