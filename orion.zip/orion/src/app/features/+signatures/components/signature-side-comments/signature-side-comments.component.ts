import { ChangeDetectionStrategy, Component, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { LyraAnimation } from '@leap/lyra-design';

import { CoreModel } from '@app/core/models';
import { SignaturesModel } from '../../models/signatures.model';
import { environment } from '@env/environment';
import { AnnotatorModel } from '@app/shared/models';
import { DialogService } from '@app/shared/services';
import {
  CustomEventService,
  SIGNATURES_COMMENT_REPLIED_DELETE,
  SIGNATURES_COMMENT_CLICK_TO_VIEW,
  SIGNATURES_SIDE_REFRESH_ME
} from '@app/core/services';
import { SignaturesAction } from '../../store';
import { Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

const emptyComment = environment.locale.no_results.comments.empty;

@Component({
  selector: 'sc-signature-side-comments',
  templateUrl: './signature-side-comments.component.html',
  animations: [LyraAnimation.xAnimationCardItemCollapse],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignatureSideCommentsComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();

  @Input('document-id') documentId: string;

  @Input('comments') comments: SignaturesModel.LawConnectDocumentAnnotation[];

  @Input('replied') replied: SignaturesModel.AnnotationRepliedList;

  @Input('current-user') currentUser: CoreModel.LogonUserInfo;

  isCommentStillUpdateInProgress = false;
  showReplyForm = false;
  enableReplies = false;
  replyFormCommentId = '';
  initUpdate = false;

  get emptyComment(): any {
    return emptyComment;
  }

  hasValidComments(comments: SignaturesModel.LawConnectDocumentAnnotation[]): boolean {
    if (!comments || comments.length == 0) {
      return false;
    }

    return true;
  }

  getCommentUserName(userInfo: AnnotatorModel.AnnotatedBy): string {
    return `${userInfo.firstName} ${userInfo.lastName}`;
  }

  getUserComment(comments: AnnotatorModel.AnnotatedEvent[]): string {
    if (comments && comments.length > 0) {
      return comments[0].text;
    }

    return ' - ';
  }

  navigateTo(info: SignaturesModel.CommentClickToViewRequest): void {
    this.customEventSvc.dispatchEvent(SIGNATURES_COMMENT_CLICK_TO_VIEW, {
      pageId: info.pageId,
      seqId: `annotation-seq-${info.seqId}`
    });
  }

  deleteDocumentAnnotation(annotation: SignaturesModel.LawConnectDocumentAnnotation) {
    this.dialogSvc.confirm({
      title: 'Deleting the comment',
      message: 'It will also delete all replies to the comment. Are you sure?',
      actionText: 'Delete',
      closeText: 'Cancel',
      showCancel: true,
      onClose: (confirmed: boolean) => {
        if (confirmed) {
          this.store.dispatch(new SignaturesAction.DeleteAnnotation(annotation.id));
        }
      }
    });
  }

  getReply(annotationId: string): SignaturesModel.LawConnectDocumentAnnotationReplied[] {
    if (this.replied) {
      return this.replied[annotationId] || [];
    }

    return [];
  }

  getReplyForm(commentId: string) {
    this.showReplyForm = true;
    this.replyFormCommentId = commentId;
  }

  cancelReply() {
    this.showReplyForm = false;
  }

  displayReplies() {
    this.enableReplies = true;
  }

  deleteAnnotationReply(replyId: string, annotationId: string) {
    const deletePayload = <AnnotatorModel.DeleteAnnotationReply>{
      annotationId: annotationId,
      replyId: replyId
    };

    this.customEventSvc.dispatchEvent(SIGNATURES_COMMENT_REPLIED_DELETE, { ...deletePayload });
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  trackReplyElement(index: number, element: any) {
    return `${element ? element.id : index}-replied`;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(
    private dialogSvc: DialogService,
    private customEventSvc: CustomEventService,
    private store: Store,
    private cd: ChangeDetectorRef
  ) {
    this.refreshMeSideEffect$()
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private refreshMeSideEffect$(): Observable<{}> {
    return this.customEventSvc.registerEvent(SIGNATURES_SIDE_REFRESH_ME, () => {
      this.cd && this.cd.markForCheck();
    });
  }
}
