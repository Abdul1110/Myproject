import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'sc-signature-card-information',
  templateUrl: './signature-card-information.component.html',
  host: { '[class.x-card-inline]': 'enabled' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignatureCardInformationComponent {
  enabled = true;

  @Input('name')
  name: string;

  @Input('type')
  type: string;

  @Input('status')
  status: string;

  @Input('created')
  created: string;

  @Input('modified')
  modified: string;

  constructor() {}

  ngOnInit() {}
}
