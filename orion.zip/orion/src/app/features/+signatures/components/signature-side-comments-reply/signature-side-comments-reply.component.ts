import { Component, Input, EventEmitter, Output, HostBinding } from '@angular/core';
import { LyraAnimation } from '@leap/lyra-design';
import { SignaturesModel } from '../../models/signatures.model';
import { Store } from '@ngxs/store';
import { SignaturesAction } from '../../store';

@Component({
  selector: 'sc-signature-side-comments-reply',
  templateUrl: './signature-side-comments-reply.component.html',
  host: {
    '[@xAnimationCardFooterCollapse]': 'true'
  },
  animations: [LyraAnimation.xAnimationCardFooterCollapse]
})
export class SignatureSideCommentsReplyComponent {
  @Input('document-id') documentId: string;
  @Input('annotation-id') annotationId: string;
  @Input('page-id') pageId: string;
  @Output('cancel') cancel = new EventEmitter();

  constructor(private store: Store) {}

  @HostBinding('class.x-card-footer-reply')
  onCancel(): void {
    this.cancel.emit();
  }

  onReply(replyText: string): void {
    if (!replyText) {
      return;
    }

    this.store.dispatch(
      new SignaturesAction.ReplyComment({
        documentId: this.documentId,
        annotationId: this.annotationId,
        text: replyText,
        pageId: this.pageId
      })
    );

    this.onCancel();
  }
}
