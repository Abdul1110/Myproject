import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { SignaturesModel } from '../../models/signatures.model';
import { CoreModel, SignatureModel } from '@app/core/models';
import { environment } from '@env/environment';

const emptyComment = environment.locale.no_results.details.empty;

@Component({
  selector: 'sc-signature-side-details',
  templateUrl: './signature-side-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SignatureSideDetailsComponent {
  documentMessage = emptyComment;
  @Input('data') data: SignaturesModel.SignatureItem;
  @Input('current-user') currentUser: CoreModel.LogonUserInfo;
  @Input('firm-name') firmName: string;
  @Input('activities') activities: SignaturesModel.LawConnectDocumentHistory[];

  signatureStatus(data: SignaturesModel.SignatureItem): string {
    return data && SignatureModel.Helper.ESignatureDocumentStatusToText(data.esignedDocumentStatus);
  }

  fileSize(fs: number): string {
    if (!fs || fs === 0) {
      return '0 KB';
    }

    const sizes = [' KB', ' MB', ' GB'];
    const i = Math.floor(Math.log(fs) / Math.log(1024));
    const fileSize =
      i < 3 ? Math.round(fs / Math.pow(1024, i)) + sizes[i] : Math.round(fs / Math.pow(1024, 2)) + sizes[2];
    return fileSize;
  }

  hasValidDetail(data: SignaturesModel.SignatureItem): boolean {
    if (!data || !((data.esignedDocumentId || data.orderId) && data.esignedDocumentName)) {
      return false;
    }

    return true;
  }

  hasValidSharedBy(data: SignaturesModel.SignatureItem): boolean {
    if (!data || !data.staffName) {
      return false;
    }

    return true;
  }

  getSharedByDescription(data) {
    if (data && this.currentUser && this.data.staffId === this.currentUser.userId) {
      return '';
    }
    return this.firmName;
  }

  hasValidSigner(data: SignaturesModel.SignatureItem): boolean {
    return data && data.requestedSigners && data.requestedSigners.length > 0;
  }

  hasValidActivities(activities: SignaturesModel.LawConnectDocumentWithActivity[]): boolean {
    return activities && activities.length > 0;
  }

  getActivityDescription(
    activity: SignaturesModel.LawConnectDocumentHistory,
    currentUser: CoreModel.LogonUserInfo
  ): string {
    return SignaturesModel.Helper.getMatterActivityDescription(activity, currentUser.userId);
  }

  getSignerTitle(data: SignaturesModel.SignatureItem): string {
    return data.requestedSigners.length > 1 ? 'Signers' : 'Signer';
  }

  getSignerName(signer: SignatureModel.ESigner): string {
    if (signer && signer.firstName && signer.lastName) {
      return `${signer.firstName} ${signer.lastName}`;
    }

    if (signer && signer.firstName) {
      return signer.firstName;
    }

    return signer.lastName || signer.initials || '?';
  }

  getSignStatus(signer: SignatureModel.ESigner): string {
    if (signer && signer.status !== undefined) {
      const status = SignatureModel.Helper.SignerStatusText(signer.status);
      if (status) {
        return status;
      }
    }
    return 'Unknown';
  }

  trackElement(index: number, element: any) {
    return index;
  }

  constructor() {}
}
