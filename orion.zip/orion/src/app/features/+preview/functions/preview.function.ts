export function isDocument(ext: string): boolean {
  return isPdf(ext) === true || isWordDocument(ext) === true || isSpreadsheet(ext) === true || isEmail(ext) === true;
}

export function isPdf(ext: string): boolean {
  return /(pdf)$/i.test(ext);
}

export function isWordDocument(ext: string): boolean {
  return /(docx)$/i.test(ext);
}

export function isSpreadsheet(ext: string): boolean {
  return /(xlsx)$/i.test(ext);
}

export function isEmail(ext: string): boolean {
  return /(msg|eml|emlx)$/i.test(ext);
}

export function isImage(ext: string): boolean {
  return /(bmp|gif|jpe?g|png|tiff)$/i.test(ext);
}
