import { CorrespondenceViewComponent } from './view/correspondence-view.component';
import { CorrespondenceToolbarComponent } from './toolbar/correspondence-toolbar.component';

export * from './view/correspondence-view.component';
export * from './toolbar/correspondence-toolbar.component';

export const previewComponents = [CorrespondenceViewComponent, CorrespondenceToolbarComponent];
