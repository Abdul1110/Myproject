import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PreviewModel } from '@app/features/+preview/models';
import { isDocument, isImage } from '@app/features/+preview/functions';
import { environment } from '@env/environment';

const { document: no_results } = (<any>environment.locale).no_results.documents;

@Component({
  selector: 'sc-correspondence-view',
  templateUrl: './correspondence-view.component.html'
})
export class CorrespondenceViewComponent implements OnInit {
  file_to_large: any;
  @Input() errorMessage: string;
  @Input() token: string;
  @Input()
  set preview(value: PreviewModel.PreviewInfo) {
    this.usePdfViewer = true;
    if (value) {
      this.isBigFile = value.fileSizeInKb > environment.appSettings.previewFileSizeLimit; //FileSize >50MB
      this.previewUrl = value.downloadUrl;
      this.usePdfViewer = isDocument(value.downloadFileExtension);
      this.useImgViewer = isImage(value.downloadFileExtension);
    }
  }
  @Input('is-document-downloading') documentDownloading: boolean;

  @Output('download-document') download = new EventEmitter();

  previewUrl: string;
  usePdfViewer: boolean;
  useImgViewer: boolean;
  isBigFile: boolean;

  constructor() {
    this.file_to_large = no_results.file_to_large;
  }

  ngOnInit() {}

  downloadDocument(): void {
    this.download.emit();
  }
}
