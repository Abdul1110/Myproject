import { Component, OnInit, EventEmitter, Output, HostBinding } from '@angular/core';

@Component({
  selector: 'sc-correspondence-toolbar',
  templateUrl: './correspondence-toolbar.component.html'
})
export class CorrespondenceToolbarComponent implements OnInit {
  @Output() onViewInLawConnect = new EventEmitter<void>();

  constructor() {}

  @HostBinding('class.x-file-viewer-toolbar')
  ngOnInit() {}

  viewInLawConnect(): void {
    this.onViewInLawConnect.emit();
  }
}
