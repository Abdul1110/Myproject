import { catchError, map, switchMap } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';
import { environment } from '@env/environment';
import { State, Selector, Action, StateContext } from '@ngxs/store';
import { saveAs as FileSaver } from 'file-saver';
import { PreviewModel } from '../../models';
import { PreviewAction } from '../actions';
import { PreviewService } from '../../services';

export interface PreviewStateModel {
  error: any | string | null;
  loading: boolean;
  laddaLoading: boolean;
  correspondence: PreviewModel.CurrentPreviewCorrespondence;
  download: PreviewModel.PreviewCorrespondenceDownloadProgress;
  previewInfo: PreviewModel.PreviewInfo;
  shareId: string;
  documentDownloading: boolean;
}

@State<PreviewStateModel>({
  name: 'preview',
  defaults: {
    error: null,
    loading: true,
    laddaLoading: false,
    correspondence: undefined,
    download: undefined,
    previewInfo: null,
    shareId: null,
    documentDownloading: false
  }
})
export class PreviewState {
  constructor(private previewSvc: PreviewService, private browserSvc: BrowserService) {}

  @Selector()
  static selectLoading(state: PreviewStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.loading;
  }

  @Selector()
  static selectError(state: PreviewStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.error;
  }

  @Selector()
  static selectLaddaLoading(state: PreviewStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.laddaLoading;
  }

  @Selector()
  static selectPreviewCorrespondence(state: PreviewStateModel): PreviewModel.CurrentPreviewCorrespondence {
    if (!state) {
      return undefined;
    }

    return state.correspondence;
  }

  @Selector()
  static selectDownloadCorrespondence(state: PreviewStateModel): PreviewModel.PreviewCorrespondenceDownloadProgress {
    if (!state) {
      return undefined;
    }

    return state.download;
  }

  @Selector()
  static selectPreviewInfo(state: PreviewStateModel): PreviewModel.PreviewInfo {
    if (!state) {
      return undefined;
    }

    return state.previewInfo;
  }

  @Selector()
  static selectShareId(state: PreviewStateModel): string {
    if (!state) {
      return '';
    }

    return state.shareId;
  }

  @Selector()
  static selectDocumentDownloading(state: PreviewStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.documentDownloading;
  }

  @Action(PreviewAction.PreviewDownload)
  PreviewDownload({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();

    setState({
      ...state,
      documentDownloading: true
    });

    return this.previewSvc.downloadDocument(state.shareId).pipe(
      map(response => dispatch(new PreviewAction.PreviewTransformDownload(response.downloadUrl))),
      catchError(error => dispatch(new PreviewAction.PreviewDownloadFaillure(error)))
    );
  }

  @Action(PreviewAction.PreviewTransformDownload)
  PreviewTransformDownload({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const url = payload.payload as string;

    return this.previewSvc.download(url).pipe(
      map(bl => {
        FileSaver.saveAs(bl, state.previewInfo.documentName);
      }),
      map(() => dispatch(new PreviewAction.PreviewTransformDownloadSuccess())),
      catchError(error => dispatch(new PreviewAction.PreviewTransformDownloadFailure(error)))
    );
  }

  @Action(PreviewAction.PreviewTransformDownloadFailure)
  PreviewTransformDownloadFailure({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      documentDownloading: false,
      error: err.message
    });
  }

  @Action(PreviewAction.PreviewTransformDownloadSuccess)
  PreviewTransformDownloadSuccess({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();

    setState({
      ...state,
      documentDownloading: false
    });
  }

  @Action(PreviewAction.PreviewDownloadFaillure)
  DownloadDocumentFailure({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      documentDownloading: false,
      error: err.message
    });
  }

  @Action(PreviewAction.PreviewDownloadInprogress)
  PreviewDownloadInprogress({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const downloadStatus = payload.payload as PreviewModel.PreviewCorrespondenceDownloadProgress;

    setState({
      ...state,
      download: downloadStatus
    });
  }

  @Action(PreviewAction.PreviewInfoStart)
  PreviewInfoStart({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const shareId = payload.payload as string;

    setState({
      ...state,
      loading: true,
      shareId
    });

    return this.previewSvc.getPreviewInfo(shareId).pipe(
      map(info => dispatch(new PreviewAction.PreviewInfoSuccess(info))),
      catchError(error => {
        const err = this.previewSvc.getError(error);
        return dispatch(new PreviewAction.PreviewInfoFailure(err));
      })
    );
  }

  @Action(PreviewAction.PreviewInfoSuccess)
  PreviewInfoSuccess({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const info = payload.payload as PreviewModel.PreviewInfo;

    setState({
      ...state,
      loading: false,
      previewInfo: info
    });
  }

  @Action(PreviewAction.PreviewInfoFailure)
  PreviewInfoFailure({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;

    setState({
      ...state,
      loading: false,
      error,
      previewInfo: undefined
    });
  }

  @Action(PreviewAction.PreviewInLawConnect)
  PreviewInLawConnect({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const info = payload.payload as PreviewModel.LawConnectPreviewInfo;
    const shareId = state.shareId;
    const previewInfo = state.previewInfo;
    const window = this.browserSvc.window;
    if (!previewInfo) {
      window.open(environment.appSettings.orionEndpoint);
      return;
    }

    const { documentId, downloadFileExtension } = previewInfo;
    const viewer = info.viewer || (PreviewModel.Helper.isImage(downloadFileExtension) ? 'image' : 'pdf');
    let url = `${environment.appSettings.orionEndpoint}/nodes/${documentId}/event/${shareId}?viewer=${viewer}`;
    url += !!info.sharedTo ? `&sharedTo=${info.sharedTo}` : '';
    url += previewInfo ? `&fileSize=${previewInfo.fileSizeInKb}` : '';
    window.open(url);
  }

  @Action(PreviewAction.PreviewOpen)
  PreviewOpen({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const correspondence = payload.payload as PreviewModel.CurrentPreviewCorrespondence;

    setState({
      ...state,
      loading: true,
      correspondence
    });
  }

  @Action(PreviewAction.PreviewOpenSuccess)
  PreviewOpenSuccess({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const folderId = payload.payload as string;

    setState({
      ...state,
      loading: false,
      correspondence: <PreviewModel.CurrentPreviewCorrespondence>{
        ...state.correspondence,
        folderId
      }
    });
  }

  @Action(PreviewAction.PreviewOpenFailure)
  PreviewOpenFailure({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;

    setState({
      ...state,
      loading: false,
      correspondence: undefined,
      error
    });
  }

  @Action(PreviewAction.PreviewCorrespondenceUpdate)
  PreviewCorrespondenceUpdate({ getState, setState, dispatch }: StateContext<PreviewStateModel>, payload) {
    const state = getState();
    const correspondence = payload.payload as PreviewModel.CurrentPreviewCorrespondence;

    if (correspondence.previewFrom === PreviewModel.PreviewTriggerType.default) {
      setState({
        ...state,
        correspondence: <PreviewModel.CurrentPreviewCorrespondence>{
          ...correspondence,
          previewFrom: state.correspondence.previewFrom
        }
      });
      return;
    }

    setState({
      ...state,
      correspondence
    });
  }
}
