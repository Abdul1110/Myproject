import { PreviewModel } from '../../models';

export namespace PreviewAction {
  const prefix = '[Preview]';

  export const ActionTypes = {
    PREVIEW_OPEN: `${prefix} modal open`,
    PREVIEW_OPEN_SUCCESS: `${prefix} modal open success`,
    PREVIEW_OPEN_FAILURE: `${prefix} Failed to open in modal`,

    PREVIEW_CORRESPONDENCE_UPDATE: `${prefix} correspondence update`,

    PREVIEW_DOWNLOAD: `${prefix} correspondence download`,
    PREVIEW_DOWNLOAD_INPROGRESS: `${prefix} correspondence download inprogress`,
    PREVIEW_TRANSFORM_DOWNLOAD: `${prefix} Transform download`,
    PREVIEW_TRANSFORM_DOWNLOAD_SUCCESS: `${prefix} Transform download success`,
    PREVIEW_TRANSFORM_DOWNLOAD_FAILURE: `${prefix} Failed to transform before downloading`,
    PREVIEW_DOWNLOAD_FAILURE: `${prefix} Failed to download the correspondence`,

    PREVIEW_EMAIL: `${prefix} correspondence email`,

    PREVIEW_PRINT: `${prefix} print`,
    PREVIEW_PRINT_SUCCESS: `${prefix} print success`,
    PREVIEW_PRINT_FAILURE: `${prefix} Failed to print the document`,

    PREVIEW_INFO_START: `${prefix} info from api start`,
    PREVIEW_INFO_SUCCESS: `${prefix} info from api success`,
    PREVIEW_INFO_FAILURE: `${prefix} Failed to read info from server`,

    PREVIEW_IN_LAWCONNECT: `${prefix} in LawConnect`
  };

  export class PreviewOpen {
    static readonly type = ActionTypes.PREVIEW_OPEN;
    constructor(public payload: PreviewModel.CurrentPreviewCorrespondence) {}
  }

  export class PreviewOpenSuccess {
    static readonly type = ActionTypes.PREVIEW_OPEN_SUCCESS;
    constructor(public payload: string) {}
  }

  export class PreviewOpenFailure {
    static readonly type = ActionTypes.PREVIEW_OPEN_FAILURE;
    constructor(public payload: any) {}
  }

  export class PreviewCorrespondenceUpdate {
    static readonly type = ActionTypes.PREVIEW_CORRESPONDENCE_UPDATE;
    constructor(public payload: PreviewModel.CurrentPreviewCorrespondence) {}
  }

  export class PreviewDownload {
    static readonly type = ActionTypes.PREVIEW_DOWNLOAD;
    constructor() {}
  }

  export class PreviewDownloadInprogress {
    static readonly type = ActionTypes.PREVIEW_DOWNLOAD_INPROGRESS;
    constructor(public payload: PreviewModel.PreviewCorrespondenceDownloadProgress) {}
  }
  export class PreviewTransformDownload {
    static readonly type = ActionTypes.PREVIEW_TRANSFORM_DOWNLOAD;
    constructor(public payload: string) {}
  }

  export class PreviewTransformDownloadSuccess {
    static readonly type = ActionTypes.PREVIEW_TRANSFORM_DOWNLOAD_SUCCESS;
    constructor() {}
  }

  export class PreviewTransformDownloadFailure {
    static readonly type = ActionTypes.PREVIEW_TRANSFORM_DOWNLOAD_FAILURE;
    constructor(public payload: string) {}
  }

  export class PreviewDownloadFaillure {
    static readonly type = ActionTypes.PREVIEW_DOWNLOAD_FAILURE;
    constructor(public payload: any) {}
  }

  export class PreviewEmail {
    static readonly type = ActionTypes.PREVIEW_EMAIL;
    constructor(public payload: boolean) {}
  }

  export class PreviewPrint {
    static readonly type = ActionTypes.PREVIEW_PRINT;
    constructor(public payload: any) {}
  }

  export class PreviewPrintSuccess {
    static readonly type = ActionTypes.PREVIEW_PRINT_SUCCESS;
    constructor(public payload: string) {}
  }

  export class PreviewPrintFailure {
    static readonly type = ActionTypes.PREVIEW_PRINT_FAILURE;
    constructor(public payload: any) {}
  }

  export class PreviewInfoStart {
    static readonly type = ActionTypes.PREVIEW_INFO_START;
    constructor(public payload: string) {}
  }

  export class PreviewInfoSuccess {
    static readonly type = ActionTypes.PREVIEW_INFO_SUCCESS;
    constructor(public payload: PreviewModel.PreviewInfo) {}
  }

  export class PreviewInfoFailure {
    static readonly type = ActionTypes.PREVIEW_INFO_FAILURE;
    constructor(public payload: any) {}
  }

  export class PreviewInLawConnect {
    static readonly type = ActionTypes.PREVIEW_IN_LAWCONNECT;
    constructor(public payload: PreviewModel.LawConnectPreviewInfo) {}
  }
}
