import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Angulartics2Module } from 'angulartics2';
import { NgxsModule } from '@ngxs/store';

// local
import { SharedModule } from '@app/shared';
import { previewPages } from './pages';
import { previewComponents } from './components';
import { AppStateModule } from '@app/core/app-state.module';
import { PreviewRoutingModule } from './preview-routing.module';
import { PreviewStates } from './store';
import { previewServices } from './services';
import { InlineSVGModule } from 'ng-inline-svg';
import { LyraDesignEmptyStateModule, LyraDesignButtonModule, LyraDesignTypeModule } from '@leap/lyra-design';

@NgModule({
  imports: [
    NgxsModule.forFeature([...PreviewStates]),
    Angulartics2Module,
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    LyraDesignEmptyStateModule,
    LyraDesignButtonModule,
    LyraDesignTypeModule,
    SharedModule,
    AppStateModule,
    PreviewRoutingModule
  ],
  entryComponents: [...previewPages],
  declarations: [...previewComponents, ...previewPages],
  providers: [...previewServices]
})
export class PreviewModule {}
