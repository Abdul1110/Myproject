import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { LogService } from '@app/core/services';
import { PreviewModel } from '@app/features/+preview/models';
import { environment } from '@env/environment';

@Injectable(<any>{
  providedIn: 'root'
})
export class PreviewService {
  constructor(private http: HttpClient, private _log: LogService) {
    this._log.init('preview-service');
  }

  getPreviewInfo(shareId: string): Observable<PreviewModel.PreviewInfo> {
    const url = `${
      environment.appSettings.apiBaseUrl
    }v1/dto/home/documents/share/${shareId}/downloadInfo?isPreview=true`;
    return this.http.get<PreviewModel.PreviewInfo>(url);
  }

  downloadDocument(shareId: string): Observable<PreviewModel.DownloadResponse> {
    const url = `${
      environment.appSettings.apiBaseUrl
    }v2/dto/home/documents/share/${shareId}/download?isPreview=false&redirect=false`;
    return this.http.get<PreviewModel.DownloadResponse>(url);
  }

  download(url: string): Observable<any> {
    return this.http.get(url, { responseType: 'blob' });
  }

  getError(error: any): string {
    if (!error) {
      return '';
    }
    if (error instanceof HttpErrorResponse) {
      const status = (<HttpErrorResponse>error).status;
      switch (status) {
        case 401:
          return 'This document link is no longer valid!';
        case 404:
          return 'This document link is not valid!';
        case 500:
          return 'There is an error when retrieving this document. Please contact the document owner!';
        default:
          return 'No Preview Available!';
      }
    }
    return 'No Preview Available!';
  }
}
