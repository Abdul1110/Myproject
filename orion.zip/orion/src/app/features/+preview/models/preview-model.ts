export namespace PreviewModel {
  export interface CurrentPreviewCorrespondence {
    id: string;
    latestVersionId: string;
    name: string;
    previewUrl?: string;
    folderId: string;
    createDate: Date;
    staffName: string;
    ext: string;
    desktopOnly: boolean;
    isEmail: boolean;
    isPdf: boolean;
    isImage: boolean;
    isWord: boolean;
    previewFrom: PreviewTriggerType;
  }

  export interface SelectedPreviewCorrespondence {
    folderId: string;
    // doc: IDoc;
  }

  export interface PreviewCorrespondenceDownloadProgress {
    fileName: string;
    fileNameOnly: string;
    url: string;
    loading: boolean;
  }

  export interface PreviewInfo {
    documentId: string;
    documentName: string;
    downloadFileExtension: string;
    downloadUrl: string;
    fileSizeInKb: number;
  }
  export interface DownloadResponse {
    downloadUrl: string;
  }

  export enum PreviewTriggerType {
    default = 0,
    click = 1,
    contextMenu = 2
  }

  export interface LawConnectPreviewInfo {
    viewer: string;
    sharedTo: string;
  }

  export class Helper {
    static isDocument(ext: string): boolean {
      return (
        this.isPdf(ext) === true ||
        this.isWordDocument(ext) === true ||
        this.isSpreadsheet(ext) === true ||
        this.isEmail(ext) === true
      );
    }

    static isPdf(ext: string): boolean {
      return /(pdf)$/i.test(ext);
    }

    static isWordDocument(ext: string): boolean {
      return /(docx)$/i.test(ext);
    }

    static isSpreadsheet(ext: string): boolean {
      return /(xlsx)$/i.test(ext);
    }

    static isEmail(ext: string): boolean {
      return /(msg|eml|emlx)$/i.test(ext);
    }

    static isImage(ext: string): boolean {
      return /(bmp|gif|jpe?g|png|tiff)$/i.test(ext);
    }
  }
}
