import { PreviewModalShellComponent } from './preview/preview-modal-shell.component';

export * from './preview/preview-modal-shell.component';

export const previewPages = [PreviewModalShellComponent];
