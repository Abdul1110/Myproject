import { Component, OnDestroy, OnInit, ViewEncapsulation, HostBinding } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Select, Store } from '@ngxs/store';

import * as actions from '../../store/actions';
import { LogService, AnalyticService } from '@app/core/services';
import { PreviewModel } from '@app/features/+preview/models';
import { PreviewState } from '@app/features/+preview/store';
import { PreviewService } from '../../services';
import { BrowserService } from '@leap/lyra-design';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

@Component({
  selector: 'sc-preview-modal-shell',
  templateUrl: './preview-modal-shell.component.html',
  styleUrls: ['./preview-modal-shell.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PreviewModalShellComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<boolean>();

  token: string;

  @Select(PreviewState.selectLoading) loading$: Observable<boolean>;

  @Select(PreviewState.selectError) error$: Observable<boolean>;

  @Select(PreviewState.selectPreviewInfo) preview$: Observable<PreviewModel.PreviewInfo>;

  @Select(PreviewState.selectDocumentDownloading) downloadingDocument$: Observable<boolean>;

  constructor(
    private route: ActivatedRoute,
    private log: LogService,
    private store: Store,
    private previewSvc: PreviewService,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.PreviewDocumentPage, action: 'View document' });
    }

    this.log.init('preview-modal-shell');
  }

  @HostBinding('class.x-file-viewer-full')
  ngOnDestroy() {
    this.destroy$.next(true);
  }

  ngOnInit() {
    const shareId = this.route.snapshot.params['shareId'];
    this.store.dispatch(new actions.PreviewAction.PreviewInfoStart(shareId));
  }

  onViewInLawConnect(): void {
    this.store.dispatch(
      new actions.PreviewAction.PreviewInLawConnect({
        viewer: this.route.snapshot.queryParams['viewer'],
        sharedTo: this.route.snapshot.queryParams['sharedTo']
      })
    );
  }

  getTitle(info: PreviewModel.PreviewInfo): string {
    if (!info) {
      return '';
    }
    return `${info.documentName}`;
  }

  getError(error: any): string {
    return this.previewSvc.getError(error);
  }

  download(): void {
    this.store.dispatch(new actions.PreviewAction.PreviewDownload());
  }
}
