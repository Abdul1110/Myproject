import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { StandardModel } from '@leap/lyra-design';

@Component({
  selector: 'sc-side-firm-document',
  templateUrl: './side-firm-document.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SideFirmDocumentComponent {
  @Input('theme')
  themeSetting: StandardModel.ThemeSetting;

  @Input('is-whitelabel')
  isWhiteLabel: boolean;

  @Input('firm-id')
  firmId: string;

  @Input('height')
  height: number;

  @Input('width')
  width: number;
}
