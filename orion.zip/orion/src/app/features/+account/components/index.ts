import { SideFirmDocumentComponent } from './side-firm-document/side-firm-document.component';

export * from './side-firm-document/side-firm-document.component';

export const accountComponents = [SideFirmDocumentComponent];
