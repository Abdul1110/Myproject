export namespace AccountModel {
  export interface SignUpRequest {
    userName: string;
    firstName: string;
    lastName: string;
    password: string;
    isWhiteLabel?: boolean;
    agreeToTermsAndConditions?: boolean;
    redirectUrl?: string;
    firmId: string;
  }

  export interface SignInRequest {
    userName: string;
    password: string;
    rememberMe: boolean;
  }

  export interface ResetPasswordRequest {
    userName: string;
    firmId: string;
  }

  export interface ProfileResponse {
    userId: string;
    displayName: string;
  }

  export interface ProfileAndUserMetadata extends ProfileResponse {
    hasAgreeTermsAndConditions: boolean;
    documentAnnotationVisited: boolean;
    documentSignatureVisited: boolean;
  }

  export interface ResendConfirmationRequest {
    email: string;
    userId: string;
    firmId: string;
    agreeToTermsAndConditions: boolean;
    redirectUrl: string;
  }

  export class Helper {
    static toLowerCase(val: string): string {
      if (val) {
        return val.toLowerCase();
      }
      return val;
    }
  }
}
