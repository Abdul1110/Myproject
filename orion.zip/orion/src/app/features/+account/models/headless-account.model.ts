export const headlessAccountPaths = {
  signinPath: '/account/headless/signin',
  signupPath: '/account/headless/signup',
  resetPath: '/account/headless/reset-password',
  confirmation: '/account/headless/signup-confirmation'
};

export interface PostMessage {
  page: 'login' | 'create account' | 'forgot password';
  success: boolean;
  message: string;
}
