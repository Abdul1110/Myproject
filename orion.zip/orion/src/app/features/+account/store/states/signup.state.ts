import { State, Selector, StateContext, Action } from '@ngxs/store';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { map, catchError } from 'rxjs/operators';

import { CoreModel } from '@app/core/models';
import { NavigationService } from '@app/core/services';
import { AccountApiService } from '../../services';
import { SignUpAction } from '../actions';
import { AccountModel } from '../../models';

export interface SignUpStateModel {
  error: string;
  loading: boolean;
  data: LyraDesignFormModel.SignUpResponse;
}

@State<SignUpStateModel>({
  name: 'signup',
  defaults: {
    error: undefined,
    loading: false,
    data: undefined
  }
})
export class SignUpState {
  constructor(
    private accountSvc: AccountApiService,
    private browserSvc: BrowserService,
    private navigationSvc: NavigationService
  ) {}

  @Selector()
  static getLoadingStatus(state: SignUpStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.loading;
  }

  @Selector()
  static getError(state: SignUpStateModel): string {
    if (!state) {
      return undefined;
    }

    return state.error;
  }

  @Selector()
  static getEmail(state: SignUpStateModel): string {
    if (!state || !state.data) {
      return undefined;
    }

    return state.data.email;
  }

  @Selector()
  static getResendData(state: SignUpStateModel): { userId: string; email: string; agreeToTermsAndConditions: boolean } {
    if (!state || !state.data) {
      return undefined;
    }

    const data = state.data;
    return {
      userId: data._id,
      email: data.email,
      agreeToTermsAndConditions: data.user_metadata
        ? AccountModel.Helper.toLowerCase(data.user_metadata['has_agree_to_lawconnect_privacy']) == 'true'
        : false
    };
  }

  @Action(SignUpAction.SignUpStart)
  SignUpStart({ getState, setState, dispatch }: StateContext<SignUpStateModel>, payload) {
    const state = getState();
    const signUpRequest = payload.payload as AccountModel.SignUpRequest;

    setState({
      ...state,
      loading: true,
      error: undefined,
      data: undefined
    });

    return this.accountSvc.signup(signUpRequest).pipe(
      map(result => dispatch(new SignUpAction.SignUpSuccess(result))),
      catchError(error => dispatch(new SignUpAction.SignUpFailure(error)))
    );
  }

  @Action(SignUpAction.SignUpSuccess)
  SignUpSuccess({ getState, setState, dispatch }: StateContext<SignUpStateModel>, payload) {
    const state = getState();
    const data = payload.payload as LyraDesignFormModel.SignUpResponse;

    setState({
      ...state,
      loading: false,
      error: undefined,
      data
    });
  }

  @Action(SignUpAction.SignUpFailure)
  SignUpFailure({ getState, setState, dispatch }: StateContext<SignUpStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      loading: false,
      error: err.message,
      data: undefined
    });
  }

  @Action(SignUpAction.SignUpClear)
  SignUpClear({ getState, setState, dispatch }: StateContext<SignUpStateModel>, payload) {
    const state = getState();

    setState({
      ...state,
      loading: false,
      error: undefined,
      data: undefined
    });
  }

  @Action(SignUpAction.ResendConfirmationStart)
  ResendConfirmationStart({ getState, setState, dispatch }: StateContext<SignUpStateModel>, payload) {
    const state = getState();
    const confirmationRequest = payload.payload as AccountModel.ResendConfirmationRequest;

    setState({
      ...state,
      loading: true,
      error: undefined
    });

    return this.accountSvc.resend(confirmationRequest).pipe(
      map(status => {
        const message = `We've sent another confirmation email to ${confirmationRequest.email}.`;
        dispatch([new SignUpAction.ResendConfirmationSuccess({ message }), new SignUpAction.SignUpClear(undefined)]);
        this.navigationSvc.goto(
          <CoreModel.NavigationData>{
            path: '/account/signin'
          },
          100
        );
      }),
      catchError(error => dispatch(new SignUpAction.ResendConfirmationFailure(error)))
    );
  }

  @Action(SignUpAction.ResendConfirmationFailure)
  ResendConfirmationFailure({ getState, setState, dispatch }: StateContext<SignUpStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      loading: false,
      error: err.message
    });
  }

  @Action(SignUpAction.ResendConfirmationSuccess)
  ResendConfirmationSuccess({ getState, setState, dispatch }: StateContext<SignUpStateModel>, payload) {
    const state = getState();

    setState({
      ...state,
      loading: false
    });
  }
}
