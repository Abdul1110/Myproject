import { State, Selector, StateContext, Action, Store } from '@ngxs/store';
import { Location } from '@angular/common';
import { map, catchError } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';

import { AccountApiService } from '../../services';
import { SignInAction } from '../actions';
import { AccountModel } from '../../models';
import { environment } from '@env/environment';
import { SetAppAuthencation, SetLoginDefaults, SetMatterFirmId, SetReturnTo } from '@app/core/store/actions';
import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models';
import { ActivatedRoute } from '@angular/router';
import { NavigationService } from '@app/core/services';

export interface SignInStateModel {
  error: string;
  loading: boolean;
  social: string;
}

@State<SignInStateModel>({
  name: 'signin',
  defaults: {
    error: undefined,
    loading: false,
    social: undefined
  }
})
export class SignInState {
  constructor(
    private store: Store,
    private accountSvc: AccountApiService,
    private browserSvc: BrowserService,
    private location: Location,
    private routeSnapshot: ActivatedRoute,
    private navigationSvc: NavigationService
  ) {}

  @Selector()
  static getLoadingStatus(state: SignInStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.loading;
  }

  @Selector()
  static getError(state: SignInStateModel): string {
    if (!state) {
      return undefined;
    }

    return state.error;
  }

  @Selector()
  static isSocialLogin(state: SignInStateModel): boolean {
    if (!state) {
      return false;
    }

    return !!state.social;
  }

  @Action(SignInAction.SignInStart)
  SignInStart({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const signInRequest = payload.payload as AccountModel.SignInRequest;

    setState({
      ...state,
      loading: true,
      error: undefined,
      social: undefined
    });

    dispatch([new SetLoginDefaults(signInRequest.rememberMe)]);

    return this.accountSvc
      .signin(<AccountModel.SignInRequest>{
        password: signInRequest.password,
        userName: signInRequest.userName,
        rememberMe: signInRequest.rememberMe
      })
      .pipe(
        map(status => dispatch(new SignInAction.SignInSuccess(status.metadata))),
        catchError(error => dispatch(new SignInAction.SignInFailure(error)))
      );
  }

  @Action(SignInAction.SignInSuccess)
  SignInSuccess({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const signInResponse = payload.payload as CoreModel.SignInMeta;
    const redirectUrl = this.routeSnapshot.snapshot.queryParamMap.get('returnTo');
    const returnTo = (redirectUrl && decodeURIComponent(redirectUrl)) || '/recents';
    const previewInfo = this.store.selectSnapshot(AppState.getSharePreviewInfo);
    let redirectTo = returnTo && returnTo.indexOf('/signin') !== -1 ? '/recents' : returnTo;

    setState({
      ...state,
      loading: false,
      error: undefined
    });

    // Preview normally link for Share documents or eSignatures.
    if (previewInfo && previewInfo.firmId && previewInfo.matterId) {
      const { matterId, firmId, id: documentId, eSignature } = previewInfo;

      this.store.dispatch(new SetMatterFirmId({ matterId, firmId }));

      if (!eSignature && documentId && !redirectTo.includes(documentId)) {
        redirectTo = `matters/${matterId}/sharedocuments/${documentId}/preview`;
      } else if (eSignature && eSignature.orderId && !redirectTo.includes(eSignature.orderId)) {
        redirectTo = `matters/${matterId}/signatures/${eSignature.orderId}/sign`;
      }
    }

    return dispatch([new SetAppAuthencation({ path: redirectTo, result: signInResponse })]);
  }

  @Action(SignInAction.SignInFailure)
  SignInFailure({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      loading: false,
      error: err.message
    });

    return dispatch(new SetAppAuthencation({ result: <CoreModel.SignInMeta>{ login: false }, path: 'account/signin' }));
  }

  @Action(SignInAction.SocialSignInStart)
  SocialSignInStart({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const accountType = payload.payload as string; //account type

    setState({
      ...state,
      loading: true,
      error: undefined,
      social: accountType
    });

    // environment.appSettings.orionEndpoint;
    const url = this.browserSvc.isBrowser
      ? this.browserSvc.window.location.origin
      : environment.appSettings.orionEndpoint;

    const origin = this.browserSvc.window.location.origin;

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      url: `${url}/account/signin/${accountType.toLowerCase()}`
    });
    return;
  }

  @Action(SignInAction.SocialSignInSuccess)
  SocialSignInSuccess({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const returnTo = payload.payload as string;

    return dispatch([new SetReturnTo(returnTo), new SignInAction.SocialGetProfileStart(undefined)]);
  }

  @Action(SignInAction.SocialSignInFailure)
  SocialSignInFailure({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const message = payload.payload as string; // error message

    setState({
      ...state,
      loading: false,
      error: message,
      social: undefined
    });

    return dispatch(new SetAppAuthencation({ result: <CoreModel.SignInMeta>{ login: false }, path: 'account/signin' }));
  }

  @Action(SignInAction.SocialGetProfileStart, { cancelUncompleted: true })
  SocialGetProfileStart({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    return this.accountSvc.profile().pipe(
      map(userProfile => dispatch(new SignInAction.SocialGetProfileSuccess(userProfile))),
      catchError(error => dispatch(new SignInAction.SocialGetProfileFailure(error)))
    );
  }

  @Action(SignInAction.SocialGetProfileSuccess)
  SocialGetProfileSuccess({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const profile = payload.payload as AccountModel.ProfileAndUserMetadata;
    const { userId, displayName } = profile;
    const returnTo = this.store.selectSnapshot(AppState.getReturnTo) || '/recents';

    setState({
      ...state,
      loading: false,
      error: undefined,
      social: undefined
    });

    return dispatch(
      new SetAppAuthencation({ result: <CoreModel.SignInMeta>{ login: true, ...profile }, path: returnTo })
    );
  }

  @Action(SignInAction.SocialGetProfileFailure)
  SocialGetProfileFailure({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const message = payload.payload as string; // error message

    setState({
      ...state,
      loading: false,
      error: message,
      social: undefined
    });

    dispatch(new SetAppAuthencation({ result: <CoreModel.SignInMeta>{ login: false }, path: 'account/signin' }));

    this.navigationSvc.goto(
      <CoreModel.NavigationData>{
        path: '/account/signin'
      },
      100
    );
  }

  @Action(SignInAction.ReturnTo)
  ReturnTo({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const path = payload.payload as string; // url

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: path === '/' ? '/recents' : path
    });
  }

  @Action(SignInAction.ResetPasswordStart)
  ResetPasswordStart({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const userName = payload.payload as string; // username
    const firmId = this.store.selectSnapshot(AppState.getSelectedFirmId);
    const resetReq = <AccountModel.ResetPasswordRequest>{
      userName,
      firmId
    };

    setState({
      ...state,
      loading: true,
      error: undefined
    });

    return this.accountSvc.reset(resetReq).pipe(
      map(status => {
        const message = `We've sent ${userName} an email to reset your password`;
        dispatch(new SignInAction.ResetPasswordSuccess({ message }));
      }),
      catchError(error => dispatch(new SignInAction.ResetPasswordFailure(error)))
    );
  }

  @Action(SignInAction.ResetPasswordSuccess)
  ResetPasswordSuccess({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();

    setState({
      ...state,
      loading: false,
      error: undefined
    });

    if (this.browserSvc.isBrowser) {
      this.location.replaceState(this.browserSvc.window.location.pathname);
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: '/account/signin'
      });
    }
  }

  @Action(SignInAction.ResetPasswordFailure)
  ResetPasswordFailure({ getState, setState, dispatch }: StateContext<SignInStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      loading: false,
      error: err.message
    });
  }
}
