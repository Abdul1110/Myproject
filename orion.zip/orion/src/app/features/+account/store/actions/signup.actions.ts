import { LyraDesignFormModel } from '@leap/lyra-design';

import { AccountModel } from '../../models';

export namespace SignUpAction {
  const prefix = '[SignUp]';

  export const ActionTypes = {
    SIGNUP_START: `${prefix} start`,
    SIGNUP_SUCCESS: `${prefix} success`,
    SIGNUP_FAILURE: `${prefix} Failed to signup`,
    SIGNUP_CLEAR: `${prefix} clear`,
    RESEND_CONFIRMATION_START: `${prefix} resend confirmation start`,
    RESEND_CONFIRMATION_SUCCESS: `${prefix} resend confirmation success`,
    RESEND_CONFIRMATION_FAILURE: `${prefix} Failed to resend confirmation`
  };

  export class SignUpStart {
    static readonly type = ActionTypes.SIGNUP_START;
    constructor(public payload: AccountModel.SignUpRequest) {}
  }

  export class SignUpSuccess {
    static readonly type = ActionTypes.SIGNUP_SUCCESS;
    constructor(public payload: LyraDesignFormModel.SignUpResponse) {}
  }

  export class SignUpFailure {
    static readonly type = ActionTypes.SIGNUP_FAILURE;
    constructor(public payload: any) {}
  }

  export class SignUpClear {
    static readonly type = ActionTypes.SIGNUP_CLEAR;
    constructor(public payload: any) {}
  }

  export class ResendConfirmationStart {
    static readonly type = ActionTypes.RESEND_CONFIRMATION_START;
    constructor(public payload: AccountModel.ResendConfirmationRequest) {}
  }

  export class ResendConfirmationSuccess {
    static readonly type = ActionTypes.RESEND_CONFIRMATION_SUCCESS;
    constructor(public payload: { message: string }) {}
  }

  export class ResendConfirmationFailure {
    static readonly type = ActionTypes.RESEND_CONFIRMATION_FAILURE;
    constructor(public payload: any) {}
  }
}
