import { AccountModel } from '../../models';
import { CoreModel } from '@app/core/models';

export namespace SignInAction {
  const prefix = '[SignIn]';

  export const ActionTypes = {
    SIGNIN_START: `${prefix} start`,
    SIGNIN_SUCCESS: `${prefix} success`,
    SIGNIN_FAILURE: `${prefix} Failed to signin`,

    SOCIAL_SIGNIN_START: `${prefix} social start`,
    SOCIAL_SIGNIN_SUCCESS: `${prefix} social success`,
    SOCIAL_SIGNIN_FAILURE: `${prefix} Failed to social signin`,

    RESET_PASSWORD_START: `${prefix} reset password start`,
    RESET_PASSWORD_SUCCESS: `${prefix} reset password success`,
    RESET_PASSWORD_FAILURE: `${prefix} Failed to reset password`,

    SOCIAL_GET_PROFILE_START: `${prefix} social get profile start`,
    SOCIAL_GET_PROFILE_SUCCESS: `${prefix} social get profile success`,
    SOCIAL_GET_PROFILE_FAILURE: `${prefix} Failed to get social profile`,

    RETURN_TO: `${prefix} return to`
  };

  export class SignInStart {
    static readonly type = ActionTypes.SIGNIN_START;
    constructor(public payload: AccountModel.SignInRequest) {}
  }

  export class SignInSuccess {
    static readonly type = ActionTypes.SIGNIN_SUCCESS;
    constructor(public payload: CoreModel.SignInMeta) {}
  }

  export class SignInFailure {
    static readonly type = ActionTypes.SIGNIN_FAILURE;
    constructor(public payload: any) {}
  }

  export class SocialSignInStart {
    static readonly type = ActionTypes.SOCIAL_SIGNIN_START;
    constructor(public payload: string) {} // accountType
  }

  export class SocialSignInSuccess {
    static readonly type = ActionTypes.SOCIAL_SIGNIN_SUCCESS;
    constructor(public payload: string) {} // returnTo url
  }

  export class SocialSignInFailure {
    static readonly type = ActionTypes.SOCIAL_SIGNIN_FAILURE;
    constructor(public payload: any) {}
  }

  export class ReturnTo {
    static readonly type = ActionTypes.RETURN_TO;
    constructor(public payload: string) {}
  }

  export class ResetPasswordStart {
    static readonly type = ActionTypes.RESET_PASSWORD_START;
    constructor(public payload: string) {} // username
  }

  export class ResetPasswordSuccess {
    static readonly type = ActionTypes.RESET_PASSWORD_SUCCESS;
    constructor(public payload: { message: string }) {}
  }

  export class ResetPasswordFailure {
    static readonly type = ActionTypes.RESET_PASSWORD_FAILURE;
    constructor(public payload: any) {}
  }

  export class SocialGetProfileStart {
    static readonly type = ActionTypes.SOCIAL_GET_PROFILE_START;
    constructor(public payload: any) {}
  }

  export class SocialGetProfileSuccess {
    static readonly type = ActionTypes.SOCIAL_GET_PROFILE_SUCCESS;
    constructor(public payload: AccountModel.ProfileAndUserMetadata) {}
  }

  export class SocialGetProfileFailure {
    static readonly type = ActionTypes.SOCIAL_GET_PROFILE_FAILURE;
    constructor(public payload: any) {}
  }
}
