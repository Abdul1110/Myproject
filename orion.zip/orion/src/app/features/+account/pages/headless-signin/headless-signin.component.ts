import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Select } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged, map, filter } from 'rxjs/operators';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { HeadlessAccountService } from '../../services/headless-account.service';
import { SignInState } from '../../store';
import { headlessAccountPaths } from '../../models/headless-account.model';
import { AnalyticService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

@Component({
  selector: 'sc-headless-signin',
  templateUrl: './headless-signin.component.html'
})
export class HeadlessSigninComponent implements OnInit, OnDestroy {
  signinResponse: LyraDesignFormModel.AccountSignInResponse;
  signinForm: FormGroup;
  signupPath = headlessAccountPaths.signupPath;
  forgotPath = headlessAccountPaths.resetPath;
  defaultLogin = false;
  defaultSocial = [];
  errors = {};

  @Select(SignInState.getLoadingStatus) loading$: Observable<boolean>;
  @Select(SignInState.getError) error$: Observable<string>;

  private destroy$ = new Subject<boolean>();
  private validations;

  constructor(
    private headlessAccountSvc: HeadlessAccountService,
    private formBuilder: FormBuilder,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AccountHeadlessSignIn, action: 'User signin' });
    }
  }

  ngOnInit(): void {
    this.validations = this.getValidation();
    this.setupForm();
    this.setupSubscriptions();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  signinAccount(accountType: LyraDesignFormModel.AccountType): void {
    if (accountType === LyraDesignFormModel.AccountType.custom) {
      this.headlessAccountSvc.markFileldsDirty(this.signinForm, this.validations);
      this.errors = this.headlessAccountSvc.validateForm(this.signinForm, this.validations);
      if (this.headlessAccountSvc.hasErrors(this.errors)) {
        return;
      }
      const { email, password, rememberMe } = this.signinForm.value;
      this.headlessAccountSvc
        .signinAccount(email, password, rememberMe)
        .pipe(takeUntil(this.destroy$))
        .subscribe();
    }
  }

  createAccount(): void {
    this.headlessAccountSvc.navigate(this.signupPath);
  }

  resetAccount(): void {
    this.headlessAccountSvc.navigate(this.forgotPath);
  }

  private setupSubscriptions(): void {
    this.signinForm.valueChanges
      .pipe(
        takeUntil(this.destroy$),
        debounceTime(100),
        distinctUntilChanged(),
        filter(c => !!c),
        map(() => {
          this.errors = this.headlessAccountSvc.validateForm(this.signinForm, this.validations);
          this.signinResponse = this.signinResponseFormat(false, undefined);
        })
      )
      .subscribe();

    this.error$
      .pipe(takeUntil(this.destroy$))
      .subscribe(msg => (this.signinResponse = this.signinResponseFormat(!!msg, msg)));
  }

  private setupForm(): void {
    this.signinForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      rememberMe: ['']
    });
  }

  private getValidation() {
    return {
      email: [{ type: 'required', message: 'Email is required' }, { type: 'email', message: 'Enter a valid email' }],
      password: [{ type: 'required', message: 'Password is required' }]
    };
  }

  private signinResponseFormat(hasError: boolean, error: any): LyraDesignFormModel.AccountSignInResponse {
    return {
      error: hasError,
      message: this.browserSvc.getStandardError(error).message
    };
  }
}
