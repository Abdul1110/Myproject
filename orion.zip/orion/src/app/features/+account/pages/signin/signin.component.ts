import { Component, OnDestroy } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Store, Select } from '@ngxs/store';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { Observable, Subject } from 'rxjs';
import { map, distinctUntilChanged, debounceTime, takeUntil, tap } from 'rxjs/operators';
import { UUID } from 'angular2-uuid';

import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models';
import { AnalyticService, NavigationService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { AccountModel } from '../../models';
import * as actions from '../../store/actions';
import { SignInState } from '../../store';

@Component({
  selector: 'sc-signin',
  templateUrl: './signin.component.html',
  host: { '[class.layout-column]': 'enabled' }
})
export class SignInComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private validations = {
    email: [
      { type: 'required', message: 'Email is required' },
      { type: 'email', message: 'Enter a valid email' }
    ],
    password: [{ type: 'required', message: 'Password is required' }]
  };

  private errorCodes = {
    'email-verification-expired': `Your email verification link has expired. Don't worry, we have sent you a new one. Please check your mailbox and verify again.`,
    'email-verification-duplicated': `Your LawConnect account has already been verified.`,
    'email-verification-rejected': `There was an error verifying your email.`,
    'password-reset-expired': `Your password reset link has expired. Don't worry, we have sent you a new one. Please check your mailbox.`,
    'password-reset-rejected': `Your password has been reset, please login.`
  };

  signinForm: FormGroup;
  errors = {};
  signIn$: Observable<any>;
  signinResponse: LyraDesignFormModel.AccountSignInResponse;
  enabled = true;
  sharePreview = undefined;
  hasSharePreview = false;
  sharePreviewSocial = [];
  reloadRandomId = undefined;
  isExistingUser = false;

  @Select(SignInState.getLoadingStatus) loading$: Observable<boolean>;

  @Select(SignInState.getError) error$: Observable<string>;

  @Select(SignInState.isSocialLogin) isSocialLogin$: Observable<boolean>;

  @Select(AppState.getSharePreviewInfo) sharePreview$: Observable<CoreModel.SharePreviewInfo>;

  constructor(
    private fb: FormBuilder,
    private store: Store,
    private routeSnapshot: ActivatedRoute,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private navigationSvc: NavigationService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AccountSignIn, action: 'User signin' });
    }

    this.setup();
    this.subscribeEvent();

    const errFromUrl =
      this.routeSnapshot.snapshot.queryParamMap.get('error_desc') ||
      this.routeSnapshot.snapshot.queryParamMap.get('error');

    if (errFromUrl) {
      this.store.dispatch(new actions.SignInAction.SocialSignInFailure(errFromUrl));
      return;
    }

    if (this.routeSnapshot.snapshot.queryParamMap.get('social')) {
      this.store.dispatch(new actions.SignInAction.SocialSignInSuccess(undefined));
    }

    if (this.routeSnapshot.snapshot.queryParamMap.get('code')) {
      const code = this.routeSnapshot.snapshot.queryParamMap.get('code');
      const errorCodes = Object.keys(this.errorCodes);
      if (errorCodes.includes(code)) {
        if (code.indexOf('email-') !== -1) {
          this.store.dispatch(new actions.SignUpAction.SignUpFailure(this.errorCodes[code]));
          return;
        }

        if (code.indexOf('password-') !== -1) {
          this.store.dispatch(new actions.SignInAction.ResetPasswordFailure(this.errorCodes[code]));
          return;
        }
      }
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  signinAccount(accountType: LyraDesignFormModel.AccountType): void {
    if (accountType === LyraDesignFormModel.AccountType.custom) {
      this.markFileldsDirty();
      this.errors = Object.assign({}, this.validateForm());
      if (this.hasErrors()) {
        return;
      }
      const { email, password, rememberMe } = this.signinForm.value;
      this.store.dispatch(
        new actions.SignInAction.SignInStart(<AccountModel.SignInRequest>{
          password,
          userName: email,
          rememberMe
        })
      );

      return;
    }

    this.store.dispatch(new actions.SignInAction.SocialSignInStart(accountType));
  }

  createAccount(e: any): void {
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/account/signup'
    });
  }

  resetAccount(e: any): void {
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/account/reset-password'
    });
  }

  reloadUiRequest(): void {
    this.reloadRandomId = UUID.UUID();
  }

  private setup(): void {
    const { sharedTo, isMatterShared, nodeId, userId, requestId } = (this.routeSnapshot.queryParams as any).value;
    const preview = this.store.selectSnapshot(AppState.getSharePreviewInfo);
    const signUpEmail = this.store.selectSnapshot(AppState.getCallBackEmail);
    const userEmail = preview ? preview.userEmail : sharedTo || signUpEmail || '';
    const validEmail = !userEmail || (userEmail && userEmail === 'none') ? '' : userEmail;
    const email = new FormControl(validEmail, [Validators.required, Validators.email]);
    if (validEmail) {
      email.markAsDirty();
    }

    this.signinForm = this.fb.group({
      email,
      password: ['', [Validators.required]],
      rememberMe: ['']
    });
  }

  private subscribeEvent(): void {
    this.signinForm.valueChanges
      .pipe(
        takeUntil(this.destroy$),
        debounceTime(100),
        distinctUntilChanged(),
        map(changes => {
          if (changes) {
            this.errors = Object.assign({}, this.validateForm());
            this.signinResponse = this.signinResponseFormat(false, undefined);
          }
        })
      )
      .subscribe();

    this.error$
      .pipe(
        takeUntil(this.destroy$),
        tap(msg => {
          this.signinResponse = Object.assign({}, <LyraDesignFormModel.AccountCreatedResponse>{
            error: !!msg,
            message: msg
          });
        })
      )
      .subscribe();

    this.sharePreview$
      .pipe(
        takeUntil(this.destroy$),
        tap(v => {
          this.sharePreview = v;
          this.hasSharePreview = v && !!v.userEmail;
          this.sharePreviewSocial = v && v.providers ? v.providers : [];

          if (this.hasSharePreview) {
            if (!this.signinForm.get('email').value) {
              this.signinForm.get('email').setValue(v.userEmail);
              this.signinForm.get('email').markAsDirty();
            }

            const hasAuthenticated = this.store.selectSnapshot(AppState.getAppAuthentication);
            const hasAgreeToTermsAndCondition = this.store.selectSnapshot(AppState.getUserTermsAndConditionsStatus);
            const logonUser = this.store.selectSnapshot(AppState.getLoginUser);

            if (hasAuthenticated && hasAgreeToTermsAndCondition && logonUser && logonUser.displayName == v.userName) {
              this.navigationSvc.goto(<CoreModel.NavigationData>{
                path: `/matters/${(v && v.matterId) || 'none'}/sharedocuments/${(v && v.id) || 'none'}`
              });
            }

            this.isExistingUser = v.isExistingUser;
          }
        })
      )
      .subscribe();
  }

  private validateForm(): {} {
    let errors = {};

    if (this.signinForm) {
      Object.keys(this.validations).forEach(col => {
        const colControl = this.signinForm.get(col);
        const validations = this.validations[col];
        let result = new Array<string>();
        if (!colControl.pristine) {
          validations.forEach(validation => {
            if (colControl.hasError(validation.type)) {
              result = result.concat(validation.message);
            }
          });
        }
        errors[col] = result;
      });
    }

    return errors;
  }

  private signinResponseFormat(hasError: boolean, error: any): LyraDesignFormModel.AccountSignInResponse {
    return Object.assign({}, <LyraDesignFormModel.AccountSignInResponse>{
      error: hasError,
      message: this.browserSvc.getStandardError(error).message
    });
  }
  private markFileldsDirty() {
    if (this.signinForm) {
      Object.keys(this.validations).forEach(col => {
        const colControl = this.signinForm.get(col);
        if (colControl.pristine) {
          colControl.markAsDirty();
        }
      });
    }
  }
  private hasErrors(): boolean {
    let hasError = false;
    if (this.errors) {
      Object.keys(this.errors).forEach(col => {
        if (this.errors[col].length > 0) {
          hasError = true;
        }
      });
    }
    return hasError;
  }
}
