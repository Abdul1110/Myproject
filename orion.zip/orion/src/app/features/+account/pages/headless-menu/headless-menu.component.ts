import { Component, OnInit, HostBinding, OnDestroy } from '@angular/core';
import { HeadlessAccountService } from '../../services/headless-account.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';
import { AnalyticService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

@Component({
  selector: 'sc-headless-menu',
  templateUrl: './headless-menu.component.html'
})
export class HeadlessMenuComponent implements OnInit, OnDestroy {
  @HostBinding('class') classes = 'ng-tns-c1-0 x-form';

  accountName = '';

  private accessToken = '';
  private destroy$ = new Subject<boolean>();

  constructor(
    private headlessAccountSvc: HeadlessAccountService,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService
  ) {
    this.accountName = history.state.accountName;
    this.accessToken = history.state.accessToken;
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.AccountHeadlessMenu,
        action: 'Provide user login options'
      });
    }
  }

  ngOnInit() {}

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  openLawConnect() {
    this.headlessAccountSvc.postSuccess('login', this.accessToken);
  }

  signOut() {
    this.headlessAccountSvc
      .signOut()
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }
}
