import { Component, OnInit, OnDestroy } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { takeUntil } from 'rxjs/operators';
import { HeadlessAccountService } from '../../services/headless-account.service';
import { headlessAccountPaths } from '../../models/headless-account.model';
import { SignUpState } from '../../store';
import { AnalyticService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

@Component({
  selector: 'sc-headless-confirm',
  templateUrl: './headless-confirm.component.html'
})
export class HeadlessConfirmComponent implements OnInit, OnDestroy {
  resendVericationResponse: LyraDesignFormModel.ResendEmailVerificationResponse;

  @Select(SignUpState.getEmail) email$: Observable<string>;
  @Select(SignUpState.getLoadingStatus) loading$: Observable<boolean>;
  @Select(SignUpState.getError) error$: Observable<string>;

  private destroy$ = new Subject<boolean>();

  constructor(
    private headlessAccountSvc: HeadlessAccountService,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AccountHeadlessConfirmPage, action: 'Notify user' });
    }
  }

  ngOnInit() {
    this.setupSubscriptions();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  resendEmail(): void {
    this.headlessAccountSvc
      .resendEmail()
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  signIn(): void {
    this.headlessAccountSvc.navigate(headlessAccountPaths.signinPath);
  }

  private setupSubscriptions() {
    this.error$.pipe(takeUntil(this.destroy$)).subscribe(
      msg =>
        (this.resendVericationResponse = {
          error: !!msg,
          message: msg
        })
    );
  }
}
