import { Component, OnDestroy } from '@angular/core';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { Store, Select } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { Subject, Observable } from 'rxjs';
import { takeUntil, debounceTime, map, distinctUntilChanged, tap } from 'rxjs/operators';

import { CoreModel } from '@app/core/models';
import { environment } from '@env/environment';
import { AppState } from '@app/core/store/states';
import { AnalyticService, NavigationService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { AccountModel } from '../../models';
import * as actions from '../../store';
import { SignUpState } from '../../store';

@Component({
  selector: 'sc-signup',
  templateUrl: './signup.component.html',
  host: { '[class.layout-column]': 'enabled' }
})
export class SignUpComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private validations = {
    email: [
      { type: 'required', message: 'Email is required' },
      { type: 'email', message: 'Enter a valid email' }
    ],
    password: [{ type: 'required', message: 'Password is required' }],
    firstName: [{ type: 'requiredNotWhitespace', message: 'First name is required' }],
    lastName: [{ type: 'requiredNotWhitespace', message: 'Last name is required' }],
    agree: [{ type: 'agreedToPrivacyPolicy', message: 'LawConnect privacy policy is required' }]
  };

  policyUrl = environment.appSettings.privacyUrl;
  signupForm: FormGroup;
  errors = {};
  userNamePassWordSignUp$: Observable<any>;
  signupResponse: LyraDesignFormModel.AccountCreatedResponse;
  enabled = true;

  @Select(SignUpState.getLoadingStatus) loading$: Observable<boolean>;

  @Select(SignUpState.getError) error$: Observable<string>;

  @Select(SignUpState.getEmail) email$: Observable<string>;

  constructor(
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private navigationSvc: NavigationService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AccountSignUp, action: 'User signup' });
    }

    this.setup();
    this.subscribeEvent();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  newAccount(accountType: LyraDesignFormModel.AccountType): void {
    if (accountType === LyraDesignFormModel.AccountType.custom) {
      this.markFileldsDirty();
      this.errors = Object.assign({}, this.validateForm());
      if (this.hasErrors()) {
        return;
      }
      const redirectUrl = this.browserSvc.window.location.origin;
      const theme = this.store.selectSnapshot(AppState.getTheme);
      const isWhiteLabel = this.store.selectSnapshot(AppState.isWhiteLabel);
      const { email, agree, ...keys } = this.signupForm.value;
      this.store.dispatch(
        new actions.SignUpAction.SignUpStart(<AccountModel.SignUpRequest>{
          ...keys,
          userName: email,
          redirectUrl,
          agreeToTermsAndConditions: agree,
          isWhiteLabel: isWhiteLabel.whiteLabel,
          firmId: !!theme && !theme.firmNotFound ? theme.firmId : undefined
        })
      );

      return;
    }

    this.store.dispatch(new actions.SignInAction.SocialSignInStart(accountType));
  }

  private setup(): void {
    const { sharedTo, isMatterShared, nodeId } = (this.activatedRoute.queryParams as any).value;
    const preview = this.store.selectSnapshot(AppState.getSharePreviewInfo);

    const userEmail = preview ? preview.userEmail : sharedTo || '';
    const email = new FormControl(userEmail, [Validators.required, Validators.email]);
    if (userEmail) {
      email.markAsDirty();
    }

    this.signupForm = this.fb.group({
      email,
      password: ['', [Validators.required]],
      firstName: ['', [this.requiredNotWhitespace]],
      lastName: ['', [this.requiredNotWhitespace]],
      agree: ['', [this.agreedToPrivacyPolicy]]
    });
  }

  private agreedToPrivacyPolicy(control: AbstractControl): { [key: string]: any } | null {
    return control.value === true ? null : { agreedToPrivacyPolicy: { value: control.value } };
  }

  private requiredNotWhitespace(control: AbstractControl): { [key: string]: any } | null {
    return !!control.value && control.value.trim() !== '' ? null : { requiredNotWhitespace: { value: control.value } };
  }

  private subscribeEvent(): void {
    this.signupForm.valueChanges
      .pipe(
        takeUntil(this.destroy$),
        debounceTime(100),
        distinctUntilChanged(),
        map(changes => {
          if (changes) {
            this.errors = Object.assign({}, this.validateForm());
            this.signupResponse = this.signupResponseFormat(false, undefined, undefined);
          }
        })
      )
      .subscribe();

    this.error$
      .pipe(
        takeUntil(this.destroy$),
        tap(msg => {
          this.signupResponse = this.signupResponseFormat(!!msg, msg, undefined);
        })
      )
      .subscribe();

    this.email$
      .pipe(
        takeUntil(this.destroy$),
        tap(email => {
          if (email) {
            this.navigationSvc.goto(<CoreModel.NavigationData>{
              path: '/account/signup-confirmation'
            });
          }
        })
      )
      .subscribe();
  }

  private validateForm(): {} {
    const errors = {};

    if (this.signupForm) {
      Object.keys(this.validations).forEach(col => {
        const colControl = this.signupForm.get(col);
        const validations = this.validations[col];
        let result = new Array<string>();
        if (!colControl.pristine) {
          validations.forEach(validation => {
            if (colControl.hasError(validation.type)) {
              result = result.concat(validation.message);
            }
          });
        }
        errors[col] = result;
      });
    }

    return errors;
  }

  signinAccount(e: any): void {
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/account/signin'
    });
  }

  private signupResponseFormat(
    hasError: boolean,
    error: any,
    data: LyraDesignFormModel.SignUpResponse
  ): LyraDesignFormModel.AccountCreatedResponse {
    return Object.assign({}, <LyraDesignFormModel.AccountCreatedResponse>{
      error: hasError,
      data,
      message: this.browserSvc.getStandardError(error).message
    });
  }

  private markFileldsDirty() {
    if (this.signupForm) {
      Object.keys(this.validations).forEach(col => {
        const colControl = this.signupForm.get(col);
        if (colControl.pristine) {
          colControl.markAsDirty();
        }
      });
    }
  }

  private hasErrors(): boolean {
    let hasError = false;
    if (this.errors) {
      Object.keys(this.errors).forEach(col => {
        if (this.errors[col].length > 0) {
          hasError = true;
        }
      });
    }
    return hasError;
  }
}
