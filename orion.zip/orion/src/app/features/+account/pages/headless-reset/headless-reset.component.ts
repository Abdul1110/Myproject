import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { takeUntil, debounceTime, distinctUntilChanged, map, filter } from 'rxjs/operators';
import { HeadlessAccountService } from '../../services/headless-account.service';
import { Select } from '@ngxs/store';
import { SignInState } from '../../store';
import { headlessAccountPaths } from '../../models/headless-account.model';
import { AnalyticService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
@Component({
  selector: 'sc-headless-reset',
  templateUrl: './headless-reset.component.html'
})
export class HeadlessResetComponent implements OnInit, OnDestroy {
  signupPath = headlessAccountPaths.signupPath;
  cancelPath = headlessAccountPaths.signinPath;
  forgotForm: FormGroup;
  resetPwdResponse: LyraDesignFormModel.ResetPasswordResponse;
  errors = {};

  @Select(SignInState.getLoadingStatus) loading$: Observable<boolean>;
  @Select(SignInState.getError) error$: Observable<string>;

  private destroy$ = new Subject<boolean>();
  private validations;

  constructor(
    private headlessAccountSvc: HeadlessAccountService,
    private formBuilder: FormBuilder,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.AccountHeadlessReset,
        action: 'Reset user credentials'
      });
    }
  }

  ngOnInit() {
    this.validations = {
      email: [
        { type: 'required', message: 'Email is required' },
        { type: 'email', message: 'Enter a valid email' }
      ]
    };
    this.forgotForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
    });
    this.setupSubscriptions();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  resetAccount(): void {
    this.headlessAccountSvc
      .resetAccount(this.forgotForm)
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private setupSubscriptions() {
    this.forgotForm.valueChanges
      .pipe(
        takeUntil(this.destroy$),
        debounceTime(100),
        distinctUntilChanged(),
        filter(c => !!c),
        map(() => {
          this.errors = this.headlessAccountSvc.validateForm(this.forgotForm, this.validations);
          this.resetPwdResponse = this.resetPwdResponseFormat(false, undefined);
        })
      )
      .subscribe();

    this.error$
      .pipe(takeUntil(this.destroy$))
      .subscribe(msg => (this.resetPwdResponse = this.resetPwdResponseFormat(!!msg, msg)));
  }

  private resetPwdResponseFormat(hasError: boolean, error: any): LyraDesignFormModel.ResetPasswordResponse {
    return {
      error: hasError,
      message: this.browserSvc.getStandardError(error).message
    };
  }
}
