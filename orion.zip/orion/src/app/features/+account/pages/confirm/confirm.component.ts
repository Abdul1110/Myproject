import { Component, OnDestroy } from '@angular/core';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { Store, Select } from '@ngxs/store';
import { takeUntil, tap } from 'rxjs/operators';
import { Subject, Observable } from 'rxjs';

import { CoreModel } from '@app/core/models';
import { AppState } from '@app/core/store/states';
import { AnalyticService, NavigationService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import * as actions from '../../store';
import { SignUpState } from '../../store';

@Component({
  selector: 'sc-confirm',
  templateUrl: './confirm.component.html',
  host: { '[class.layout-column]': 'enabled' }
})
export class ConfirmComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  enabled = true;
  resendVericationResponse: LyraDesignFormModel.ResendEmailVerificationResponse;

  @Select(SignUpState.getEmail) email$: Observable<string>;

  @Select(SignUpState.getLoadingStatus) loading$: Observable<boolean>;

  @Select(SignUpState.getError) error$: Observable<string>;

  constructor(
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private navigationSvc: NavigationService
  ) {
    this.subscribeEvent();
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AccountConfirmPage, action: 'Notify user' });
    }

    const resendArgs = this.store.selectSnapshot(SignUpState.getResendData);
    if (!resendArgs) {
      this.signIn();
      return;
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  signIn(): void {
    this.store.dispatch(new actions.SignUpAction.SignUpClear(undefined));
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/account/signin'
    });
  }

  resendEmail(): void {
    const resendArgs = this.store.selectSnapshot(SignUpState.getResendData);
    if (!resendArgs) {
      this.signIn();
      return;
    }

    const theme = this.store.selectSnapshot(AppState.getTheme);
    const redirectUrl = this.browserSvc.window.location.origin;
    this.store.dispatch(
      new actions.SignUpAction.ResendConfirmationStart({
        agreeToTermsAndConditions: resendArgs.agreeToTermsAndConditions,
        email: resendArgs.email,
        firmId: theme && theme.firmId ? theme.firmId : null,
        redirectUrl: redirectUrl,
        userId: resendArgs.userId
      })
    );
  }

  private subscribeEvent(): void {
    this.error$
      .pipe(
        takeUntil(this.destroy$),
        tap(msg => {
          this.resendVericationResponse = Object.assign({}, <LyraDesignFormModel.ResendEmailVerificationResponse>{
            error: !!msg,
            message: msg
          });
        })
      )
      .subscribe();
  }
}
