import { Component, OnInit, OnDestroy } from '@angular/core';
import { environment } from '@env/environment';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { Select } from '@ngxs/store';
import { SignUpState } from '../../store';
import { Observable, Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged, map, filter } from 'rxjs/operators';
import { HeadlessAccountService } from '../../services/headless-account.service';
import { headlessAccountPaths } from '../../models/headless-account.model';
import { AnalyticService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

@Component({
  selector: 'sc-headless-signup',
  templateUrl: './headless-signup.component.html'
})
export class HeadlessSignupComponent implements OnInit, OnDestroy {
  signupResponse: LyraDesignFormModel.AccountCreatedResponse;
  signupForm: FormGroup;
  policyUrl = environment.appSettings.privacyUrl;
  signinPath = headlessAccountPaths.signinPath;
  errors = {};

  @Select(SignUpState.getLoadingStatus) loading$: Observable<boolean>;
  @Select(SignUpState.getError) error$: Observable<string>;
  @Select(SignUpState.getEmail) email$: Observable<string>;

  private destroy$ = new Subject<boolean>();
  private validations;

  constructor(
    private headlessAccountSvc: HeadlessAccountService,
    private formBuilder: FormBuilder,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AccountHeadlessSignUp, action: 'User signup' });
    }
  }

  ngOnInit() {
    this.validations = this.getValidation();
    this.setupForm();
    this.setupSubscriptions();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  createAccount(accountType: LyraDesignFormModel.AccountType): void {
    if (accountType === LyraDesignFormModel.AccountType.custom) {
      this.headlessAccountSvc.markFileldsDirty(this.signupForm, this.validations);
      this.errors = this.headlessAccountSvc.validateForm(this.signupForm, this.validations);
      if (this.headlessAccountSvc.hasErrors(this.errors)) {
        return;
      }
      this.headlessAccountSvc.createAccount(this.signupForm);
    }
  }

  signinAccount(): void {
    this.headlessAccountSvc.navigate(this.signinPath);
  }

  private setupSubscriptions(): void {
    this.signupForm.valueChanges
      .pipe(
        takeUntil(this.destroy$),
        debounceTime(100),
        distinctUntilChanged(),
        filter(c => !!c),
        map(() => {
          this.errors = this.headlessAccountSvc.validateForm(this.signupForm, this.validations);
          this.signupResponse = this.signupResponseFormat(false, undefined, undefined);
        })
      )
      .subscribe();

    this.error$
      .pipe(takeUntil(this.destroy$))
      .subscribe(msg => (this.signupResponse = this.signupResponseFormat(!!msg, msg, undefined)));

    this.email$
      .pipe(
        takeUntil(this.destroy$),
        filter(e => !!e)
      )
      .subscribe(() => this.headlessAccountSvc.navigate(headlessAccountPaths.confirmation));
  }

  private requiredNotWhitespace(control: AbstractControl) {
    return !!control.value && control.value.trim() !== '' ? null : { requiredNotWhitespace: { value: control.value } };
  }

  private agreedToPrivacyPolicy(control: AbstractControl) {
    return control.value === true ? null : { agreedToPrivacyPolicy: { value: control.value } };
  }

  private setupForm() {
    this.signupForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      firstName: ['', [this.requiredNotWhitespace]],
      lastName: ['', [this.requiredNotWhitespace]],
      agree: ['', [this.agreedToPrivacyPolicy]]
    });
  }

  private getValidation() {
    return {
      email: [{ type: 'required', message: 'Email is required' }, { type: 'email', message: 'Enter a valid email' }],
      password: [{ type: 'required', message: 'Password is required' }],
      firstName: [{ type: 'requiredNotWhitespace', message: 'First name is required' }],
      lastName: [{ type: 'requiredNotWhitespace', message: 'Last name is required' }],
      agree: [{ type: 'agreedToPrivacyPolicy', message: 'LawConnect privacy policy is required' }]
    };
  }

  private signupResponseFormat(
    hasError: boolean,
    error: any,
    data: LyraDesignFormModel.SignUpResponse
  ): LyraDesignFormModel.AccountCreatedResponse {
    return {
      error: hasError,
      data,
      message: this.browserSvc.getStandardError(error).message
    };
  }
}
