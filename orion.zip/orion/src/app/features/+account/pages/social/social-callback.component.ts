import { Component, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngxs/store';
import { BrowserService } from '@leap/lyra-design';
import { Subject } from 'rxjs';

import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models';
import { AnalyticService, NavigationService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import * as actions from '../../store';

@Component({
  selector: 'sc-social-callback',
  templateUrl: './social-callback.component.html'
})
export class SocialCallbackComponent implements OnDestroy, AfterViewInit {
  private destroy$ = new Subject<boolean>();

  constructor(
    private routeSnapshot: ActivatedRoute,
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private navigationSvc: NavigationService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({
        category: AnalyticCategories.AccountSocialLoginCallback,
        action: 'Continue social login after validating'
      });
    }

    if (this.routeSnapshot.snapshot.queryParamMap.get('social')) {
      const redirectUrl = this.routeSnapshot.snapshot.queryParamMap.get('returnTo');
      const returnTo = (redirectUrl && decodeURIComponent(redirectUrl)) || '/recents';
      const internalReturnTo = this.store.selectSnapshot(AppState.getReturnTo);
      const newInternalReturnTo = internalReturnTo == '/account/signin' ? undefined : internalReturnTo;
      const redirectTo = newInternalReturnTo || (returnTo && returnTo !== '/') ? returnTo : '/recents';

      this.store.dispatch(new actions.SignInAction.SocialSignInSuccess(redirectTo));

      return;
    }

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/account/signin'
    });
  }

  ngAfterViewInit(): void {}

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }
}
