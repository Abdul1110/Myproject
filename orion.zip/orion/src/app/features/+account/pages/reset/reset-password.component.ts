import { Component, OnDestroy } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { LyraDesignFormModel, BrowserService } from '@leap/lyra-design';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { takeUntil, debounceTime, distinctUntilChanged, map, tap } from 'rxjs/operators';
import { Store, Select } from '@ngxs/store';

import * as actions from '../../store/actions';
import { SignInState } from '../../store';
import { AnalyticService } from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';

@Component({
  selector: 'sc-reset-password',
  templateUrl: './reset-password.component.html',
  host: { '[class.layout-column]': 'enabled' }
})
export class ResetPasswordComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private validations = {
    email: [
      { type: 'required', message: 'Email is required' },
      { type: 'email', message: 'Enter a valid email' }
    ]
  };

  forgotForm: FormGroup;
  errors = {};
  enabled = true;
  signIn$: Observable<any>;
  resetPwdResponse: LyraDesignFormModel.ResetPasswordResponse;

  @Select(SignInState.getLoadingStatus) loading$: Observable<boolean>;

  @Select(SignInState.getError) error$: Observable<string>;

  constructor(
    private fb: FormBuilder,
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AccountReset, action: 'Reset user credentials' });
    }

    this.setup();
    this.subscribeEvent();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  createAccount(accountType: LyraDesignFormModel.AccountType): void {
    this.store.dispatch(new actions.SignInAction.SocialSignInStart(accountType));
  }

  resetAccount(): void {
    const { email } = this.forgotForm.value;
    this.store.dispatch(new actions.SignInAction.ResetPasswordStart(email));
  }

  private setup(): void {
    this.forgotForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  private subscribeEvent(): void {
    this.forgotForm.valueChanges
      .pipe(
        takeUntil(this.destroy$),
        debounceTime(100),
        distinctUntilChanged(),
        map(changes => {
          if (changes) {
            this.errors = Object.assign({}, this.validateForm());
            this.resetPwdResponse = this.resetPwdResponseFormat(false, undefined);
          }
        })
      )
      .subscribe();

    this.error$
      .pipe(
        takeUntil(this.destroy$),
        tap(msg => {
          this.resetPwdResponse = this.resetPwdResponseFormat(!!msg, msg);
        })
      )
      .subscribe();
  }

  private validateForm(): {} {
    const errors = {};

    if (this.forgotForm) {
      Object.keys(this.validations).forEach(col => {
        const colControl = this.forgotForm.get(col);
        const validations = this.validations[col];
        let result = new Array<string>();
        if (!colControl.pristine) {
          validations.forEach(validation => {
            if (colControl.hasError(validation.type)) {
              result = result.concat(validation.message);
            }
          });
        }
        errors[col] = result;
      });
    }

    return errors;
  }

  private resetPwdResponseFormat(hasError: boolean, error: any): LyraDesignFormModel.ResetPasswordResponse {
    return Object.assign({}, <LyraDesignFormModel.ResetPasswordResponse>{
      error: hasError,
      message: this.browserSvc.getStandardError(error).message
    });
  }
}
