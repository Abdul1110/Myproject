import { SignInComponent } from './signin/signin.component';
import { SignUpComponent } from './signup/signup.component';
import { ResetPasswordComponent } from './reset/reset-password.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { SocialCallbackComponent } from './social/social-callback.component';
import { HeadlessSigninComponent } from './headless-signin/headless-signin.component';
import { HeadlessSignupComponent } from './headless-signup/headless-signup.component';
import { HeadlessResetComponent } from './headless-reset/headless-reset.component';
import { HeadlessConfirmComponent } from './headless-confirm/headless-confirm.component';
import { HeadlessMenuComponent } from './headless-menu/headless-menu.component';

export * from './signin/signin.component';
export * from './signup/signup.component';
export * from './reset/reset-password.component';
export * from './confirm/confirm.component';
export * from './social/social-callback.component';

export * from './headless-signin/headless-signin.component';
export * from './headless-signup/headless-signup.component';
export * from './headless-reset/headless-reset.component';
export * from './headless-confirm/headless-confirm.component';
export * from './headless-menu/headless-menu.component';

export const accountPages = [
  SignInComponent,
  SignUpComponent,
  ResetPasswordComponent,
  ConfirmComponent,
  SocialCallbackComponent
];

export const headlessAccountPages = [
  HeadlessSigninComponent,
  HeadlessSignupComponent,
  HeadlessResetComponent,
  HeadlessConfirmComponent,
  HeadlessMenuComponent
];
