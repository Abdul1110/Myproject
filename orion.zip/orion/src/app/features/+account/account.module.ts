import { NgModule } from '@angular/core';
import { NgxsModule } from '@ngxs/store';
import { InlineSVGModule } from 'ng-inline-svg';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppStateModule } from '@app/core/app-state.module';
import { AccountRoutingModule } from './account-routing.module';
import { accountPages, headlessAccountPages } from './pages';
import { SharedModule } from '@app/shared';
import {
  LyraDesignFormModule,
  LyraDesignCommonModule,
  LyraDesignAsideModule,
  LyraDesignIconModule,
  LyraDesignUserModule,
  LyraDesignTypeModule,
  LyraDesignFilesModule,
  LyraDesignCardModule,
  GalaxyPreLoaderComponentModule,
  LyraDesignEmptyStateModule
} from '@leap/lyra-design';
import { AccountStates } from './store';
import { accountLayouts } from './layout';
import { accountComponents } from './components';
import { HeadlessAuthGuard } from './guards/headless-auth.guard';

@NgModule({
  imports: [
    NgxsModule.forFeature([...AccountStates]),
    //   AgGridModule,
    //   Angulartics2Module,
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    AppStateModule,
    AccountRoutingModule,
    LyraDesignCommonModule,
    LyraDesignAsideModule,
    LyraDesignFormModule,
    LyraDesignIconModule,
    LyraDesignUserModule,
    LyraDesignFilesModule,
    LyraDesignTypeModule,
    LyraDesignCardModule,
    GalaxyPreLoaderComponentModule,
    LyraDesignEmptyStateModule
  ],
  entryComponents: [...accountLayouts, ...accountPages, ...accountComponents],
  declarations: [...accountLayouts, ...accountPages, ...accountComponents, ...headlessAccountPages],
  providers: [HeadlessAuthGuard] //...previewServices
})
export class AccountModule {}
