import { Injectable } from '@angular/core';
import { Store } from '@ngxs/store';
import { FormGroup } from '@angular/forms';
import { BrowserService } from '@leap/lyra-design';
import { Observable } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';

import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models';
import { UserMetadataService, NavigationService } from '@app/core/services';
import { SignUpState, SignUpAction, SignInAction } from '../store';
import { AccountApiService } from './account-api.service';
import { AccountModel } from '../models';
import { PostMessage } from '../models/headless-account.model';
import * as Actions from '../store/actions';

@Injectable({
  providedIn: 'root'
})
export class HeadlessAccountService {
  private parentWindow: Window;

  constructor(
    private accountSvc: AccountApiService,
    private userMetadataSvc: UserMetadataService,
    private browserSvc: BrowserService,
    private store: Store,
    private navigateSvc: NavigationService
  ) {
    this.parentWindow = window.parent;
  }

  createAccount(signupForm: FormGroup): void {
    const signupRequestModel = this.createAccountRequestModel(signupForm.value);
    this.store.dispatch(new Actions.SignUpAction.SignUpStart(signupRequestModel));
  }

  signinAccount(email: string, password: string, rememberMe: boolean): Observable<string> {
    return this.accountSvc
      .signin({
        password,
        userName: email,
        rememberMe
      })
      .pipe(
        map(res => res.accessToken),
        tap(accessToken => this.postSuccess('login', accessToken))
        // catchError(error => this.store.dispatch(new SignInAction.SignInFailure(error)))
      );
  }

  resetAccount(resetForm: FormGroup) {
    const { email } = resetForm.value;
    const firmId = this.store.selectSnapshot(AppState.getSelectedFirmId);
    const resetReq = { userName: email, firmId };
    // May need to update to a more bespoke error response
    return this.accountSvc.reset(resetReq).pipe(
      tap(() => {
        this.postSuccess('forgot password', 'Password reset request successful.');
        this.navigate('/account/headless/signin');
      }),
      catchError(error => this.store.dispatch(new SignInAction.ResetPasswordFailure(error)))
    );
  }

  resendEmail() {
    const resendArgs = this.store.selectSnapshot(SignUpState.getResendData);
    const redirectUrl = this.browserSvc.window.location.origin;
    const requestModel = {
      agreeToTermsAndConditions: resendArgs.agreeToTermsAndConditions,
      email: resendArgs.email,
      firmId: undefined, // Need to determine if firmId is worth retrieving.
      redirectUrl: redirectUrl,
      userId: resendArgs.userId
    };

    return this.accountSvc.resend(requestModel).pipe(
      tap(() => {
        this.store.dispatch([
          new SignUpAction.ResendConfirmationSuccess(null),
          new SignUpAction.SignUpClear(undefined)
        ]);
        // Redirect after resending confirmation?
        this.navigate('/account/headless/signin');
        // Perhaps create another page type for confirmation resent.
        this.postSuccess('create account', 'Confirmation email resent.');
      }),
      catchError(error => this.store.dispatch(new SignUpAction.ResendConfirmationFailure(error)))
    );
  }

  signOut() {
    return this.userMetadataSvc.signout().pipe(
      tap(() => {
        if (this.browserSvc.isBrowser) {
          this.browserSvc.window.location = 'account/headless/signin';
        }
      }),
      catchError(() => (this.browserSvc.isBrowser ? (this.browserSvc.window.location = 'account/headless/signin') : []))
    );
  }

  markFileldsDirty(form: FormGroup, validations: any): void {
    if (!!form) {
      Object.keys(validations).forEach(field => {
        const control = form.get(field);
        if (control.pristine) {
          control.markAsDirty();
        }
      });
    }
  }

  validateForm(form: FormGroup, validations: any) {
    const errors = {};

    if (!!form) {
      Object.keys(validations).forEach(field => {
        const control = form.get(field);
        const controlValidations = validations[field];
        let result = [];
        if (!control.pristine) {
          controlValidations.forEach(validation => {
            if (control.hasError(validation.type)) {
              result = result.concat(validation.message);
            }
          });
        }
        errors[field] = result;
      });
    }

    return errors;
  }

  hasErrors(errors): boolean {
    return !!errors ? Object.keys(errors).some(f => errors[f].length > 0) : false;
  }

  navigate(path: string) {
    this.navigateSvc.goto(<CoreModel.NavigationData>{ path });
  }

  postSuccess(page: 'login' | 'create account' | 'forgot password', message: string = '') {
    const msg: PostMessage = { page, success: true, message };
    this.parentWindow.postMessage(msg, '*');
  }

  private createAccountRequestModel(formData: any) {
    const { email, agree, ...keys } = formData;
    const redirectUrl = this.browserSvc.window.location.origin;
    // const theme = this.store.selectSnapshot(AppState.getTheme);
    const isWhiteLabel = this.store.selectSnapshot(AppState.isWhiteLabel);
    const signupRequestModel: AccountModel.SignUpRequest = {
      ...keys,
      userName: email,
      redirectUrl,
      agreeToTermsAndConditions: agree,
      isWhiteLabel: isWhiteLabel.whiteLabel,
      firmId: undefined // Need to determine if firmId is worth retrieving.
    };
    return signupRequestModel;
  }
}
