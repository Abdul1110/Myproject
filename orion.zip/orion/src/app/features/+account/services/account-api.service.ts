import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UUID } from 'angular2-uuid';
import { AccountModel } from '../models';
import { CoreModel } from '../../../core/models';

@Injectable({
  providedIn: 'root'
})
export class AccountApiService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  signup(user: AccountModel.SignUpRequest): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/signup?rdid=${randomId}`;
    return this.http.post<any>(url, user);
  }

  signin(user: AccountModel.SignInRequest): Observable<CoreModel.SignInResponse> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/signin?rdid=${randomId}`;
    return this.http.post<any>(url, user);
  }

  reset(user: AccountModel.ResetPasswordRequest): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/reset?rdid=${randomId}`;
    return this.http.post<any>(url, user);
  }

  resend(data: AccountModel.ResendConfirmationRequest): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/resend?rdid=${randomId}`;
    return this.http.post<any>(url, data);
  }

  profile(): Observable<AccountModel.ProfileAndUserMetadata> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/profile?rdid=${randomId}`;
    return this.http.get<AccountModel.ProfileAndUserMetadata>(url);
  }

  themes(): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/theme?rdid=${randomId}`;
    return this.http.post<any>(url, {});
  }
}
