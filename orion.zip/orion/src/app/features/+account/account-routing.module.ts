import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {
  SignUpComponent,
  SignInComponent,
  ResetPasswordComponent,
  ConfirmComponent,
  SocialCallbackComponent,
  HeadlessSigninComponent,
  HeadlessSignupComponent,
  HeadlessResetComponent,
  HeadlessConfirmComponent,
  HeadlessMenuComponent
} from './pages';
import { AccountHomeComponent } from './layout';
import { HeadlessAuthGuard } from './guards/headless-auth.guard';
import { HasAuthGuard } from '@app/shared/guards/has-auth.guard';

const routes: Routes = [
  {
    path: '',
    component: AccountHomeComponent,
    children: [
      {
        path: 'signin',
        component: SignInComponent,
        canActivate: [HasAuthGuard]
      },
      {
        path: 'signup',
        component: SignUpComponent
      },
      {
        path: 'reset-password',
        component: ResetPasswordComponent
      },
      {
        path: 'signup-confirmation',
        component: ConfirmComponent
      },
      { path: '', redirectTo: 'signin', pathMatch: 'full' }
    ]
  },
  {
    path: 'headless',
    children: [
      {
        path: 'signin',
        component: HeadlessSigninComponent,
        canActivate: [HeadlessAuthGuard]
      },
      {
        path: 'signup',
        component: HeadlessSignupComponent
      },
      {
        path: 'reset-password',
        component: HeadlessResetComponent
      },
      {
        path: 'signup-confirmation',
        component: HeadlessConfirmComponent
      },
      {
        path: 'menu',
        component: HeadlessMenuComponent
      },
      {
        path: '',
        redirectTo: 'signin',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: 'social-callback/:randomId',
    component: SocialCallbackComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule {}
