import { Component, HostBinding, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subject } from 'rxjs';

import { CoreModel } from '@app/core/models';
import { versions } from '@env/versions';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { StandardModel } from '@leap/lyra-design';
import { tap, takeUntil } from 'rxjs/operators';
import { environment } from '@env/environment';
import { Store } from '@ngxs/store';
import { AppState } from '@app/core/store/states';

@Component({
  selector: 'sc-account-home',
  templateUrl: './account-home.component.html'
})
export class AccountHomeComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<boolean>();

  isSmallScreen$: Observable<boolean>;
  get version(): string {
    return `v${versions.version}`;
  }

  authenticated$ = this.appActionSvc.isAuthenticated$;
  whiteLabelProps$ = this.appActionSvc.whiteLabelStatus$;
  theme$ = this.appActionSvc.theme$;
  firmId$ = this.appActionSvc.firmId$;
  previewShare$ = this.appActionSvc.sharePreview$;
  firmTheme: StandardModel.ThemeSetting = undefined;

  getShareDescription(share: CoreModel.SharePreviewInfo): string {
    const hasSharedItems = share && share.documents && share.documents.length > 0;
    const staffName = share && share.staffName;

    if (hasSharedItems && share.documents[0].fileExtension.includes('app')) {
      return `${staffName || 'Someone'} has granted you access to:`;
    }

    const shareType = hasSharedItems && share.documents[0].fileExtension.includes('folder') ? 'folder' : 'document';
    return `${staffName || 'Someone'} has shared the following ${shareType} with you:`;
  }

  getDocIcon(document: CoreModel.ShareDocumentInfo): string {
    if (document) {
      return CoreModel.Helper.getDocTypeIcon(document.fileExtension);
    }
    return CoreModel.Helper.getDocTypeIcon('');
  }

  getDocName(document: CoreModel.ShareDocumentInfo): string {
    if (document) {
      return document.fileExtension &&
        !document.fileExtension.includes('folder') &&
        !document.fileExtension.includes('app')
        ? `${document.name}.${document.fileExtension}`
        : document.name;
    }
    return '';
  }

  shareDocuments(share: CoreModel.SharePreviewInfo): CoreModel.ShareDocumentInfo[] {
    if (share && share.documents && share.documents.length > 0) {
      return share.documents;
    }
    return [];
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  isWhiteLabel(data: { whiteLabel: boolean; firmId: string }): boolean {
    if (data && data.whiteLabel) {
      return true;
    }
    return false;
  }

  @HostBinding('class.login-success') loginSuccess = false;
  @HostBinding('class.layout-column')
  ngOnInit() {
    this.isSmallScreen$ = this.appActionSvc.isSmallScreen$;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  constructor(private appActionSvc: AppActionService, private store: Store) {
    this.firmSideEffect$()
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private firmSideEffect$(): Observable<StandardModel.ThemeSetting> {
    return this.appActionSvc.theme$.pipe(
      tap((f: StandardModel.ThemeSetting) => {
        if (f) {
          const { firmId, whiteLabel: isWhiteLabel } = this.store.selectSnapshot(AppState.isWhiteLabel);
          this.firmTheme = { ...f, firmLogoUrl: this.getLogoUrl(isWhiteLabel ? firmId : null, isWhiteLabel) };
          return;
        }
        this.firmTheme = {
          firmName: 'LawConnect',
          firmLogoUrl: this.getLogoUrl(undefined, false),
          hasLogo: false,
          primaryColor: '',
          secondaryColor: ''
        };
      })
    );
  }

  private getLogoUrl(firmId: string, isWhiteLabel: boolean): string {
    if (!firmId || !isWhiteLabel) {
      return '/assets/images/lawconnect/header-logo-dark.svg';
    }

    return `${environment.appSettings.apiBaseUrl}v1/dto/whitelabel/assets/firm/${firmId}/logo`;
  }
}
