import { AccountHomeComponent } from './home/account-home.component';

export * from './home/account-home.component';

export const accountLayouts = [AccountHomeComponent];
