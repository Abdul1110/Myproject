import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { HeadlessAccountService } from '../services/headless-account.service';

@Injectable()
export class HeadlessAuthGuard implements CanActivate {
  private endpoint = '/api/internal';
  constructor(private http: HttpClient, private router: Router, private headlessAccountSvc: HeadlessAccountService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const url = `${this.endpoint}/api/account/isAuthenticated`;

    return this.http.get(url).pipe(
      map((res: any) => {
        if (!res) {
          return true;
        }
        if (!!res && !!res.cookieNotExpired && !!res.accessToken) {
          // this.headlessAccountSvc.postSuccess('login', res.accessToken);
          this.router.navigate(['account/headless/menu'], {
            state: {
              accountName: !!res.userMetadata ? res.userMetadata.displayName : null,
              accessToken: res.accessToken
            }
          });
          return false;
        }
        return true;
      })
    );
  }
}
