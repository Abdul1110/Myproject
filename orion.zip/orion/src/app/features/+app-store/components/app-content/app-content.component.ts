import {
  Component,
  OnDestroy,
  Input,
  HostBinding,
  Output,
  EventEmitter,
  ViewChild,
  AfterViewInit
} from '@angular/core';
import { Subject, fromEvent } from 'rxjs';
import { CustomEventService } from '@app/core/services';
import { LyraDesignFormModel } from '@leap/lyra-design';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'sc-app-content',
  templateUrl: './app-content.component.html'
})
export class AppContentComponent implements OnDestroy, AfterViewInit {
  private destroy$ = new Subject<boolean>();
  isLoading = true;

  @ViewChild('content_app', { static: false }) contentApp: any;

  @Input('url') url: string;

  @HostBinding('class.w-100')
  ngOnDestroy() {
    this.destroy$.next();
  }

  ngAfterViewInit() {
    this.contentApp &&
      fromEvent(this.contentApp.nativeElement, 'load')
        .pipe(takeUntil(this.destroy$))
        .subscribe(v => {
          this.contentLoaded();
        });
  }

  contentLoaded(): void {
    this.isLoading = false;
  }

  constructor(private customEventSvc: CustomEventService) {}
}
