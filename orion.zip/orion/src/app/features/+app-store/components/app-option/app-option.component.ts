import { Component, OnDestroy, Input, HostBinding, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import { CustomEventService } from '@app/core/services';
import { LyraDesignFormModel } from '@leap/lyra-design';

@Component({
  selector: 'sc-app-option',
  templateUrl: './app-option.component.html'
})
export class AppOpotionComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  @Input('data') data: LyraDesignFormModel.SelectOption;
  @Input('is-selected') isSelected: boolean;
  @Output('launch') launch = new EventEmitter<LyraDesignFormModel.SelectOption>();

  @HostBinding('class.w-100')
  ngOnDestroy() {
    this.destroy$.next();
  }

  launchApp(): void {
    this.launch.emit(this.data);
  }

  constructor(private customEventSvc: CustomEventService) {}
}
