import { AppOpotionComponent } from './app-option/app-option.component';
import { AppContentComponent } from './app-content/app-content.component';

export * from './app-option/app-option.component';
export * from './app-content/app-content.component';

export const appStoreComponents = [AppOpotionComponent, AppContentComponent];
