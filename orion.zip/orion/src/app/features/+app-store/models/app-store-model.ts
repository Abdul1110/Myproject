export namespace AppStoreModel {
  export interface LaunchAppRequest {
    matterId: string;
    appId: string;
    shareId: string;
  }

  export interface SelectedApp {
    appId: string;
    shareId: string;
  }

  export class Helper {
    static isImage(ext: string): boolean {
      return /(bmp|gif|jpe?g|png|tiff)$/i.test(ext);
    }
  }
}
