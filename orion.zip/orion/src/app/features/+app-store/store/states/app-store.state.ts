import { State, Selector, Action, StateContext } from '@ngxs/store';
import { LyraDesignFormModel } from '@leap/lyra-design';

import { CoreModel, NodeModel } from '@app/core/models';
import { NavigationService } from '@app/core/services';
import { AppStoreModel } from '../../models';
import { AppStoreAction } from '../actions';

export interface AppStoreStateModel {
  error: any | string | null;
  loading: boolean;
  selectedApp: AppStoreModel.SelectedApp;
  appOption: LyraDesignFormModel.SelectOption[];
}

@State<AppStoreStateModel>({
  name: 'app_store',
  defaults: {
    error: null,
    loading: false,
    selectedApp: undefined,
    appOption: []
  }
})
export class AppStoreState {
  constructor(private navigationSvc: NavigationService) {}

  @Action(AppStoreAction.LaunchApp)
  LaunchApp({ getState, setState, dispatch }: StateContext<AppStoreStateModel>, payload) {
    const { shareId, appId, matterId } = payload.payload as AppStoreModel.LaunchAppRequest;
    const state = getState();
    const selectedApp = <AppStoreModel.SelectedApp>{ shareId, appId };

    setState({
      ...state,
      selectedApp
    });

    if (matterId && appId && shareId) {
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `matters/${matterId}/apps/${appId}/shares/${shareId}`
      });
    }
  }

  @Action(AppStoreAction.SetAppOptions)
  SetAppOptions({ getState, setState, dispatch }: StateContext<AppStoreStateModel>, payload) {
    const nodes = payload.payload as NodeModel.LawConnectNode[];
    const state = getState();
    const options = nodes.map(o => {
      return <LyraDesignFormModel.SelectOption>{
        id: o.subType,
        name: o.name,
        value: {
          shareId: o.id,
          url: o.url
        }
      };
    });

    // @tarah, if u want to have the list, please comment out below:
    setState({
      ...state,
      appOption: options
    });
  }

  @Selector()
  static selectLoading(state: AppStoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.loading;
  }

  @Selector()
  static selectError(state: AppStoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.error;
  }

  @Selector()
  static selectedApp(state: AppStoreStateModel): AppStoreModel.SelectedApp {
    if (!state) {
      return undefined;
    }

    return state.selectedApp;
  }

  @Selector()
  static selectedAppOption(state: AppStoreStateModel): LyraDesignFormModel.SelectOption {
    if (!state || !state.selectedApp || !state.appOption) {
      return undefined;
    }

    const { selectedApp } = state;
    return state.appOption.find(a => a.id == selectedApp.appId);
  }

  @Selector()
  static appOption(state: AppStoreStateModel): LyraDesignFormModel.SelectOption[] {
    if (!state) {
      return [];
    }

    return state.appOption;
  }
}
