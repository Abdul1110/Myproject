import { AppStoreModel } from '../../models';
import { NodeModel } from '@app/core/models';

export namespace AppStoreAction {
  const prefix = '[AppIntegration]';

  export const ActionTypes = {
    LAUCH_APP: `${prefix} launch app`,
    SET_APP_OPTIONS: `${prefix} set app options`
  };

  export class LaunchApp {
    static readonly type = ActionTypes.LAUCH_APP;
    constructor(public payload: AppStoreModel.LaunchAppRequest) {}
  }

  export class SetAppOptions {
    static readonly type = ActionTypes.SET_APP_OPTIONS;
    constructor(public payload: NodeModel.LawConnectNode[]) {}
  }
}
