import { Component, OnDestroy, HostBinding } from '@angular/core';
import { LyraDesignFormModel } from '@leap/lyra-design';
import { Store, Select } from '@ngxs/store';
import { ActivatedRoute } from '@angular/router';
import { Subject, Observable, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import { CustomEventService } from '@app/core/services';
import { AppStoreAction, AppStoreState } from '../../store';
import { AppStoreModel } from '../../models';

@Component({
  selector: 'sc-app-selection',
  templateUrl: './app-selection.component.html'
})
export class AppSelectionComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private matterId = '';
  private selectedApp: AppStoreModel.SelectedApp = undefined;

  @Select(AppStoreState.appOption) appStoreOption$: Observable<LyraDesignFormModel.SelectOption[]>;
  @Select(AppStoreState.selectedApp) selectedApp$: Observable<AppStoreModel.SelectedApp>;

  isOptionSelected(option: LyraDesignFormModel.SelectOption): boolean {
    if (!option || !this.selectedApp) {
      return false;
    }

    return option.id == this.selectedApp.appId;
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  hasStoreOptions(options: any): boolean {
    return options && options.length > 1;
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  launchApp(option: LyraDesignFormModel.SelectOption): void {
    this.store.dispatch(
      new AppStoreAction.LaunchApp({
        appId: option.id,
        matterId: this.matterId,
        shareId: option.value.shareId
      })
    );
  }

  constructor(private customEventSvc: CustomEventService, private store: Store, private route: ActivatedRoute) {
    this.updateFromPathParams();
    merge(this.listenToSelectedApp$())
      .pipe(takeUntil(this.destroy$))
      .subscribe();
  }

  private listenToSelectedApp$(): Observable<any> {
    return this.selectedApp$.pipe(
      tap(v => {
        this.selectedApp = v;
      })
    );
  }

  private updateFromPathParams(matterId: string = undefined): void {
    this.matterId = matterId || (this.route.parent && this.route.parent.snapshot.params['matterId']) || '';
  }
}
