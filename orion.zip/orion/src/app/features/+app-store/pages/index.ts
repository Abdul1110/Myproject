import { AppSelectionComponent } from './app-selection/app-selection.component';

export * from './app-selection/app-selection.component';

export const appStorePages = [AppSelectionComponent];
