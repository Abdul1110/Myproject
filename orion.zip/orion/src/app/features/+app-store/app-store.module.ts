import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Angulartics2Module } from 'angulartics2';
import { NgxsModule } from '@ngxs/store';
import {
  GalaxyPreLoaderComponentModule,
  LyraDesignEmptyStateModule,
  LyraDesignPanelModule,
  LyraDesignAvatarModule,
  LyraDesignMenuModule,
  LyraDesignCommonModule,
  LyraDesignIconModule,
  LyraDesignAsideModule,
  LyraDesignMainModule,
  LyraDesignNavbarModule,
  LyraDesignCardModule,
  LyraDesignFilesModule,
  LyraDesignTabsModule,
  LyraDesignTypeModule,
  LyraDesignSectionModule
} from '@leap/lyra-design';
import { InlineSVGModule } from 'ng-inline-svg';

// local
import { SharedModule } from '@app/shared';
import { appStoreLayouts } from './layout';
import { appStorePages } from './pages';
import { appStoreComponents } from './components';
import { AppStateModule } from '@app/core/app-state.module';
import { AppStoreRoutingModule } from './app-store-routing.module';
import { AppStoreStates } from './store';
import { appStoreServices } from './services';

@NgModule({
  imports: [
    NgxsModule.forFeature([...AppStoreStates]),
    Angulartics2Module,
    InlineSVGModule.forRoot({
      baseUrl: '/assets/icons/'
    }),
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    LyraDesignEmptyStateModule,
    GalaxyPreLoaderComponentModule,
    LyraDesignEmptyStateModule,
    LyraDesignPanelModule,
    LyraDesignAvatarModule,
    LyraDesignMenuModule,
    LyraDesignCommonModule,
    LyraDesignIconModule,
    LyraDesignAsideModule,
    LyraDesignMainModule,
    LyraDesignNavbarModule,
    LyraDesignTabsModule,
    LyraDesignCardModule,
    LyraDesignFilesModule,
    LyraDesignTypeModule,
    LyraDesignSectionModule,
    LyraDesignTypeModule,
    SharedModule,
    AppStateModule,
    AppStoreRoutingModule
  ],
  entryComponents: [...appStorePages, ...appStoreLayouts],
  declarations: [...appStoreComponents, ...appStorePages, ...appStoreLayouts],
  providers: [...appStoreServices]
})
export class AppStoreModule {}
