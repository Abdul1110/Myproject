import { Component, OnDestroy, OnInit, HostBinding } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { BrowserService, LyraAnimation, LyraDesignFormModel } from '@leap/lyra-design';
import { Observable, Subject, merge } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';

import {
  AnalyticService,
  CustomEventService,
  NAVIGATION_SIDE_BAR_TOGGLE,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED,
  MATTERS_SELECT_CLOSED,
  NavigationService
} from '@app/core/services';
import { AppStoreState, AppStoreAction } from '@app/features/+app-store/store';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { environment } from '@env/environment';
import { CoreModel } from '@app/core/models';
import { SetNavigationActionId } from '@app/core/store/actions';
import { SideNavigationModel } from '@app/shared/models';
import { AppState } from '@app/core/store/states';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';

const { locale } = environment;
const icon = locale.global.menu.apps.icon;

@Component({
  selector: 'sc-app-store-home',
  templateUrl: './app-store-home.component.html',
  animations: [LyraAnimation.xAnimationCardItemCollapse]
})
export class AppStoreHomeComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<boolean>();
  private selectedAppOption: LyraDesignFormModel.SelectOption = undefined;

  selectedAppUrl = '';
  token: string;
  firm: CoreModel.FirmDetail = null;
  matterName: string;
  matterId = '';

  @Select(AppStoreState.selectLoading) loading$: Observable<boolean>;
  @Select(AppStoreState.selectError) error$: Observable<boolean>;
  @Select(AppStoreState.selectedAppOption) selectedAppOption$: Observable<LyraDesignFormModel.SelectOption>;

  @HostBinding('class.lt-container')
  @HostBinding('class.bg-light-secondary')
  ngOnDestroy() {
    this.destroy$.next(true);
  }

  ngOnInit() {
    const { shareId, appId, matterId } = this.route.snapshot.params;

    shareId &&
      appId &&
      this.store.dispatch(
        new AppStoreAction.LaunchApp({
          shareId,
          appId,
          matterId
        })
      );
  }

  documentTitle(): string {
    if (!this.selectedAppOption) {
      return environment.locale.global.menu.apps.title;
    }

    return this.selectedAppOption.name;
  }

  getNavbarIcon(): string {
    return icon;
  }

  getFirmName(): string {
    return (this.firm && this.firm.name) || locale.matters.title;
  }

  getMatterName(): string {
    return this.matterName;
  }

  constructor(
    private route: ActivatedRoute,
    private store: Store,
    private customEventSvc: CustomEventService,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private appActionSvc: AppActionService,
    private navigationSvc: NavigationService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.AppPreviewPage, action: 'View app' });

      this.updateFromPathParams();
      this.updateMatterName(this.matterId);

      merge(this.listenToSelectedAppOption$(), this.listenToMatterSelectedFromOptions$(), this.listenToAppStoreNodes$())
        .pipe(takeUntil(this.destroy$))
        .subscribe();

      this.store.dispatch(new SetNavigationActionId(SideNavigationModel.SideActionId.apps));
      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_TOGGLE, { open: true });
      this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, {
        actionId: SideNavigationModel.SideActionId.apps
      });
    }
  }

  private listenToMatterSelectedFromOptions$(): Observable<any> {
    return this.customEventSvc.registerEvent(MATTERS_SELECT_CLOSED, ({ returnToActionId, path, matterId }) => {
      if (!matterId || matterId === this.matterId) {
        return;
      }

      const apps = this.store.selectSnapshot(AppState.getAppStoreByMatter);
      const app = apps && matterId && apps[matterId].length > 0 && apps[matterId][0];
      const { id, subType } = app || { id: '', subType: '' };

      this.store.dispatch([
        new AppStoreAction.SetAppOptions((apps && apps[matterId]) || []),
        new AppStoreAction.LaunchApp({
          shareId: id,
          appId: subType,
          matterId
        })
      ]);

      this.updateFromPathParams(matterId);
      this.updateMatterName(this.matterId);
    });
  }

  private listenToSelectedAppOption$(): Observable<any> {
    return this.selectedAppOption$.pipe(
      tap((v: LyraDesignFormModel.SelectOption) => {
        this.selectedAppUrl = '';
        this.selectedAppOption = v;
        if (v && v.value && v.value.url) {
          setTimeout(() => {
            this.updateBrowserPathIfNotPatch(v.id, v.value.shareId);
            this.selectedAppUrl = v.value.url;
          }, 0);
        }
      })
    );
  }

  private listenToAppStoreNodes$(): Observable<any> {
    return this.appActionSvc.appStoreByMatter$.pipe(
      tap(v => {
        const list = v ? v[this.matterId] : [];
        if (!list || list.length === 0) {
          this.navigationSvc.goto(
            <CoreModel.NavigationData>{
              path: `matters/${this.matterId}/sharedocuments`
            },
            0
          );
          return;
        }

        this.store.dispatch(new AppStoreAction.SetAppOptions(list || []));
      })
    );
  }

  private updateBrowserPathIfNotPatch(appId: string, shareId: string): void {
    if (shareId && appId) {
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: `matters/${this.matterId}/apps/${appId}/shares/${shareId}`
      });
    }
  }

  private updateFromPathParams(matterId: string = undefined): void {
    this.matterId = matterId || (this.route && this.route.snapshot.params['matterId']) || '';
  }

  private updateMatterName(matterId: string): void {
    const matterDetail = CoreModel.Helper.getMatterDetail(
      matterId,
      this.store.selectSnapshot(AppState.getMattersByFirm)
    );

    this.matterName = (matterDetail && matterDetail.name) || '';
  }
}
