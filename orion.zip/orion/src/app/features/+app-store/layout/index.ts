import { AppStoreHomeComponent } from './home/app-store-home.component';

export * from './home/app-store-home.component';

export const appStoreLayouts = [AppStoreHomeComponent];
