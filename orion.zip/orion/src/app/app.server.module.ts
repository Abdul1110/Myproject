// angular
import { APP_BOOTSTRAP_LISTENER, ApplicationRef, NgModule, ErrorHandler } from '@angular/core';
import { makeStateKey, TransferState } from '@angular/platform-browser';
import { ServerModule, ServerTransferStateModule } from '@angular/platform-server';
import { REQUEST } from '@nguniversal/express-engine/tokens';
import { ModuleMapLoaderModule } from '@nguniversal/module-map-ngfactory-loader';

// libs
import * as express from 'express';
import { Subscription } from 'rxjs';
import { filter, first } from 'rxjs/operators';
import { CACHE, CacheService, STORAGE } from '@ngx-cache/core';
import { FsCacheService, ServerCacheModule } from '@ngx-cache/platform-server';
import { fsStorageFactory, FsStorageLoader, FsStorageService } from '@ngx-cache/fs-storage';
import * as SentryNode from '@sentry/node';

// app
import { AppModule, REQ_KEY } from './app.module';
import { AppComponent } from './app.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

export function bootstrapFactory(
  appRef: ApplicationRef,
  transferState: TransferState,
  request: express.Request,
  cache: CacheService
): () => Subscription {
  return () =>
    appRef.isStable
      .pipe(
        filter(stable => stable),
        first()
      )
      .subscribe(() => {
        transferState.set<any>(<any>REQ_KEY, {
          hostname: request.hostname,
          originalUrl: request.originalUrl,
          referer: request.get('referer')
        });

        transferState.set<any>(makeStateKey<string>(cache.key), JSON.stringify(cache.dehydrate()));
      });
}

@NgModule({
  imports: [
    AppModule,
    ServerModule,
    ModuleMapLoaderModule,
    NoopAnimationsModule,
    ServerTransferStateModule,
    ServerCacheModule.forRoot([
      {
        provide: CACHE,
        useClass: FsCacheService
      },
      {
        provide: STORAGE,
        useClass: FsStorageService
      },
      {
        provide: FsStorageLoader,
        useFactory: fsStorageFactory
      }
    ])
  ],
  providers: [
    // Add universal-only providers here
    // {
    //   provide: APP_BOOTSTRAP_LISTENER,
    //   useFactory: bootstrapFactory,
    //   multi: true,
    //   deps: [ApplicationRef, TransferState, REQUEST, CacheService]
    // }
  ],
  bootstrap: [AppComponent]
})
export class AppServerModule {}
