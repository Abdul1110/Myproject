import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { environment } from '@env/environment';

import {
  PreviewRouteHandlerComponent,
  NoRouteHandlerComponent,
  ShareLoginRouteHandlerComponent,
  ShareNodeRouteHandlerComponent,
  ShareESignatureRouteHandlerComponent,
  ESignatureRequestRouteHandlerComponent,
  ShareAppRouteHandlerComponent
} from './components';
import { AuthGuard } from './shared/guards/auth.guard';
import { ShareFolderRouteHandlerComponent } from './components/share-folder-route-handler.component';

// TODO: fix this
export function errorHandler(err: any): any {
  console.warn('Route error?', err);
  return '';
}

const routes: Routes = [
  {
    path: 'preview/:shareId',
    component: PreviewRouteHandlerComponent,
    loadChildren: () => import('app/features/+preview/preview.module').then(m => m.PreviewModule)
  },
  {
    path: 'apps/:appId/shares/:shareId',
    component: ShareAppRouteHandlerComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'nodes/:nodeId/event/:eventId',
    component: ShareNodeRouteHandlerComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'nodes/:nodeId/folders/:folderId',
    component: ShareFolderRouteHandlerComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'request',
    component: ShareESignatureRouteHandlerComponent
  },
  {
    path: 'share-login',
    component: ShareLoginRouteHandlerComponent
  },
  {
    path: 'esignatures',
    component: ESignatureRequestRouteHandlerComponent,
    pathMatch: 'full'
  },
  {
    path: 'account',
    loadChildren: () => import('app/features/+account/account.module').then(m => m.AccountModule)
  },
  {
    path: '',
    loadChildren: () => import('app/features/+layout/layout.module').then(m => m.LayoutModule)
  },
  {
    path: '**',
    pathMatch: 'full',
    component: NoRouteHandlerComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      errorHandler,
      enableTracing: !environment.production
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
