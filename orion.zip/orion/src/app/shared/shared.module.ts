import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import {
  BsDropdownModule,
  ModalModule,
  TabsModule,
  AlertModule,
  ButtonsModule,
  ProgressbarModule
} from 'ngx-bootstrap';

import { NotFoundComponent } from './components/not-found/not-found.component';
import { modalComponents } from '@app/shared/components/modal';
import { sharedModalComponents } from '@app/shared/components';
import { sharedDirectives } from '@app/shared/directives';
import { sharedServices } from '@app/shared/services';
import { sharedGuards } from '@app/shared/guards';
import { RouterModule } from '@angular/router';
import {
  GalaxyPreLoaderComponentModule,
  LyraDesignIconModule,
  LyraDesignButtonModule,
  LyraDesignTypeModule,
  LyraDesignEmptyStateModule,
  LyraDesignCardModule,
  LyraDesignAvatarModule,
  LyraDesignFormModule,
  LyraDesignSectionModule,
  LyraDesignCommonModule
} from '@leap/lyra-design';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    PdfViewerModule,
    ProgressbarModule.forRoot(),
    ModalModule.forRoot(),
    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    AlertModule.forRoot(),
    ButtonsModule.forRoot(),
    GalaxyPreLoaderComponentModule,
    LyraDesignIconModule,
    LyraDesignCommonModule,
    LyraDesignButtonModule,
    LyraDesignAvatarModule,
    LyraDesignTypeModule,
    LyraDesignEmptyStateModule,
    LyraDesignCardModule,
    LyraDesignFormModule,
    LyraDesignSectionModule
  ],
  entryComponents: [...modalComponents, ...sharedModalComponents],
  declarations: [NotFoundComponent, ...sharedDirectives, ...modalComponents, ...sharedModalComponents],
  exports: [NotFoundComponent, ...sharedDirectives, ...modalComponents, ...sharedModalComponents],
  providers: [...sharedServices, ...sharedGuards]
})
export class SharedModule {}
