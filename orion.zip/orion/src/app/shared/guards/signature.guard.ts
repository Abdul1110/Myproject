import { Injectable } from '@angular/core';
import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { Store } from '@ngxs/store';
import { finalize, take } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';

import { GetSignaturesStart, SetSignatureInit } from '@app/core/store/actions';
import { AppState } from '@app/core/store/states';
import { BrowserService } from '@leap/lyra-design';
import { UserMetadataService } from '@app/core/services';

@Injectable()
export class SignatureGuard implements CanActivate {
  constructor(private store: Store, private brwSvc: BrowserService, private userService: UserMetadataService) {}

  canActivate(activatedRoute: ActivatedRouteSnapshot, routeState: RouterStateSnapshot): Observable<boolean> {
    return Observable.create((observer: Subject<boolean>) => {
      this.userService.authenticationStatus$.subscribe(isAuthenticated => {
        if (!isAuthenticated) {
          return observer.next(false);
        }

        const isLogout =
          this.brwSvc.isBrowser && this.brwSvc.window && this.brwSvc.window.location.pathname.indexOf('/logout') !== -1;
        const initDone = this.store.selectSnapshot(AppState.getSignatureInitStatus);

        if (initDone || isLogout) {
          observer.next(true);
        } else {
          this.store
            .dispatch(new GetSignaturesStart(true))
            .pipe(
              finalize(() => observer.next(true)),
              take(1)
            )
            .subscribe({
              next: this.updateDone.bind(this),
              error: this.updateWithError.bind(this)
            });
        }
      });
    });
  }

  updateDone = (data: any) => {
    this.store.dispatch(new SetSignatureInit(true));
  };

  updateWithError = (err: any) => {
    console.log('error to init signatures');
  };
}
