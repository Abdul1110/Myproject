import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Params } from '@angular/router';
import { Store } from '@ngxs/store';
import { HttpClient } from '@angular/common/http';
import { map, take } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';
import { Observable, Subject } from 'rxjs';

import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models';
import * as actions from '@app/core/store/actions';
import { NavigationService, UserMetadataService } from '@app/core/services';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private store: Store,
    private brwSvc: BrowserService,
    private navigationSvc: NavigationService,
    private userService: UserMetadataService
  ) {}

  private useStateUrl = ['/nodes/', '/request'];
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const isAutenticated = this.store.selectSnapshot(AppState.getAppAuthentication);
    let path = this.brwSvc.isBrowser ? this.brwSvc.window.location.pathname : '';

    return Observable.create((observer: Subject<boolean>) => {
      if (isAutenticated) {
        this.userService.authenticationStatus$.next(true);
        return observer.next(true);
      }

      this.userService
        .isAuthenticated()
        .pipe(
          take(1),
          map(currentStatus => {
            if (currentStatus && currentStatus.userMetadata && currentStatus.userMetadata.login) {
              if (currentStatus.cookieNotExpired) {
                if (this.useStateUrl.findIndex(x => path.indexOf(x) === 0) !== -1) {
                  path = state.url;
                }

                this.store.dispatch(
                  new actions.SetAppAuthencation({ path, result: { ...currentStatus.userMetadata } })
                );
              }

              this.userService.authenticationStatus$.next(true);
              return observer.next(true);
            }

            this.userService.authenticationStatus$.next(false);
            this.handleNotAuthenticated(state.url);
            return observer.next(false);
          })
        )
        .subscribe();
    });
  }

  private handleNotAuthenticated(url: string): void {
    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/account/signin',
      queryParams: <Params>{
        returnTo: `${encodeURIComponent(url)}`
      }
    });
  }
}
