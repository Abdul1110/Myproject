import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Params } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { map, catchError, mergeMap, take } from 'rxjs/operators';
import { Observable, Subject, throwError } from 'rxjs';

import { CoreModel } from '@app/core/models';
import { NavigationService } from '@app/core/services';

@Injectable()
export class HasAuthGuard implements CanActivate {
  private endpoint = '/api/internal';
  constructor(private navigationSvc: NavigationService, private http: HttpClient) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return Observable.create((observer: Subject<boolean>) => {
      const url = `${this.endpoint}/api/account/isAuthenticated`;
      this.http
        .get(url)
        .pipe(
          take(1),
          map((res: any) => {
            if (!!res && res.cookieNotExpired) {
              const qp = route.queryParams;
              //noted: handle public preview being revoked, redirect to recents; fixed infinite looping!
              const returnTo = qp.returnTo && !(qp.returnTo.indexOf('/preview/') === 0) ? qp.returnTo : undefined;
              const path = returnTo || 'recents';
              this.navigationSvc.goto(<CoreModel.NavigationData>{ path });
            }
            return observer.next(true);
          }),
          catchError(err => {
            observer.next(true);
            return throwError(err);
          })
        )
        .subscribe();
    });
  }
}
