import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { Observable, of, Subject, throwError } from 'rxjs';
import { map, tap, catchError, take } from 'rxjs/operators';

import { CoreModel } from '@app/core/models';
import { UserMetadataService, NavigationService } from '@app/core/services';

@Injectable()
export class TermsGuard implements CanActivate {
  constructor(private navigationSvc: NavigationService, private userMetadataSvc: UserMetadataService) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return Observable.create((observer: Subject<boolean>) => {
      this.userMetadataSvc.authenticationStatus$.subscribe(isAuthenticated => {
        if (!isAuthenticated) {
          return observer.next(false);
        }

        this.userMetadataSvc
          .getUserMetadata()
          .pipe(
            take(1),
            map(v => v.has_agree_to_lawconnect_privacy),
            tap(agree => {
              if (!agree) {
                this.navigationSvc.goto(<CoreModel.NavigationData>{
                  path: '/terms'
                });
                return observer.next(false);
              }
              return observer.next(true);
            }),
            catchError(err => {
              observer.next(false);
              if (err && err.status == 403) {
                return of(null);
              }
              return throwError(err);
            })
          )
          .subscribe();
      });
    });
  }
}
