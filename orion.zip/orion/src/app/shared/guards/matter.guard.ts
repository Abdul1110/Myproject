import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Store } from '@ngxs/store';
import { finalize, take } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';

import { AppState } from '@app/core/store/states';
import { GetMattersStart, SetNodesInit } from '@app/core/store/actions';
import { BrowserService } from '@leap/lyra-design';
import { UserMetadataService } from '@app/core/services';

@Injectable()
export class MatterGuard implements CanActivate {
  constructor(private store: Store, private brwSvc: BrowserService, private userService: UserMetadataService) {}

  canActivate(router: ActivatedRouteSnapshot, routeState: RouterStateSnapshot): Observable<boolean> {
    return Observable.create((observer: Subject<boolean>) => {
      this.userService.authenticationStatus$.subscribe(isAuthenticated => {
        if (!isAuthenticated) {
          return observer.next(false);
        }

        const { loading, error } = this.store.selectSnapshot(AppState.getNodeStatus);
        const isLogout =
          this.brwSvc.isBrowser && this.brwSvc.window && this.brwSvc.window.location.pathname.indexOf('/logout') !== -1;
        const initDone = this.store.selectSnapshot(AppState.getNodeInitStatus);

        if (loading || initDone || isLogout) {
          observer.next(true);
        } else {
          this.store
            .dispatch(new GetMattersStart(undefined))
            .pipe(
              finalize(() => observer.next(true)),
              take(1)
            )
            .subscribe({
              next: this.updateDone.bind(this),
              error: this.updateWithError.bind(this)
            });
        }
      });
    });
  }

  updateDone = (data: any) => {
    data && data.app && data.app.isAuthenticated && this.store.dispatch(new SetNodesInit(true));
  };

  updateWithError = (err: any) => {
    console.log('error to init nodes');
  };
}
