import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivateChild } from '@angular/router';
import { Store } from '@ngxs/store';
import { finalize, take } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';

import { GetCollaborationStart } from '@app/core/store/actions';

@Injectable()
export class CollaborationGuard implements CanActivateChild {
  constructor(private store: Store) {}

  canActivateChild(activatedRoute: ActivatedRouteSnapshot, routeState: RouterStateSnapshot): Observable<boolean> {
    const { matterId } = activatedRoute.params;

    return Observable.create((observer: Subject<boolean>) => {
      const isLogout = routeState && routeState.url.indexOf('logout') !== -1;

      if (!matterId || isLogout) {
        observer.next(true);
      } else {
        this.store
          .dispatch(new GetCollaborationStart({ matterId, skipPathUpdate: false }))
          .pipe(
            finalize(() => observer.next(true)),
            take(1)
          )
          .subscribe({
            next: this.updateDone.bind(this),
            error: this.updateWithError.bind(this)
          });
      }
    });
  }

  updateDone = (data: any) => {};

  updateWithError = (err: any) => {
    console.log('error to init collaboration');
  };
}
