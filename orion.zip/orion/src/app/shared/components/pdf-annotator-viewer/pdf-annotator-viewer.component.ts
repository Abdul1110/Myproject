import {
  Component,
  OnInit,
  AfterViewInit,
  Input,
  OnDestroy,
  ChangeDetectionStrategy,
  HostBinding,
  HostListener,
  Output,
  EventEmitter,
  ElementRef
} from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'sc-pdf-annotator-viewer',
  templateUrl: './pdf-annotator-viewer.component.html',
  styles: [
    `
      .annotator-viewer-wrapper {
        position: absolute;
      }
      .new-annotator-viewer {
        position: absolute;
        min-width: 22rem;
        bottom: 20px;
        box-shadow: 0 0.75rem 1.5rem -0.25rem rgba(109, 114, 120, 0.16);
        border-radius: 0.5rem;
        padding: 1rem !important;
        border: 1px solid #d2d5d9 !important;
        background-color: #ffffff !important;
      }
    `
  ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PdfAnnotatorViewerComponent implements OnInit, OnDestroy, AfterViewInit {
  @HostBinding('style.position') pos = 'absolute';
  @HostBinding('style.left') left = '0px';
  @HostBinding('style.top') top = '0px';

  @Input()
  set position(value: { top: number; left: number }) {
    this.left = `${value.left}px`;
    this.top = `${value.top}px`;
  }

  @Input() annotations: any[]; // currently annotations array, because maybe multiple annotaions could exist on a single quote in future.
  @Input() currentUserId: string;

  @Output() mouseOver = new EventEmitter();
  @Output() editAnnotation = new EventEmitter<string>();
  @Output() deleteAnnotation = new EventEmitter<string>();

  private destroy$ = new Subject<boolean>();
  private currentTimeout;

  constructor(private elementRef: ElementRef) {}

  ngOnInit() {}

  ngOnDestroy(): void {
    if (!!this.currentTimeout) {
      clearTimeout(this.currentTimeout);
    }
    this.destroy$.next(true);
  }

  ngAfterViewInit() {}

  edit(annotation) {
    this.editAnnotation.emit(annotation);
  }

  delete(annotationId: string) {
    this.deleteAnnotation.emit(annotationId);
  }

  @HostListener('document:mouseover', ['$event.target'])
  mousedLeave(targetElement: HTMLElement): void {
    if (!targetElement) {
      return;
    }

    const mousedInside =
      this.elementRef.nativeElement.contains(targetElement) ||
      targetElement === this.elementRef.nativeElement ||
      targetElement.className === 'annotator-hl';

    if (mousedInside && !!this.currentTimeout) {
      clearTimeout(this.currentTimeout);
      this.currentTimeout = null;
    }

    if (!mousedInside && !this.currentTimeout) {
      // Check after one second if the user did not move the mouse onto the annotation
      this.currentTimeout = setTimeout(() => {
        this.mouseOver.emit();
      }, 750);
    }
  }

  decodeURI(val: string): string {
    return decodeURIComponent(val);
  }

  allow(permission: string[]): boolean {
    return !permission || permission.length == 0 || permission.includes(this.currentUserId);
  }

  getUserName(annotation: any) {
    if (!annotation || !annotation.user) {
      return '';
    }

    return this.decodeURI(annotation.user.userName);
  }
}
