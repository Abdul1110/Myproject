import {
  Component,
  Input,
  OnDestroy,
  ViewChild,
  Output,
  EventEmitter,
  Renderer2,
  ComponentFactoryResolver,
  ViewContainerRef
} from '@angular/core';
import { isEmpty } from 'lodash';
import { Subject, fromEvent } from 'rxjs';
import { UUID } from 'angular2-uuid';
import { takeUntil, tap } from 'rxjs/operators';
import { PdfViewerComponent as pd2 } from 'ng2-pdf-viewer';

import { AnnotatorModel } from '@app/shared/models';
import { PdfAnnotatorComponent } from '../pdf-annotator/pdf-annotator.component';
import { DialogService } from '../../services/dialog/dialog.service';
import { PdfAnnotatorViewerComponent } from '../pdf-annotator-viewer/pdf-annotator-viewer.component';
import { environment } from '@env/environment';
import { AnnotatorService } from '@app/shared/services/annotator/annotator.service';
import { BrowserService } from '@leap/lyra-design';

@Component({
  selector: 'sc-pdf-viewer',
  templateUrl: './pdf-viewer.component.html'
})
export class PdfViewerComponent implements OnDestroy {
  server_error: any;
  annotationHighlights: { annotations: AnnotatorModel.PageHighlights[]; callback: (event: MouseEvent) => void };

  private _pdfUrl: string;
  private _noPreviewMessage: string;
  private _annotationSeq: AnnotatorModel.AnnotationSeq[] = [];
  private previousScrollPosition = 0;
  private activeSelection: any;
  private annotatingByData: AnnotatorModel.AnnotatingBy;
  private pagesLoaded: number[] = [];
  private loadedAnnotations: AnnotatorModel.DocumentAnnotation[];
  private annotationViewerInstance;

  get hasUrlToPreview(): boolean {
    return !isEmpty(this.previewUrl);
  }

  get previewUrl(): string {
    return this.pdfUrl;
  }

  get enablePreviousPage(): boolean {
    return this.page > 1;
  }

  get enableNextPage(): boolean {
    return this.page < this.totalPages;
  }

  commentId: string;
  hasError: boolean;
  originalSize = true;
  zoom = 1;
  fitToPage = true;
  autoresize = false;
  page = 1;
  totalPages = 1;
  isLoaded = false;
  destroy$ = new Subject<boolean>();
  tag: string;
  showProgress = true;
  objUrl: any;
  editingPageNumber = false;
  data: any;
  isViewerControlShown = true;
  thresholdViewControlVisibility = 600;
  scrollDirectionDown = false;
  lastScrollTopPosition = 0;

  @ViewChild(pd2, { static: false }) private ng2PdfViewerComponent: pd2;

  // annotation related
  @Input('switch-to-page')
  set switchToPage(info: { pageId: number; seqId: string }) {
    if (info && this.ng2PdfViewerComponent) {
      const element = Array.from(this.ng2PdfViewerComponent.pdfViewer._pages).find(x => info.pageId === x['id']) as any;
      element.div.scrollIntoView();

      this.page = info.pageId;

      const ele = this.browserSvc.window.document.getElementById(info.seqId);
      if (ele) {
        ele.scrollIntoView();
      }
    }
  }

  @Input('annotating-by')
  set annotatingBy(value: AnnotatorModel.AnnotatingBy) {
    if (!!value) {
      this.annotatingByData = value;
    }
  }

  @Input('annotations')
  set annotations(value: AnnotatorModel.DocumentAnnotation[]) {
    this.loadedAnnotations = value;
    this.loadHighlightedAnnotations();
  }

  @Input('annotation-deleted')
  set annotationDeleted(lastDeleted: string) {
    if (lastDeleted) {
      if (!!this.annotatorEnabled) {
        // this.redrawAllAnnotators(); // Remove
      }
    }
  }

  @Input('annotation-seqs')
  set annotationSeqs(sq: AnnotatorModel.AnnotationSeq[]) {
    this._annotationSeq = sq;
  }

  @Input('annotator-reload')
  set reloadAnnotator(status: AnnotatorModel.PageAnnotatorReloadStatus) {} // Remove

  // pdf viewer related
  @Input('set-no-preview-message')
  set noPreviewMessage(data: string) {
    this._noPreviewMessage = data;
  }
  get noPreviewMessage() {
    return this._noPreviewMessage || 'No Preview Available!';
  }

  @Input('pdf-url')
  set pdfUrl(value: string) {
    this.hasError = false;
    this.isLoaded = false;
    this.zoom = 1;
    this.page = 1;
    this.totalPages = 1;
    this.tag = UUID.UUID();
    this.showProgress = true;
    this._pdfUrl = value;
  }
  get pdfUrl(): string {
    return this._pdfUrl;
  }

  @Input('is-printing') isPrintingDocument: boolean;
  @Input('disable-print') disablePrint: boolean;
  @Input('is-comment-still-update') isCommentUpdateInProgress: boolean;
  @Input('annotator-enabled') annotatorEnabled: boolean;
  @Input('active-annotation-status') activeAnnotationStatus: AnnotatorModel.AnnotationBeforeCreated;
  @Input('is-previewUrl-loading') isPreviewUrlLoading: boolean;
  @Input('token') token: string;

  @Output('reload-annotator-done') reloadAnnotatorDone = new EventEmitter<AnnotatorModel.AnnotationResponse>();
  @Output('set-active-annotation') activeCommentStatus = new EventEmitter<AnnotatorModel.AnnotationBeforeCreated>();
  @Output('new-comment') newComment = new EventEmitter<AnnotatorModel.AnnotationData>();
  @Output('delete-comment') deleteComment = new EventEmitter<AnnotatorModel.DeleteAnnotation>();
  @Output('active-comment') activeComment = new EventEmitter<string>();
  @Output('comment-reload') commentReload = new EventEmitter<AnnotatorModel.AnnotatedPage>(); //tdo: removed?
  @Output('scroll-direction') scrollDirection = new EventEmitter<string>();
  @Output('print-url') printUrl = new EventEmitter<string>();

  constructor(
    private renderer: Renderer2,
    private viewContainerRef: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver,
    private dialogSvc: DialogService,
    private AnnotatorSvc: AnnotatorService,
    private browserSvc: BrowserService
  ) {
    const { document: no_results } = environment.locale.no_results.documents;
    this.server_error = no_results.server_error;
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }

  onError(err): void {
    const safeToExclude = ['Worker was destroyed'];
    if (err && err.message && safeToExclude.includes(err.message)) {
      return;
    }
    this.hasError = true;
  }

  onZoomIn(): void {
    this.zoom += 0.25;
  }

  onZoomOut(): void {
    this.zoom -= 0.25;
    if (this.zoom <= 0) {
      this.zoom = 0.25;
    }
  }

  onPrint(): void {
    this.printUrl.emit(this.pdfUrl);
  }

  onOriginalSize(): void {
    this.autoresize = false;
    this.originalSize = !this.originalSize;
  }

  onNextPage(): void {
    if (this.enableNextPage) {
      this.page += 1;
      this.scrollToPage();
    }
  }

  onPreviousPage(): void {
    if (this.enablePreviousPage) {
      this.page -= 1;
      this.scrollToPage();
    }
  }

  onLoadComplete(pdfData: any): void {
    this.totalPages = pdfData.numPages;
    this.isLoaded = true;

    this.scrollAndUpdatePageEvent();
    this.emitScrollDirection();
  }

  textLayerRendered(event) {
    this.pagesLoaded.push(event.pageNumber);
    this.loadHighlightedAnnotations();
  }

  handleUserPageValue(): void {
    if (this.page > this.totalPages) {
      this.page = this.totalPages;
    } else if (this.page < 1) {
      this.page = 1;
    }

    this.scrollToPage();
  }

  renderZoomPercent(): string {
    return `${this.zoom * 100.0}%`;
  }

  setViewerControlState(): void {
    this.isViewerControlShown = this.isViewerControlShown ? false : true;
  }

  selectedRange = undefined;

  handleSelectedText(event: AnnotatorModel.HighlightModel) {
    // Need to provide a page number for each annotation
    if (!!event.highlightedText) {
      // Not sure if this 'before created' should go into the store
      const range = <AnnotatorModel.AnnotatedRange>{
        start: event.range.start,
        end: event.range.end,
        startOffset: event.range.startOffset,
        endOffset: event.range.endOffset
      };

      this.activeSelection = {
        quote: event.highlightedText,
        ranges: [range]
      };

      this.activeCommentStatus.emit(this.activeSelection);
      this.createPdfAnnotatorComponent(event.mouseUpEvent.target, event.mouseUpEvent.pageY, event.mouseUpEvent.pageX);

      // used by temp annotating range to highlight the text
      this.selectedRange = { range, seqNumber: this.loadedAnnotations.length, quote: event.highlightedText };
    }
  }

  private checkScrollPosition(): void {
    const scrollTop = this.ng2PdfViewerComponent.pdfViewer.container.scrollTop;

    if (
      scrollTop > this.thresholdViewControlVisibility &&
      !this.scrollDirectionDown &&
      scrollTop > this.lastScrollTopPosition
    ) {
      this.setViewerControlState();
      this.scrollDirectionDown = true;
    }

    if (scrollTop < this.lastScrollTopPosition && this.scrollDirectionDown) {
      this.setViewerControlState();
      this.scrollDirectionDown = false;
    }

    this.lastScrollTopPosition = scrollTop;
  }

  private scrollToPage(): void {
    const element = Array.from(this.ng2PdfViewerComponent.pdfViewer._pages).find(x => this.page === x['id']) as any;
    element.div.scrollIntoView();
  }

  private scrollAndUpdatePageEvent(): void {
    fromEvent(this.ng2PdfViewerComponent.pdfViewer.container, 'scroll')
      .pipe(
        takeUntil(this.destroy$),
        tap(e => {
          this.page = this.ng2PdfViewerComponent.pdfViewer.currentPageNumber;
          this.checkScrollPosition();
        })
      )
      .subscribe();
  }

  private emitScrollDirection(): void {
    fromEvent(this.ng2PdfViewerComponent.pdfViewer.container, 'scroll')
      .pipe(
        takeUntil(this.destroy$),
        tap(e => {
          const currentScrollPosition = this.ng2PdfViewerComponent.pdfViewer.container.scrollTop;
          const scrollBuffer = 35;

          if (currentScrollPosition > this.previousScrollPosition + scrollBuffer) {
            this.scrollDirection.emit('down');
          }

          if (currentScrollPosition <= this.previousScrollPosition) {
            this.scrollDirection.emit('up');
          } else if (currentScrollPosition === 0) {
            this.scrollDirection.emit('up');
          }

          this.previousScrollPosition = currentScrollPosition;
        })
      )
      .subscribe();
  }

  // Move to service if possible
  private createPdfAnnotatorComponent(target: Element, offsetY: number = 20, offsetX: number = 20, isEdit = false) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(PdfAnnotatorComponent);
    const componentInstance = this.viewContainerRef.createComponent(componentFactory);
    const pageEl = target.closest('.page');
    const pageRect = pageEl.getBoundingClientRect();
    const positions = {
      top: isEdit ? this.getYValue(offsetY) : +target['offsetTop'] || offsetY - pageRect.top,
      left: this.getXValue(isEdit ? offsetX : offsetX - pageRect.left)
    };
    const annotationIndex =
      this._annotationSeq && this._annotationSeq.findIndex(s => s.annotationId == this.activeSelection.id);

    componentInstance.instance.pageNumber = `${(pageEl && pageEl['dataset'] && pageEl['dataset']['pageNumber']) || 1}`;
    componentInstance.instance.annotationId = this.commentId || this.activeSelection.id;
    componentInstance.instance.initialText = this.activeSelection.text;
    componentInstance.instance.position = positions;
    componentInstance.instance.isEdit = isEdit;
    componentInstance.instance.annotationSeq =
      annotationIndex >= 0 ? annotationIndex + 1 : this._annotationSeq && this._annotationSeq.length + 1;

    this.renderer.appendChild(target.closest('.page'), componentInstance.location.nativeElement);

    componentInstance.instance.postAnnotation.subscribe(comment => this.postComment(comment));
    componentInstance.instance.cancelAnnotation.subscribe(() => componentInstance.destroy());
    componentInstance.instance.clickedOutside.subscribe(() => componentInstance.destroy());
  }

  private loadHighlightedAnnotations() {
    if (!this.loadedAnnotations || this.pagesLoaded.length === 0) {
      return;
    }
    this.annotationHighlights = {
      annotations: this.loadedAnnotations
        .filter(la => this.pagesLoaded.some(p => p === la.pageId))
        .map(la => ({
          id: la.id,
          page: la.pageId,
          highlightedText: la.quote,
          range: this.AnnotatorSvc.convertRangesToFullXPath(la.ranges[0], la.pageId)
        })),
      callback: (event: MouseEvent) => {
        const annotationId = (<Element>event.target).getAttribute('annotation-id');
        this.createAnnotatorViewerComponent(annotationId, <Element>event.target, event.pageY, event.pageX);
      }
    };
  }

  private createAnnotatorViewerComponent(
    annotationId: string,
    target: Element,
    offsetY: number = 20,
    offsetX: number = 20
  ) {
    if (!!this.annotationViewerInstance) {
      this.annotationViewerInstance.destroy();
    }
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(PdfAnnotatorViewerComponent);
    this.annotationViewerInstance = this.viewContainerRef.createComponent(componentFactory);
    const pageEl = target.closest('.page');
    const pageRect = pageEl.getBoundingClientRect();
    const positions = { top: this.getYValue(offsetY - pageRect.top), left: this.getXValue(offsetX - pageRect.left) };

    this.annotationViewerInstance.instance.annotations = [this.loadedAnnotations.find(a => a.id === annotationId)];
    this.annotationViewerInstance.instance.position = positions;
    this.annotationViewerInstance.instance.currentUserId = this.annotatingByData && this.annotatingByData.userId;
    this.renderer.appendChild(pageEl, this.annotationViewerInstance.location.nativeElement);

    this.annotationViewerInstance.instance.editAnnotation.subscribe(id => this.updateAnnotation(id));
    this.annotationViewerInstance.instance.deleteAnnotation.subscribe(id => this.deleteAnnotation(id));
    this.annotationViewerInstance.instance.mouseOver.subscribe(() => this.annotationViewerInstance.destroy());
  }

  private getXValue(xValue: number): number {
    return xValue < 0 ? -xValue : xValue;
  }

  private getYValue(yValue: number): number {
    return yValue < 180 ? 180 : yValue;
  }

  private updateAnnotation(event: AnnotatorModel.AnnotationData) {
    this.activeSelection = <AnnotatorModel.AnnotationBeforeCreated>{
      quote: event.quote,
      ranges: event.ranges,
      text: event.text,
      id: event.id,
      aboutUpdate: <AnnotatorModel.AnnotationDataForUpdated>{
        creationDate: event.creationDate,
        events: event.events,
        isDuringUpdate: true,
        oldText: event.text,
        updateDate: event.updateDate,
        userInfo: event.userInfo,
        versionId: event.versionId
      }
    };

    this.activeCommentStatus.emit(this.activeSelection);

    const target = this.annotationViewerInstance.instance;
    target &&
      this.createPdfAnnotatorComponent(
        target.elementRef.nativeElement,
        this.getYValue(target.elementRef.nativeElement.offsetTop),
        this.getXValue(target.elementRef.nativeElement.offsetLeft),
        true
      );

    this.annotationViewerInstance.destroy();
  }

  private deleteAnnotation(annotationId: string) {
    const annotation = this.loadedAnnotations.find(a => a.id === annotationId);

    if (!!annotation && !!annotation.id && !!annotation.fileId) {
      this.dialogSvc.confirm({
        title: 'Deleting the comment',
        message: 'It will also delete all replies to the comment. Are you sure?',
        actionText: 'Delete',
        closeText: 'Cancel',
        showCancel: true,
        onClose: (confirmed: boolean) => {
          if (confirmed) {
            this.deleteComment.emit(<AnnotatorModel.DeleteAnnotation>{
              annotationId: annotation.id,
              documentId: annotation.fileId
            });
          }
        }
      });
    }
  }

  private postComment(annotatorData: any) {
    let annotation = <AnnotatorModel.AnnotationData>{
      aboutPage: { page: 1 },
      ...annotatorData,
      ...this.activeSelection,
      annotationId: this.activeSelection.id
    };

    this.newComment.emit(annotation);
  }
}
