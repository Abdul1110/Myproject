import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'sc-btn-old',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements OnInit {
  @Input() btnType: string;
  @Input() btnSize: string;
  @Input() disabled: boolean;
  @Output() btnClicked = new EventEmitter<boolean>();
  constructor() {}

  ngOnInit() {}

  onBtnClick(event: any) {
    this.btnClicked.emit(event);
  }

  buildBtnSize(): any {
    if (this.btnSize) {
      return 'btn-' + this.btnSize + ' ';
    } else {
      return '';
    }
  }

  get btnClass(): string {
    if (this.btnType === ('default' || 'outline-default')) {
      return this.buildBtnSize() + 'x-btn-' + this.btnType;
    } else {
      return this.buildBtnSize() + 'btn-' + this.btnType;
    }
  }
}
