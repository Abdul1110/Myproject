import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  AfterViewInit,
  Input,
  Output,
  EventEmitter,
  HostListener,
  HostBinding
} from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { UUID } from 'angular2-uuid';

import { AnnotatorModel } from '@app/shared/models';

@Component({
  selector: 'sc-pdf-annotator',
  templateUrl: './pdf-annotator.component.html',
  styles: [
    `
      .new-annotator-widget {
        position: relative;
        min-width: 22rem;
        bottom: 20px;
        box-shadow: 0 0.75rem 1.5rem -0.25rem rgba(109, 114, 120, 0.16);
        border-radius: 0.5rem;
        padding: 1rem !important;
        border: 1px solid #d2d5d9 !important;
        background-color: #ffffff !important;
      }
    `
  ]
})
export class PdfAnnotatorComponent implements OnInit, OnDestroy, AfterViewInit {
  @HostBinding('style.position') pos = 'absolute';
  @HostBinding('style.zIndex') zIndex = '10';
  @HostBinding('style.left') left = '0px';
  @HostBinding('style.top') top = '0px';

  @ViewChild('annotatorTextArea', { static: false }) set annotatorTextArea(textArea: ElementRef) {
    if (!!textArea) {
      textArea.nativeElement.focus();
    }
  }

  @Input()
  set position(value: { top: number; left: number }) {
    this.left = `${value.left}px`;
    this.top = `${value.top}px`;
  }

  @Input('annotation-seq') annotationSeq: number;
  @Input('annotation-id') annotationId: string;

  @Input('initial-text')
  set initialText(text: string) {
    this.initialValue = text ? text : '';
    this.annotationForm.get('comment').setValue(this.initialText);
  }
  get initialText() {
    return this.initialValue;
  }

  @Input('is-edit')
  set isEdit(edit: boolean) {
    edit && this.displayAnnotator();
    this._isEdit = edit;
  }
  get isEdit() {
    return this._isEdit;
  }

  @Input('page-number') pageNumber: string;

  @Output('data') data = new EventEmitter<AnnotatorModel.AnnotationData>();

  @Output('reload-please') reload = new EventEmitter<string>();

  @Output() postAnnotation = new EventEmitter();

  @Output() cancelAnnotation = new EventEmitter();

  @Output() clickedOutside = new EventEmitter();

  annotationForm: FormGroup;
  showAnnotator = false;

  private _isEdit = false;
  private destroy$ = new Subject<boolean>();
  private initialValue: string;

  constructor(fb: FormBuilder, private elementRef: ElementRef) {
    this.annotationForm = fb.group({
      comment: ['', Validators.required],
      anyoneView: [true]
    });
  }

  ngOnInit(): void {}

  ngAfterViewInit(): void {}

  ngOnDestroy(): void {
    this.destroy$.next(true);
  }

  post() {
    if (!this.annotationForm || !this.annotationForm.valid) {
      return;
    }
    const comment = this.annotationForm.get('comment').value.trim();

    const isNew = !this._isEdit;
    const allowAnyoneView = this.annotationForm.get('anyoneView').value;
    this.postAnnotation.emit(<AnnotatorModel.AnnotationData>{
      annotationId: isNew ? UUID.UUID() : this.annotationId,
      comment,
      isNew,
      allowAnyoneView,
      aboutPage: <AnnotatorModel.AnnotatedPage>{
        page: this.pageNumber ? +this.pageNumber : 1
      }
    });

    this.cancelAnnotation.emit();
    this.swapTemporaryHighlightToTextNode();
  }

  cancel() {
    this.cancelAnnotation.emit();
    this.swapTemporaryHighlightToTextNode();
  }

  displayAnnotator() {
    this.showAnnotator = true;
  }

  private swapTemporaryHighlightToTextNode(): void {
    // clean any previous temp.
    const elements = document.querySelectorAll('.annotator-hl-temp');
    if (elements && elements.length > 0) {
      for (let i = 0; i < elements.length; i++) {
        elements[i].replaceWith(elements[i]['innerText']);
      }
    }
  }

  @HostListener('document:mousedown', ['$event', '$event.target'])
  documentClick(event: Event, targetElement: HTMLElement): void {
    if (!targetElement) {
      return;
    }

    const clickedInside = this.elementRef.nativeElement.contains(targetElement);
    if (!clickedInside) {
      this.clickedOutside.emit();
      this.swapTemporaryHighlightToTextNode();
    }
  }

  @HostListener('mouseup', ['$event'])
  componentClicked(event: Event) {
    event.preventDefault();
    event.stopPropagation();
  }
}
