import { Component, Input, OnInit } from '@angular/core';
import { isEmpty } from 'lodash';

@Component({
  selector: 'sc-image-viewer',
  templateUrl: './image-viewer.component.html',
  styleUrls: ['./image-viewer.component.scss']
})
export class ImageViewerComponent implements OnInit {
  @Input()
  set noPreviewMessage(data: string) {
    this._noPreviewMessage = data;
  }
  get noPreviewMessage() {
    return this._noPreviewMessage || 'No Preview Available!';
  }
  @Input()
  set imgUrl(value: string) {
    this.hasError = false;
    this._imgUrl = value;
  }
  get imgUrl(): string {
    return this._imgUrl;
  }

  @Input() token: string;

  get hasUrlToPreview(): boolean {
    return !isEmpty(this.previewUrl);
  }

  get previewUrl(): string {
    // return `${this.imgUrl}?access_token=${this.token}`;
    return this.imgUrl;
  }

  hasError: boolean;
  private _imgUrl: string;
  private _noPreviewMessage: string;

  constructor() {}

  ngOnInit() {}

  onError(err): void {
    this.hasError = true;
  }
}
