import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';
import { Subject } from 'rxjs';

import { IDialogOptions } from '@app/shared/models';
import { LyraDesignFormModel } from '@leap/lyra-design';
import { CoreModel } from '@app/core/models';

@Component({
  selector: 'sc-folder-selection',
  templateUrl: './folder-selection.component.html',
  styleUrls: ['./folder-selection.component.scss']
})
export class FolderSelectionComponent implements OnInit {
  actionText: string;
  closeText: string;
  message: string;
  showCancel = false;
  title: string;
  folderLevel: string;
  folderOptions: LyraDesignFormModel.SelectOption[] = [];
  defaultFolder: LyraDesignFormModel.SelectOption;
  options: IDialogOptions; // styling options
  onClose: Subject<string>;
  hasValidation = false;
  private selectedFolderId = '';
  selectedFolder: any;

  get proxyActionText(): string {
    return this.actionText || 'Upload';
  }

  get proxyCloseText(): string {
    return this.closeText || 'Cancel';
  }

  get headerClass(): string {
    return `x-text-primary`;
  }

  get btnType(): string {
    return `primary`;
  }
  constructor(private _bsModalRef: BsModalRef) {}

  ngOnInit() {
    setTimeout(() => {
      this.setupContent();
    }, 0);
  }

  getOtherUsers(users: CoreModel.OtherUser[]): CoreModel.User[] {
    if (users && users.length > 0) {
      return users.map<CoreModel.User>((u: CoreModel.OtherUser) => {
        const fullname = `${u.firstName} ${u.lastName}`;
        return {
          initial: CoreModel.Helper.getUserInitial(fullname),
          name: fullname
        };
      });
    }

    return [];
  }

  trackElement(index: number, element: any) {
    return element ? element.id : index;
  }

  private setupContent(): void {
    const content = this._bsModalRef.content;
    if (!content) {
      return;
    }

    this.actionText = content.actionText || this.actionText;
    this.closeText = content.closeText || this.closeText;
    this.message = content.message || this.message;
    this.showCancel = content.options.showCancel || false;
    this.title = content.title || this.title;
    this.options = content.options || {};
    this.onClose = content.onClose || new Subject<string>();
    this.folderOptions = content.folderOptions || [];

    const hasFolderOptions = this.folderOptions.length > 0;
    const hasDefaultIdIdx =
      content.defaultFolderId && hasFolderOptions && this.folderOptions.findIndex(x => x.id == content.defaultFolderId);

    this.defaultFolder =
      hasDefaultIdIdx && hasDefaultIdIdx > -1
        ? {
            ...this.folderOptions[hasDefaultIdIdx],
            value: { ...this.folderOptions[hasDefaultIdIdx].value, default: true }
          }
        : hasFolderOptions
        ? { ...this.folderOptions[0], value: { ...this.folderOptions[0].value, default: true } }
        : undefined;

    this.selectedFolderId = this.defaultFolder && this.defaultFolder.id;
    this.selectedFolder = this.defaultFolder;
  }

  confirm() {
    // we set dialog result as true on click on confirm button,
    // then we can get dialog result from caller code
    this.close(true);
  }

  close(confirmed: boolean = false): void {
    this.onClose.next(confirmed ? this.selectedFolderId : '');
    this._bsModalRef.hide();
  }

  onFolderSelected(folder: LyraDesignFormModel.SelectOption) {
    this.defaultFolder = folder ? folder.value : '';
    this.selectedFolder = this.defaultFolder;
    this.selectedFolderId = folder ? folder.id : '';
  }
}
