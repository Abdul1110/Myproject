import { animate, trigger, transition, style, query, state } from '@angular/animations';

export const xAnimationAsideCollapse = trigger('xAnimationAsideCollapse', [
  state(
    'inactive',
    style({
      transform: 'translateX(25rem)',
      maxWidth: '0'
    })
  ),
  state(
    'active',
    style({
      transform: 'translateX(0)',
      maxWidth: '*'
    })
  ),
  transition('active => inactive', [query(':self', [animate('250ms ease-in')])]),
  transition('inactive => active', [query(':self', [animate('250ms ease-in')])])
]);
