import { Component, HostBinding, OnInit } from '@angular/core';
// import { xAnimationOverlay } from '@app/shared/animations/animations';

@Component({
  selector: 'sc-proxy-route',
  templateUrl: './proxy-route.component.html',
  styleUrls: ['./proxy-route.component.css']
  // animations: [xAnimationOverlay]
})
export class ProxyRouteComponent implements OnInit {
  constructor() {}
  // @HostBinding('@xAnimationOverlay')
  // @HostBinding('class.x-overlay')
  ngOnInit() {}
}
