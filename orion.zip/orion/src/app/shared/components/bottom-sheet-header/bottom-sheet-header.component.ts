import { Component, OnInit, Input, Output, HostBinding, EventEmitter } from '@angular/core';

@Component({
  selector: 'sc-bottom-sheet-header',
  templateUrl: './bottom-sheet-header.component.html'
})
export class BottomSheetHeaderComponent implements OnInit {
  @Input('title') title: string;

  @Input('subtitle') subtitle: string;

  @Output('close') close = new EventEmitter();

  constructor() {}

  @HostBinding('class.x-bottom-sheet-header')
  ngOnInit() {}

  closeBottomSheet() {
    this.close.emit(null);
  }
}
