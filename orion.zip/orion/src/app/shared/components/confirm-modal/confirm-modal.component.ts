import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';
import { Subject } from 'rxjs';
import { isEmpty } from 'lodash';
import { IDialogOptions } from '@app/shared/models';

@Component({
  selector: 'sc-confirm-modal',
  templateUrl: './confirm-modal.component.html'
})
export class ConfirmModalComponent implements OnInit {
  actionText: string;
  closeText: string;
  message: string;
  showCancel = false;
  title: string;
  type: 'error' | 'warning' | 'info' | 'confirm' = 'error';

  options: IDialogOptions; // styling options
  onClose: Subject<boolean>;

  get proxyActionText(): string {
    return this.actionText || 'OK';
  }

  get proxyCloseText(): string {
    return this.closeText || 'Cancel';
  }

  get headerClass(): string {
    switch (this.type) {
      case 'error': {
        return `text-danger`;
      }
      case 'warning': {
        return `text-warning`;
      }
      case 'info':
      case 'confirm': {
        return `x-text-primary`;
      }
    }
  }

  get iconClass(): string {
    switch (this.type) {
      case 'error': {
        return `text-danger`;
      }
      case 'warning': {
        return `text-warning`;
      }
      case 'info':
      case 'confirm': {
        return `x-text-primary`;
      }
    }
  }

  get iconName(): string {
    switch (this.type) {
      case 'error': {
        return `error-circle`;
      }
      case 'warning': {
        return `warning-triangle`;
      }
      case 'info':
      case 'confirm': {
        return `info-circle`;
      }
    }
  }

  get btnType(): string {
    switch (this.type) {
      case 'error': {
        return `danger`;
      }
      case 'warning': {
        return `warning`;
      }
      case 'info':
      case 'confirm': {
        return `primary`;
      }
    }
  }
  constructor(private _bsModalRef: BsModalRef) {}

  ngOnInit() {
    setTimeout(() => {
      this.setupContent();
    }, 0);
  }

  private setupContent(): void {
    const content = this._bsModalRef.content;
    if (!content) {
      return;
    }

    this.actionText = content.actionText || this.actionText;
    this.closeText = content.closeText || this.closeText;
    this.message = content.message || this.message;
    this.showCancel = content.options.showCancel || false;
    this.title = content.title || this.title;
    this.type = content.type || this.type;
    this.options = content.options || {};
    this.onClose = content.onClose || new Subject<boolean>();
  }

  confirm() {
    // we set dialog result as true on click on confirm button,
    // then we can get dialog result from caller code
    this.close(true);
  }

  close(confirmed: boolean = false): void {
    this.onClose.next(confirmed);
    this._bsModalRef.hide();
  }
}
