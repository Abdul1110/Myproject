import { Component } from '@angular/core';
import { BrowserTitleService } from '@app/shared/services';
import { LogService } from '@app/core/services';

@Component({
  selector: 'sc-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.scss']
})
export class NotFoundComponent {
  constructor(private browserTitle: BrowserTitleService, private logger: LogService) {
    this.logger.debug('NotFoundComponent - ctor');

    this.browserTitle.pageTitle = 'Page not found';
  }
}
