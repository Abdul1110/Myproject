import { Component, OnInit, Input, HostBinding } from '@angular/core';

@Component({
  selector: 'sc-pre-load',
  templateUrl: './pre-load.component.html'
})
export class PreLoadComponent implements OnInit {
  @HostBinding('class')
  classes: string;
  @Input('icon-class')
  iconClass: string;
  @Input('is-card')
  isCard: boolean;
  @Input()
  background: string;
  @Input('position-class')
  positionClass: string;
  @Input('spacing-top')
  spacingTop: string;
  @Input('spacing-bottom')
  spacingBottom: string;
  @Input()
  icon: string;
  @Input()
  size: string;
  constructor() {}

  ngOnInit() {
    this.classes = !!this.isCard ? 'x-loader-card ' : 'x-loader ';
    if (this.background) {
      this.classes += this.background + ' ';
    }
    if (this.positionClass) {
      this.classes += this.positionClass + ' ';
    }
    if (this.size) {
      this.iconClass += ' ' + this.size;
    }
    if (this.spacingTop) {
      this.classes += 'mt-' + this.spacingTop + ' ';
    }
    if (this.spacingBottom) {
      this.classes += 'mb-' + this.spacingBottom + ' ';
    }
  }
}
