import { Component, ViewChild, Input, HostBinding, ElementRef, AfterViewInit, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';
import { environment } from '@env/environment';
import { DeviceDetectorService } from 'ngx-device-detector';
import { UrlParams, buildUrlWithParams } from '@app/shared/models/url.model';

@HostBinding('class.x-overlay-panel x-panel-center border-0-sm x-panel-lg x-max-height-560')
@Component({
  selector: 'sc-feedback',
  templateUrl: './feedback.component.html'
})
export class FeedbackComponent implements OnInit, AfterViewInit {
  @ViewChild('addinFrame', { static: true }) addinFrame: ElementRef;

  isLoading = true;

  private firm: string;
  private email: string;
  private userName: string;
  private region: string;
  private platform: string;

  constructor(private _bsModalRef: BsModalRef, private deviceService: DeviceDetectorService) {}

  ngOnInit(): void {
    // firm, email, userName are provided via BsModalRef initialState
    this.region = environment.appSettings.region;
    this.platform = `${this.deviceService.browser}-${this.deviceService.browser_version}`;
  }

  ngAfterViewInit(): void {
    this.setupIframe();
  }

  private setupIframe() {
    const urlParams: UrlParams[] = [
      { key: 'firm', value: this.firm },
      { key: 'email', value: this.email },
      { key: 'region', value: this.region },
      { key: 'username', value: this.userName },
      { key: 'platform', value: this.platform }
    ];
    const baseUrl = environment.config.support.feedbackUrl;
    const formCode = environment.config.support.feedbackCode;
    const url = buildUrlWithParams(`${baseUrl}/${formCode}`, urlParams);
    const encodedUrl = encodeURI(url);

    const iFrame = document.createElement('iframe');
    iFrame.setAttribute('style', 'position: absolute; height:100%; width: 100%; border: none;');
    iFrame.setAttribute('src', encodedUrl);
    this.addinFrame.nativeElement.appendChild(iFrame);
    iFrame.onload = () => {
      this.isLoading = false;
    };
  }

  close() {
    this._bsModalRef.hide();
  }
}
