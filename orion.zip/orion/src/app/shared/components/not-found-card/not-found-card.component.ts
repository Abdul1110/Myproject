import { Component, Input, HostBinding } from '@angular/core';

@Component({
  selector: 'sc-not-found-card',
  templateUrl: './not-found-card.component.html'
})
export class NotFoundCardComponent {
  @Input() error: string;

  @HostBinding('class.x-card-inline') inline = true;
  @HostBinding('class.mb-2') mb = true;

  constructor() {}
}
