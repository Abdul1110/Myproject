import { Component, EventEmitter, HostListener, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'sc-modal-header',
  templateUrl: './modal-header.component.html',
  styleUrls: ['./modal-header.component.scss']
})
export class ModalHeaderComponent implements OnInit {
  useKeyTab = false;
  @Input() hideCloseBtn = false;
  @Output() modalDismiss = new EventEmitter<boolean>();
  constructor() {}

  ngOnInit() {}

  closeModal(event: any) {
    this.modalDismiss.emit(event);
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.key === 'Tab') {
      this.useKeyTab = true;
    }
  }

  @HostListener('mouseenter')
  onMouseEnter() {
    this.useKeyTab = false;
  }
}
