import { Component, OnInit, HostBinding } from '@angular/core';

@Component({
  selector: 'sc-modal-toolbar',
  templateUrl: './modal-toolbar.component.html',
  styleUrls: ['./modal-toolbar.component.scss']
})
export class ModalToolbarComponent implements OnInit {
  constructor() {}
  @HostBinding('class.modal-toolbar')
  ngOnInit() {}
}
