import { Component, OnDestroy } from '@angular/core';
import { LyraDesignCardModel, LyraAnimation, BrowserService, LyraDesignFormModel } from '@leap/lyra-design';
import { Subject, Observable, merge } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Store, Select, Actions, ofActionSuccessful } from '@ngxs/store';
import { takeUntil, tap, take } from 'rxjs/operators';
import { environment } from '@env/environment';
import { Location } from '@angular/common';

import { SetMatterFirmId, SetFilterFirmId, PopulateFirm } from '@app/core/store/actions';
import { NodeModel, CoreModel } from '@app/core/models';
import { AppState } from '@app/core/store/states';
import {
  AnalyticService,
  CustomEventService,
  MATTERS_SELECT_CLOSED,
  CustomEventModel,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED,
  NavigationService
} from '@app/core/services';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { RecentAction } from '@app/features/+recent/store';
import { SideNavigationModel } from '@app/shared/models';
import { AppActionService } from '@app/core/services/lawconnect/app.action.service';
import { TrustAction } from '@app/features/+trust/store';

const { locale } = environment;

@Component({
  selector: 'sc-matter-select',
  templateUrl: './matter-select.component.html',
  host: {
    '[@xAnimationSlideRightOverlay]': 'true'
  },
  animations: [LyraAnimation.xAnimationSlideRightOverlay]
})
export class MatterSelectComponent implements OnDestroy {
  private destroy$ = new Subject<boolean>();
  private keyDefaultFirm = { id: '0', name: 'All Firms', value: { default: true } } as LyraDesignFormModel.SelectOption;

  matterSelect = false;
  userFirms: NodeModel.Firms = undefined;
  enabledStyle = true;
  formValidation = false;
  onlyOneFirm = false;
  resetSelect = false;
  defaultFirmOption = undefined;
  firmOptions: LyraDesignFormModel.SelectOption[] = [];
  isGenericLC = false;
  groupMatterOptionsByFirm: { [firmId: string]: LyraDesignCardModel.MatterCardInfo[] } = {};
  matterOptions: LyraDesignCardModel.MatterCardInfo[] = [];
  selectedMatterId = '';
  notGroupDisplay = true;
  firmFilterKeys = {};
  currentSelectedFirm: string = 'All Firms';

  @Select(AppState.getSelectedFirm) selectedFirm$: Observable<CoreModel.FirmDetail>;

  @Select(AppState.getNodeLoadingStatus) loading$: Observable<boolean>;

  @Select(AppState.getNodeError) error$: Observable<string>;

  @Select(AppState.getFirmsByUser) userFirms$: Observable<NodeModel.Firms>;

  @Select(AppState.getSelectedFilterFirmId) filterFirmId$: Observable<string>;

  isSmall = false;

  constructor(
    private router: ActivatedRoute,
    private store: Store,
    private browserSvc: BrowserService,
    private analyticsSvc: AnalyticService,
    private actions$: Actions,
    private customEventSvc: CustomEventService,
    private appActionSvc: AppActionService,
    private location: Location,
    private navigationSvc: NavigationService
  ) {
    if (!this.browserSvc.isServer) {
      this.analyticsSvc.eventTrack({ category: AnalyticCategories.MattersSelectOption, action: 'Select matter' });
    }
    this.setupMatterOptions();
    const site = this.store.selectSnapshot(AppState.isWhiteLabel);
    this.selectedMatterId =
      this.router.parent.snapshot.params['matterId'] || this.router.parent.parent.snapshot.params['matterId'];

    if (site && site.whiteLabel) {
      return;
    }

    this.isGenericLC = true;

    this.setupFirms();

    merge(
      this.filterFirmIdSideEffect$(),
      this.getRecentDocumentsSuccessSideEffect$(),
      this.populateFirmSuccessSideEffect$(),
      this.listenToIsSmallSideEffect$()
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe();

    this.customEventSvc.dispatchEvent(NAVIGATION_SIDE_BAR_ACTION_SELECTED, {
      actionId: SideNavigationModel.SideActionId.matters
    });
  }

  private listenToIsSmallSideEffect$(): Observable<any> {
    return this.appActionSvc.isSmallScreen$.pipe(tap(v => (this.isSmall = v)));
  }

  private populateFirmSuccessSideEffect$(): Actions {
    return this.actions$.pipe(
      ofActionSuccessful(PopulateFirm),
      tap(v => {
        this.setupFirms();
        this.setupMatterOptions();
      })
    );
  }

  private getRecentDocumentsSuccessSideEffect$(): Actions {
    return this.actions$.pipe(
      ofActionSuccessful(RecentAction.GetDocumentsSuccess),
      tap(v => {
        const nodes = this.store.selectSnapshot(AppState.getNodes);
        this.store.dispatch(new PopulateFirm(nodes));
      })
    );
  }

  private filterFirmIdSideEffect$(): Observable<string> {
    return this.filterFirmId$.pipe(
      take(1),
      tap(firmId => {
        if (firmId && this.userFirms && this.userFirms.list) {
          this.defaultFirmOption = this.getSelectedFirmOption(firmId);
          this.currentSelectedFirm = this.getFirmName(firmId);
        } else if (!this.defaultFirmOption) {
          this.defaultFirmOption = this.keyDefaultFirm;
        }
      })
    );
  }

  private setupMatterOptions(): void {
    this.matterOptions = [].concat(this.store.selectSnapshot(AppState.getMatterOptions));
    if (!this.onlyOneFirm) {
      let temp = {};
      this.matterOptions.forEach(m => {
        temp[m.firmId] = !temp[m.firmId] ? [].concat(m) : temp[m.firmId].concat(m);
      });

      this.groupMatterOptionsByFirm = Object.assign({}, temp);
      this.firmFilterKeys = Object.keys(temp);
    }
  }

  private setupFirms(): void {
    this.userFirms = this.store.selectSnapshot(AppState.getFirmsByUser);

    if (!this.userFirms || !this.userFirms.list || Object.keys(this.userFirms.list).length == 0) {
      this.onlyOneFirm = true;
      this.firmOptions = [this.keyDefaultFirm];
      return;
    }

    const nodes = Object.values(this.userFirms.list).map(v => v[0]);
    if (!nodes || nodes.length === 0) {
      this.onlyOneFirm = true;
      this.firmOptions = [this.keyDefaultFirm];
      return;
    }

    const allFirms = [this.keyDefaultFirm].concat(
      nodes.map(
        n =>
          <LyraDesignFormModel.SelectOption>{
            id: n.id,
            name: n.name,
            value: n
          }
      )
    );

    if (allFirms.length === 2) {
      this.defaultFirmOption = Object.assign({}, allFirms[1], { value: { ...allFirms[1].value, default: true } });
      this.firmOptions = [this.defaultFirmOption];
      this.onlyOneFirm = true;
      this.resetSelect = true;
      return;
    }

    this.notGroupDisplay = false;
    this.firmOptions = allFirms;
  }

  private getSelectedFirmOption(firmId: string): LyraDesignFormModel.SelectOption {
    if (!firmId) {
      return this.keyDefaultFirm;
    }
    const v = this.userFirms.list[firmId][0];
    return Object.assign({}, { id: v.id, name: v.name }, { value: { ...v, default: true } });
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  getSelectMatterTitle(): string {
    return locale.matters.select.title;
  }

  isSelected(item: any): boolean {
    return item.name === this.defaultFirmOption.name;
  }

  private matterSelectClosed(newPath = '', actionId = '', matterId = '', isSmall = false): void {
    const path =
      newPath ||
      (this.browserSvc.isBrowser ? this.browserSvc.window.location.pathname.replace('/(aside:select)', '') : '');
    const selectClosedDetail: CustomEventModel.MatterSelectClosedDetail = {
      path,
      returnToActionId: actionId || SideNavigationModel.Helper.getSideActionId(path),
      matterId
    };

    if (isSmall) {
      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path: selectClosedDetail.path
      });
    }
    this.customEventSvc.dispatchEvent(MATTERS_SELECT_CLOSED, { ...selectClosedDetail });
  }

  selectedMatter(matter: LyraDesignCardModel.MatterCardInfo, isSmall: boolean): void {
    const { id, firmId } = matter;
    const matterId = id;

    this.matterSelect = true;
    this.selectedMatterId = matterId;

    const currentStoreActionId = this.store.selectSnapshot(AppState.getLastNavigatedActionId);
    const actionId =
      currentStoreActionId == SideNavigationModel.SideActionId.recents
        ? SideNavigationModel.SideActionId.documents
        : currentStoreActionId;

    const pageSlot = SideNavigationModel.Helper.getPagePathByActionId(actionId);

    const isTrustPath = this.location.path().includes('/trust');
    const path = `/matters/${matterId}/${pageSlot}/`;

    isTrustPath && this.store.dispatch(new TrustAction.CleanTrustFilterOption(undefined));

    this.matterSelectClosed(path, actionId, matterId, isSmall);
    this.store.dispatch(new SetMatterFirmId({ firmId, matterId }));
  }

  closeAsideSelect(): void {
    if (this.matterSelect) {
      return;
    }

    if (
      this.router.routeConfig &&
      this.router.routeConfig.outlet == 'aside' &&
      this.router.routeConfig.path == 'select'
    ) {
      this.matterSelectClosed();
    }
  }

  onFirmSelected(firm: LyraDesignFormModel.SelectOption) {
    this.defaultFirmOption =
      firm.id !== this.keyDefaultFirm.id ? this.getSelectedFirmOption(firm.id) : this.keyDefaultFirm;

    setTimeout(() => {
      const displaySelectedFirm = firm.id && firm.id !== this.keyDefaultFirm.id;
      this.notGroupDisplay = displaySelectedFirm;
      this.store.dispatch(new SetFilterFirmId(displaySelectedFirm ? firm.id : undefined));
      this.setupMatterOptions();
      this.currentSelectedFirm = this.defaultFirmOption.name;
    }, 0);
  }

  getFirmName(firmId: string): string {
    const firm = this.firmOptions.find(x => x.id == firmId);
    return firm ? firm.name : '';
  }

  trackElement(index: number, element: any) {
    return (element && element.id) || element || index;
  }
}
