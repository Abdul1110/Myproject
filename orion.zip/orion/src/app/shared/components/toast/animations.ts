import { trigger, state, style, transition, group, query, useAnimation, animate, animation } from '@angular/animations';

export const standardAnimationTiming = '250ms cubic-bezier(0.16, 0.66, 0.32, 1.2)';
export let xAnimationScaleIn = animation([
  style({
    transform: 'scale(0)'
  }),
  animate(
    standardAnimationTiming,
    style({
      transform: 'scale(1)'
    })
  )
]);

export let xAnimationFadeIn = animation([
  style({
    opacity: 0
  }),
  animate(
    '250ms ease',
    style({
      opacity: 1
    })
  )
]);
export let xAnimationScaleOut = animation([
  style({
    transform: 'scale(1)'
  }),
  animate(
    standardAnimationTiming,
    style({
      transform: 'scale(0)'
    })
  )
]);

export let xAnimationFadeOut = animation([
  style({
    opacity: 1
  }),
  animate(
    '250ms ease',
    style({
      opacity: 0
    })
  )
]);
export const flyInOut = trigger('flyInOut', [
  state(
    'inactive',
    style({
      display: 'none',
      opacity: 0
    })
  ),
  transition('inactive => active', [
    group([query(':self', [useAnimation(xAnimationScaleIn)]), query(':self', [useAnimation(xAnimationFadeIn)])])
  ]),
  transition(':leave', [
    group([query(':self', [useAnimation(xAnimationScaleOut)]), query(':self', [useAnimation(xAnimationFadeOut)])])
  ])
]);
