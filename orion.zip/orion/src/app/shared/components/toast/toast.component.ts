import { Component, OnInit, HostBinding } from '@angular/core';
import { Toast, ToastrService, ToastPackage } from 'ngx-toastr';
import { flyInOut } from './animations';

@Component({
  selector: 'sc-toast',
  templateUrl: './toast.component.html',
  animations: [flyInOut]
})
export class ToastComponent extends Toast implements OnInit {
  constructor(protected toastrService: ToastrService, public toastPackage: ToastPackage) {
    super(toastrService, toastPackage);
  }

  @HostBinding('class.toast')
  ngOnInit() {
    this.getIconClass();
  }

  getIconClass() {
    switch (this.toastPackage.toastType) {
      case 'toast-error':
        return 'error-circle';
      case 'toast-success':
        return 'tick-circle';
      case 'toast-warning':
        return 'warning-outline';
      case 'toast-info':
        return 'info-circle';
      default:
        return 'spinner';
    }
  }

  get toastType(): string {
    //error: 'toast-error',
    //info: 'toast-info',
    //success: 'toast-success',
    //warning: 'toast-warning'
    return this.toastPackage.toastType;
  }
}
