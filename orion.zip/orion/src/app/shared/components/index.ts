import { ButtonComponent } from './button/button.component';
import { ConfirmModalComponent } from './confirm-modal/confirm-modal.component';
import { FileDownloadProgressComponent } from './file-download-progress/file-download-progress.component';
import { ImageViewerComponent } from './image-viewer/image-viewer.component';
import { PdfViewerComponent } from './pdf-viewer/pdf-viewer.component';
import { PreLoadComponent } from './pre-load/pre-load.component';
import { ProxyRouteComponent } from './proxy-route/proxy-route.component';
import { PdfAnnotatorComponent } from './pdf-annotator/pdf-annotator.component';
import { ToastComponent } from './toast/toast.component';
import { PdfAnnotatorViewerComponent } from './pdf-annotator-viewer/pdf-annotator-viewer.component';
import { BottomSheetHeaderComponent } from './bottom-sheet-header/bottom-sheet-header.component';
import { MatterSelectComponent } from './matter-select/matter-select.component';
import { FolderSelectionComponent } from './folder-selection/folder-selection.component';
import { NotFoundCardComponent } from './not-found-card/not-found-card.component';
import { FeedbackComponent } from './feedback/feedback.component';

export * from './confirm-modal/confirm-modal.component';
export * from './button/button.component';
export * from './file-download-progress/file-download-progress.component';
export * from './image-viewer/image-viewer.component';
export * from './pdf-viewer/pdf-viewer.component';
export * from './pre-load/pre-load.component';
export * from './proxy-route/proxy-route.component';
export * from './pdf-annotator/pdf-annotator.component';
export * from './bottom-sheet-header/bottom-sheet-header.component';
export * from './folder-selection/folder-selection.component';
export * from './not-found-card/not-found-card.component';
export * from './feedback/feedback.component';

export const sharedModalComponents = [
  ButtonComponent,
  ConfirmModalComponent,
  FileDownloadProgressComponent,
  ImageViewerComponent,
  PdfViewerComponent,
  PreLoadComponent,
  ProxyRouteComponent,
  PdfAnnotatorComponent,
  PdfAnnotatorViewerComponent,
  ToastComponent,
  BottomSheetHeaderComponent,
  MatterSelectComponent,
  FolderSelectionComponent,
  NotFoundCardComponent,
  FeedbackComponent
];
