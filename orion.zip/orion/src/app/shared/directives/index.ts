import { AutoExpandDirective } from './auto-expand/auto-expand.directive';
import { AutofocusDirective } from './autofocus/autofocus.directive';
import { DisableControlDirective } from './disable-control/disable-control.directive';
import { ElementResizeDirective } from './element-resize/element-resize.directive';
import { PreventDefaultDirective } from './prevent-default/prevent-default.directive';
import { AutoSelectTextDirective } from './auto-select-text/auto-select-text.directive';
import { HighlighterDirective } from './highlighter/highlighter.directive';

export * from './auto-expand/auto-expand.directive';
export * from './autofocus/autofocus.directive';
export * from './disable-control/disable-control.directive';
export * from './element-resize/element-resize.directive';
export * from './prevent-default/prevent-default.directive';
export * from './auto-select-text/auto-select-text.directive';
export * from './highlighter/highlighter.directive';

export const sharedDirectives = [
  AutoExpandDirective,
  AutofocusDirective,
  DisableControlDirective,
  ElementResizeDirective,
  PreventDefaultDirective,
  AutoSelectTextDirective,
  HighlighterDirective
];
