import { Directive, Output, EventEmitter, ElementRef, NgZone, OnDestroy, OnInit, Input } from '@angular/core';
import { BrowserService } from '@leap/lyra-design';

import { AnnotatorModel } from '@app/shared/models/annotator.model.ts';
@Directive({
  selector: '[sc-highlighter]'
})
export class HighlighterDirective implements OnInit, OnDestroy {
  @Input('selected-range')
  set selectedRange(value: { range: AnnotatorModel.AnnotatedRange; seqNumber: number; quote: string }) {
    if (value && value.range) {
      // clean any previous temp.
      const elements = document.querySelectorAll('.annotator-hl-temp');
      if (elements && elements.length > 0) {
        for (let i = 0; i < elements.length; i++) {
          elements[i].replaceWith(elements[i]['innerText']);
        }
      }

      const { range, seqNumber, quote } = value;
      const rangeStart =
        range.start && range.start.includes('scPdfPreview')
          ? range.start
          : `id("scPdfPreview")/div[2]/pdf-viewer[1]/div[1]/div[1]/div[1]${range.start}`;
      const rangeEnd =
        range.end && range.end.includes('scPdfPreview')
          ? range.end
          : `id("scPdfPreview")/div[2]/pdf-viewer[1]/div[1]/div[1]/div[1]${range.end}`;
      const annotating = this.annotationTextNode(
        rangeStart,
        range.startOffset,
        rangeEnd,
        range.endOffset,
        seqNumber,
        '',
        quote
      );
      annotating && this.wrapAnnotatedText(annotating.textNode, annotating.id, annotating.idx, true);
    }
  }

  @Input('annotator-disabled') annotatorDisabled: boolean;

  @Input()
  set annotations(value: { annotations: AnnotatorModel.HighlightModel[]; callback: (e) => void }) {
    if (!!value && !this.annotatorDisabled) {
      this.cleanAnnotations(value.annotations);
      this.loadAnnotations(value.annotations, value.callback);
    }
  }

  @Output('selected-text')
  selectedText = new EventEmitter<AnnotatorModel.HighlightModel>();

  private hasSelection = false;
  private callback: (event) => void;

  constructor(private elementRef: ElementRef, private zone: NgZone, private browserSvc: BrowserService) {}

  ngOnInit() {
    this.zone.runOutsideAngular(() => {
      !this.annotatorDisabled && this.elementRef.nativeElement.addEventListener('mousedown', this.handleMousedown);
    });
  }

  ngOnDestroy() {
    this.elementRef.nativeElement.removeEventListener('mousedown', this.handleMousedown);
    !this.annotatorDisabled && this.browserSvc.window.document.removeEventListener('mouseup', this.handleMouseup);
  }

  private handleMousedown = () => {
    !this.annotatorDisabled && this.browserSvc.window.document.addEventListener('mouseup', this.handleMouseup);
  };

  private handleMouseup = event => {
    if (this.annotatorDisabled) {
      return;
    }
    this.browserSvc.window.document.removeEventListener('mouseup', this.handleMouseup);
    this.processSelection(event);
  };

  private processSelection(event) {
    const selection = this.browserSvc.window.document.getSelection();

    if (this.hasSelection) {
      this.hasSelection = false;
      this.emitSelection({ highlightedText: '', range: null });
    }

    if (!!selection.rangeCount || !!selection.toString()) {
      this.handleNewSelection(selection);
    }
  }

  private getNodeStartOffsetByAncestorContainer(data: string, selectionText: string, allText: string): number {
    if (allText) {
      return allText.indexOf(selectionText);
    }

    return data.indexOf(selectionText);
  }

  private getNodeOffsetByAncestorContainer(data: string, selectionText: string, allText: string): number {
    if (allText) {
      return allText.indexOf(selectionText) + selectionText.length;
    }

    return data.indexOf(selectionText) + selectionText.length;
  }

  private getNodeOffsetByNode(endNodeValue: string, selectionText: string): number {
    return endNodeValue ? endNodeValue.indexOf(selectionText) + selectionText.length : selectionText.length;
  }

  // this method apply when multiline selection, and we need to choose the lowest value.
  // only happen to endNode.
  private takeTheLowestValue(newOffSet: number, selectedRangeOffset: number): number {
    if (newOffSet > selectedRangeOffset) {
      return selectedRangeOffset;
    }
    return newOffSet;
  }

  private handleNewSelection(selection: Selection) {
    const elRange = selection.getRangeAt(0);
    this.hasSelection = true;
    const start = this.readAnnotationXPath(elRange.startContainer.parentElement);
    const end = this.readAnnotationXPath(elRange.endContainer.parentElement);

    // multiple text annotated and delete, the element will not be the same from the origin state.
    // thus, it is useful if we manage to get whole text value from commonAncestorContainer to read the start and end node offset.
    const useCommonAncestorContainer = ['text', 'span'];
    const readFromCommonAncestorContainerText =
      useCommonAncestorContainer.findIndex(
        b => elRange.commonAncestorContainer.nodeName.toLowerCase().indexOf(b) !== -1
      ) !== -1;
    const wholeText =
      readFromCommonAncestorContainerText &&
      (elRange.commonAncestorContainer['wholeText'] || elRange.commonAncestorContainer['innerText']);

    const allTextInTheRow =
      selection &&
      selection.focusNode &&
      selection.focusNode.parentNode &&
      selection.focusNode.parentNode['innerText'] &&
      selection.focusNode.parentNode['innerText'];

    const endOffset = readFromCommonAncestorContainerText
      ? this.getNodeOffsetByAncestorContainer(wholeText, selection.toString(), allTextInTheRow)
      : this.takeTheLowestValue(
          this.getNodeOffsetByNode(elRange.endContainer.nodeValue, selection.toString()),
          elRange.endOffset
        );

    const startOffset = readFromCommonAncestorContainerText
      ? this.getNodeStartOffsetByAncestorContainer(wholeText, selection.toString(), allTextInTheRow)
      : elRange.startOffset;

    this.emitSelection({
      mouseUpEvent: event,
      highlightedText: selection.toString(),
      range: <AnnotatorModel.HighlightedRangeModel>{
        start,
        end,
        startOffset,
        endOffset
      }
    });
  }

  private emitSelection(selection: AnnotatorModel.HighlightModel) {
    // Reenter Angular zone, since event handlers are registered within runOutsideAngular,
    // and we want this to trigger change detection on the calling component
    this.zone.runGuarded(() => {
      this.selectedText.emit(selection);
    });
  }

  // Annotation loading methods
  private loadAnnotations(annotations: AnnotatorModel.HighlightModel[], callback: (event) => void = null) {
    this.handleCallback(callback);
    let pendingRenderTextNodes: { textNode: any; id: string; idx: number }[] = [];

    // Order might matter, a lot, give annotations count/orderId
    annotations.forEach((a, idx) => {
      const textNode = this.annotationTextNode(
        <string>a.range.start,
        a.range.startOffset,
        <string>a.range.end,
        a.range.endOffset,
        idx,
        a.id,
        a.highlightedText
      );
      if (textNode) {
        pendingRenderTextNodes = pendingRenderTextNodes.concat(textNode);
      }
    });

    // Only apply the node changes here to minimise noise element created.
    pendingRenderTextNodes.forEach(tn => {
      this.wrapAnnotatedText(tn.textNode, tn.id, tn.idx);
    });
  }

  private annotationTextNode(
    rangeStart: string,
    rangeStartOffset: number,
    rangeEnd: string,
    rangeEndOffset: number,
    annotationSeqNumber: number,
    annotationId: string,
    highlightedText: string
  ) {
    const startContainer = this.findAnnotationByXPath(rangeStart, rangeStartOffset);
    const endContainer = this.findAnnotationByXPath(rangeEnd, rangeEndOffset);
    // Check if annotation already exists
    // This is predicated on the rule that an annotation can not start or stop within another annotation
    if (
      startContainer.node &&
      endContainer.node &&
      // startContainer.node.nodeName !== 'SPAN' &&
      startContainer.node.className !== 'annotator-hl' &&
      // endContainer.node.nodeName !== 'SPAN' &&
      endContainer.node.className !== 'annotator-hl'
    ) {
      let exists = false;
      // check any data-annotation-seq=x exists
      startContainer.node &&
        startContainer.node.childNodes.forEach(cn => {
          if (!exists && cn && cn['nodeName'].includes('SPAN') && cn['className'].includes('annotator-hl')) {
            if ((cn as any).getAttribute('data-annotation-seq') == annotationSeqNumber + 1) {
              exists = true;
            }
          }
        });

      if (!exists) {
        const range = this.createRangeFromAnnotation(startContainer, endContainer, annotationId, highlightedText);
        const textNodes = this.createTextNodeTree(range);
        const selectedTextNodes = this.updateTextNodesFromOffset(textNodes, range);
        return { textNode: selectedTextNodes, id: annotationId, idx: annotationSeqNumber + 1 };
      }

      return undefined;
    }
  }

  private handleCallback(callback: (event: any) => void) {
    const currentAnnotations = this.browserSvc.window.document.getElementsByClassName('annotator-hl');
    if (currentAnnotations.length > 0) {
      for (let i = 0; i < currentAnnotations.length; i++) {
        const anno = currentAnnotations[i];
        anno.removeEventListener('mouseover', this.callback);
      }
    }
    this.callback = !!callback ? callback.bind(this) : (e => console.log(e.target)).bind(this);
    if (currentAnnotations.length > 0) {
      for (let i = 0; i < currentAnnotations.length; i++) {
        const anno = currentAnnotations[i];
        anno.addEventListener('mouseover', this.callback);
      }
    }
  }

  private wrapAnnotatedText(selectedTextNodes: any[], annotationId: string, seq: number, temp = false) {
    for (let i = 0; i < selectedTextNodes.length; i++) {
      if (
        selectedTextNodes[i] &&
        selectedTextNodes[i].parentNode &&
        selectedTextNodes[i].parentNode.className !== 'annotator-hl'
      ) {
        const wrapper = this.browserSvc.window.document.createElement('span');
        wrapper.className = temp ? 'annotator-hl-temp' : 'annotator-hl';
        wrapper.textContent = selectedTextNodes[i].textContent;
        !temp && wrapper.setAttribute('id', annotationId);
        !temp && wrapper.addEventListener('mouseover', this.callback);
        !temp && wrapper.setAttribute('annotation-id', annotationId);
        selectedTextNodes[i].parentElement.replaceChild(wrapper, selectedTextNodes[i]);

        i == 0 && !temp && wrapper.setAttribute('data-annotation-seq', `${seq}`);
      } else {
        const currentElement = this.browserSvc.window.document.getElementById(annotationId);
        currentElement &&
          currentElement.getAttribute('data-annotation-seq') &&
          currentElement.getAttribute('data-annotation-seq') !== `${seq}` &&
          currentElement.setAttribute('data-annotation-seq', `${seq}`);
      }
    }
  }

  private updateTextNodesFromOffset(textNodes: any[], range: Range) {
    const startNodePos = textNodes.indexOf(range.startContainer);
    const endNodePos = textNodes.indexOf(range.endContainer);

    if (startNodePos < 0 || endNodePos < 0) {
      return textNodes.slice(0, 1);
    }

    let selectedTextNodes = textNodes.slice(startNodePos, endNodePos + 1);
    const lastSelectedNodePos = selectedTextNodes.length - 1;
    // Check whether text nodes are already correctly split
    if (
      !!(selectedTextNodes[0].length === range.startOffset) &&
      !!(selectedTextNodes[lastSelectedNodePos].length === range.endOffset)
    ) {
      selectedTextNodes = selectedTextNodes.slice(1, selectedTextNodes.length || -1);
    } else {
      const replaceFirstTextNode = selectedTextNodes[0].splitText(range.startOffset);
      selectedTextNodes[0] = replaceFirstTextNode;
      selectedTextNodes[lastSelectedNodePos].splitText(range.endOffset);
    }
    return selectedTextNodes;
  }

  private createTextNodeTree(range: Range) {
    const textNodeTree = this.browserSvc.window.document.createTreeWalker(
      range.commonAncestorContainer,
      NodeFilter.SHOW_TEXT
    );
    const textNodes = [];
    while (textNodeTree.nextNode()) {
      textNodes.push(textNodeTree.currentNode);
    }
    if (textNodes.length === 0) {
      textNodes.push(textNodeTree.currentNode);
    }
    return textNodes;
  }

  private createRangeFromAnnotation(
    startContainer: { node: Element; offset: number },
    endContainer: { node: Element; offset: number },
    annotationId: string,
    selectedText: string
  ) {
    const range = this.browserSvc.window.document.createRange();
    const startTextNode = this.getTextNodeFromOffset(
      startContainer.node,
      startContainer.offset,
      annotationId,
      true,
      selectedText
    );
    const endTextNode = this.getTextNodeFromOffset(
      endContainer.node,
      endContainer.offset,
      annotationId,
      false,
      selectedText
    );

    if (
      startTextNode &&
      startTextNode.textNode &&
      endTextNode &&
      endTextNode.textNode &&
      !startTextNode.hasDrawBefore &&
      !endTextNode.hasDrawBefore
    ) {
      range.setStart(startTextNode.textNode, startTextNode.offset);
      range.setEnd(endTextNode.textNode, endTextNode.offset);
    }
    return range;
  }

  private getTextNodeFromOffset(
    node: Node,
    offset: number,
    annotationId: string,
    startNode: boolean,
    selectedText: string
  ) {
    // valid nodes, only contains single text node.
    if (node.childNodes && node.childNodes.length === 1) {
      const nodeId = node.childNodes[0]['id'] || '';
      const textNode = node.childNodes[0];
      return { textNode, offset, hasDrawBefore: annotationId && nodeId === annotationId };
    }

    if (startNode) {
      if (offset === 0) {
        const nodeId = node.childNodes[0]['id'] || '';
        const textNode = node.childNodes[0];
        return { textNode, offset, hasDrawBefore: annotationId && nodeId === annotationId };
      } else {
        const hasStartNode = this.loopStartChildNodes(node, annotationId, offset, selectedText);
        if (hasStartNode) {
          return hasStartNode;
        }
      }
    } else {
      const hasEndNode = this.loopEndChildNodes(node, annotationId, offset, selectedText);
      if (hasEndNode) {
        return hasEndNode;
      }
    }

    // invalid, just ignore.
    return { textNode: null, offset, hasDrawBefore: false };
  }

  // this is useful to handle noise scenario where origin single element has been distorted to multiple elements.
  // the loop will try to get the correct idx and element from the noise.
  private loopStartChildNodes(
    node: Node,
    annotationId: string,
    recordedOffset: number,
    selectedText: string
  ): { textNode: any; offset: number; hasDrawBefore: boolean } {
    let found = false;
    let correctIdx = 0;
    let foundElementIdx = 0;
    let currentLength = 0;
    node.childNodes.forEach((text, idx) => {
      if (text['data']) {
        const currentTextLength = text['data'].length;
        currentLength += currentTextLength;
        if (!found && currentLength >= recordedOffset) {
          found = true;
          const starts = currentLength - currentTextLength;
          let internalIdx = 0;
          for (let a = starts; starts <= currentLength; a++) {
            if (a == recordedOffset) {
              correctIdx = internalIdx;
              foundElementIdx = idx;
              break;
            }
            internalIdx += 1;
          }
        }
      }
    });

    if (found) {
      const nodeId = node.childNodes[foundElementIdx]['id'] || '';
      return {
        textNode: node.childNodes[foundElementIdx],
        offset: correctIdx,
        hasDrawBefore: annotationId && nodeId === annotationId
      };
    }

    // Give it another try to find the text element by text matching probability approach.
    // If any text match start from selected text or text element list, consider match and return.
    node.childNodes.forEach((text, idx) => {
      const textValue = text['data'];
      if (
        !found &&
        textValue &&
        (textValue.toLowerCase().includes(selectedText) || selectedText.toLowerCase().includes(textValue))
      ) {
        found = true;
        foundElementIdx = idx;
        correctIdx =
          textValue.indexOf(selectedText) >= 0 ? textValue.indexOf(selectedText) : selectedText.indexOf(textValue);
      }
    });

    if (found) {
      const nodeId = node.childNodes[foundElementIdx]['id'] || '';
      return {
        textNode: node.childNodes[foundElementIdx],
        offset: correctIdx,
        hasDrawBefore: annotationId && nodeId === annotationId
      };
    }

    // No luck, return nothing.
    return undefined;
  }

  // this is useful to handle noise scenario where origin single element has been distorted to multiple elements.
  // the loop will try to get the correct idx and element from the noise.
  private loopEndChildNodes(
    node: Node,
    annotationId: string,
    recordedOffset: number,
    selectedText: string
  ): { textNode: any; offset: number; hasDrawBefore: boolean } {
    let found = false;
    let correctOffset = 0;
    let foundElementIdx = 0;
    let currentLength = 0;
    node.childNodes.forEach((text, idx) => {
      if (text['data']) {
        const currentTextLength = text['data'].length;
        currentLength += currentTextLength;
        if (!found && currentLength >= recordedOffset) {
          found = true;
          const deductOffset = currentLength - recordedOffset;
          correctOffset = currentTextLength - deductOffset;
          foundElementIdx = idx;
        }
      }
    });

    if (found) {
      const nodeId = node.childNodes[foundElementIdx]['id'] || '';
      return {
        textNode: node.childNodes[foundElementIdx],
        offset: correctOffset < 1 ? 1 : correctOffset,
        hasDrawBefore: annotationId && nodeId === annotationId
      };
    }

    // Give it another try to find the text element by text matching probability approach.
    // If any text match start from selected text or text element list, consider match and return.
    node.childNodes.forEach((text, idx) => {
      const textValue = text['data'];
      if (
        !found &&
        textValue &&
        (textValue.toLowerCase().includes(selectedText) || selectedText.toLowerCase().includes(textValue))
      ) {
        found = true;
        foundElementIdx = idx;
        correctOffset =
          textValue.indexOf(selectedText) >= 0
            ? textValue.indexOf(selectedText) + selectedText.length
            : selectedText.indexOf(textValue) + textValue.length;
      }
    });

    if (found) {
      const nodeId = node.childNodes[foundElementIdx]['id'] || '';
      return {
        textNode: node.childNodes[foundElementIdx],
        offset: correctOffset,
        hasDrawBefore: annotationId && nodeId === annotationId
      };
    }

    // No luck, return nothing.
    return undefined;
  }

  // the id = scPdfPreview is very important.
  // changes of this, need to reflect at here as well.
  private readAnnotationXPath(element: Element, excludePagePath = true): string {
    const xpath = this.getElementXPath(element);
    const prefix = 'id("scPdfPreview")/div[2]/pdf-viewer[1]/div[1]/div[1]/';
    const path = xpath.replace(prefix, '/');

    if (excludePagePath && path.split('/').length === 4) {
      const pathWithPage = path.split('/');
      return `/${pathWithPage.slice(2).join('/')}`;
    }

    return path;
  }

  private getElementXPath(element: Element): string {
    const idx = (sib, name = '') =>
      sib ? idx(sib.previousElementSibling, name || sib.localName) + (sib.localName == name) : 1;
    const segs = elm =>
      !elm || elm.nodeType !== 1
        ? ['']
        : elm.id && this.browserSvc.window.document.querySelector(`#${elm.id}`) === elm
        ? [`id("${elm.id}")`]
        : [...segs(elm.parentNode), `${elm.localName.toLowerCase()}[${idx(elm)}]`];
    return segs(element).join('/');
  }

  private findAnnotationByXPath(xpath: string, offset: number): { node: Element; offset: number } {
    const node = this.getElementByXPath(xpath);

    return { node: <Element>node, offset };
  }

  private getElementByXPath(path: string) {
    return new XPathEvaluator().evaluate(
      path,
      this.browserSvc.window.document.documentElement,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null
    ).singleNodeValue;
  }

  private cleanAnnotations(annotations: AnnotatorModel.HighlightModel[]) {
    const currentAnnotations = this.elementRef.nativeElement.querySelectorAll('.annotator-hl');
    if (currentAnnotations && currentAnnotations.length > 0) {
      for (let i = 0; i < currentAnnotations.length; i++) {
        currentAnnotations[i].replaceWith(currentAnnotations[i]['innerText']);
      }
    }
  }
}
