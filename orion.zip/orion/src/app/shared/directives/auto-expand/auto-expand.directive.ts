import { Directive, ElementRef, Input, OnInit } from '@angular/core';

const defaultExpandedClass = 'aside-right-full';
const defaultContractedClass = 'aside-right-slim';

@Directive({
  selector: '[scAutoExpand]'
})
export class AutoExpandDirective implements OnInit {
  @Input()
  set expanded(value: boolean) {
    this._expanded = value;
    this.toggleElementClass();
  }
  get expanded() {
    return this._expanded;
  }
  @Input()
  set expandedClass(value: string) {
    this._expandedClass = value;
    this.toggleElementClass();
  }
  get expandedClass() {
    return this._expandedClass;
  }
  @Input()
  set contractedClass(value: string) {
    this._contractedClass = value;
    this.toggleElementClass();
  }
  get contractedClass() {
    return this._contractedClass;
  }

  private _expanded: boolean;
  private _expandedClass: string;
  private _contractedClass: string;

  constructor(private elementRef: ElementRef) {}

  ngOnInit(): void {}

  toggleElementClass(): void {
    const getAsideClass = (expanded: boolean) => {
      return expanded ? this.expandedClass || defaultExpandedClass : this.contractedClass || defaultContractedClass;
    };
    const toRemoveClass = getAsideClass(!this.expanded).split(' ');
    const toAddClass = getAsideClass(this.expanded).split(' ');
    this.elementRef.nativeElement.classList.add(...toAddClass);
    this.elementRef.nativeElement.classList.remove(...toRemoveClass);
  }
}
