import { Directive, OnInit, ElementRef } from '@angular/core';

@Directive({
  selector: '[scElementResize]'
})
export class ElementResizeDirective implements OnInit {
  constructor(private elementRef: ElementRef) {}

  ngOnInit(): void {
    console.log('ElementResizeDirective called');
  }
}
