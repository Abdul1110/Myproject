import { Directive, OnInit, ElementRef, AfterViewInit, Input } from '@angular/core';
import { isUndefined } from 'lodash';

@Directive({
  selector: '[scAutofocus]'
})
export class AutofocusDirective implements OnInit, AfterViewInit {
  @Input() autofocus: boolean;

  constructor(private elementRef: ElementRef) {}

  ngOnInit(): void {}

  ngAfterViewInit() {
    if (isUndefined(this.autofocus) || this.autofocus) {
      setTimeout(() => this.elementRef.nativeElement.focus());
    }
  }
}
