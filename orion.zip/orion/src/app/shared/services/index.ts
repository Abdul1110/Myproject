import { DialogService } from '@app/shared/services/dialog/dialog.service';
import { UtilsService } from '@app/shared/services/utils/utils.service';
import { AnnotatorService } from './annotator/annotator.service';

export * from './dialog/dialog.service';
export * from './utils/utils.service';
export * from './browser-title/browser-title.service';
export * from './annotator/annotator.service';

export const sharedServices = [DialogService, UtilsService, AnnotatorService];
