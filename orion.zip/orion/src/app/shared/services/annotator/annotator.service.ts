import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { AnnotatorModel } from '@app/shared/models';
import { Router, UrlSerializer } from '@angular/router';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AnnotatorService {
  private endpoint = '/api/internal/api/document';

  constructor(private http: HttpClient, private router: Router, private serializer: UrlSerializer) {}

  createAnnotation(annotationData: AnnotatorModel.NewAnnotation) {
    const url = `${this.endpoint}/annotations/add`;
    const time = Date.now().toString();
    return this.http.post(url, annotationData, { params: { time } });
  }

  updateAnnotation(annotationData: AnnotatorModel.UpdateAnnotation) {
    const url = `${this.endpoint}/annotations/update/:id`;
    const time = Date.now().toString();
    return this.http.put(url, annotationData, { params: { time } });
  }

  deleteAnnotation(annotationId: string) {
    const url = `${this.endpoint}/annotations/delete/${annotationId}`;
    const time = Date.now().toString();
    return this.http.delete(url, { params: { time } });
  }

  loadAnnotations(annotatingByData: AnnotatorModel.AnnotatingBy) {
    const { documentId, userId, userName } = annotatingByData;
    const searchQuery: AnnotatorModel.SearchAnnotation = {
      limit: 1000,
      fileId: encodeURIComponent(documentId),
      pageId: 1,
      user: {
        userId: userId,
        userName: userName
      }
    };
    return this.getAnnotation(searchQuery).pipe(map(anno => this.mapAnnotationsToHighlights(anno)));
  }

  convertRanges(range: AnnotatorModel.AnnotatedRange) {
    const start: string = JSON.parse(range.start);
    const end: string = JSON.parse(range.end);
    return <AnnotatorModel.HighlightedRangeModel>{
      start,
      end,
      startOffset: range.startOffset,
      endOffset: range.endOffset
    };
  }

  convertRangesToFullXPath(range: AnnotatorModel.AnnotatedRange, pageId: number) {
    const prefix = 'id("scPdfPreview")/div[2]/pdf-viewer[1]/div[1]/div[1]';

    const hasStartIncludePage = range.start.split('/').length > 3;
    const start = hasStartIncludePage ? `${prefix}${range.start}` : `${prefix}/div[${pageId}]${range.start}`;

    const hasEndIncludePage = range.end.split('/').length > 3;
    const end = hasEndIncludePage ? `${prefix}${range.end}` : `${prefix}/div[${pageId}]${range.end}`;

    return <AnnotatorModel.HighlightedRangeModel>{
      start,
      end,
      startOffset: range.startOffset,
      endOffset: range.endOffset
    };
  }

  private getAnnotation(searchQuery: AnnotatorModel.SearchAnnotation) {
    const url = `${this.endpoint}/annotations/search`;
    const time = Date.now().toString();

    const httpParams = new HttpParams()
      .set('time', time)
      .set('fileId', searchQuery.fileId)
      .set('limit', searchQuery.limit.toString())
      .set('pageId', searchQuery.pageId.toString())
      .set('user[userId]', searchQuery.user.userId)
      .set('user[username]', searchQuery.user.userName);
    return this.http.get<AnnotatorModel.AnnotationResponse>(url, { params: httpParams });
  }

  private mapAnnotationsToHighlights(anno: AnnotatorModel.AnnotationResponse) {
    const annoHighlights: AnnotatorModel.PageHighlights[] = anno.rows.map(a => {
      // Not sure why ranges is an array in previous model?
      const r = a.ranges[0];
      const start = JSON.parse(r.start);
      const end = JSON.parse(r.end);
      const range = <AnnotatorModel.HighlightedRangeModel>{
        start,
        end,
        startOffset: r.startOffset,
        endOffset: r.endOffset
      };
      return <AnnotatorModel.PageHighlights>{ highlightedText: a.quote, range, page: a.pageId };
    });
    return annoHighlights;
  }
}
