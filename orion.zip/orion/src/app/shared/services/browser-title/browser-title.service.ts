import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class BrowserTitleService {
  baseTitle: string;

  set pageTitle(value: string) {
    this.titleService.setTitle(`${value} | ${this.baseTitle}`);
  }

  constructor(private titleService: Title) {
    // Get the current base title (configured in WebPack)
    this.baseTitle = titleService.getTitle();
  }
}
