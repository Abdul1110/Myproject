import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser, isPlatformServer } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class PlatformService {
  constructor(@Inject(PLATFORM_ID) private platformId: any) {}

  public get isBrowser(): boolean {
    return isPlatformBrowser(this.platformId);
  }

  public get isServer(): boolean {
    return isPlatformServer(this.platformId);
  }

  public get isMacLikeOS(): boolean {
    const isMacLike = !!navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i);
    return this.isBrowser && isMacLike;
  }

  public get window(): Window | any {
    return this.isBrowser ? window : {};
  }
}
