import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';

import { has, isFunction, keys, omit } from 'lodash';

import { IDialogInfo, IDialogOptions, IConfirmModel, IFolderSelectionModel, IDialogFolderOptions } from '../../models';
import { ConfirmModalComponent } from '../../components/confirm-modal/confirm-modal.component';
import { FolderSelectionComponent } from '@app/shared/components/folder-selection/folder-selection.component';

@Injectable()
export class DialogService {
  private static error: IDialogInfo;
  private static warning: IDialogInfo;
  private static confirm: IDialogInfo;
  private static confirmStay: IDialogInfo;
  private static notify: IDialogInfo;

  constructor(private _modalSvc: BsModalService) {
    this.setupService();
  }

  error(opts: IDialogOptions): void {
    const dialogData = { ...DialogService.error, ...opts },
      { title, message, actionText, closeText, showCancel } = dialogData;
    this.showDialog({ title, message, actionText, closeText, showCancel }, opts);
  }

  warning(opts: IDialogOptions): void {
    const dialogData = { ...DialogService.warning, ...opts },
      { title, message, actionText, closeText, showCancel } = dialogData;
    this.showDialog({ title, message, actionText, closeText, showCancel, type: 'warning' }, opts);
  }

  confirm(opts: IDialogOptions): void {
    const dialogData = { ...DialogService.confirm, ...opts },
      { title, message, actionText, closeText } = dialogData;
    this.showDialog({ title, message, actionText, closeText, type: 'confirm' }, opts);
  }

  folderSelections(opts: IDialogFolderOptions): void {
    this.showFolderOptionsDialog(
      { folderOptions: opts.folderOptions, title: opts.title, defaultFolderId: opts.defaultFolderId },
      opts
    );
  }

  private setupService(): void {
    // DialogService.error = {
    //   title: this._translateSvc.instant('Core.Dialog.Error.Title'),
    //   message: this._translateSvc.instant('Core.Dialog.Error.Message'),
    //   actionText: this._translateSvc.instant('Core.Dialog.Error.Action.Text')
    // };
    // DialogService.warning = {
    //   title: this._translateSvc.instant('Core.Dialog.Warning.Title'),
    //   message: this._translateSvc.instant('Core.Dialog.Warning.Message'),
    //   actionText: this._translateSvc.instant('Core.Dialog.Warning.Action.Text')
    // };
    // DialogService.confirm = {
    //   title: this._translateSvc.instant('Core.Dialog.Confirm.Title'),
    //   message: this._translateSvc.instant('Core.Dialog.Confirm.Message'),
    //   actionText: this._translateSvc.instant('Core.Dialog.Confirm.Action.Text'),
    //   closeText: this._translateSvc.instant('Core.Dialog.Confirm.Close.Text')
    // };
    // DialogService.confirmStay = {
    //   title: this._translateSvc.instant('Core.Dialog.ConfirmStay.Title'),
    //   message: this._translateSvc.instant('Core.Dialog.ConfirmStay.Message'),
    //   actionText: this._translateSvc.instant('Core.Dialog.ConfirmStay.Action.Text'),
    //   closeText: this._translateSvc.instant('Core.Dialog.ConfirmStay.Close.Text')
    // };
    // DialogService.notify = {
    //   title: this._translateSvc.instant('Core.Dialog.Notify.Title'),
    //   message: this._translateSvc.instant('Core.Dialog.Notify.Message'),
    //   actionText: this._translateSvc.instant('Core.Dialog.Notify.Action.Text')
    // };
  }

  private showDialog(data: Partial<IConfirmModel>, opts: IDialogOptions): void {
    const modalClose$ = new Subject<boolean>();
    const bsModalRef: BsModalRef = this._modalSvc.show(ConfirmModalComponent, {
      backdrop: 'static',
      class: 'x-modal-alert x-modal-alert-md'
    });
    bsModalRef.content = data;
    bsModalRef.content.options = omit(opts, keys(data));
    bsModalRef.content.onClose = new Subject<boolean>();

    bsModalRef.content.onClose.pipe(takeUntil(modalClose$)).subscribe((confirmed: boolean) => {
      if (has(opts, 'onClose') && isFunction(opts.onClose)) {
        opts.onClose(confirmed);
      }
      modalClose$.next(true);
    });
  }

  private showFolderOptionsDialog(data: Partial<IFolderSelectionModel>, opts: IDialogFolderOptions): void {
    const modalClose$ = new Subject<boolean>();
    const bsModalRef: BsModalRef = this._modalSvc.show(FolderSelectionComponent, {
      backdrop: 'static',
      class: 'x-modal-alert x-modal-alert-md'
    });
    bsModalRef.content = data;
    bsModalRef.content.options = omit(opts, keys(data));
    bsModalRef.content.onClose = new Subject<string>();
    bsModalRef.content.folderOptions = data.folderOptions;
    bsModalRef.content.defaultFolderId = data.defaultFolderId;

    bsModalRef.content.onClose.pipe(takeUntil(modalClose$)).subscribe((folderId: string) => {
      if (has(opts, 'onClose') && isFunction(opts.onClose)) {
        opts.onClose(folderId);
      }
      modalClose$.next(true);
    });
  }
}
