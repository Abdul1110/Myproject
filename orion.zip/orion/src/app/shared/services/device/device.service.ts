import { Injectable } from '@angular/core';
import * as bowser from 'bowser';
import { BrowserService } from '@leap/lyra-design';

@Injectable({
  providedIn: 'root'
})
export class DeviceService {
  private _browser: bowser.Parser.Parser;

  get isDesktop(): boolean {
    const value = this._browser.getPlatformType(true) || '';
    return value.includes('desktop');
  }

  constructor(private browserSvc: BrowserService) {
    if (this.browserSvc.isBrowser) {
      this._browser = bowser.getParser(this.browserSvc.window.navigator.userAgent);
    }
  }
}
