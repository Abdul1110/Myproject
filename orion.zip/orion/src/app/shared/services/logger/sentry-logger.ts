import { ErrorHandler } from '@angular/core';
import { environment } from '@env/environment';
import { versions } from '@env/versions';

export class SentryLogger implements ErrorHandler {
  static initWith(sentry: any, source: string) {
    return () => new SentryLogger(sentry, source);
  }

  constructor(private sentry: any, private source: string) {
    if (environment.production) {
      this.sentry.init({
        dsn: 'https://f1d8749d84d44c7ab6daaea724438aab@sentry.io/1730121',
        environment: `${environment.appSettings.environment}-${source}`,
        release: versions.version
      });
    }
  }

  handleError(error: any): void {
    if (environment.production) {
      this.sentry.captureException(error.originalError || error);
    }
    throw error; // for default behaviour rather than silently dying
  }
}
