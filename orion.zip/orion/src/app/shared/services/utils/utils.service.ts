import { Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';
import { keys } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {
  // RegExp credit: http://stackoverflow.com/a/1373724/2797996
  private _validEmailAddressRegExp: RegExp = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;

  get validEmailAddressRegExp(): RegExp {
    return this._validEmailAddressRegExp;
  }

  isValidEmailAddress(emailAddress: string): boolean {
    return this._validEmailAddressRegExp.test(emailAddress) && emailAddress.indexOf('+') < 0;
  }

  getErrorMessagesFromForm(form: NgForm, errorMessages: any): string[] {
    const errors = [];

    if (form.invalid) {
      keys(errorMessages).forEach((controlName: string) => {
        keys(errorMessages[controlName]).forEach((validation: string) => {
          if (form.controls[controlName].errors && form.controls[controlName].errors[validation]) {
            errors.push(errorMessages[controlName][validation]);
          }
        });
      });
    }

    return errors;
  }

  buildErrorMessagesHTML(errors: string[]): string {
    return `
      <ul>
        ${errors.map((error: string) => `<li>${error}</li>`).join('')}
      </ul>
    `;
  }

  compareVersions(version1: string, version2: string): number {
    const regExStrip0 = /(\.0+)+$/;
    const version1Segments = version1.replace(regExStrip0, '').split('.');
    const version2Segments = version2.replace(regExStrip0, '').split('.');
    const length = Math.min(version1Segments.length, version2Segments.length);

    for (let i = 0; i < length; i++) {
      const diff = Number(version1Segments[i]) - Number(version2Segments[i]);
      if (diff) {
        return Math.sign(diff);
      }
    }

    return Math.sign(version1Segments.length - version2Segments.length);
  }
}
