import { LyraDesignFormModel } from '@leap/lyra-design';

export interface IDialogOptions {
  // Unused fields [atm]
  modalCls?: string;
  headerCls?: string;
  bodyCls?: string;
  footerCls?: string;
  iconCls?: string;

  title?: string;
  message?: string;
  actionText?: string;
  closeText?: string;
  showCancel?: boolean;
  onClose?: (confirmed: boolean) => void;
}

export interface IDialogInfo {
  title: string;
  message: string;
  actionText?: string;
  closeText?: string;
}

export interface IConfirmModel {
  actionText: string;
  closeText: string;
  message: string;
  showCancel: boolean;
  type: 'error' | 'warning' | 'info' | 'confirm';
  title: string;
}

export interface IDialogFolderOptions {
  // Unused fields [atm]
  modalCls?: string;
  headerCls?: string;
  bodyCls?: string;
  footerCls?: string;
  iconCls?: string;

  title?: string;
  message?: string;
  actionText?: string;
  closeText?: string;
  showCancel?: boolean;
  onClose?: (confirmed: string) => void;
  folderOptions: LyraDesignFormModel.SelectOption[];
  defaultFolderId: string;
}

export interface IFolderSelectionModel {
  actionText: string;
  closeText: string;
  showCancel: boolean;
  title: string;
  folderOptions: LyraDesignFormModel.SelectOption[];
  defaultFolderId: string;
}
