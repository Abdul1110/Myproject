export enum Browser {
  Chrome = 1,
  Firefox = 2,
  InternetExplorer = 3,
  MicrosoftEdge = 4,
  Other = 5,
  Safari = 6
}
