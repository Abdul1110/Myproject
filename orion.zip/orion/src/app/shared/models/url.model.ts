export interface UrlParams {
  key: string;
  value: string;
}

export function buildUrlWithParams(baseUrl: string, urlParams: UrlParams[]) {
  let url = baseUrl;
  urlParams.forEach((param, index) => {
    const first = index === 0 ? '?' : '';
    const last = index === urlParams.length - 1 ? '' : '&';
    url = url.concat(`${first}${param.key}=${encodeURIComponent(param.value)}${last}`);
  });
  return url;
}
