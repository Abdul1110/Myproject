export namespace SideNavigationModel {
  export enum SideActionId {
    recents = 'recents',
    matters = 'matters',
    documents = 'documents',
    signatures = 'signatures',
    collaborations = 'collaborations',
    billing = 'billing',
    trust = 'trust',
    apps = 'apps',
    support = 'support',
    feedback = 'feedback',
    communities = 'communities',
    logout = ' logout'
  }

  export class Helper {
    static getSideActionId(path: string): string {
      if (!path) {
        return;
      }

      const matterSelectOpened = path.includes('(aside:select)');
      if (path.startsWith(`/${SideActionId.matters}`) && matterSelectOpened) {
        return SideActionId.matters;
      }

      if (path.includes(`/sharedocuments`) && !matterSelectOpened) {
        return SideActionId.documents;
      }

      return Object.keys(SideActionId)
        .filter(x => x !== SideActionId.matters)
        .find(actionId => path.includes(`/${actionId}`) && !matterSelectOpened);
    }

    static getPagePathByActionId(action: string): string {
      if (!action) {
        return SideActionId.recents;
      }

      if (action == SideActionId.documents) {
        return 'sharedocuments';
      }

      return SideActionId[action] || SideActionId.recents;
    }
  }
}
