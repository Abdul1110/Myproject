export namespace AnnotatorModel {
  export interface AnnotationBeforeCreated {
    id: string;
    quote: string;
    ranges: AnnotatedRange[];
    text: string;
    aboutUpdate?: AnnotationDataForUpdated;
    seq?: number;
  }

  export interface AnnotationDataForUpdated {
    creationDate: string;
    events: AnnotatedEvent[];
    oldText: string;
    updateDate: string;
    userInfo?: AnnotatedBy;
    versionId: string;
    isDuringUpdate: boolean;
  }

  export interface AnnotatedPage {
    fileId: string;
    page: number;
    userId: string;
    userName: string;
  }

  export interface AnnotationData {
    annotationId: string;
    allowAnyoneView: boolean;
    comment: string;
    quote: string;
    ranges: AnnotatedRange[];
    isNew: boolean;
    aboutPage?: AnnotatedPage;
    aboutUpdate?: AnnotationDataForUpdated;
    text?: string;
    id?: string;
    creationDate?: string;
    events?: AnnotatorModel.AnnotatedEvent[];
    updateDate?: string;
    userInfo?: AnnotatorModel.AnnotatedBy;
    versionId?: string;
  }

  export interface AnnotatedRange {
    start: string;
    startOffset: number;
    end: string;
    endOffset: number;
  }

  export interface AnnotatedEvent {
    eventId: string;
    annotationId: string;
    actionType: number;
    modifiedDate: string;
    text: string;
    eventType: number;
  }

  export interface AnnotatedBy {
    firstName: string;
    lastName: string;
    email: string;
    id: string;
    leapCloudId: string;
    initials: string;
    userType: number;
  }

  export interface AnnotationSeq {
    seq: number;
    annotationId: string;
    quote: string;
    page: number;
  }

  export interface PageAnnotatorReloadStatus {
    lastPulled: Date;
    loading: boolean;
    error: any;
  }

  export interface AnnotationResponse {
    total: string;
    rows: DocumentAnnotation[];
  }

  export interface AnnotatedPermission {
    admin: string[];
    delete: string[];
    read: string[];
    update: string[];
  }

  export interface DocumentAnnotation {
    creationDate: string; //
    fileId: string; //
    id: string; //
    pageId: number; //
    quote: string; //
    text: string; //
    ranges: AnnotatedRange[]; //
    updateDate: string; //
    userInfo: AnnotatedBy; //
    versionId: string; //
    permissions: AnnotatedPermission; //
    annotationSeq?: number;
  }

  export interface AnnotationResponse {
    total: string;
    rows: DocumentAnnotation[];
  }

  export interface AnnotationElement {
    annotationId: string;
    element: Element;
  }

  export interface AnnotatedUser {
    userId: string;
    userName: string;
  }

  export interface AnnotatingBy extends AnnotatedUser {
    documentId: string;
  }

  export interface DeleteAnnotation {
    annotationId: string;
    documentId: string;
    staffId?: string;
  }

  export interface DeleteAnnotationReply {
    annotationId: string;
    replyId: string;
  }

  export interface HighlightModel {
    id?: string;
    mouseUpEvent?: any;
    highlightedText: string;
    range: HighlightedRangeModel;
  }

  export interface HighlightedRangeModel {
    start: string;
    end: string;
    startOffset: number;
    endOffset: number;
  }

  export interface PageHighlights extends HighlightModel {
    page: number;
  }

  export interface NewAnnotation {
    id: string;
    fileId: string;
    quote: string;
    text: string;
    pageId: number;
    user: AnnotatedUser;
    permissions: AnnotatedPermission;
    ranges: AnnotatedRange[];
  }

  export interface UpdateAnnotation extends NewAnnotation {
    creationDate: string;
    events: AnnotatedEvent[];
    isDuringUpdate: boolean;
    oldText: string;
    updateDate: string;
    versionId: string;
  }

  export interface SearchAnnotation {
    limit: number;
    fileId: string;
    pageId: number;
    user: AnnotatedUser;
  }
}
