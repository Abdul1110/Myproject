import { Injectable } from '@angular/core';
import { PubNubAngular } from 'pubnub-angular2';
import { environment } from '@env/environment';
import { CoreModel } from '@app/core/models';

@Injectable()
export class PubNubService {
  private initialised = false;

  constructor(private pubnub: PubNubAngular) {}

  init(userId: string): void {
    const publishKey = environment.appSettings.pubnubPublisherKey;
    const subscribeKey = environment.appSettings.pubnubSubscriberKey;

    this.pubnub.init({
      ssl: location.protocol.toLowerCase() === 'https:',
      publishKey,
      subscribeKey,
      uuid: `pubnub-client-${userId}`
    });
    this.initialised = true;
  }

  private guard(userId: string, channels: string[]) {
    if (!userId || !channels || channels.filter(c => !c).length > 0) {
      return () => {};
    }

    if (!this.initialised) {
      this.init(userId);
    }
  }

  subscribeToChannels(
    userId: string,
    channels: string[],
    action: (notification: any) => void
  ): CoreModel.PubNubSubscription {
    // channel from '<userId>', '<documentId>', and 'comments-<documentId>'

    this.guard(userId, channels);

    const channelsInLowerCase = channels.map(c => {
      return c.toLowerCase();
    });
    const listener = {
      message: /*istanbul ignore next Cannot test PubNub callback*/ (event: any): void => {
        if (channelsInLowerCase.indexOf(event.channel) === -1) {
          return;
        }

        let message: any;
        try {
          message = JSON.parse(event.message);
        } catch (ex) {
          message = { MessageType: event.message };
        }

        if (!!message && !!message.MessageType) {
          action(message.MessageType.Body);
        }
      }
    };

    const unsubscribe = this.subscribe({ channels: channelsInLowerCase, triggerEvents: true, withPresence: true });
    const removeListener = this.addListener(listener);

    return <CoreModel.PubNubSubscription>{
      unsubscribe: (): void => {
        unsubscribe();
        removeListener();
      }
    };
  }

  addListener(listener: any): () => void {
    this.pubnub.addListener(listener);
    return () => {
      this.pubnub.removeListener(listener);
    };
  }

  subscribe(options: any): () => void {
    this.pubnub.subscribe(options);
    return () => {
      this.pubnub.unsubscribe(options);
    };
  }

  unsubscribeAll(): void {
    if (this.pubnub) {
      this.pubnub.unsubscribeAll();
      this.pubnub = undefined;
    }
    this.initialised = false;
  }
}
