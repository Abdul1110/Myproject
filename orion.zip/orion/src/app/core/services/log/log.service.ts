import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { Log } from 'ng2-logger/browser/es5';

const noop = (): any => undefined;

@Injectable({
  providedIn: 'root'
})
export class LogService {
  info: any;
  warn: any;
  debug: any;
  error: any;
  log: any;

  constructor() {
    console.log('LogService ctor');
    this.setupLogs('core');
  }

  // rename log service
  // TODO: find a better way to inject name
  init(name: string) {
    console.log('LogService init', name);
    this.setupLogs(name);
  }

  setupLogs(name: string) {
    this.log = Log.create(name);
    this.error = this.log.er.bind(this.log);
    if (!environment.production) {
      this.debug = this.log.d.bind(this.log);
      this.info = this.log.i.bind(this.log);
      this.warn = this.log.w.bind(this.log);
    } else {
      this.debug = noop;
      this.info = noop;
      this.warn = noop;
    }
  }
}
