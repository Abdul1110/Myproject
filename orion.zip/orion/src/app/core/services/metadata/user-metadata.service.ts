import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { UUID } from 'angular2-uuid';
import { CoreModel, AuthenticationStatus } from '@app/core/models';

@Injectable({
  providedIn: 'root'
})
export class UserMetadataService {
  private endpoint = '/api/internal';

  authenticationStatus$ = new BehaviorSubject(undefined);

  constructor(private http: HttpClient) {}

  getUserMetadata(): Observable<CoreModel.UserMetadata> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/usermetadata?rdid=${randomId}`;
    return this.http.get<CoreModel.UserMetadata>(url);
  }

  setUserMetadata(metadata: CoreModel.UserMetadata): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/usermetadata?rdid=${randomId}`;
    return this.http.put<any>(url, { metadata });
  }

  root(): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/root?rdid=${randomId}`;
    return this.http.get<any>(url);
  }

  signout(): Observable<any> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/account/signout?rdid=${randomId}`;
    return this.http.get(url);
  }

  isAuthenticated(): Observable<AuthenticationStatus> {
    const url = `${this.endpoint}/api/account/isAuthenticated`;
    return this.http.get<AuthenticationStatus>(url);
  }
}
