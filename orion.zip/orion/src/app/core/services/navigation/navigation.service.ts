import { Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { BrowserService } from '@leap/lyra-design';

import { CoreModel } from '@app/core/models';

@Injectable()
export class NavigationService {
  constructor(private router: Router, private browserSvc: BrowserService, private ngZone: NgZone) {}

  goto = (navigation: CoreModel.NavigationData, delay: number = -1): void => {
    if (delay > -1) {
      setTimeout(() => this.navigate(navigation), delay);
      return;
    }

    this.navigate(navigation);
  };

  private navigate = (navigation: CoreModel.NavigationData): void => {
    this.ngZone.run(() => {
      if (!navigation) {
        return;
      }

      if (navigation.path) {
        if (navigation.outlet) {
          const outlets = {};
          outlets[navigation.outlet] = navigation.outletPath || null;
          this.router.navigate([navigation.path, { outlets: outlets }], {
            queryParams: navigation.queryParams,
            state: navigation.state
          });
          return;
        }

        if (navigation.queryParams) {
          this.router.navigate([navigation.path], { queryParams: navigation.queryParams, state: navigation.state });
          return;
        }

        this.router.navigate([navigation.path]);
        return;
      }

      if (navigation.url && this.browserSvc.isBrowser) {
        this.browserSvc.window.location = navigation.url;
      }
    });
  };
}
