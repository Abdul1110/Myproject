import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StandardModel } from '@leap/lyra-design';
import { CoreModel } from '@app/core/models';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private endpoint = '/api/internal';
  constructor(private http: HttpClient) {}

  themes(firmName: string): Observable<StandardModel.ContainerSetting> {
    const url = `${this.endpoint}/api/document/theme/${firmName}`;

    return this.http.get<any>(url, {});
  }

  shareInfo(
    firmName: string,
    email: string,
    nodeId: string,
    eventId: string,
    userId: string,
    requestId: string,
    isFolder: boolean,
    folderId: string,
    collaborationId: string,
    appId: string = '',
    shareId: string = ''
  ): Observable<CoreModel.ShareInfo> {
    const url = isFolder
      ? `${
          this.endpoint
        }/api/document/share/${firmName}/preview?email=${email}&folderId=${folderId}&nodeId=${nodeId}&collaborationId=${collaborationId ||
          ''}`
      : userId && requestId
      ? `${this.endpoint}/api/document/share/${firmName}/preview?userId=${userId}&requestId=${requestId}`
      : appId && shareId
      ? `${this.endpoint}/api/document/share/${firmName}/preview?email=${email}&appId=${appId}&shareId=${shareId}`
      : `${this.endpoint}/api/document/share/${firmName}/preview?email=${email}&nodeId=${nodeId}&eventId=${eventId ||
          ''}`;

    return this.http.get<any>(url, {});
  }

  getShareInfo(
    email: string,
    nodeId: string,
    eventId: string,
    userId: string,
    requestId: string,
    isFolder: boolean,
    folderId: string,
    collaborationId: string,
    appId: string,
    shareId: string
  ): Observable<CoreModel.ShareInfo> {
    const url = isFolder
      ? `${
          this.endpoint
        }/api/document/share/previewinfo?email=${email}&folderId=${folderId}&nodeId=${nodeId}&collaborationId=${collaborationId ||
          ''}`
      : userId && requestId
      ? `${this.endpoint}/api/document/share/previewinfo?userId=${userId}&requestId=${requestId}`
      : appId && shareId
      ? `${this.endpoint}/api/document/share/previewinfo?email=${email}&appId=${appId}&shareId=${shareId}`
      : `${this.endpoint}/api/document/share/previewinfo?email=${email}&nodeId=${nodeId}&eventId=${eventId || ''}`;

    return this.http.get<any>(url, {});
  }
}
