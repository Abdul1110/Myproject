import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UUID } from 'angular2-uuid';
import { NodeModel, CoreModel, SignatureModel } from '../../models';

@Injectable({
  providedIn: 'root'
})
export class NodeService {
  private endpoint = '/api/internal';

  constructor(private http: HttpClient) {}

  documents(userId: string): Observable<NodeModel.LawConnectNode[]> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/nodes?noid=${userId || randomId}`;
    return this.http.get<NodeModel.LawConnectNode[]>(url);
  }

  documentsByFirm(firmId: string): Observable<NodeModel.LawConnectNode[]> {
    const url = `${this.endpoint}/api/document/nodes/${firmId}`;
    return this.http.get<NodeModel.LawConnectNode[]>(url);
  }

  getCollaboration(matterId: string): Observable<CoreModel.Collaboration[]> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/collaboration/${matterId}`;
    return this.http.get<CoreModel.Collaboration[]>(url);
  }

  getSignatures(): Observable<SignatureModel.ESignature[]> {
    const randomId = UUID.UUID();
    const url = `${this.endpoint}/api/document/signatures`;
    return this.http.get<SignatureModel.ESignature[]>(url);
  }

  deleteDocumentDraft(documentIds: string[]): Observable<any> {
    const url = `${this.endpoint}/api/document/upload/draft/delete`;
    return this.http.post<any>(url, { documentIds });
  }

  getNotifications(): Observable<CoreModel.RecentNotification[]> {
    const url = `${this.endpoint}/api/document/notifications`;
    return this.http.get<CoreModel.RecentNotification[]>(url, {
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=0'
      })
    });
  }

  getNotificationsByFirm(firmId: string): Observable<CoreModel.RecentNotification[]> {
    const url = `${this.endpoint}/api/document/notifications/${firmId}`;
    return this.http.get<CoreModel.RecentNotification[]>(url, {
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=0'
      })
    });
  }
}
