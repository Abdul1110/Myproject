import { Injectable } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';

import { AppState } from '@app/core/store/states';
import { CoreModel } from '@app/core/models/core.model';
import { map } from 'rxjs/operators';
import { StandardModel } from '@leap/lyra-design';
import {
  DeleteUploadDraft,
  DeletePendingCollaboration,
  GetCollaborationStart,
  GetMattersStart
} from '@app/core/store/actions/app.actions';
import { SignatureModel, NodeModel } from '@app/core/models';

@Injectable({
  providedIn: 'root'
})
export class AppActionService {
  constructor(private breakpointObserver: BreakpointObserver, private store: Store) {}

  deletePendingUploads(): void {
    const drafts = this.store.selectSnapshot(AppState.getUploadDrafts) || [];
    const pendings = drafts.filter(x => !x.done) || [];
    if (pendings && pendings.length > 0) {
      const ids = pendings.map(x => x.id);
      this.store.dispatch(new DeleteUploadDraft(ids));
    }
  }

  deletePendingCollaborationFromPool(documentId: string): void {
    this.store.dispatch(new DeletePendingCollaboration(documentId));
  }

  updateNodesAndCollaborationFromAPI(matterId: string): void {
    this.store.dispatch([
      new GetCollaborationStart({
        matterId,
        skipPathUpdate: true
      }),
      new GetMattersStart(undefined)
    ]);
  }

  @Select(AppState.getLastNavigatedActionId) lastNavigatedSideActionId$: Observable<string>;

  @Select(AppState.getUploadDrafts) drafts$: Observable<CoreModel.DraftDocument[]>;

  @Select(AppState.getSelectedMatterId) matterId$: Observable<string>;

  @Select(AppState.getSelectedFirm) selectedFirm$: Observable<CoreModel.FirmDetail>;

  @Select(AppState.getUserDocumentAnnotationVisitStatus) firstAnnotationVisit$: Observable<boolean>;

  @Select(AppState.getNavigation) navigation$: Observable<CoreModel.FolderPath[]>;

  @Select(AppState.getCollaboration) collaborations$: Observable<{}>;

  @Select(AppState.getAllCollaborations) allCollaborations$: Observable<{}>;

  @Select(AppState.getIsSidebarExpanded) isSideBarExpanded$: Observable<boolean>;

  @Select(AppState.getAppTheme) theme$: Observable<StandardModel.ThemeSetting>;

  @Select(AppState.getSelectedFirmId) firmId$: Observable<string>;

  @Select(AppState.isWhiteLabel) whiteLabelStatus$: Observable<{ whiteLabel: boolean; firmId: string }>;

  @Select(AppState.getNotificationCount) notificationCount$: Observable<number>;

  @Select(AppState.getLoginUser) logonUser$: Observable<CoreModel.LogonUserInfo>;

  @Select(AppState.getSharePreviewInfo) sharePreview$: Observable<CoreModel.SharePreviewInfo>;

  @Select(AppState.getAppAuthentication) isAuthenticated$: Observable<boolean>;

  @Select(AppState.getPreviewMode) previewMode$: Observable<boolean>;

  @Select(AppState.getPendingCollaboration) uploadPendingCollaboration$: Observable<CoreModel.PendingCollaration[]>;

  @Select(AppState.getSignatures) signatures$: Observable<SignatureModel.ESignature[]>;

  @Select(AppState.getDocumentsByMatter) documentsByMatter$: Observable<{
    [matterId: string]: NodeModel.LawConnectNode[];
  }>;

  @Select(AppState.getAppStoreByMatter) appStoreByMatter$: Observable<{
    [matterId: string]: NodeModel.LawConnectNode[];
  }>;

  isSmallScreen$ = this.breakpointObserver
    .observe(['(max-width: 991.98px)'])
    .pipe(map((state: BreakpointState) => state.matches));
}
