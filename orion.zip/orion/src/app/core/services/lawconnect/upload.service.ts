import { Injectable } from '@angular/core';
import { CoreModel } from '@app/core/models';

@Injectable({
  providedIn: 'root'
})
export class UploadService {
  constructor() {}

  canNavigate(drafts: CoreModel.DraftDocument[] = []) {
    if (!drafts) {
      return true;
    }
    const hasUploadedAll = drafts.reduce((result, x) => {
      return x.done && x.done === true && result;
    }, true);

    if (!hasUploadedAll) {
      return false;
    } else {
      return true;
    }
  }
}
