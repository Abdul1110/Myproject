export const BILLING_ACCOUNT_CHECKLIST = 'billing.account.checklist';
export const BILLING_ACCOUNT_SIDE_DISPLAY = 'billing.account.side';
export const BILLING_TRUST_SIDE_DISPLAY = 'billing.trust.side';
export const BILLING_VIEW_DETAILS_DISPLAY = 'billing.view.details';
export const BILLING_ACCOUNT_MULTIPLE_ACTIONS = 'billing.account.multiple.actions';
export const BILLING_ACCOUNT_MAKE_PAYMENT = 'billing.account.make.payment';

export const COLLABORATIONS_MULTIPLE_ACTIONS = 'collaborations.multiple.actions';
export const COLLABORATIONS_MULTIPLE_ACTIONS_OPEN = 'collaborations.multiple.actions.open';
export const COLLABORATIONS_PREVIEW_ATTACHMENT = 'collaborations.preview.attachment';
export const COLLABORATIONS_LIST_SORTING = 'collaborations.list.sorting';
export const COLLABORATIONS_SIDE_TAB_SWITCH = 'collaborations.side.tab.switch';
export const COLLABORATIONS_SIDE_TAB_TOGGLE = 'collaborations.side.tab.toggle';
export const COLLABORATIONS_LIST_FOLDER_OPEN = 'collaborations.list.folder.open';
export const COLLABORATIONS_LIST_FILE_PREVIEW = 'collaborations.list.file.preview';
export const COLLABORATIONS_LIST_FILE_DELETE = 'collaborations.list.file.delete';
export const COLLABORATIONS_LIST_HOME_VIEW = 'collaborations.list.home.view';
export const COLLABORATIONS_LIST_MY_UPLOADS_ONLY = 'collaborations.list.my.uploads.only';

export const SIGNATURES_LIST_SORTING = 'signatures.list.sorting';
export const SIGNATURES_SIDE_TAB_SWITCH = 'signatures.side.tab.switch';
export const SIGNATURES_LIST_VIEW = 'signatures.list.view';
export const SIGNATURES_LIST_FILE_PREVIEW = 'signatures.list.file.preview';
export const SIGNATURES_SIDE_TAB_TOGGLE = 'signatures.side.tab.toggle';
export const SIGNATURES_MULTIPLE_ACTIONS = 'signatures.multiple.actions';
export const SIGNATURES_MULTIPLE_ACTIONS_OPEN = 'signatures.multiple.actions.open';
export const SIGNATURES_LIST_FILE_SIGN = 'signatures.list.file.sign';
export const SIGNATURES_COMMENT_REPLIED_DELETE = 'signatures.comment.replied.delete';
export const SIGNATURES_COMMENT_CLICK_TO_VIEW = 'signatures.comment.click.to.view';
export const SIGNATURES_SIDE_REFRESH_ME = 'signatures.side.refresh.me';
export const SIGNATURES_PREVIEW_HEADER_DISPLAY = 'signatures.preview.header.display';

export const DOCUMENTS_LIST_SORTING = 'documents.list.sorting';
export const DOCUMENTS_SIDE_TAB_SWITCH = 'documents.side.tab.switch';
export const DOCUMENTS_LIST_VIEW = 'documents.list.view';
export const DOCUMENTS_LIST_FILE_PREVIEW = 'documents.list.file.preview';
export const DOCUMENTS_SIDE_TAB_TOGGLE = 'documents.side.tab.toggle';
export const DOCUMENTS_MULTIPLE_ACTIONS = 'documents.multiple.actions';
export const DOCUMENTS_MULTIPLE_ACTIONS_OPEN = 'documents.multiple.actions.open';
export const DOCUMENTS_LIST_FILE_SIGN = 'documents.list.file.sign';
export const DOCUMENTS_COMMENT_REPLIED_DELETE = 'documents.comment.replied.delete';
export const DOCUMENTS_COMMENT_CLICK_TO_VIEW = 'documents.comment.click.to.view';
export const DOCUMENTS_SIDE_REFRESH_ME = 'documents.side.refresh.me';
export const DOCUMENTS_PREVIEW_HEADER_DISPLAY = 'documents.preview.header.display';
export const DOCUMENTS_LIST_MY_UPLOADS_ONLY = 'documents.list.my.uploads.only';

export const MATTERS_SELECT_CLOSED = 'matters.select.closed';
export const NAVIGATION_SIDE_BAR_TOGGLE = 'navigation.side.bar.toggle';
export const NAVIGATION_SIDE_BAR_TOGGLE_MOBILE = 'navigation.side.bar.toggle.mobile';
export const NAVIGATION_SIDE_BAR_ACTION_SELECTED = 'navigation.side.bar.action.selected';
export const NAVIGATION_SIDE_BAR_UPDATE = 'navigation.side.bar.update';

export const LAYOUT_HOME_INIT_COMPLETED = 'layout.home.init.completed';

export const SUPPORTED_CUSTOM_EVENT = [
  BILLING_ACCOUNT_CHECKLIST,
  BILLING_ACCOUNT_SIDE_DISPLAY,
  BILLING_TRUST_SIDE_DISPLAY,
  BILLING_ACCOUNT_MULTIPLE_ACTIONS,
  BILLING_VIEW_DETAILS_DISPLAY,
  BILLING_ACCOUNT_MAKE_PAYMENT,

  COLLABORATIONS_MULTIPLE_ACTIONS,
  COLLABORATIONS_MULTIPLE_ACTIONS_OPEN,
  COLLABORATIONS_PREVIEW_ATTACHMENT,
  COLLABORATIONS_LIST_SORTING,
  COLLABORATIONS_SIDE_TAB_SWITCH,
  COLLABORATIONS_LIST_FOLDER_OPEN,
  COLLABORATIONS_LIST_FILE_PREVIEW,
  COLLABORATIONS_SIDE_TAB_TOGGLE,
  COLLABORATIONS_LIST_HOME_VIEW,
  COLLABORATIONS_LIST_FILE_DELETE,
  COLLABORATIONS_LIST_MY_UPLOADS_ONLY,

  SIGNATURES_SIDE_TAB_SWITCH,
  SIGNATURES_LIST_FILE_PREVIEW,
  SIGNATURES_SIDE_TAB_TOGGLE,
  SIGNATURES_MULTIPLE_ACTIONS,
  SIGNATURES_MULTIPLE_ACTIONS_OPEN,
  SIGNATURES_LIST_FILE_SIGN,
  SIGNATURES_LIST_SORTING,
  SIGNATURES_COMMENT_REPLIED_DELETE,
  SIGNATURES_LIST_VIEW,
  SIGNATURES_COMMENT_CLICK_TO_VIEW,
  SIGNATURES_SIDE_REFRESH_ME,
  SIGNATURES_PREVIEW_HEADER_DISPLAY,

  DOCUMENTS_SIDE_TAB_SWITCH,
  DOCUMENTS_LIST_FILE_PREVIEW,
  DOCUMENTS_SIDE_TAB_TOGGLE,
  DOCUMENTS_MULTIPLE_ACTIONS,
  DOCUMENTS_MULTIPLE_ACTIONS_OPEN,
  DOCUMENTS_LIST_FILE_SIGN,
  DOCUMENTS_LIST_SORTING,
  DOCUMENTS_COMMENT_REPLIED_DELETE,
  DOCUMENTS_LIST_VIEW,
  DOCUMENTS_COMMENT_CLICK_TO_VIEW,
  DOCUMENTS_SIDE_REFRESH_ME,
  DOCUMENTS_PREVIEW_HEADER_DISPLAY,
  DOCUMENTS_LIST_MY_UPLOADS_ONLY,

  MATTERS_SELECT_CLOSED,
  NAVIGATION_SIDE_BAR_TOGGLE,
  NAVIGATION_SIDE_BAR_ACTION_SELECTED,
  NAVIGATION_SIDE_BAR_TOGGLE_MOBILE,
  NAVIGATION_SIDE_BAR_UPDATE,

  LAYOUT_HOME_INIT_COMPLETED
];
