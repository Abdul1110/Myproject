import { SUPPORTED_CUSTOM_EVENT } from './custom-event.const';

export namespace CustomEventModel {
  export type EventOption = typeof SUPPORTED_CUSTOM_EVENT[number];

  export interface BillingAccountChecklistEventDetail {
    [id: string]: boolean;
  }

  export interface BillingAccountSideDisplayEventDetail {
    show: boolean;
  }

  export interface BillingTrustSideDisplayEventDetail {
    show: boolean;
  }

  export interface BillingViewDetailsDisplayEventDetail {
    show: boolean;
  }

  export interface BillingAccountMultipleActionEventDetail {
    actionType: string;
    value: any;
  }

  export interface MatterSelectClosedDetail {
    path: string;
    returnToActionId: string;
    matterId: string;
  }
}
