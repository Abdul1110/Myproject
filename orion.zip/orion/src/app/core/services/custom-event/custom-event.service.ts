import { Injectable } from '@angular/core';
import { Observable, fromEvent } from 'rxjs';
import { tap } from 'rxjs/operators';
import { BrowserService } from '@leap/lyra-design';

import { CustomEventModel } from './custom-event.model';

@Injectable({
  providedIn: 'root'
})
export class CustomEventService {
  constructor(private browserSvc: BrowserService) {}

  registerEvent(which: CustomEventModel.EventOption, action: (detail: any) => void): Observable<any> {
    const nativeElement = this.browserSvc.window;
    return fromEvent(nativeElement, which).pipe(
      tap(v => {
        const { detail: data } = v as CustomEvent;
        data && action(data);
      })
    );
  }

  dispatchEvent(which: CustomEventModel.EventOption, detail: any): void {
    const nativeElement = this.browserSvc.window;
    nativeElement.dispatchEvent(new CustomEvent(which, { detail: detail, bubbles: true }));
  }
}
