import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  constructor(private toastservice: ToastrService) {}

  showError(message: string, title: string = 'Error') {
    this.toastservice.error(message, title);
  }

  showSuccess(message: string, title: string = 'Success') {
    this.toastservice.success(message, title);
  }
}
