import { Injectable } from '@angular/core';
import { Angulartics2 } from 'angulartics2';
import { Angulartics2GoogleTagManager } from 'angulartics2/gtm';
import { Subscription } from 'rxjs';
import { AnalyticCategories } from '@app/core/constants/analytic.constant';
import { AnalyticModel } from '@app/core/models/analytic.model';
import { PlatformService } from '@app/shared/services/platform/platform.service';

@Injectable()
export class AnalyticService {
  private _navigateEndSub: Subscription;
  constructor(
    private _angulartics2: Angulartics2,
    private _gtm: Angulartics2GoogleTagManager,
    private platformSvc: PlatformService
  ) {}

  startTracking() {
    this._gtm.startTracking();
  }

  initalise(): void {
    this.eventTrack({ category: AnalyticCategories.Init, action: 'Init' });
  }

  eventTrack(model: AnalyticModel): void {
    if (this.platformSvc.isBrowser) {
      this._angulartics2.eventTrack.next({
        action: model.action,
        properties: {
          category: model.category,
          label: model.label,
          value: model.value
        }
      });
    }
  }

  dispose(): void {
    this._navigateEndSub.unsubscribe();
  }
}
