import { versions } from '@env/versions';
import { StandardModel } from '@leap/lyra-design';
import { CoreModel, NodeModel, SignatureModel } from '../../models';
import { AccountModel } from '../../../features/+account/models';

export class InitApp {
  static readonly type = '[App] init';
  constructor(public payload: string) {
    this.payload = versions.version;
  }
}

export class SetNodesInit {
  static readonly type = '[App] nodes has been init';
  constructor(public payload: boolean) {}
}

export class SetSignatureInit {
  static readonly type = '[App] signatures has been init';
  constructor(public payload: boolean) {}
}

export class Logout {
  static readonly type = '[App] logout';
  constructor(public payload: any) {}
}

export class SetAppTheme {
  static readonly type = '[App] set theme';
  constructor(public payload: StandardModel.ContainerSetting) {}
}

export class SetSharePreview {
  static readonly type = '[App] set share preview';
  constructor(public payload: CoreModel.SharePreviewInfo) {}
}

export class GetRoot {
  static readonly type = '[App] get firms if login';
  constructor(public payload: any) {}
}

export class GetRootFailure {
  static readonly type = '[App] Failed to get firms';
  constructor(public payload: any) {}
}

export class SetTermsAndConditionsStatus {
  static readonly type = '[App] set terms and conditions status';
  constructor(public payload: boolean) {} //true >> agree or false >> pending
}

export class SetTermsAndConditionsStatusSuccess {
  static readonly type = '[App] set terms and conditions status success';
  constructor(public payload: boolean) {}
}

export class SetTermsAndConditionsStatusFailure {
  static readonly type = '[App] Failed to save terms and conditions status';
  constructor(public payload: any) {}
}

export class SetDocumentAnnotationVisitStatus {
  static readonly type = '[App] set document annotation visit status';
  constructor(public payload: boolean) {} //true >> user know how to use annotation or false >> new to user
}

export class SetDocumentAnnotationVisitStatusSuccess {
  static readonly type = '[App] set document annotation visit status success';
  constructor(public payload: boolean) {}
}

export class SetDocumentAnnotationVisitStatusFailure {
  static readonly type = '[App] Failed to save document annotation visit status';
  constructor(public payload: any) {}
}

export class SetDocumentSignatureVisitStatus {
  static readonly type = '[App] set signature visit status';
  constructor(public payload: boolean) {} //true >> user know how to use annotation or false >> new to user
}

export class SetDocumentSignatureVisitStatusSuccess {
  static readonly type = '[App] set signature visit status success';
  constructor(public payload: boolean) {}
}

export class SetDocumentSignatureVisitStatusFailure {
  static readonly type = '[App] Failed to save signature visit status';
  constructor(public payload: any) {}
}

export class SetAppAuthencation {
  static readonly type = '[App] set authentication';
  constructor(public payload: { path: string; result: AccountModel.ProfileResponse }) {}
}

export class SetReturnTo {
  static readonly type = '[App] set return to';
  constructor(public payload: string) {}
}

export class AppDefault {
  static readonly type = '[App] default';
  constructor(public payload: any) {}
}

export class SetLoginDefaults {
  static readonly type = '[App] Login default';
  constructor(public payload: any) {}
}

export class SetMatterId {
  static readonly type = '[App] set matter id';
  constructor(public payload: string) {}
}

export class SetFirmId {
  static readonly type = '[App] set firm id';
  constructor(public payload: string) {}
}

export class SetMatterFirmId {
  static readonly type = '[App] set matter and firm id';
  constructor(public payload: CoreModel.SelectedMatter) {}
}

export class GetNotification {
  static readonly type = '[App] get notification';
  constructor(public payload: string) {} //logon user id
}

export class GetNotificationSuccess {
  static readonly type = '[App] get notification success';
  constructor(public payload: { logonUserId: string; data: CoreModel.RecentNotification[] }) {}
}

export class GetNotificationFailure {
  static readonly type = '[App] get notification failure';
  constructor(public payload: any) {}
}

export class SetNotificationCount {
  static readonly type = '[App] set notification count';
  constructor(public payload: number) {}
}

export class ToggleSideBar {
  static readonly type = '[App] toggle side bar';
  constructor() {}
}

export class RedirectToLogin {
  static readonly type = '[App] redirect to login';
  constructor(public payload: string) {} // returnTo
}

export class SetSignUpEmail {
  static readonly type = '[App] set sign up email';
  constructor(public payload: string) {}
}

export class GetMattersStart {
  static readonly type = '[App] get matters start';
  constructor(public payload: any) {}
}

export class GetMattersSuccess {
  static readonly type = '[App] get matters start success';
  constructor(public payload: NodeModel.LawConnectNode[]) {}
}

export class GetMattersFailure {
  static readonly type = '[App] Failed to get matters';
  constructor(public payload: any) {}
}

export class PopulateFirm {
  static readonly type = '[App] populate firm';
  constructor(public payload: NodeModel.LawConnectNode[]) {}
}

export class PopulateMatter {
  static readonly type = '[App] populate matters';
  constructor(public payload: NodeModel.MatterProcessData) {}
}

export class PopulateDocument {
  static readonly type = '[App] populate documents';
  constructor(public payload: NodeModel.DocumentProcessData) {}
}

export class PopulateMyCollaborationFromNodes {
  static readonly type = '[App] populate my collaboration from nodes';
  constructor(public payload: NodeModel.DocumentProcessData) {}
}

export class PopulateAppStore {
  static readonly type = '[App] populate app store';
  constructor(public payload: NodeModel.DocumentProcessData) {}
}

export class PopulateShareMatter {
  static readonly type = '[App] populate share matters';
  constructor(public payload: NodeModel.MatterFirmId[]) {}
}

export class SetFilterFirmId {
  static readonly type = '[App] set filter firm id';
  constructor(public payload: string) {} // firm id
}

export class AddPendingCollaboration {
  static readonly type = '[App] add pending collaboration';
  constructor(public payload: CoreModel.PendingCollaration[]) {}
}

export class DeletePendingCollaboration {
  static readonly type = '[App] delete pending collaboration';
  constructor(public payload: string) {} //documentId
}

export class GetCollaborationStart {
  static readonly type = '[App] get collaboration start';
  constructor(public payload: { matterId: string; skipPathUpdate: boolean }) {}
}

export class GetCollaborationSuccess {
  static readonly type = '[App] get collaboration success';
  constructor(public payload: { matterId: string; data: CoreModel.Collaboration[]; skipPathUpdate: boolean }) {}
}

export class GetCollaborationFailure {
  static readonly type = '[App] Failed to get collaboration';
  constructor(public payload: any) {}
}

export class GotoCollaborationFolder {
  static readonly type = '[App] goto collaboration folder';
  constructor(public payload: { rootId: string; folderId: string; matterId?: string }) {}
}

export class PopulateCurrentCollaboration {
  static readonly type = '[App] populate current collaboration';
  constructor(public payload: { updateNavigation: boolean; data: CoreModel.Collaboration[] }) {}
}

export class SetNavigation {
  static readonly type = '[App] set navigation';
  constructor(public payload: CoreModel.FolderPath[]) {}
}

export class AddCollaborationBin {
  static readonly type = '[App] add collaboration bin';
  constructor(public payload: string) {} //documentId
}

export class DeleteFromCollaborationBin {
  static readonly type = '[App] delete from collaboration bin';
  constructor(public payload: string) {} //documentId
}

export class ValidateNavigationPath {
  static readonly type = '[App] validate navigation path';
  constructor(public payload: string) {} //documentId
}

export class GetSignaturesStart {
  static readonly type = '[App] get signatures data';
  constructor(public payload: boolean) {} // reloadSignatureStatus
}

export class GetSignaturesSuccess {
  static readonly type = '[App] get signatures data success';
  constructor(public payload: { reload: boolean; signatures: SignatureModel.ESignature[] }) {}
}

export class GetSignaturesFailure {
  static readonly type = '[App] Failed to get signatures';
  constructor(public payload: any) {}
}

export class AddSignaturePendingUpdateEntry {
  static readonly type = '[App] add signature pending update entry';
  constructor(public payload: SignatureModel.ESignaturePendingStatus) {}
}

export class RemoveSignaturePendingUpdateFromList {
  static readonly type = '[App] remove signature pending update entry';
  constructor(public payload: string) {} // documentId
}

export class SetPreviewDocumentStatus {
  static readonly type = '[App] set preview document status';
  constructor(public payload: boolean) {} // in preview mode
}

export class UpdateUploadCancelFlag {
  static readonly type = '[App] update upload cancel flag';
  constructor(public payload: { localId: string; flag: boolean }[]) {}
}

export class UpdateUploadCompleteFlag {
  static readonly type = '[App] update upload complete flag';
  constructor(public payload: { localId: string; flag: boolean }[]) {}
}

export class RemoveUploadDraftFromStore {
  static readonly type = '[App] remove upload draft from store';
  constructor(public payload: string[]) {} // local ids.
}

export class DeleteUploadDraft {
  static readonly type = '[App] delete upload draft';
  constructor(public payload: string[]) {} //document ids
}

export class DeleteUploadDraftSuccess {
  static readonly type = '[App] delete upload draft success';
  constructor(public payload: string[]) {} //document ids
}

export class DeleteUploadDraftFailure {
  static readonly type = '[App] Failed to delete upload draft';
  constructor(public payload: any) {}
}

export class DeleteStaleUploadDrafts {
  static readonly type = '[App] delete stale upload drafts';
  constructor(public payload: string[]) {}
}

export class DeleteStaleUploadDraftsSuccess {
  static readonly type = '[App] delete stale upload drafts success';
  constructor(public payload: any) {}
}

export class DeleteStaleUploadDraftsFailure {
  static readonly type = '[App] Failed to delete stale upload drafts';
  constructor(public payload: any) {}
}

export class AddUploadDraftToStore {
  static readonly type = '[App] add upload draft to store';
  constructor(public payload: CoreModel.DraftDocument[]) {}
}

export class SetWalkMeVariables {
  static readonly type = '[App] set walkme variables';
  constructor(public payload: any) {}
}

export class SetNavigationActionId {
  static readonly type = '[App] set navigated action id';
  constructor(public payload: string) {}
}
