import { State, Action, StateContext, NgxsOnInit, Selector } from '@ngxs/store';
import { Title } from '@angular/platform-browser';
import { NgZone } from '@angular/core';
import { Router, Params } from '@angular/router';
import * as SentryBrowser from '@sentry/browser';
import { StandardModel, BrowserService, LyraDesignCardModel } from '@leap/lyra-design';
import produce from 'immer';
import { map, catchError } from 'rxjs/operators';

import { environment } from '@env/environment';

import { AppSlice } from '@core/store/app.slice';
import {
  InitApp,
  SetAppTheme,
  SetAppAuthencation,
  SetReturnTo,
  SetTermsAndConditionsStatus,
  SetDocumentAnnotationVisitStatus,
  SetDocumentSignatureVisitStatus,
  SetTermsAndConditionsStatusFailure,
  SetTermsAndConditionsStatusSuccess,
  SetDocumentAnnotationVisitStatusSuccess,
  SetDocumentAnnotationVisitStatusFailure,
  SetDocumentSignatureVisitStatusSuccess,
  SetDocumentSignatureVisitStatusFailure,
  GetRoot,
  GetRootFailure,
  SetLoginDefaults,
  SetSharePreview,
  SetMatterId,
  SetFirmId,
  SetMatterFirmId,
  SetNotificationCount,
  Logout,
  ToggleSideBar,
  RedirectToLogin,
  SetSignUpEmail,
  GetMattersStart,
  GetMattersSuccess,
  GetMattersFailure,
  PopulateFirm,
  PopulateMatter,
  PopulateDocument,
  PopulateShareMatter,
  SetNodesInit,
  SetFilterFirmId,
  AddPendingCollaboration,
  GetCollaborationStart,
  GetCollaborationSuccess,
  GetCollaborationFailure,
  PopulateCurrentCollaboration,
  GotoCollaborationFolder,
  SetNavigation,
  AddCollaborationBin,
  DeleteFromCollaborationBin,
  ValidateNavigationPath,
  DeletePendingCollaboration,
  GetSignaturesStart,
  GetSignaturesSuccess,
  GetSignaturesFailure,
  SetSignatureInit,
  AddSignaturePendingUpdateEntry,
  RemoveSignaturePendingUpdateFromList,
  SetPreviewDocumentStatus,
  UpdateUploadCancelFlag,
  UpdateUploadCompleteFlag,
  RemoveUploadDraftFromStore,
  DeleteUploadDraft,
  DeleteUploadDraftSuccess,
  DeleteUploadDraftFailure,
  DeleteStaleUploadDrafts,
  DeleteStaleUploadDraftsSuccess,
  DeleteStaleUploadDraftsFailure,
  AddUploadDraftToStore,
  SetWalkMeVariables,
  SetNavigationActionId,
  GetNotification,
  GetNotificationSuccess,
  GetNotificationFailure,
  PopulateAppStore
} from '@core/store/actions';
import { CoreModel, NodeModel, SignatureModel } from '../../models';
import { UserMetadataService, NodeService, NavigationService } from '../../services';
import { RecentAction } from '@app/features/+recent/store/actions/recent.actions';

export interface CoreStateModel {
  version: string;
  theme: StandardModel.ContainerSetting;
  isAuthenticated: boolean;
  returnTo: string;
  userId: string;
  displayName: string;
  firstName: string;
  lastName: string;
  email: string;
  rememberMe: boolean;
  hasAgreeTermsAndConditions: boolean;
  documentAnnotationVisited: boolean;
  documentSignatureVisited: boolean;
  updateUserMetadataLoading: boolean;
  error: string;
  sharePreview: CoreModel.SharePreviewInfo;
  matterId: string;
  firmId: string;
  isWhiteLabel: boolean;
  notificationCount: number;
  isSidebarExpanded: boolean;
  isNodesInit: boolean;
  isSignatureInit: boolean;
  nodesStatus: CoreModel.DataStatus;
  signaturesStatus: CoreModel.DataStatus;
  badgesStatus: CoreModel.DataStatus;
  nodes: NodeModel.LawConnectNode[];
  firms: { [firmId: string]: NodeModel.LawConnectNode[] };
  matters: { [firmId: string]: NodeModel.LawConnectNode[] };
  shareMatters: { [matterId: string]: NodeModel.SharedMatterDetails };
  documents: { [matterId: string]: NodeModel.LawConnectNode[] };
  signatures: SignatureModel.ESignature[];
  signaturesLoading: boolean;
  signaturePendingUpdate: { [documentId: string]: SignatureModel.ESignaturePendingStatus };
  badges: { [documentId: string]: NodeModel.DocumentBadgeState[] };
  selectedFilterFirmId: string;
  collaborationLoading: boolean;
  collaboration: { [matterId: string]: CoreModel.Collaboration[] };
  currentCollaboration: { [rootId: string]: CoreModel.Collaboration[] };
  uploadCollaborationId: string;
  collaborationBin: string[];
  pendingCollaboration: CoreModel.PendingCollaration[];
  navigation: CoreModel.FolderPath[];
  previewDocument: boolean;
  uploadDrafts: CoreModel.DraftDocument[];
  lastNavigatedSideActionId: string;
  appStore: { [matterId: string]: NodeModel.LawConnectNode[] };
}

export const initialState: CoreStateModel = {
  version: '0.0.0',
  theme: undefined,
  isAuthenticated: false,
  returnTo: undefined,
  userId: undefined,
  displayName: undefined,
  firstName: undefined,
  lastName: undefined,
  email: undefined,
  rememberMe: false,
  hasAgreeTermsAndConditions: false,
  documentAnnotationVisited: false,
  documentSignatureVisited: false,
  updateUserMetadataLoading: false,
  error: undefined,
  sharePreview: undefined,
  matterId: undefined,
  firmId: undefined,
  isWhiteLabel: false,
  notificationCount: 0,
  isSidebarExpanded: false,
  isNodesInit: false,
  isSignatureInit: false,
  nodesStatus: { loading: false, error: undefined },
  signaturesStatus: { loading: false, error: undefined },
  badgesStatus: { loading: false, error: undefined },
  nodes: [],
  firms: {},
  matters: {},
  shareMatters: {},
  documents: {},
  signatures: [],
  signaturesLoading: false,
  signaturePendingUpdate: {},
  badges: {},
  selectedFilterFirmId: undefined,
  collaborationLoading: false,
  collaboration: {},
  currentCollaboration: {},
  uploadCollaborationId: '',
  collaborationBin: [],
  pendingCollaboration: [],
  navigation: [],
  previewDocument: false,
  uploadDrafts: [],
  lastNavigatedSideActionId: '',
  appStore: undefined
};

@State<CoreStateModel>({
  name: AppSlice.App,
  defaults: initialState
})
export class AppState implements NgxsOnInit {
  constructor(
    private browserSvc: BrowserService,
    private userMetadataSvc: UserMetadataService,
    private titleService: Title,
    private nodeSvc: NodeService,
    private router: Router,
    private ngZone: NgZone,
    private navigationSvc: NavigationService
  ) {}

  ngxsOnInit(ctx: StateContext<CoreStateModel>) {
    console.log('State initialized, now calling initApp');
    ctx.dispatch(new InitApp(null));
  }

  @Action(SetNavigationActionId)
  SetNavigationActionId({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const actionId = payload.payload as string;

    setState({
      ...state,
      lastNavigatedSideActionId: actionId
    });
  }

  @Action(SetPreviewDocumentStatus)
  SetPreviewDocumentStatus({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const open = payload.payload as boolean;

    setState({
      ...state,
      previewDocument: open
    });
  }

  @Action(SetNodesInit)
  SetNodesInit(ctx: StateContext<CoreStateModel>, action: SetNodesInit) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.isNodesInit = action.payload;
      })
    );
  }

  @Action(SetSignatureInit)
  SetSignatureInit(ctx: StateContext<CoreStateModel>, action: SetSignatureInit) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.isSignatureInit = action.payload;
      })
    );
  }

  @Action(InitApp)
  initApp(ctx: StateContext<CoreStateModel>, action: InitApp) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.version = `${action.payload}`;
      })
    );
  }

  @Action(SetMatterId)
  SetMatterId(ctx: StateContext<CoreStateModel>, action: SetMatterId) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.matterId = action.payload;
      })
    );
  }

  @Action(SetFirmId)
  SetFirmId(ctx: StateContext<CoreStateModel>, action: SetFirmId) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.firmId = action.payload;
      })
    );
  }

  @Action(SetMatterFirmId)
  SetMatterFirmId(ctx: StateContext<CoreStateModel>, action: SetMatterFirmId) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.matterId = action.payload ? action.payload.matterId : undefined;
        app.firmId = action.payload ? action.payload.firmId : undefined;

        environment.production && SentryBrowser.setExtra('firmId', app.firmId);

        // fix the incorrect firm name.
        if (
          app.currentCollaboration &&
          app.currentCollaboration['empty'] &&
          app.currentCollaboration['empty'].length > 0 &&
          app.firms[app.firmId]
        ) {
          const empty = app.currentCollaboration['empty'].map((m, idx) => {
            if (idx === 0) {
              return { ...m, name: `Collaboration with ${app.firms[app.firmId][0].name}` };
            }
            return { ...m };
          });

          app.currentCollaboration = { ...app.currentCollaboration, ...{ empty: empty } };
        }
      })
    );
  }

  @Action(SetAppTheme)
  setAppTheme(ctx: StateContext<CoreStateModel>, action: SetAppTheme) {
    const isWhiteLabel = action.payload ? action.payload.firmId && !action.payload.firmNotFound : false;
    const firmId = action.payload ? action.payload.firmId : undefined;
    const firmName = action.payload ? action.payload.firmName : undefined;
    const firmLogoUrl =
      isWhiteLabel && !!firmId
        ? `${environment.appSettings.apiBaseUrl}v1/dto/whitelabel/assets/firm/${firmId}/logo`
        : '/assets/images/lawconnect/header-logo-dark.svg';
    const appTheme = action.payload;

    appTheme.themeSetting = { ...appTheme.themeSetting, ...{ firmLogoUrl } };

    ctx.setState(
      produce(ctx.getState(), app => {
        app.theme = appTheme;
        app.firmId = action.payload ? action.payload.firmId : undefined;
        app.isWhiteLabel = isWhiteLabel;
      })
    );

    if (isWhiteLabel && !!firmName) {
      this.titleService.setTitle(firmName);
    }

    const walkMeVariables = {
      env: environment.appSettings.environment,
      whiteLabel: isWhiteLabel,
      firmId: firmId,
      firmName: firmName,
      firmLogoUrl: firmLogoUrl
    };

    ctx.dispatch(new SetWalkMeVariables(walkMeVariables));
  }

  @Action(SetSharePreview)
  SetSharePreview(ctx: StateContext<CoreStateModel>, action: SetSharePreview) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.sharePreview = action.payload;
      })
    );
  }

  @Action(ToggleSideBar)
  ToggleSideBar(ctx: StateContext<CoreStateModel>, action: ToggleSideBar) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.isSidebarExpanded = !app.isSidebarExpanded;
      })
    );
  }

  @Action(GetRoot, { cancelUncompleted: true })
  GetRoot(ctx: StateContext<CoreStateModel>, action: GetRoot) {
    return this.userMetadataSvc.root().pipe(
      map(ok => {
        if (ok && ok.length > 0) {
          const firmId = ok[0].id;
          ctx.dispatch(
            new SetAppTheme({
              firmId,
              themeSetting: undefined,
              containsSetting: false,
              firmName: '',
              firmNotFound: true
            })
          );
        }
      }),
      catchError(error => ctx.dispatch(new GetRootFailure(error)))
    );
  }

  @Action(GetRootFailure)
  GetRootFailure(ctx: StateContext<CoreStateModel>, action: GetRootFailure) {
    const error = action.payload as any;
    const msg = this.browserSvc.getStandardError(error);

    ctx.setState(
      produce(ctx.getState(), app => {
        app.error = msg.message;
      })
    );
  }

  @Action(SetTermsAndConditionsStatus)
  setTermsAndConditionsStatus(ctx: StateContext<CoreStateModel>, action: SetTermsAndConditionsStatus) {
    const consent = { has_agree_to_lawconnect_privacy: action.payload };

    ctx.setState(
      produce(ctx.getState(), app => {
        app.updateUserMetadataLoading = true;
      })
    );

    return this.userMetadataSvc.setUserMetadata(consent).pipe(
      map(ok => ctx.dispatch(new SetTermsAndConditionsStatusSuccess(consent.has_agree_to_lawconnect_privacy))),
      catchError(error => ctx.dispatch(new SetTermsAndConditionsStatusFailure(error)))
    );
  }

  @Action(SetTermsAndConditionsStatusSuccess)
  setTermsAndConditionsStatusSuccess(ctx: StateContext<CoreStateModel>, action: SetTermsAndConditionsStatusSuccess) {
    const consent = action.payload;

    ctx.setState(
      produce(ctx.getState(), app => {
        app.hasAgreeTermsAndConditions = consent;
        app.updateUserMetadataLoading = false;
      })
    );

    this.navigationSvc.goto(<CoreModel.NavigationData>{ path: '/recents' });
  }

  @Action(SetTermsAndConditionsStatusFailure)
  SetTermsAndConditionsStatusFailure(ctx: StateContext<CoreStateModel>, action: SetTermsAndConditionsStatusFailure) {
    const error = action.payload as any;
    const msg = this.browserSvc.getStandardError(error);

    ctx.setState(
      produce(ctx.getState(), app => {
        app.updateUserMetadataLoading = false;
        app.error = msg.message;
      })
    );
  }

  @Action(SetDocumentAnnotationVisitStatus)
  SetDocumentAnnotationVisitStatus(ctx: StateContext<CoreStateModel>, action: SetDocumentAnnotationVisitStatus) {
    const consent = { document_annotation_visited: action.payload };

    ctx.setState(
      produce(ctx.getState(), app => {
        app.updateUserMetadataLoading = true;
      })
    );

    return this.userMetadataSvc.setUserMetadata(consent).pipe(
      map(ok => ctx.dispatch(new SetDocumentAnnotationVisitStatusSuccess(consent.document_annotation_visited))),
      catchError(error => ctx.dispatch(new SetDocumentAnnotationVisitStatusFailure(error)))
    );
  }

  @Action(SetDocumentAnnotationVisitStatusSuccess)
  SetDocumentAnnotationVisitStatusSuccess(
    ctx: StateContext<CoreStateModel>,
    action: SetDocumentAnnotationVisitStatusSuccess
  ) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.documentAnnotationVisited = action.payload;
        app.updateUserMetadataLoading = false;
      })
    );
  }

  @Action(SetDocumentAnnotationVisitStatusFailure)
  SetDocumentAnnotationVisitStatusFailure(
    ctx: StateContext<CoreStateModel>,
    action: SetDocumentAnnotationVisitStatusFailure
  ) {
    const error = action.payload as any;
    const msg = this.browserSvc.getStandardError(error);

    ctx.setState(
      produce(ctx.getState(), app => {
        app.updateUserMetadataLoading = false;
        app.error = msg.message;
      })
    );
  }

  @Action(SetDocumentSignatureVisitStatus)
  SetDocumentSignatureVisitStatus(ctx: StateContext<CoreStateModel>, action: SetDocumentSignatureVisitStatus) {
    const consent = { document_esignature_visited: action.payload };

    ctx.setState(
      produce(ctx.getState(), app => {
        app.updateUserMetadataLoading = true;
      })
    );

    return this.userMetadataSvc.setUserMetadata(consent).pipe(
      map(ok => ctx.dispatch(new SetDocumentSignatureVisitStatusSuccess(consent.document_esignature_visited))),
      catchError(error => ctx.dispatch(new SetDocumentSignatureVisitStatusFailure(error)))
    );
  }

  @Action(SetDocumentSignatureVisitStatusSuccess)
  SetDocumentSignatureVisitStatusSuccess(
    ctx: StateContext<CoreStateModel>,
    action: SetDocumentSignatureVisitStatusSuccess
  ) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.documentSignatureVisited = action.payload;
        app.updateUserMetadataLoading = false;
      })
    );
  }

  @Action(SetDocumentSignatureVisitStatusFailure)
  SetDocumentSignatureVisitStatusFailure(
    ctx: StateContext<CoreStateModel>,
    action: SetDocumentSignatureVisitStatusFailure
  ) {
    const error = action.payload as any;
    const msg = this.browserSvc.getStandardError(error);
    ctx.setState(
      produce(ctx.getState(), app => {
        app.updateUserMetadataLoading = false;
        app.error = msg.message;
      })
    );
  }

  @Action(SetAppAuthencation)
  setAppAuthencation(ctx: StateContext<CoreStateModel>, action: SetAppAuthencation) {
    const { path, result } = action.payload as { path: string; result: CoreModel.SignInMeta };
    const {
      login,
      userId,
      displayName,
      firstName,
      lastName,
      email,
      hasAgreeTermsAndConditions,
      documentAnnotationVisited,
      documentSignatureVisited
    } = result;

    ctx.setState(
      produce(ctx.getState(), app => {
        app.isAuthenticated = login;
        app.userId = userId;
        app.displayName = displayName;
        app.firstName = firstName;
        app.lastName = lastName;
        app.email = email;
        app.hasAgreeTermsAndConditions = hasAgreeTermsAndConditions;
        app.documentAnnotationVisited = documentAnnotationVisited;
        app.documentSignatureVisited = documentSignatureVisited;

        if (!action.payload) {
          app.theme = undefined;
        }
      })
    );

    if (environment.production && !!login) {
      SentryBrowser.setExtra('email', email);
    }

    const walkMeVariables = {
      userId: userId,
      firstName: firstName,
      lastName: lastName,
      email: email
    };
    ctx.dispatch(new SetWalkMeVariables(walkMeVariables));

    if (action.payload) {
      const state = ctx.getState();
      const isWhiteLabel = state.theme && state.theme.firmId;
      const asideOutlet = path.indexOf('aside:select') > -1;

      const outlets = {};
      if (asideOutlet) {
        outlets['aside'] = 'select' || null;
      }

      !isWhiteLabel && ctx.dispatch(new GetRoot(undefined));

      const pathToGo = path.replace('/(aside:select)', '');
      const hasQuery = path.split('?').length > 1;

      if (asideOutlet) {
        this.navigationSvc.goto(<CoreModel.NavigationData>{
          path: pathToGo,
          outlet: 'aside',
          outletPath: outlets['aside']
        });
        return;
      }

      if (hasQuery) {
        this.navigationSvc.goto(<CoreModel.NavigationData>{
          path: path.split('?')[0],
          queryParams: { ...this.getParams(path.split('?')[1]) }
        });
        return;
      }

      this.navigationSvc.goto(<CoreModel.NavigationData>{
        path
      });
      return;
    }

    this.navigationSvc.goto(<CoreModel.NavigationData>{
      path: '/account/signin'
    });
    return;
  }

  @Action(SetWalkMeVariables)
  SetWalkMeVariables(ctx: StateContext<CoreStateModel>, action: SetWalkMeVariables) {
    const data = action.payload;
    const walkMeVariableName = 'leap-user';
    const currentData = window[walkMeVariableName];

    window[walkMeVariableName] = { ...currentData, ...data };
  }

  private getParams(qp: string): Params {
    const result = qp.split('&').map(x => {
      const c = x.split('=');
      return { [c[0]]: c[1] };
    });
    return result.reduce((x, y) => Object.assign(x, y));
  }

  @Action(SetLoginDefaults)
  setLoginDefaults(ctx: StateContext<CoreStateModel>, action: SetLoginDefaults) {
    const rememberMe = action.payload as any;
    ctx.setState(
      produce(ctx.getState(), app => {
        app.rememberMe = rememberMe;
      })
    );
  }

  @Action(Logout)
  Logout(ctx: StateContext<CoreStateModel>, action: Logout) {
    return this.userMetadataSvc.signout().pipe(
      map(ok => {
        this.navigationSvc.goto(<CoreModel.NavigationData>{ path: 'account/signin' });
        return null;
      }),
      catchError(err => {
        this.navigationSvc.goto(<CoreModel.NavigationData>{ path: 'account/signin' });
        return err;
      })
    );
  }

  @Action(SetReturnTo)
  setReturnTo(ctx: StateContext<CoreStateModel>, action: SetReturnTo) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.returnTo = action.payload;
      })
    );
  }

  @Action(GetNotification, { cancelUncompleted: true })
  GetNotification({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const logonUserId = payload.payload as string;

    const siteEnv = state.isWhiteLabel;

    if (state && state.isWhiteLabel) {
      return this.nodeSvc.getNotificationsByFirm(state.firmId).pipe(
        map(notifications => dispatch(new GetNotificationSuccess({ logonUserId, data: notifications }))),
        catchError(error => dispatch(new GetNotificationFailure(error)))
      );
    }

    // Generic LC shows all notifications regardless selected firm.
    return this.nodeSvc.getNotifications().pipe(
      map(notifications => dispatch(new GetNotificationSuccess({ logonUserId, data: notifications }))),
      catchError(error => dispatch(new GetNotificationFailure(error)))
    );
  }

  @Action(GetNotificationSuccess)
  GetNotificationSuccess({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const notifications = payload.payload as { logonUserId; data: CoreModel.RecentNotification[] };
    const briefNotifications = (notifications && notifications.data && notifications.data) || [];

    return dispatch([new SetNotificationCount(briefNotifications.length)]);
  }

  @Action(GetNotificationFailure)
  GetNotificationFailure({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    if (err && err.status == '403') {
      return dispatch(new RedirectToLogin(`${this.router.url}`));
    }
  }

  @Action(SetNotificationCount)
  setNotificationCount(ctx: StateContext<CoreStateModel>, action: SetNotificationCount) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.notificationCount = action.payload;
      })
    );
  }

  @Action(RedirectToLogin)
  RedirectToLogin(ctx: StateContext<CoreStateModel>, action: RedirectToLogin) {
    const returnTo = action.payload as string;
    const state = ctx.getState();

    if (!state.isAuthenticated) {
      return;
    }

    if (returnTo) {
      ctx.setState(
        produce(ctx.getState(), app => {
          app.returnTo = returnTo;
          app.isAuthenticated = false;
        })
      );

      this.navigationSvc.goto(<CoreModel.NavigationData>{ path: 'account/signin' });
      return;
    }

    ctx.setState(
      produce(ctx.getState(), app => {
        app.returnTo = undefined;
        app.isAuthenticated = false;
      })
    );
    this.navigationSvc.goto(<CoreModel.NavigationData>{ path: 'account/signin' });
  }

  @Action(SetSignUpEmail)
  setSignupEmail(ctx: StateContext<CoreStateModel>, action: SetSignUpEmail) {
    ctx.setState(
      produce(ctx.getState(), app => {
        app.email = action.payload;
      })
    );
  }

  @Action(GetMattersStart, { cancelUncompleted: true })
  GetMattersStart({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();

    setState({
      ...state,
      nodesStatus: { loading: true, error: undefined },
      nodes: []
    });

    if (state.isWhiteLabel) {
      return this.nodeSvc.documentsByFirm(state.firmId).pipe(
        map(documents => dispatch(new GetMattersSuccess(documents))),
        catchError(error => dispatch(new GetMattersFailure(error)))
      );
    }

    return this.nodeSvc.documents(state.userId).pipe(
      map(documents => dispatch(new GetMattersSuccess(documents))),
      catchError(error => dispatch(new GetMattersFailure(error)))
    );
  }

  @Action(GetMattersSuccess)
  GetMattersSuccess({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const nodes = payload.payload as NodeModel.LawConnectNode[];

    setState({
      ...state,
      nodesStatus: { loading: false, error: undefined },
      nodes: nodes || []
    });

    return dispatch(new PopulateFirm(nodes));
  }

  @Action(GetMattersFailure)
  GetMatttersFailure({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      nodesStatus: { loading: false, error: err.message }
    });
  }

  @Action(PopulateFirm)
  PopulateFirm({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const nodes = payload.payload as NodeModel.LawConnectNode[];
    const firmIds = nodes ? nodes.filter(x => x.nodeType === NodeModel.NodeType.Firm).map(n => n.id) : [];

    const firms = {};
    firmIds.forEach(id => {
      firms[id] = nodes.filter(d => d.id === id);
    });

    setState({
      ...state,
      firms
    });

    return dispatch(
      new PopulateMatter(<NodeModel.MatterProcessData>{
        firmIds,
        nodes
      })
    );
  }

  @Action(PopulateMatter)
  PopulateMatter({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const data = payload.payload as NodeModel.MatterProcessData;
    const nodes = data.nodes;
    const firmIds = data.firmIds;

    const matters: { [firmId: string]: NodeModel.LawConnectNode[] } = {};
    firmIds.forEach(firmId => {
      matters[firmId] = nodes.filter(d => d.parentId === firmId && d.nodeType === NodeModel.NodeType.Matter);
    });

    setState({
      ...state,
      matters
    });

    const matterList =
      matters && Object.values(matters).length > 0 ? Object.values(matters).reduce((a, b) => a.concat(b)) : [];
    const matterIds = Array.from(matterList.map(x => x.id));
    const sharedMatters = Array.from(
      matterList
        .filter(y => y.isSharedMatter === true)
        .map(x => <NodeModel.MatterFirmId>{ matterId: x.id, firmId: x.parentId })
    );

    const nextValue = <NodeModel.DocumentProcessData>{
      matterIds,
      sharedMatters,
      nodes
    };
    return dispatch([new PopulateDocument(nextValue), new PopulateAppStore(nextValue)]);
  }

  @Action(PopulateDocument)
  PopulateDocument({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const data = payload.payload as NodeModel.DocumentProcessData;
    const { matterIds, sharedMatters, nodes } = data;

    const documents = {};
    matterIds.forEach(matterId => {
      documents[matterId] = nodes.filter(d => d.parentId === matterId && d.nodeType != NodeModel.NodeType.App);
    });

    setState({
      ...state,
      documents
    });

    sharedMatters && sharedMatters.length > 0 && dispatch(new PopulateShareMatter(sharedMatters));
  }

  @Action(PopulateAppStore)
  PopulateAppStore({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const data = payload.payload as NodeModel.DocumentProcessData;
    const { matterIds, nodes } = data;

    const appStore = {};
    matterIds.forEach(matterId => {
      appStore[matterId] = nodes.filter(d => d.parentId === matterId && d.nodeType === NodeModel.NodeType.App);
    });

    setState({
      ...state,
      appStore
    });
  }

  @Action(PopulateShareMatter)
  PopulateShareMatter({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const sharedMatters = payload.payload as NodeModel.MatterFirmId[];

    let shared = Object.assign({}, state.shareMatters);
    sharedMatters.forEach(m => {
      if (!shared[m.matterId]) {
        shared[m.matterId] = undefined;
      }
    });

    setState({
      ...state,
      shareMatters: shared
    });
  }

  @Action(SetFilterFirmId)
  SetFilterFirmId({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const firmId = payload.payload as string;

    setState({
      ...state,
      selectedFilterFirmId: firmId
    });
  }

  @Action(AddPendingCollaboration)
  AddPendingCollaboration({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const pendings = payload.payload as CoreModel.PendingCollaration[];

    setState({
      ...state,
      pendingCollaboration: [].concat(state.pendingCollaboration).concat(pendings)
    });
  }

  @Action(DeletePendingCollaboration)
  DeletePendingCollaboration({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentId = payload.payload as string;
    const remainings =
      (state.pendingCollaboration && state.pendingCollaboration.filter(x => x.fileId !== documentId)) || [];

    setState({
      ...state,
      pendingCollaboration: [].concat(remainings)
    });
  }

  @Action(GetCollaborationStart, { cancelUncompleted: true })
  GetCollaborationStart({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const { matterId, skipPathUpdate } = payload.payload as { matterId: string; skipPathUpdate: boolean };

    setState({
      ...state,
      collaborationLoading: true,
      error: undefined
    });

    return this.nodeSvc.getCollaboration(matterId).pipe(
      map(data => dispatch(new GetCollaborationSuccess({ matterId, data, skipPathUpdate }))),
      catchError(error => dispatch(new GetCollaborationFailure(error)))
    );
  }

  @Action(GetCollaborationSuccess)
  GetCollaborationSuccess({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const { matterId, data: sharedFoldersAndDocs, skipPathUpdate } = payload.payload as {
      matterId: string;
      data: CoreModel.Collaboration[];
      skipPathUpdate: boolean;
    };

    const collaboration = state.collaboration;
    const firm = AppState.getSelectedFirm(state);
    const collaborationFolder =
      sharedFoldersAndDocs && sharedFoldersAndDocs.length > 0
        ? [].concat(
            sharedFoldersAndDocs.map(c =>
              c.parent
                ? c
                : // #collaboration uploading: we need to provide 'empty-1' as id and only happen if lawyer share folder (manually created) prior any default document share.
                  { ...c, id: 'empty-1', parent: { name: 'Home', id: null, parent: null } }
            )
          )
        : [].concat(<CoreModel.Collaboration>{
            documents: [],
            folders: [],
            fullDocuments: [],
            id: 'empty',
            name: `Collaboration with ${(firm && firm.name) || '-'}`,
            parent: { name: 'Home', id: null, parent: null }
          });

    const hasEmpty1Id = !!(
      collaborationFolder &&
      collaborationFolder.length > 0 &&
      collaborationFolder.findIndex((x: CoreModel.Collaboration) => x.id.includes('empty-1')) !== -1
    );
    const hasEmpty1InCurrentCollaboration = !!(state.currentCollaboration && state.currentCollaboration['empty-1']);

    setState({
      ...state,
      collaborationLoading: false,
      error: undefined,
      collaboration: Object.assign({}, collaboration, { [matterId]: collaborationFolder }),
      currentCollaboration: skipPathUpdate
        ? // #collaboration uploading: collaborationFolder.length > 0 requies to ensure folder has been uploaded and display in list.
          // #collaboration uploading: The pending is yet to be removed after api dislay with uploaded item. This is because user may switch to another feature e.g. Billing and back to Collaboration page.
          !hasEmpty1Id && hasEmpty1InCurrentCollaboration && collaborationFolder.length > 0
          ? { ...this.getOtherThanEmpty1(state.currentCollaboration) }
          : state.currentCollaboration
        : {},
      navigation: skipPathUpdate ? state.navigation : []
    });

    let nextFolder: CoreModel.FolderPath = undefined;
    if (skipPathUpdate && state.navigation.length > 0) {
      nextFolder = Object.assign({}, state.navigation[state.navigation.length - 1]);
    }

    const currentCollaborations = collaborationFolder
      .filter(z => !nextFolder || nextFolder.collaborationId !== z.id)
      .map(x => {
        return new PopulateCurrentCollaboration({ updateNavigation: false, data: [x] });
      });

    if (nextFolder && collaborationFolder.findIndex(c => c.id == nextFolder.collaborationId) > -1) {
      return dispatch(
        []
          .concat(new GotoCollaborationFolder({ rootId: nextFolder.collaborationId, folderId: nextFolder.id }))
          .concat(currentCollaborations)
      );
    }

    return dispatch(currentCollaborations);
  }

  private getOtherThanEmpty1(value: {}): {} {
    let newValue = {};
    Object.keys(value).forEach(k => {
      if (k !== 'empty-1') {
        newValue[k] = value[k];
      }
    });
    return newValue;
  }

  @Action(GetCollaborationFailure)
  GetCollaborationFailure({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      collaborationLoading: false,
      error: err.message
    });

    if (err && err.status == '403') {
      return dispatch(new RedirectToLogin(`${this.router.url}`));
    }
  }

  @Action(GotoCollaborationFolder)
  GotoCollaborationFolder({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const { folderId, rootId, matterId: selectedMatterId } = payload.payload as {
      rootId: string;
      folderId: string;
      matterId?: string;
    };

    const isAllEmpty = rootId == folderId && !rootId;
    const matterId = selectedMatterId || state.matterId;

    if (isAllEmpty) {
      const rootFolder =
        state.collaboration &&
        state.collaboration[matterId] &&
        state.collaboration[matterId].length > 0 &&
        state.collaboration[matterId][0];

      return dispatch(new PopulateCurrentCollaboration({ updateNavigation: false, data: [rootFolder] }));
    }

    const collaborations =
      state.collaboration && state.collaboration[matterId] && state.collaboration[matterId].length > 0
        ? state.collaboration[matterId]
        : undefined;
    const targetRootIndex = collaborations ? collaborations.findIndex(f => f.id === rootId) : -1;
    const targetRoot = targetRootIndex > -1 ? collaborations[targetRootIndex] : undefined;

    if (rootId === folderId) {
      return dispatch([
        new PopulateCurrentCollaboration({ updateNavigation: false, data: [targetRoot] }),
        new SetNavigation([
          <CoreModel.FolderPath>{
            id: folderId,
            collaborationId: rootId,
            name: targetRoot.name,
            source: CoreModel.DocumentFilter.collaboration
          }
        ])
      ]);
    }

    const targetFolders = targetRoot
      ? targetRoot.folders
          .map(fd => {
            const r = this.getFolders(folderId, fd, undefined);
            return r;
          })
          .reduce((a, b) => a.concat(b))
          .filter(z => z) || []
      : [];

    if (targetFolders && targetFolders.length > 0) {
      return dispatch(new PopulateCurrentCollaboration({ updateNavigation: true, data: targetFolders }));
    }
  }

  @Action(SetNavigation)
  SetNavigation({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const navigation = payload.payload as CoreModel.FolderPath[];

    setState({
      ...state,
      navigation
    });

    if (navigation && navigation.length == 0) {
      return dispatch(new GotoCollaborationFolder({ rootId: null, folderId: null }));
    }
  }

  @Action(PopulateCurrentCollaboration)
  PopulateCurrentCollaboration({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const { data: nextFoldersFromRoot, updateNavigation, skipPathUpdate } = payload.payload as {
      data: CoreModel.Collaboration[];
      updateNavigation: boolean;
      skipPathUpdate: boolean;
    };

    const rootId =
      nextFoldersFromRoot && nextFoldersFromRoot.length > 0 && nextFoldersFromRoot[0]
        ? (nextFoldersFromRoot[0].parent && nextFoldersFromRoot[0].parent.id) || nextFoldersFromRoot[0].id
        : '';

    if (rootId) {
      if (!state.currentCollaboration[rootId]) {
        setState({
          ...state,
          error: undefined,
          currentCollaboration: Object.assign({}, state.currentCollaboration, { [rootId]: nextFoldersFromRoot }),
          navigation: updateNavigation
            ? nextFoldersFromRoot.map(
                x =>
                  <CoreModel.FolderPath>{
                    id: x.id,
                    name: x.name,
                    collaborationId: rootId,
                    source: CoreModel.DocumentFilter.collaboration
                  }
              )
            : state.navigation
        });
      }

      const newCollaborations =
        nextFoldersFromRoot.findIndex(x => x.id == rootId) > -1
          ? nextFoldersFromRoot
          : state.currentCollaboration[rootId] && state.currentCollaboration[rootId][0]
          ? [state.currentCollaboration[rootId][0]].concat(nextFoldersFromRoot)
          : nextFoldersFromRoot;

      setState({
        ...state,
        error: undefined,
        currentCollaboration: Object.assign({}, state.currentCollaboration, { [rootId]: newCollaborations }),
        navigation: updateNavigation
          ? newCollaborations.map(
              x =>
                <CoreModel.FolderPath>{
                  id: x.id,
                  name: x.name,
                  collaborationId: rootId,
                  source: CoreModel.DocumentFilter.collaboration
                }
            )
          : state.navigation
      });
    }
  }

  @Action(AddCollaborationBin)
  AddCollaborationBin({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentId = payload.payload as string;

    setState({
      ...state,
      collaborationBin: [].concat(state.collaborationBin).concat(documentId)
    });
  }

  @Action(DeleteFromCollaborationBin)
  DeleteFromCollaborationBin({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentId = payload.payload as string;

    setState({
      ...state,
      collaborationBin: [].concat(state.collaborationBin.filter(x => x !== documentId))
    });
  }

  @Action(ValidateNavigationPath)
  ValidateNavigationPath({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentId = payload.payload as string;
    const matterId = state.matterId;
    const allCollaborations = state.collaboration;

    const folders = CoreModel.Helper.getCollaborationFoldersByDocument(
      state.matterId,
      documentId,
      state.currentCollaboration,
      allCollaborations,
      state.navigation
    );

    if (folders && folders.length > 0) {
      const rootFolder =
        allCollaborations &&
        allCollaborations[matterId] &&
        allCollaborations[matterId].length > 0 &&
        allCollaborations[matterId][0];

      dispatch(
        new GotoCollaborationFolder({
          rootId: rootFolder.id,
          folderId: folders[folders.length - 1].id
        })
      );
    }
  }

  private getFolders(
    folderId: string,
    folder: CoreModel.Collaboration,
    parentFolder: CoreModel.Collaboration
  ): CoreModel.Collaboration[] {
    if (folder.id == folderId) {
      return parentFolder ? [parentFolder, folder] : [folder];
    }

    if (folder.folders && folder.folders.length > 0) {
      const temp = folder.folders
        .map(x => this.getFolders(folderId, x, folder))
        .reduce((a, b) => {
          return a.concat(b);
        });

      return temp && temp.length > 0 ? [].concat(parentFolder).concat(temp) : [];
    }

    return [];
  }

  @Action(GetSignaturesStart, { cancelUncompleted: true })
  GetSignaturesStart({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const reloadSignatureStatus = payload.payload as boolean;

    setState({
      ...state,
      signaturesLoading: true
    });

    return this.nodeSvc.getSignatures().pipe(
      map(signatures => dispatch(new GetSignaturesSuccess({ reload: reloadSignatureStatus, signatures }))),
      catchError(error => dispatch(new GetSignaturesFailure(error)))
    );
  }

  @Action(GetSignaturesSuccess)
  GetSignaturesSuccess({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const { signatures, reload } = payload.payload;

    setState({
      ...state,
      signaturesLoading: false,
      signatures
    });

    reload && dispatch(new RecentAction.UpdateSignatureStatus(reload));
  }

  @Action(GetSignaturesFailure)
  GetSignaturesFailure({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const error = payload.payload as any;
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      signaturesLoading: false,
      error: err.message
    });
  }

  @Action(AddSignaturePendingUpdateEntry)
  AddSignaturePendingUpdateEntry(ctx: StateContext<CoreStateModel>, action: AddSignaturePendingUpdateEntry) {
    const payload = action.payload;
    if (payload) {
      ctx.setState(
        produce(ctx.getState(), app => {
          // manually update the signature list.
          const updated = app.signatures.map(s =>
            s.orderId == payload.orderId ? { ...s, esignedDocumentStatus: payload.signStatus } : s
          );
          app.signaturePendingUpdate = Object.assign({}, app.signaturePendingUpdate, { [payload.documentId]: payload });
          app.signatures = [].concat(updated);
        })
      );
    }
  }

  @Action(RemoveSignaturePendingUpdateFromList)
  RemoveSignaturePendingUpdateFromList(
    ctx: StateContext<CoreStateModel>,
    action: RemoveSignaturePendingUpdateFromList
  ) {
    const documentId = action.payload as string;
    if (documentId) {
      ctx.setState(
        produce(ctx.getState(), app => {
          app.signaturePendingUpdate = Object.assign({}, app.signaturePendingUpdate, { [documentId]: undefined });
        })
      );
    }
  }

  @Action(UpdateUploadCancelFlag)
  UpdateUploadCancelFlag({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const item = payload.payload as { localId: string; flag: boolean }[];
    const current = state.uploadDrafts;

    if (current) {
      const newDrafts = current.map(y => {
        const i = item.findIndex(z => z.localId === y.id);
        if (i >= 0) {
          return Object.assign({}, { ...y, uploadCancel: item[i].flag });
        }
        return y;
      });
      setState({
        ...state,
        uploadDrafts: newDrafts
      });
    }
  }

  @Action(UpdateUploadCompleteFlag)
  UpdateUploadCompleteFlag({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const item = payload.payload as { localId: string; flag: boolean }[];
    const current = state.uploadDrafts;

    if (current) {
      const newDrafts = current.map(y => {
        const i = item.findIndex(z => z.localId === y.id);
        if (i >= 0) {
          return Object.assign({}, { ...y, done: item[i].flag });
        }
        return y;
      });

      const pendings = state.pendingCollaboration;
      const newPendings = pendings.map(d => {
        const found = newDrafts.find(f => f.id == d.fileId);
        const isUploading = found && found.done ? false : d.uploading;
        return { ...d, uploading: isUploading };
      });

      setState({
        ...state,
        uploadDrafts: newDrafts,
        pendingCollaboration: newPendings
      });
    }
  }

  @Action(AddUploadDraftToStore)
  AddUploadDraftToStore({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const drafts = payload.payload as CoreModel.DraftDocument[];

    setState({
      ...state,
      uploadDrafts: state.uploadDrafts.concat(...drafts)
    });
  }

  @Action(RemoveUploadDraftFromStore)
  DeleteUploadDraftFromStore({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const localIds = payload.payload as string[];
    const current = state.uploadDrafts;
    const newCopy = current.filter(x => localIds.findIndex(y => y === x.id) === -1);

    setState({
      ...state,
      uploadDrafts: newCopy
    });
  }

  @Action(DeleteUploadDraft)
  DeleteUploadDraft({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentIds = payload.payload as string[];
    const localIds = state.uploadDrafts.filter(x => documentIds.findIndex(y => y === x.documentId) >= 0).map(z => z.id);

    return this.nodeSvc.deleteDocumentDraft(documentIds).pipe(
      map(deleted => dispatch([new DeleteUploadDraftSuccess(documentIds)])),
      catchError(error => dispatch(new DeleteUploadDraftFailure({ error, localIds })))
    );
  }

  @Action(DeleteUploadDraftSuccess)
  DeleteUploadDraftSuccess({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentIds = payload.payload as string[];
    const old = state.uploadDrafts;
    const newDrafts = old.filter(x => documentIds.findIndex(id => id == x.documentId) === -1);

    setState({
      ...state,
      uploadDrafts: newDrafts
    });

    if (documentIds && documentIds.length > 0) {
      const deletePendings = documentIds.map(did => new DeletePendingCollaboration(did));
      return dispatch(deletePendings);
    }
  }

  @Action(DeleteUploadDraftFailure)
  DeleteUploadDraftFailure({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const { error, localIds } = payload.payload as { error: any; localIds: string[] };
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      error: err.message
    });

    if (err.status && err.status.toString().indexOf('40') >= 0) {
      // any client error status code from 40x
      return dispatch(new RemoveUploadDraftFromStore(localIds));
    }
  }

  @Action(DeleteStaleUploadDrafts)
  DeleteStaleUploadDrafts({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentIds = payload.payload as string[];
    const localIds = state.uploadDrafts.filter(x => documentIds.findIndex(y => y === x.documentId) >= 0).map(z => z.id);

    return this.nodeSvc.deleteDocumentDraft(documentIds).pipe(
      map(deleted => dispatch(new DeleteStaleUploadDraftsSuccess(documentIds))),
      catchError(error => dispatch(new DeleteStaleUploadDraftsFailure({ error, localIds })))
    );
  }

  @Action(DeleteStaleUploadDraftsSuccess)
  DeleteStaleUploadDraftsSuccess({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const documentIds = payload.payload as string[];
    const old = state.uploadDrafts;
    const newDrafts = old.filter(x => documentIds.findIndex(id => id == x.documentId) === -1);

    setState({
      ...state,
      uploadDrafts: newDrafts
    });
  }

  @Action(DeleteStaleUploadDraftsFailure)
  DeleteStaleUploadDraftsFailure({ getState, setState, dispatch }: StateContext<CoreStateModel>, payload) {
    const state = getState();
    const { error, localIds } = payload.payload as { error: any; localIds: string[] };
    const err = this.browserSvc.getStandardError(error);

    setState({
      ...state,
      error: err.message
    });

    if (err.status && err.status.toString().indexOf('40') >= 0) {
      // any client error status code from 40x
      return dispatch(new RemoveUploadDraftFromStore(localIds));
    }
  }

  @Selector()
  static getLastNavigatedActionId(state: CoreStateModel): string {
    if (!state) {
      return 'recents';
    }

    return state.lastNavigatedSideActionId || 'recents';
  }

  @Selector()
  static getUploadDrafts(state: CoreStateModel): CoreModel.DraftDocument[] {
    if (!state || !state.uploadDrafts || state.uploadDrafts.length == 0) {
      return [];
    }

    return state.uploadDrafts;
  }

  @Selector()
  static getPreviewMode(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.previewDocument;
  }

  @Selector()
  static getSignaturesPendingUpdate(
    state: CoreStateModel
  ): { [documentId: string]: SignatureModel.ESignaturePendingStatus } {
    if (!state) {
      return undefined;
    }

    return state.signaturePendingUpdate;
  }

  @Selector()
  static getPendingCollaboration(state: CoreStateModel): CoreModel.PendingCollaration[] {
    if (!state) {
      return [];
    }

    return state.pendingCollaboration;
  }

  @Selector()
  static geCollaborationBinIds(state: CoreStateModel): string[] {
    if (!state) {
      return [];
    }

    return state.collaborationBin;
  }

  @Selector()
  static getSelectedFilterFirmId(state: CoreStateModel): string {
    // only used by Matter Select option to filter the matters options.
    if (!state) {
      return undefined;
    }

    return state.selectedFilterFirmId;
  }

  @Selector()
  static getNavigation(state: CoreStateModel): CoreModel.FolderPath[] {
    if (!state || !state.navigation) {
      return [];
    }

    return state.navigation;
  }

  @Selector()
  static getShareMatters(state: CoreStateModel): { [matterId: string]: NodeModel.SharedMatterDetails } {
    if (!state) {
      return {};
    }

    return state.shareMatters;
  }

  @Selector()
  static getNodeStatus(state: CoreStateModel): CoreModel.DataStatus {
    if (!state) {
      return { loading: false, error: '' };
    }

    return state.nodesStatus;
  }

  @Selector()
  static getNodeInitStatus(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.isNodesInit;
  }

  @Selector()
  static getSignatureInitStatus(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.isSignatureInit;
  }

  @Selector()
  static getNodes(state: CoreStateModel): NodeModel.LawConnectNode[] {
    if (!state) {
      return [];
    }

    return state.nodes;
  }

  @Selector()
  static getNotificationCount(state: CoreStateModel): number {
    if (!state) {
      return 0;
    }

    return state.notificationCount;
  }

  @Selector()
  static isWhiteLabel(state: CoreStateModel): { whiteLabel: boolean; firmId: string } {
    if (!state) {
      return { whiteLabel: false, firmId: '' };
    }

    return { whiteLabel: state.isWhiteLabel, firmId: state.firmId };
  }

  @Selector()
  static getSelectedMatterId(state: CoreStateModel): string {
    if (!state) {
      return undefined;
    }

    return state.matterId;
  }

  @Selector()
  static getSelectedFirmId(state: CoreStateModel): string {
    if (!state) {
      return undefined;
    }

    return state.firmId;
  }

  @Selector()
  static getSelectedFirm(state: CoreStateModel): CoreModel.FirmDetail {
    if (!state || !state.firmId || !state.firms || !state.firms[state.firmId]) {
      return undefined;
    }

    const firm = state.firms[state.firmId][0];

    return (
      (firm && {
        id: firm.id,
        name: firm.name
      }) ||
      undefined
    );
  }

  @Selector()
  static getFirmsByUser(state: CoreStateModel): NodeModel.Firms {
    if (!state || !state.firms || Object.keys(state.firms).length == 0) {
      return { selected: undefined, list: {} };
    }

    const selectedFirm = state.firms[state.firmId];
    const selected = selectedFirm && selectedFirm.length > 0 && selectedFirm[0];
    return { selected: selected || undefined, list: state.firms };
  }

  @Selector()
  static getMattersByFirm(state: CoreStateModel): { [firmId: string]: NodeModel.LawConnectNode[] } {
    if (!state) {
      return undefined;
    }

    return state.matters;
  }

  @Selector()
  static getDocumentsByMatter(state: CoreStateModel): { [matterId: string]: NodeModel.LawConnectNode[] } {
    if (!state) {
      return undefined;
    }

    return state.documents;
  }

  @Selector()
  static getAppStoreByMatter(state: CoreStateModel): { [matterId: string]: NodeModel.LawConnectNode[] } {
    if (!state) {
      return undefined;
    }

    return state.appStore;
  }

  @Selector()
  static getSelectedMatterAndFirmId(state: CoreStateModel): CoreModel.SelectedMatter {
    if (!state) {
      return { firmId: undefined, matterId: undefined };
    }

    return { firmId: state.firmId, matterId: state.matterId };
  }

  @Selector()
  static getSharePreviewInfo(state: CoreStateModel): CoreModel.SharePreviewInfo {
    if (!state) {
      return undefined;
    }

    return state.sharePreview;
  }

  @Selector()
  static getUserTermsAndConditionsStatus(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return !!state.hasAgreeTermsAndConditions;
  }

  @Selector()
  static getUserDocumentAnnotationVisitStatus(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return !!state.documentAnnotationVisited;
  }

  @Selector()
  static getUserDocumentSignatureVisitStatus(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return !!state.documentSignatureVisited;
  }

  @Selector()
  static getSignatures(state: CoreStateModel): SignatureModel.ESignature[] {
    if (!state) {
      return [];
    }

    return state.signatures;
  }

  @Selector()
  static getReturnTo(state: CoreStateModel): string {
    if (!state) {
      return undefined;
    }

    return state.returnTo;
  }

  @Selector()
  static getAppAuthentication(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.isAuthenticated;
  }

  @Selector()
  static getAppTheme(state: CoreStateModel): StandardModel.ThemeSetting {
    if (!state) {
      return undefined;
    }

    return state.theme.themeSetting;
  }

  @Selector()
  static getTheme(state: CoreStateModel): StandardModel.ContainerSetting {
    if (!state) {
      return undefined;
    }

    return state.theme;
  }

  @Selector()
  static getLoginUser(state: CoreStateModel): CoreModel.LogonUserInfo {
    if (!state) {
      return undefined;
    }

    const { userId, displayName, firstName, lastName, email } = state;
    return <CoreModel.LogonUserInfo>{
      userId,
      displayName: displayName ? displayName.trim() : '',
      firstName,
      lastName,
      email
    };
  }

  @Selector()
  static getUserMetadataUpdateLoading(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    const { updateUserMetadataLoading } = state;
    return updateUserMetadataLoading;
  }

  @Selector()
  static getAppError(state: CoreStateModel): string {
    if (!state) {
      return '';
    }

    const { error } = state;
    return error;
  }

  @Selector()
  static getIsSidebarExpanded(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.isSidebarExpanded;
  }

  @Selector()
  static getCallBackEmail(state: CoreStateModel): string {
    if (!state) {
      return '';
    }
    const { email } = state;
    return email;
  }

  @Selector()
  static getWhiteLabelAndAuthenticationStatus(
    state: CoreStateModel
  ): { isWhiteLabel: boolean; isAuthenticated: boolean } {
    if (!state) {
      return { isWhiteLabel: false, isAuthenticated: false };
    }

    return { isWhiteLabel: state.isWhiteLabel, isAuthenticated: state.isAuthenticated };
  }

  @Selector()
  static getCollaboration(state: CoreStateModel): {} {
    if (!state || !state.currentCollaboration || Object.keys(state.currentCollaboration).length == 0) {
      return undefined;
    }

    return state.currentCollaboration;
  }

  @Selector()
  static getAllCollaborations(state: CoreStateModel): {} {
    if (!state || !state.collaboration || Object.keys(state.collaboration).length == 0) {
      return undefined;
    }

    return state.collaboration;
  }

  @Selector()
  static getCollaborationLoading(state: CoreStateModel): boolean {
    if (!state) {
      return false;
    }

    return state.collaborationLoading;
  }

  @Selector()
  static getMatterOptions(state: CoreStateModel): LyraDesignCardModel.MatterCardInfo[] {
    if (!state.matters || Object.keys(state.matters).length === 0) {
      return [];
    }

    let matters = [];

    if (state.selectedFilterFirmId) {
      matters = (state.matters && state.matters[state.selectedFilterFirmId]) || [];
    } else {
      Object.keys(state.matters).forEach(firmId => (matters = matters.concat(state.matters[firmId])));
    }

    const documents = state.documents;
    const signatures = state.signatures;

    return matters.map<LyraDesignCardModel.MatterCardInfo>(x => {
      const docs = documents[x.id] || [];
      const signatureShowList = CoreModel.Helper.getSignatureDocumentShowOrHideList(docs, signatures, state.userId);
      return <LyraDesignCardModel.MatterCardInfo>{
        documentCount:
          docs.length > 0
            ? docs.filter(
                x =>
                  x.nodeType == CoreModel.NodeType.Document &&
                  !x.isSharedMatter &&
                  !x.isCollaborationFile &&
                  !x.isRequestedEsignature &&
                  this.includeToCount(signatureShowList, x.id)
              ).length
            : 0,
        subtitle: x.name,
        id: x.id,
        firmId: x.parentId,
        isSharedMatter: x.isSharedMatter,
        title: x.subType
      };
    });
  }

  @Selector()
  static getNodeLoadingStatus(state: CoreStateModel): boolean {
    if (!state || !state.nodesStatus) {
      return false;
    }

    return state.nodesStatus.loading;
  }

  @Selector()
  static getNodeError(state: CoreStateModel): string {
    if (!state || !state.nodesStatus) {
      return '';
    }

    return state.nodesStatus.error;
  }

  private static includeToCount(signatureShowList: { documentId: string; show: boolean }[], docId: string): boolean {
    const item = signatureShowList.find(y => y.documentId == docId);
    if (!item) {
      return true;
    }
    return item.show;
  }
}
