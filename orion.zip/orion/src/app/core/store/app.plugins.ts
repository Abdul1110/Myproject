import { getActionTypeFromInstance } from '@ngxs/store';
import {
  Logout,
  GetRootFailure,
  SetTermsAndConditionsStatusFailure,
  SetDocumentAnnotationVisitStatusFailure,
  SetDocumentSignatureVisitStatusFailure,
  GetMattersFailure,
  GetCollaborationFailure,
  GetSignaturesFailure,
  DeleteUploadDraftFailure,
  GetNotificationFailure
} from './actions';
import { initialState } from './states';
import { RecentAction } from '@app/features/+recent/store/actions';
import { PreviewAction } from '@app/features/+preview/store/actions';
import { SignInAction, SignUpAction } from '@app/features/+account/store/actions';
import { BrowserService } from '@leap/lyra-design';
import { CollaborationsAction } from '@app/features/+collaborations/store';
import { SignaturesAction } from '@app/features/+signatures/store';
import { DocumentsAction } from '@app/features/+documents/store';
import { BillingAction } from '@app/features/+billing/store/actions/billing.actions';
import { TrustAction } from '@app/features/+trust/store';

export function logoutPlugin(state, action, next) {
  // Use the get action type helper to determine the type
  const actionText = getActionTypeFromInstance(action);
  if (actionText === Logout.type) {
    // if we are a logout type, lets erase all the state
    state = {
      app: Object.assign({}, initialState, {
        hasAgreeTermsAndConditions: state.app.hasAgreeTermsAndConditions,
        theme: state.app.theme, // retain this to ensure white label logout still able to display the logo.
        isWhiteLabel: state.app.isWhiteLabel, // retain this to ensure white label logout still able to display the logo.
        firmId: state.app.firmId // retain this to ensure white label logout still able to display the logo.
      })
    };
  }

  // return the next function with the empty state
  return next(state, action);
}

const browserSvc = new BrowserService(undefined);

export function errorNotificationPlugin(state, action, next) {
  try {
    const actionText = getActionTypeFromInstance(action);
    const listOfErrorActions = [
      //recents_file
      RecentAction.DeleteNotificationFailure.type,
      RecentAction.GetNodesFailure.type,
      RecentAction.GetDocumentsFailure.type,
      RecentAction.GetRecentsFailure.type,
      RecentAction.DownloadDocumentFailure.type,
      RecentAction.ViewDocumentFailure.type,
      RecentAction.ViewAppFailure.type,
      //'preview'
      PreviewAction.PreviewInfoFailure.type,
      PreviewAction.PreviewOpenFailure.type,
      //'signin'
      SignInAction.SignInFailure.type,
      SignInAction.SocialGetProfileFailure.type,
      SignInAction.ResetPasswordFailure.type,
      //'signup'
      SignUpAction.SignUpFailure.type,
      SignUpAction.ResendConfirmationFailure.type,
      //app
      GetRootFailure.type,
      SetTermsAndConditionsStatusFailure.type,
      SetDocumentAnnotationVisitStatusFailure.type,
      SetDocumentSignatureVisitStatusFailure.type,
      GetMattersFailure.type,
      GetCollaborationFailure.type,
      GetSignaturesFailure.type,
      DeleteUploadDraftFailure.type,
      GetNotificationFailure.type,

      // collaborations
      CollaborationsAction.DocumentUploadFailure.type,

      //signatures
      SignaturesAction.LoadSignaturePageFailure.type,
      SignaturesAction.ReplyCommentFailure.type,
      SignaturesAction.DeleteAnnotationFailure.type,
      SignaturesAction.AddAnnotationFailure.type,
      SignaturesAction.UpdateAnnotationFailure.type,

      // share with me
      DocumentsAction.ReplyCommentFailure.type,
      DocumentsAction.DeleteAnnotationFailure.type,
      DocumentsAction.AddAnnotationFailure.type,
      DocumentsAction.UpdateAnnotationFailure.type,
      DocumentsAction.GetDocumentActivityFailure.type,

      // billing
      BillingAction.DonwloadBillingAccountFailure.type,
      TrustAction.DonwloadBillingTrustAccountFailure.type
    ];
    const skipListWhenNotAuthenticated = [GetMattersFailure.type, GetSignaturesFailure.type, GetRootFailure.type];
    const notAuthenticatedOrAuthorised = [403, 401];

    if (listOfErrorActions.indexOf(actionText) >= 0) {
      // exclude get matter 403 error.
      if (
        skipListWhenNotAuthenticated.indexOf(actionText) >= 0 &&
        action.payload &&
        notAuthenticatedOrAuthorised.includes(action.payload.status)
      ) {
        // skip
      } else {
        // const error = browserSvc.getStandardError(action.payload);
        let errorMessage = actionText && actionText.includes('] ') ? actionText.split('] ')[1] : actionText; //error.message;
        if (
          [
            SignInAction.SignInFailure.type,
            SignUpAction.SignUpFailure.type,
            SignInAction.ResetPasswordFailure.type,
            RecentAction.ViewDocumentFailure.type
          ].includes(actionText)
        ) {
          const apiError = action && action.payload && action.payload.error && action.payload.error.message;
          errorMessage = apiError || errorMessage;
        }

        errorMessage && window.postMessage({ type: 'error', message: errorMessage }, window.location.origin);
      }
    }
  } catch (e) {
    //do nothing
  }
  // return the next function with the empty state
  return next(state, action);
}

export function successNotificationPlugin(state, action, next) {
  try {
    const actionText = getActionTypeFromInstance(action);
    const listOfSuccessActions = [
      //'signin'
      SignInAction.ResetPasswordSuccess.type,
      //'signup'
      SignUpAction.ResendConfirmationSuccess.type,
      // signatures
      SignaturesAction.UserSignatureStatus.type
    ];
    if (listOfSuccessActions.includes(actionText)) {
      const message = action.payload && action.payload['message'] ? action.payload['message'] : '';
      if (message) {
        window.postMessage({ type: 'success', message }, window.location.origin);
      }
    }
  } catch (e) {
    //do nothing
  }
  // return the next function with the empty state
  return next(state, action);
}
