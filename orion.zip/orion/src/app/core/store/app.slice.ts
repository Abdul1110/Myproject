export enum AppSlice {
  App = 'app',
  Router = 'router',
  Preview = 'preview'
}
