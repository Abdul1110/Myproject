export interface AnalyticModel {
  action: string;
  category: string;
  label?: string;
  value?: number;
}
