import { StandardModel } from '@leap/lyra-design';
import { Params } from '@angular/router';
import { NodeModel } from './node.model';
import { SignatureModel } from './signature.model';

export namespace CoreModel {
  export interface FirmDetail {
    id: string;
    name: string;
  }

  export interface NavigationData {
    url: string; // via window.assign
    path: string; // via ngxs Navigator
    outlet?: string;
    outletPath?: string;
    queryParams?: Params;
    state: any;
  }

  export interface SignInResponse {
    metadata: SignInMeta;
    accessToken: string;
  }

  export interface SignInMeta {
    login: boolean;
    userId: string;
    displayName: string;
    firstName: string;
    lastName: string;
    email: string;
    hasAgreeTermsAndConditions: boolean;
    documentAnnotationVisited: boolean;
    documentSignatureVisited: boolean;
  }

  export interface LogonUserInfo {
    userId: string;
    displayName: string;
    firstName: string;
    lastName: string;
    email: string;
  }

  export interface PubNubSubscription {
    unsubscribe: () => void;
  }

  export interface PubNubNotification {
    id: string;
    sourceUserId: string;
    sourceUserFullName: string;
    sourceUserInitials: string;
    destinationUserId: string;
    destinationUserFullName: string;
    destinationUserInitials: string;
    documentId: string;
    documentName: string;
    notificationDate: Date;
    notificationType: PubNubNotificationType;
    matterId: string;
    documentExtension: string;
    status?: number;
    latestVersionId?: string;
  }

  export interface RecentNotification extends PubNubNotification {
    meta?: any;
  }

  export enum PubNubNotificationType {
    sharing = 1,
    revoking,
    uploading,
    esignatureUploading,
    esignatureCreated,
    esignatureDecline = 8,
    delete = 9,
    appStore = 100,
    appStoreRevoke = 101,
    accountStatementShared = 200,
    accountStatementRevoked = 201
  }

  export interface UserMetadata {
    given_name?: string;
    family_name?: string;
    initials?: string;
    has_agree_to_lawconnect_privacy?: boolean;
    document_annotation_visited?: boolean;
    document_esignature_visited?: boolean;
  }

  export interface ShareInfo {
    theme: StandardModel.ContainerSetting;
    share: SharePreviewInfo;
  }

  export interface ESignatureRequestInfo {
    orderId: string;
    title: string;
    userId: string;
    type: string;
    status: string;
    creationDate: string;
    modifiedDate: string;
    id: string;
  }

  export interface SharePreviewInfo extends SharePreviewInfoId {
    documents: ShareDocumentInfo[];
    matterId: string;
    firmId: string;
    firmName: string;
    isExistingUser: boolean;
    providers: string[];
    staffName: string;
    userEmail: string;
    userName: string;
    userPictureUrl: string;
    eSignature?: ESignatureRequestInfo;
  }

  export interface SharePreviewInfoId {
    id: string;
    isMatterShared: boolean;
  }

  export interface ShareDocumentInfo {
    fileExtension: string;
    name: string;
    id: string;
  }

  export interface SelectedMatter {
    matterId: string;
    firmId: string;
  }

  export interface DataStatus {
    loading: boolean;
    error: string;
  }

  export interface OtherUser {
    firstName: string;
    lastName: string;
    email: string;
  }

  export interface Collaboration {
    parent: Collaboration;
    id: string;
    name: string;
    documents: string[];
    fullDocuments: Doc[];
    folders: Collaboration[];
    level?: number;
    otherUsers: OtherUser[];
  }

  export enum CorrespondenceType {
    Document = 0,
    Comment = 1,
    VoiceMemo = 2
  }

  export interface DocAttachment {
    id: string;
    name: string;
    ext: string;
    deleted: boolean;
    previewUrl?: string; // docs-api pdf version url
  }

  export enum TransferMode {
    Closed = 'Closed',
    Received = 'Received',
    Sent = 'Sent',
    Unknown = ''
  }

  export interface Doc {
    id: string;
    type: CorrespondenceType;
    toFrom: string;
    name: string;
    createDate: Date;
    userId: string;
    staffInitials: string;
    staffName: string;
    version: number;
    latestVersion: string;
    ext: string;
    deleted: boolean;
    attachments: DocAttachment[];
    orderDate: Date;
    orderId: string;
    orderBy: string;
    availableOnline: boolean;
    url: string;
    status: string;
    dateCompleted: Date;
    transferMode: TransferMode;
    iconClass: string;
    iconTooltip: string;
    pin: string;
    desktopOnly: boolean;
    deleteCode?: number;
    previewUrl?: string; // docs-api pdf version url
    isDeletable?: boolean; // only applicable to Collaboration file
    currentVersionId?: string; // only applicable to Collaboration file
    fileExtension?: string;
    fileSizeInBytes?: number;
    lastModified?: Date;
    ownerInitials?: string;
    ownerName?: string;
  }

  export interface PendingCollaration {
    collaborationRootId: string;
    folderId: string;
    folderName: string;
    fileId: string;
    fileName: string;
    fileExtension: string;
    createDate: Date;
    uploading: boolean;
  }

  export interface FolderPath {
    id: string;
    name: string;
    source: DocumentFilter;
    collaborationId?: string;
  }

  export enum DocumentFilter {
    sharedWithMe = 0,
    signature,
    correspondence,
    collaboration
  }

  export interface DraftDocument {
    uploadCancel: boolean;
    id: string; //client local id aka documentId (after new changes from bulk upload)
    documentId: string;
    uploadUrl: string;
    fileContentType: string;
    uploadProgress: number;
    done: boolean;
    matterName: string;
    name: string;
  }

  export interface User {
    initial: string;
    name: string;
  }

  export interface ColumnSorting {
    column: string;
    title: string;
    sort: SortBy;
  }

  export interface ColumnFilter {
    column: string;
    title: string;
  }

  export enum SortBy {
    asc = 0,
    desc
  }

  export enum NodeType {
    na = 0,
    Firm = 1,
    Matter,
    Folder,
    Document,
    Esignature,
    FolderHeader,
    App = 8
  }

  export enum ViewType {
    pdf = 1,
    image = 2,
    notSupported = 3,
    none = 4
  }

  export class Helper {
    static getUserInitial(name: string): string {
      if (!name || !name.trim()) {
        return '';
      }

      return name
        .trim()
        .split(' ')
        .reduce((a, b, i) => {
          const fn = `${(a && a.split('')[0].toUpperCase()) || ''}`;
          const ln = `${(b && b.split('')[0].toUpperCase()) || ''}`;
          return i == 1 ? `${fn}${ln}` : `${a}${ln}`;
        });
    }

    static getCollaborationFileByDocumentId(
      matterId: string,
      documentId: string,
      currentCollaboration: { [rootId: string]: CoreModel.Collaboration[] },
      allCollaborations: { [matterId: string]: CoreModel.Collaboration[] }
    ): { collaborationRootId: string; doc: Doc; docFromCurrentVersionId: boolean } {
      if (!matterId || !documentId) {
        return undefined;
      }

      let docFromCurrentVersionId = false;
      let found = false;
      let collaborationFile: Doc = undefined;
      let myRootId = '';
      if (currentCollaboration && Object.keys(currentCollaboration).length > 0) {
        Object.keys(currentCollaboration).forEach(rootId => {
          const cols = currentCollaboration[rootId];
          const collaborationRootId = cols && cols[0].id;
          !found &&
            cols &&
            cols.length > 0 &&
            cols[cols.length - 1].fullDocuments.forEach(doc => {
              if (!found && doc.id == documentId) {
                found = true;
                collaborationFile = doc;
                myRootId = collaborationRootId;
              } else if (!found && doc.currentVersionId == documentId) {
                found = true;
                collaborationFile = doc;
                myRootId = collaborationRootId;
                docFromCurrentVersionId = true;
              }
            });
        });
      }

      if (!found && allCollaborations && Object.keys(allCollaborations).length > 0) {
        const matterColls = allCollaborations[matterId] || [];
        const collaborationRootId = matterColls && matterColls[0] && matterColls[0].id;
        matterColls.length > 0 &&
          matterColls.forEach(col => {
            !found &&
              col.fullDocuments.length > 0 &&
              col.fullDocuments.forEach(doc => {
                if (!found && doc.id == documentId) {
                  found = true;
                  collaborationFile = doc;
                  myRootId = collaborationRootId;
                }
              });
          });
      }

      return { doc: collaborationFile, collaborationRootId: myRootId, docFromCurrentVersionId };
    }

    static getCollaborationFoldersByDocument(
      matterId: string,
      documentId: string,
      currentCollaboration: { [rootId: string]: CoreModel.Collaboration[] },
      allCollaborations: { [matterId: string]: CoreModel.Collaboration[] },
      navigation: CoreModel.FolderPath[]
    ): Collaboration[] {
      const rootFolder =
        allCollaborations &&
        allCollaborations[matterId] &&
        allCollaborations[matterId].length > 0 &&
        allCollaborations[matterId][0];

      if (rootFolder && (!navigation || navigation.length == 0)) {
        const currentPathHasTheDocument =
          currentCollaboration &&
          currentCollaboration[rootFolder.id] &&
          currentCollaboration[rootFolder.id].length > 0 &&
          currentCollaboration[rootFolder.id][currentCollaboration[rootFolder.id].length - 1].documents.includes(
            documentId
          );

        if (currentPathHasTheDocument) {
          return [rootFolder];
        }

        return this.getFoldersByDocument(documentId, rootFolder) || [];
      }

      if (rootFolder) {
        return this.getFoldersByDocument(documentId, rootFolder) || [];
      }

      return [];
    }

    private static getFoldersByDocument(
      documentId: string,
      current: CoreModel.Collaboration
    ): CoreModel.Collaboration[] {
      if (current.documents.includes(documentId)) {
        return [current];
      }

      let folders = [];
      current.folders.forEach(f => {
        const folder = this.getFoldersByDocument(documentId, f);
        if (folders.length == 0 && folder.length > 0) {
          folders = folder.findIndex(x => x.id == f.id) > -1 ? [].concat(folder) : [].concat(f).concat(folder);
        }
      });

      return folders;
    }

    static getSignatureDocumentShowOrHideList(
      nodes: NodeModel.LawConnectNode[],
      signatures: SignatureModel.ESignature[],
      currentUserId: string
    ): any {
      if (!signatures) {
        return [];
      }

      let signatureShowOrHideList: { documentId: string; show: boolean }[] = [];
      const signatureNodes = nodes.filter(x => x.signState !== NodeModel.SignState.NA) || [];

      if (signatureNodes.length > 0) {
        const parentIDs = new Set<string>(signatureNodes.map(s => s.parentId));
        let signatureDocs = {};

        parentIDs.forEach(d => {
          signatureDocs[d] = nodes.filter(f => f.parentId == d);
        });

        const signatureKeys = Object.keys(signatureDocs);
        if (signatureKeys && signatureKeys.length > 0) {
          signatureKeys.forEach(parentId => {
            const rawDocs = signatureDocs[parentId];
            const orderIdList = rawDocs.filter(x => !isNaN(Number(x.id))) || [];
            const docIdList =
              rawDocs.filter(x => x.isRequestedEsignature && x.signState !== NodeModel.SignState.NA) || [];

            if (docIdList.length > 0) {
              const docTemp = docIdList.map(x => {
                return { documentId: x.id, show: true };
              });

              signatureShowOrHideList = [].concat(signatureShowOrHideList).concat(docTemp);
            }

            orderIdList.forEach(i => {
              const signIndex = signatures.findIndex(s => s.orderId == i.id);

              if (signIndex > -1) {
                const orderDoc = signatures[signIndex];
                orderDoc.requestedDocuments.forEach(doc => {
                  const t = rawDocs.find(r => r.id == doc.id);
                  if (t) {
                    const hasRecordInDocIdList = docIdList.find(x => x.id == doc.id) > -1;
                    let show = false;
                    if (orderDoc.esignedDocumentStatus === SignatureModel.ESignatureDocumentStatus.Pending) {
                      show = true;
                    } else if (
                      orderDoc.esignedDocumentStatus === SignatureModel.ESignatureDocumentStatus.WaitingForOthers
                    ) {
                      const currentUserSignState = orderDoc.requestedSigners.find(f => f.id == currentUserId);
                      if (currentUserSignState) {
                        //&& currentUserSignState.status == SignatureModel.ESignerStatus.Signed
                        show = true;
                      }
                    }

                    signatureShowOrHideList = !hasRecordInDocIdList
                      ? [].concat(signatureShowOrHideList).concat({ documentId: doc.id, show })
                      : []
                          .concat(signatureShowOrHideList.filter(f => f.documentId !== doc.id))
                          .concat({ documentId: doc.id, show });
                  }
                });
              }
            });
          });
        }
      }

      return signatureShowOrHideList;
    }

    static convertNotificationMessage(message: any): PubNubNotification {
      if (message['Type']) {
        return Object.assign({}, <PubNubNotification>{
          notificationType: message['Type'],
          status: message['Status']
        });
      }

      return Object.assign({}, <PubNubNotification>{
        id: message.Id,
        sourceUserId: message.SourceUserId,
        sourceUserFullName: message.SourceUserFullName,
        sourceUserInitials: message.SourceUserInitials,
        destinationUserId: message.DestinationUserId,
        destinationUserFullName: message.DestinationUserFullName,
        destinationUserInitials: message.DestinationUserInitials,
        documentId: message.DocumentId,
        documentName: message.DocumetName,
        notificationDate: message.NotificationDate,
        notificationType: message.NotificationType,
        latestVersionId: message.LatestVersionId
      });
    }

    static getDocTypeIcon(fileExtension: string): string {
      if (!fileExtension) {
        return `doctype-default-24`;
      }

      const ext = fileExtension.replace('.', '').toLowerCase();
      let icon = 'doctype-';
      switch (ext) {
        case 'doc':
        case 'docx':
          icon += 'doc';
          break;
        case 'xls':
        case 'xlsx':
          icon += 'excel';
          break;
        case 'pdf':
          icon += 'pdf';
          break;
        case 'jpeg':
        case 'jpg':
        case 'png':
          icon += 'image';
          break;
        case 'msg':
        case 'eml':
          icon += 'email-default';
          break;
        case 'folder':
          icon += 'folder';
          break;
        case 'app':
          icon = 'apps';
          break;
        default:
          icon += 'default';
      }

      // the following condition is due to apps icon does not have 24 size.
      if (icon.includes('doctype-')) {
        icon += '-24';
      }

      return icon;
    }

    static getValidFileTypes(): string[] {
      const imageFiles = CoreModel.Helper.getValidImageFileTypes();
      const pdfViewFiles = CoreModel.Helper.getValidViewFileTypes();
      return imageFiles.concat(pdfViewFiles);
    }

    static getValidViewFileTypes(): string[] {
      const base = ['docx', 'doc', 'docusign', 'msg', 'pdf', 'xls', 'xlsx'];
      return [].concat(base).concat(base.map(x => x.toUpperCase()));
    }

    static getValidPdfViewFileTypes(): string[] {
      const base = ['docx', 'doc', 'docusign', 'msg', 'pdf', 'html'];
      return [].concat(base).concat(base.map(x => x.toUpperCase()));
    }

    static getFileViewer(extension: string): ViewType {
      if (!extension) {
        return ViewType.none;
      }

      const ext = extension.replace('.', '');

      let viewType: ViewType;
      if (CoreModel.Helper.getValidPdfViewFileTypes().includes(ext)) {
        viewType = ViewType.pdf;
      } else if (CoreModel.Helper.getValidImageFileTypes().includes(ext)) {
        viewType = ViewType.image;
      } else {
        viewType = ViewType.notSupported;
      }

      return viewType;
    }

    static getValidImageFileTypes(): string[] {
      const base = ['png', 'jpg', 'jpeg'];
      return [].concat(base).concat(base.map(x => x.toUpperCase()));
    }

    static isImageFile(extension: string): boolean {
      if (!extension) {
        return false;
      }

      const support = CoreModel.Helper.getValidImageFileTypes();
      return support.findIndex(x => x === extension) >= 0;
    }

    static isPdfFile(extension: string): boolean {
      if (!extension) {
        return false;
      }

      const support = ['pdf', 'PDF'];
      return support.findIndex(x => x === extension) >= 0;
    }

    static fileNameToNameAndExtension(nameWithExtension: string): { name: string; extension: string } {
      if (!nameWithExtension) return { name: '', extension: '' };

      const names = nameWithExtension.split('.');
      const fileExtension = names[names.length - 1];
      const fileName = names.filter((x, idx) => idx < names.length - 1).join('.');
      return { name: fileName, extension: fileExtension };
    }

    static toDoc(
      fildId: string,
      fileExtension: string,
      fileName: string,
      createDate: Date,
      deleted: boolean,
      isDeletable: boolean,
      status: string
    ): Doc {
      return {
        id: fildId,
        type: CorrespondenceType.Document,
        toFrom: '',
        name: fileName,
        createDate,
        userId: '',
        staffInitials: '',
        staffName: '',
        version: 0,
        latestVersion: '',
        ext: '',
        deleted,
        attachments: [],
        orderDate: undefined,
        orderId: '',
        orderBy: '',
        availableOnline: false,
        url: '',
        status,
        dateCompleted: undefined,
        transferMode: TransferMode.Unknown,
        iconClass: '',
        iconTooltip: '',
        pin: '',
        desktopOnly: false,
        isDeletable,
        fileExtension
      };
    }

    static getValidDocumentNameWithExtension(name: string, fileExtension: string): string {
      return fileExtension && name.includes(`.${fileExtension}`) ? name : `${name}.${fileExtension}`;
    }

    static getMatterDetail(
      matterId: string,
      matters: { [firmId: string]: NodeModel.LawConnectNode[] }
    ): NodeModel.LawConnectNode {
      if (!matterId || !matters || Object.keys(matters).length == 0) {
        return undefined;
      }

      let detail = undefined;
      Object.keys(matters).forEach(firmId => {
        if (!detail) {
          const matter = matters[firmId].find(m => m.id === matterId);
          if (matter) {
            return (detail = { ...matter });
          }
        }
      });

      return detail;
    }

    static sortBy(d: any, sortBy: CoreModel.ColumnSorting): [] {
      return d.sort((a, b) => {
        const bName = b
          ? typeof b[sortBy.column] == 'object'
            ? !isNaN(Date.parse(b[sortBy.column]))
              ? b[sortBy.column].toISOString()
              : b[sortBy.column]
            : (b[sortBy.column] || '').toString().toLowerCase()
          : '';

        const aName = a
          ? typeof a[sortBy.column] == 'object'
            ? !isNaN(Date.parse(a[sortBy.column]))
              ? a[sortBy.column].toISOString()
              : a[sortBy.column]
            : (a[sortBy.column] || '').toString().toLowerCase()
          : '';

        if (sortBy.sort === CoreModel.SortBy.asc) {
          if (bName > aName) {
            return -1;
          }

          if (bName < aName) {
            return 1;
          }

          return 0;
        }

        if (sortBy.sort === CoreModel.SortBy.desc) {
          if (aName < bName) {
            return 1;
          }

          if (aName > bName) {
            return -1;
          }

          return 0;
        }

        return 0;
      });
    }
  }
}
