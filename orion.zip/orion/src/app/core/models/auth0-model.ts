// Auth0 types
export interface Auth0Instance {
  login: (config: any, cb?: Function) => void;
}
export interface Auth0TokenResponse {
  id_token: string;
  access_token: string;
  token_type: string;
}
export interface Auth0Profile {
  email: string;
  name: string;
  given_name?: string; // social logins only
  family_name?: string; // social logins only
  picture: string;
  nickname: string;
  email_verified: boolean;
  clientID: string;
  user_id: string;
  created_at: string;
  updated_at: string;
}

export interface UserMetadata {
  login: boolean;
  userId: string;
  displayName: string;
}

export interface AuthenticationStatus {
  accessToken: string;
  cookieNotExpired: boolean;
  userMetadata: UserMetadata;
}
