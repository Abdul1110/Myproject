import { SignatureModel } from './signature.model';

export namespace NodeModel {
  export interface LawConnectNode {
    accessType: AccessType;
    creationDate: string; // map from createDate
    entityId: string; // map from id
    fileExtension: string; // map from ext
    fileType: FileType; // map from ext
    id: string; // map from id
    isRequestedEsignature: boolean;
    isSharedMatter: boolean; // set to true
    lastCommentDate: string;
    lastSignActionDate: string;
    lastVisitDate: string;
    modifiedDate: string;
    name: string; // map from name
    nodeType: NodeType; // Folder (if from folders) or Document (if from fullDocuments)
    ownerFullName: string;
    ownerId: string;
    parentId: string;
    signState: SignState;
    status: string;
    thumbnailUrl: string;
    userId: string; // map from userId
    visited: boolean;
    staffName?: string; // map from staffName
    previewUrl?: string; // map from previewUrl
    attachments?: DocAttachment[]; // map from attachments
    iconClass?: string; // map from iconClass
    iconTooltip?: string; // map from iconTooltp
    toFrom?: string; // map from toFrom
    subType: string;
    isCollaborationFile: boolean;
    deleted: boolean;
    currentVersionId: string;
    isDeletable: boolean;
    url?: string; // use by app store
    isOwned: boolean;
  }

  export interface DocAttachment {
    id: string;
    name: string;
    ext: string;
    deleted: boolean;
    previewUrl?: string; // docs-api pdf version url
  }

  export enum AccessType {
    na = 0,
    none = 1,
    view,
    addComment,
    sign,
    modify,
    owner,
    publicView
  }

  export enum FileType {
    na = 0,
    pdf = 1,
    png,
    jpg,
    jpeg,
    docx,
    doc,
    msg
  }

  export enum NodeType {
    na = 0,
    Firm = 1,
    Matter,
    Folder,
    Document,
    Esignature,
    App = 8
  }

  export enum SignState {
    NA = 0,
    Pending = 1,
    Signed = 2,
    Declined = 3,
    Error = 4,
    WaitingForOthers = 5,
    Notified = 6,
    InvalidRequest = 7
  }

  export interface DocumentBadgeState {
    badgeType: BadgeType;
    info: string;
    cssClass: string;
    signStatus?: SignatureModel.ESignatureDocumentStatus;
    signDocumentName?: string;
    signer?: SignatureModel.ESigner[];
  }

  export enum BadgeType {
    comment = 0,
    signature,
    correspondence,
    attachment
  }

  export interface MatterProcessData {
    firmIds: string[];
    nodes: NodeModel.LawConnectNode[];
  }

  export interface MatterFirmId {
    matterId: string;
    firmId: string;
  }

  export interface DocumentProcessData {
    matterIds: string[];
    sharedMatters: MatterFirmId[];
    nodes: NodeModel.LawConnectNode[];
  }

  export interface Firms {
    selected?: NodeModel.LawConnectNode;
    list: { [firmId: string]: NodeModel.LawConnectNode[] };
  }

  /** Share Matter **/
  export interface SharedMatterAndCards {
    matter: MatterDetail;
    cards: MatterCard[];
  }

  export interface SharedMatterDetails {
    matter: MatterDetail;
    cards: MatterCard[];
    correspondences: MatterCorrespondences;
    isSuccess: boolean;
    message: string;
  }

  export interface MatterDetail {
    matterId: string;
    fileNo: string;
    matterType: string;
    description: string;
    firstDescription: string;
    secondDescription: string;
    yourReference: string;
    status: string;
    permissions: string;
    createdDate: Date;
    shared: Date;
    modifiedDate: Date;
    userAccessLevels: UserAccessGroup[];
  }

  export enum SharedMatterAccessType {
    Read = 'r',
    Write = 'w',
    NoAccess = ''
  }

  export interface UserAccessGroup {
    name: string;
    access: SharedMatterAccessType;
    description?: string;
  }

  export interface MatterCorrespondences {
    parent: MatterCorrespondences;
    id: string;
    name: string;
    documents: string[];
    fullDocuments: Doc[];
    folders: MatterCorrespondences[];
  }

  export interface Doc {
    id: string;
    type: CorrespondenceType;
    toFrom: string;
    name: string;
    createDate: Date;
    userId: string;
    staffInitials: string;
    staffName: string;
    version: number;
    latestVersion: string;
    ext: string;
    deleted: boolean;
    attachments: DocAttachment[];
    orderDate: Date;
    orderId: string;
    orderBy: string;
    availableOnline: boolean;
    url: string;
    status: string;
    dateCompleted: Date;
    transferMode: TransferMode;
    iconClass: string;
    iconTooltip: string;
    pin: string;
    desktopOnly: boolean;
    deleteCode?: number;
    previewUrl?: string; // docs-api pdf version url
    isDeletable?: boolean;
    currentVersionId: string;
  }

  export interface MatterCard {
    description: string;
    reference: string;
    name: string;
    cardShortName?: string;
    persons?: PersonSchema[];
  }

  export interface PersonSchema {
    id: string;
    lastName: string;
    firstName: string;
    phone: string;
    email: string;
  }

  export enum CorrespondenceType {
    Document = 0,
    Comment = 1,
    VoiceMemo = 2
  }

  export enum TransferMode {
    Closed = 'Closed',
    Received = 'Received',
    Sent = 'Sent',
    Unknown = ''
  }
  /** -- Share Matter -- END **/
}
