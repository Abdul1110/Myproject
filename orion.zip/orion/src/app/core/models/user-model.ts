export class UserModel {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  initials: string;
  userType: UserType;
  documentEncryptionEnabled: boolean;
  documentEncryptionPassword: string;
  auth0Profile: any;
  leapCloudId: string;
  creationDate: string;
  lastLogin: string;
}

export enum UserType {
  staff = 1,
  customer = 2
}
