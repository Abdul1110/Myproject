// angular
import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

// libs
import { CacheModule } from '@ngx-cache/core';
import { ToastrModule } from 'ngx-toastr';

// local
import { Angulartics2Module, Angulartics2Settings } from 'angulartics2';
// import { ToastrModule } from 'ngx-toastr';
import { coreServices } from './services';
import { coreComponents } from './components';
import { NGXS_PLUGINS } from '@ngxs/store';
import { logoutPlugin, errorNotificationPlugin, successNotificationPlugin } from './store/app.plugins';
import { HttpHeaderInterceptor } from './interceptors';
import { AppActionService } from './services/lawconnect/app.action.service';

@NgModule({
  imports: [
    ToastrModule.forRoot(),
    Angulartics2Module.forRoot(<Angulartics2Settings>{
      pageTracking: {
        clearIds: false,
        clearQueryParams: false
      }
    }),
    CacheModule.forRoot()
  ],
  exports: [...coreComponents],
  declarations: [...coreComponents],
  providers: [
    ...coreServices,
    AppActionService,
    {
      provide: NGXS_PLUGINS,
      useValue: logoutPlugin,
      multi: true
    },
    {
      provide: NGXS_PLUGINS,
      useValue: errorNotificationPlugin,
      multi: true
    },
    {
      provide: NGXS_PLUGINS,
      useValue: successNotificationPlugin,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpHeaderInterceptor,
      multi: true
    }
  ]
})
export class CoreModule {
  static forRoot(configuredProviders: Array<any>): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: configuredProviders
    };
  }

  constructor(
    @Optional()
    @SkipSelf()
    parentModule: CoreModule
  ) {
    if (parentModule) {
      throw new Error('CoreModule already loaded; import in root module only.');
    }
  }
}
