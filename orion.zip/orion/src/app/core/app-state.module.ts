import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxsModule } from '@ngxs/store';
import { AppState } from './store/states';

@NgModule({
  imports: [CommonModule, NgxsModule.forFeature([AppState])],
  declarations: [],
  providers: []
})
export class AppStateModule {}
