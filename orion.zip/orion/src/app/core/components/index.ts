import { ThemeComponent } from './theme.component';

export * from './theme.component';

export const coreComponents = [ThemeComponent];
