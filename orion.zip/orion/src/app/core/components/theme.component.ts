import {
  Component,
  ViewEncapsulation,
  Renderer2,
  Inject,
  Input,
  OnChanges,
  SimpleChanges,
  Optional,
  Output,
  EventEmitter
} from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Store } from '@ngxs/store';
import { StandardModel, BrowserService } from '@leap/lyra-design';
import { throwError } from 'rxjs';
import { take, delay, map, catchError } from 'rxjs/operators';

import { environment } from '@env/environment';
import { ThemeService } from '../services';
import { SetAppTheme, SetSharePreview } from '../store/actions';

@Component({
  selector: 'sc-theme',
  template: '<ng-content></ng-content>',
  encapsulation: ViewEncapsulation.None,
  host: {
    '[class.has-custom-theme]': 'hasCustomTheme'
  }
})
export class ThemeComponent implements OnChanges {
  @Input('firm-name') firmName: string;
  @Output('error') error = new EventEmitter<string>();
  @Output('loading') loading = new EventEmitter<boolean>();

  hasCustomTheme = true;

  constructor(
    @Inject(DOCUMENT) private docElement: any,
    @Optional() private store: Store,
    private renderer: Renderer2,
    private themeSvc: ThemeService,
    private browserSvc: BrowserService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (this.browserSvc.isServer) {
      return;
    }

    if (this.docElement.location.pathname.indexOf('/preview/') >= 0) {
      return;
    }

    const shareQueries = this.docElement.location.search;
    const sharePath = this.docElement.location.pathname;
    const sharePathMatch = sharePath ? !!(sharePath.indexOf('/nodes/') !== -1) : false;
    const shareQueryMatchViewer = shareQueries ? !!(shareQueries.toLowerCase().indexOf('viewer=') !== -1) : false;
    const shareQueryMatchShareTo = shareQueries ? !!(shareQueries.toLowerCase().indexOf('sharedto=') !== -1) : false;
    const eSignatureRequestQueryMatch = shareQueries
      ? !!(
          shareQueries.toLowerCase().indexOf('userid=') !== -1 &&
          shareQueries.toLowerCase().indexOf('requestid=') !== -1
        )
      : false;

    if (eSignatureRequestQueryMatch) {
      const { userId, requestId } = this.extractQueries(shareQueries);

      this.getEsignaturePreviewAndThemeDetails(this.firmName, userId, requestId);
      return;
    }

    if ((shareQueryMatchViewer || shareQueryMatchShareTo) && sharePathMatch) {
      const { sharedTo, sharedto, userId, requestId, documentId } = this.extractQueries(shareQueries);
      const { nodeId, eventId, isFolder, folderId } = this.extractSharePath(sharePath);

      this.getShareDocOrFolderAndThemeDetails(
        this.firmName,
        sharedTo || sharedto,
        nodeId,
        eventId,
        isFolder == 'true',
        userId,
        requestId,
        folderId,
        documentId
      );
      return;
    }

    const shareLoginKeys = ['isMatterShared', 'nodeId'];
    const queries = this.docElement.location.search;
    if (queries && shareLoginKeys.filter(y => queries.indexOf(y) !== -1).length === 2) {
      const { nodeId, eventId, sharedTo, userId, requestId } = this.extractQueries(queries);

      this.getShareMatterAndThemeDetails(this.firmName, sharedTo, nodeId, eventId, userId, requestId);

      return;
    }

    const shareApp =
      sharePath && !sharePath.includes('matters/') && sharePath.includes('apps/') && sharePath.includes('shares/');
    if (shareApp) {
      const { sharedToEmail } = this.extractQueries(queries);
      const { appId, shareId } = this.extractSharePath(sharePath);

      this.getShareAppAndThemeDetails(this.firmName, sharedToEmail, appId, shareId);
      return;
    }

    if (changes && changes['firmName']) {
      this.subscribeToAppTheme();
    }
  }

  private extractQueries(val: string): { [key: string]: string } {
    const query = val.replace('?', '');
    const params = query.split('&');
    const queryParams = params.map(r => {
      const x = r.split('=');
      return { [x[0]]: x[1] };
    });

    return queryParams.reduce((x, y) => Object.assign({}, x, y));
  }

  private extractSharePath(val: string): { [key: string]: string } {
    const pathname = val.replace('/', '');
    const pp = Array.of(...pathname.split('/'));
    const nodesIndex = pp.findIndex(x => x === 'nodes');
    const eventIndex = pp.findIndex(y => y === 'event');
    const folderIndex = pp.findIndex(y => y === 'folders');
    const appIdIndex = pp.findIndex(y => y === 'apps');
    const shareIdIndex = pp.findIndex(y => y === 'shares');

    return {
      nodeId: pp[nodesIndex + 1],
      eventId: eventIndex !== -1 ? pp[eventIndex + 1] : undefined,
      isFolder: folderIndex !== -1 ? 'true' : 'false',
      folderId: folderIndex !== -1 ? pp[folderIndex + 1] : undefined,
      appId: appIdIndex !== -1 ? pp[appIdIndex + 1] : undefined,
      shareId: shareIdIndex !== -1 ? pp[shareIdIndex + 1] : undefined
    };
  }

  private subscribeToAppTheme(): void {
    this.themeSvc
      .themes(this.firmName)
      .pipe(
        take(1),
        delay(100),
        map(setting => {
          if (!setting.containsSetting) {
            // if it subdomain is not equals to v2, then redirect to v2.
            if (this.browserSvc.isBrowser) {
              const v2Endpoint = environment.appSettings.orionEndpoint || '';
              const origin = this.browserSvc.window.location.origin;
              if (v2Endpoint.indexOf(origin) === -1) {
                this.browserSvc.window.location = v2Endpoint;
                return;
              }
            }
            return;
          }

          this.updateAppTheme(setting);
        }),
        catchError(err => {
          return throwError(err);
        })
      )
      .subscribe();
  }

  private getEsignaturePreviewAndThemeDetails(firmName: string, userId: string, requestId: string): void {
    this.getPreviewAndThemeDetails({
      firmName,
      email: undefined,
      nodeId: undefined,
      eventId: undefined,
      isMatterShared: false,
      userId,
      requestId,
      isFolder: false,
      folderId: undefined,
      documentId: undefined,
      appId: undefined,
      shareId: undefined
    });
  }

  private getShareDocOrFolderAndThemeDetails(
    firmName: string,
    email: string,
    nodeId: string,
    eventId: string,
    isFolder: boolean,
    userId: string,
    requestId: string,
    folderId: string,
    documentId: string
  ): void {
    this.getPreviewAndThemeDetails({
      firmName,
      email: email || 'none',
      nodeId,
      eventId,
      isMatterShared: false,
      userId,
      requestId,
      isFolder,
      folderId,
      documentId,
      appId: undefined,
      shareId: undefined
    });
  }

  private getShareMatterAndThemeDetails(
    firmName: string,
    email: string,
    nodeId: string,
    eventId: string,
    userId: string,
    requestId: string
  ): void {
    this.getPreviewAndThemeDetails({
      firmName,
      email: email || 'none',
      nodeId,
      eventId,
      isMatterShared: true,
      userId,
      requestId,
      isFolder: false,
      folderId: undefined,
      documentId: undefined,
      appId: undefined,
      shareId: undefined
    });
  }

  private getShareAppAndThemeDetails(firmName: string, email: string, appId: string, shareId: string): void {
    this.getPreviewAndThemeDetails({
      firmName,
      email: email || 'none',
      nodeId: undefined,
      eventId: undefined,
      isMatterShared: false,
      userId: undefined,
      requestId: undefined,
      isFolder: false,
      folderId: undefined,
      documentId: undefined,
      appId,
      shareId
    });
  }

  private getPreviewAndThemeDetails(data: {
    firmName: string;
    email: string;
    nodeId: string;
    eventId: string;
    isMatterShared: boolean;
    userId: string;
    requestId: string;
    isFolder: boolean;
    folderId: string;
    documentId: string;
    appId: string;
    shareId: string;
  }): void {
    const {
      firmName,
      email,
      nodeId,
      eventId,
      userId,
      requestId,
      isFolder,
      folderId,
      documentId,
      appId,
      shareId,
      isMatterShared
    } = data;

    this.loading.emit(true);

    this.themeSvc
      .shareInfo(firmName, email, nodeId, eventId, userId, requestId, isFolder, folderId, documentId, appId, shareId)
      .pipe(
        take(1),
        delay(100),
        map(setting => {
          this.loading.emit(false);

          let hasTheme = false;
          if (setting.theme && setting.theme.containsSetting) {
            hasTheme = true;
            this.updateAppTheme(setting.theme);
          }

          // if it subdomain is not equals to v2, then redirect to v2.
          if (!hasTheme && this.browserSvc.isBrowser) {
            const v2Endpoint = environment.appSettings.orionEndpoint || '';
            const origin = this.browserSvc.window.location.origin;
            if (v2Endpoint.indexOf(origin) === -1) {
              this.browserSvc.window.location = v2Endpoint;
              return;
            }
          }

          const sharePreviewInfo = setting.share
            ? Object.assign({}, { ...setting.share, id: nodeId, isMatterShared })
            : undefined;
          this.store.dispatch(new SetSharePreview(sharePreviewInfo));
        }),
        catchError(err => {
          const error = this.browserSvc.getStandardError(err);
          this.loading.emit(false);
          this.error.emit(error.message);
          return throwError(err);
        })
      )
      .subscribe();
  }

  private updateAppTheme(setting: StandardModel.ContainerSetting): void {
    this.store.dispatch(new SetAppTheme(setting));

    const colors = StandardModel.Helper.themeSettingsMapToColors(setting.themeSetting);

    const el = this.renderer.createElement('style');
    el.setAttribute('type', 'text/css');
    el.innerHTML = colors;

    this.renderer.appendChild(this.docElement.head, el);

    this.docElement.body.classList.add('has-custom-theme');
  }
}
