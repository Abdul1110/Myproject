import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import * as SentryBrowser from '@sentry/browser';
import { BrowserService } from '@leap/lyra-design';
import { Store } from '@ngxs/store';
import { AppState } from '../store/states';

@Injectable()
export class HttpHeaderInterceptor implements HttpInterceptor {
  constructor(private browserSvc: BrowserService, private store: Store) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!request.headers.has('Cache-Control')) {
      request = request.clone({
        headers: new HttpHeaders({
          'Cache-Control': 'max-age=0'
        })
      });
    }

    return next.handle(request).pipe(
      catchError(err => {
        const skipStatus = [401, 403];
        const isActiveUserAnnotationApi =
          err &&
          (err.url.includes('document/activeuserindocument') || err.url.includes('document/activeuserheartbeat')) &&
          [400, 404].includes(err.status);
        const excludeAnnotationApi = 'document/annotations'; // because it may due to permission revoke from sharing.

        err && !skipStatus.includes(err.status) && !isActiveUserAnnotationApi && SentryBrowser.captureException(err);

        if (err && skipStatus.includes(err.status) && this.browserSvc.isBrowser) {
          const authenticated = this.store.selectSnapshot(AppState.getAppAuthentication);
          const isOriginFromAnnotationApi = err.url.includes(excludeAnnotationApi);

          authenticated &&
            !isOriginFromAnnotationApi &&
            setTimeout(() => {
              const pathname = this.browserSvc.window.location.pathname;
              this.browserSvc.window.location = pathname.includes('account')
                ? pathname
                : `account/signin?returnTo=${encodeURIComponent(pathname)}`;
            }, 0);

          isOriginFromAnnotationApi &&
            setTimeout(() => {
              const pathname = this.browserSvc.window.location.pathname;
              this.browserSvc.window.location = pathname.includes('/preview')
                ? pathname.replace('/preview', '')
                : pathname;
            }, 0);
        }
        return throwError(err);
      })
    );
  }
}
