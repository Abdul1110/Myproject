// angular
import { BrowserTransferStateModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TransferHttpCacheModule } from '@nguniversal/common';

// libs
import { CACHE } from '@ngx-cache/core';
import { BrowserCacheModule, LocalStorageCacheService } from '@ngx-cache/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// local
import { AppComponent } from './app.component';
import { AppModule } from '@app/app.module';
import { AppState } from './core/store/states';
import { NgxsModule } from '@ngxs/store';
import { NgxsLoggerPluginModule } from '@ngxs/logger-plugin';
import { NgxsReduxDevtoolsPluginModule } from '@ngxs/devtools-plugin';
import { environment } from '@env/environment';
import { ToastrModule } from 'ngx-toastr';
import { ToastComponent } from './shared/components/toast/toast.component';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    BrowserTransferStateModule,
    BrowserCacheModule.forRoot([
      {
        provide: CACHE,
        useClass: LocalStorageCacheService
      }
    ]),
    HttpClientModule,
    TransferHttpCacheModule,
    NgxsModule.forRoot([AppState], { developmentMode: !environment.production }),
    NgxsLoggerPluginModule.forRoot({ disabled: environment.production }),
    NgxsReduxDevtoolsPluginModule.forRoot({ name: 'Lyra NGXS', disabled: environment.production }),
    AppModule,
    ToastrModule.forRoot({
      toastComponent: ToastComponent,
      timeOut: 5000,
      extendedTimeOut: 3000, // time to close after a user hovers over toast
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
      closeButton: true,
      tapToDismiss: true,
      onActivateTick: true
    }),
    DeviceDetectorModule.forRoot()
  ],
  providers: [BrowserAnimationsModule],
  bootstrap: [AppComponent]
})
export class AppBrowserModule {}
