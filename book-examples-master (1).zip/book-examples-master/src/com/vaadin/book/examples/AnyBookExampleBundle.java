package com.vaadin.book.examples;

import java.io.Serializable;

public interface AnyBookExampleBundle extends Serializable {

}
