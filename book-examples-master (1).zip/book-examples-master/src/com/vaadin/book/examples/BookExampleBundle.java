package com.vaadin.book.examples;

public interface BookExampleBundle extends AnyBookExampleBundle {
    public void init (String context);
}
